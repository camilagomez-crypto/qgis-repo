import re
import time
from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QFormLayout, QHBoxLayout,
                                  QGroupBox, QLineEdit, QProgressBar, QPushButton,
                                  QLabel, QMessageBox, QTabWidget, QWidget)
from qgis.core import (QgsProject, QgsVectorLayer, QgsField, QgsFeature,
                        QgsSpatialIndex, QgsMapLayerProxyModel, QgsWkbTypes,
                        QgsFeatureRequest, QgsRectangle, QgsFields,
                        QgsGeometry, QgsPointXY)
from qgis.gui import QgsMapLayerComboBox, QgsFieldComboBox

EXCLUSION_PREFIXES_DEFAULT = ("BRR,CDE,CND,CJR,PQD,VDA,HCD,MTF,URD,URB,KDX,"
                               "SMA,AGP,MZA,BQU,TOR,APT,LTE,PAQ,ZNV,CAN,POL,SN")

# Tipos de vía reconocidos al partir una dirección completa
TIPOS_VIA = ['AC', 'AK', 'AV', 'BL', 'CL', 'CR', 'KR', 'TV', 'DG', 'CQ', 'PJ', 'VIA',
             'AUTOP', 'CARRERA', 'CALLE', 'AVENIDA', 'TRANSVERSAL', 'DIAGONAL',
             'CIRCUNVALAR', 'PASAJE']
_PAT_TIPO_VIA = re.compile(r'^(?:' + '|'.join(sorted(set(TIPOS_VIA), key=len, reverse=True)) + r')$')


def partir_direccion(direccion):
    """Parte una dirección completa en (via_principal, via_secundaria).

    Ej: 'KR 27 A CL 72 J 58' -> ('KR 27 A', 'CL 72 J')
        'CL 3 B KR 60 A BIS 47' -> ('CL 3 B', 'KR 60 A BIS')
    Devuelve (None, None) si no se reconocen dos tipos de vía.
    """
    tokens = ' '.join(str(direccion or '').upper().split()).split()
    posiciones = [i for i, t in enumerate(tokens) if _PAT_TIPO_VIA.match(t)]
    if len(posiciones) < 2:
        return None, None
    ini_prin, ini_sec = posiciones[0], posiciones[1]
    via_prin = ' '.join(tokens[ini_prin:ini_sec])
    resto = tokens[ini_sec:]
    # La placa es el último token numérico; lo anterior es la vía secundaria
    # (incluyendo sufijos como 'A' o 'BIS', que pertenecen a la vía).
    idx_numericos = [i for i, t in enumerate(resto) if t.isdigit()]
    if len(idx_numericos) < 2:
        return via_prin, ' '.join(resto)
    return via_prin, ' '.join(resto[:idx_numericos[-1]])


class AranasDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Generar arañas catastrales")
        self.setMinimumWidth(440)
        self._build_ui()

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        layout = QVBoxLayout(self)
        form = QFormLayout()

        # --- Predios ---
        self.cb_predios = QgsMapLayerComboBox()
        self.cb_predios.setFilters(QgsMapLayerProxyModel.VectorLayer)
        form.addRow("Capa predios:", self.cb_predios)

        self.cb_predio_id = QgsFieldComboBox()
        form.addRow("   Campo ID:", self.cb_predio_id)

        # Pestañas: campos separados (via_princ/via_sec) o una dirección completa
        self.tabs_via = QTabWidget()

        tab_campos = QWidget()
        form_campos = QFormLayout(tab_campos)
        self.cb_predio_via_prin = QgsFieldComboBox()
        form_campos.addRow("Campo vía principal:", self.cb_predio_via_prin)
        self.cb_predio_via_sec = QgsFieldComboBox()
        form_campos.addRow("Campo vía secundaria:", self.cb_predio_via_sec)
        self.tabs_via.addTab(tab_campos, "Campos separados")

        tab_dir = QWidget()
        form_dir = QFormLayout(tab_dir)
        self.cb_predio_direccion = QgsFieldComboBox()
        form_dir.addRow("Campo dirección:", self.cb_predio_direccion)
        self.lbl_previa_dir = QLabel("—")
        self.lbl_previa_dir.setWordWrap(True)
        form_dir.addRow("Vista previa:", self.lbl_previa_dir)
        btn_previa = QPushButton("Probar con el primer predio")
        btn_previa.clicked.connect(self._previsualizar_direccion)
        form_dir.addRow("", btn_previa)
        self.tabs_via.addTab(tab_dir, "Dirección completa")

        form.addRow("   Vías del predio:", self.tabs_via)

        # --- Malla vial ---
        self.cb_malla = QgsMapLayerComboBox()
        self.cb_malla.setFilters(QgsMapLayerProxyModel.VectorLayer)
        form.addRow("Capa malla vial:", self.cb_malla)

        self.cb_malla_prin = QgsFieldComboBox()
        form.addRow("   Campo principal:", self.cb_malla_prin)
        self.cb_malla_sec = QgsFieldComboBox()
        form.addRow("   Campo generadora:", self.cb_malla_sec)

        # --- Barrios ---
        self.cb_barrios = QgsMapLayerComboBox()
        self.cb_barrios.setFilters(QgsMapLayerProxyModel.VectorLayer)
        form.addRow("Capa barrios:", self.cb_barrios)

        self.cb_barrio_nombre = QgsFieldComboBox()
        form.addRow("   Campo nombre:", self.cb_barrio_nombre)
        self.cb_barrio_validador = QgsFieldComboBox()
        form.addRow("   Campo multiorig:", self.cb_barrio_validador)

        layout.addLayout(form)

        # --- Prefijos de exclusión ---
        grp = QGroupBox("Prefijos de vía a excluir (separados por coma)")
        grp_layout = QVBoxLayout(grp)
        self.txt_prefixes = QLineEdit(EXCLUSION_PREFIXES_DEFAULT)
        grp_layout.addWidget(self.txt_prefixes)
        layout.addWidget(grp)

        radio_form = QFormLayout()
        self.txt_radio_busqueda = QLineEdit("800")
        radio_form.addRow("Radio de búsqueda de vía (m):", self.txt_radio_busqueda)
        self.txt_max_arana = QLineEdit("60")
        radio_form.addRow("Longitud máxima de araña (m):", self.txt_max_arana)
        layout.addLayout(radio_form)

        # Vincular cada combo de campo a su capa correspondiente
        self.cb_predios.layerChanged.connect(self.cb_predio_id.setLayer)
        self.cb_predios.layerChanged.connect(self.cb_predio_via_prin.setLayer)
        self.cb_predios.layerChanged.connect(self.cb_predio_via_sec.setLayer)
        self.cb_predios.layerChanged.connect(self.cb_predio_direccion.setLayer)
        self.cb_malla.layerChanged.connect(self.cb_malla_prin.setLayer)
        self.cb_malla.layerChanged.connect(self.cb_malla_sec.setLayer)
        self.cb_barrios.layerChanged.connect(self.cb_barrio_nombre.setLayer)
        self.cb_barrios.layerChanged.connect(self.cb_barrio_validador.setLayer)

        # Disparo inicial (la capa por defecto ya está puesta al crear los combos)
        self.cb_predio_id.setLayer(self.cb_predios.currentLayer())
        self.cb_predio_via_prin.setLayer(self.cb_predios.currentLayer())
        self.cb_predio_via_sec.setLayer(self.cb_predios.currentLayer())
        self.cb_predio_direccion.setLayer(self.cb_predios.currentLayer())
        self.cb_malla_prin.setLayer(self.cb_malla.currentLayer())
        self.cb_malla_sec.setLayer(self.cb_malla.currentLayer())
        self.cb_barrio_nombre.setLayer(self.cb_barrios.currentLayer())
        self.cb_barrio_validador.setLayer(self.cb_barrios.currentLayer())

        # --- Estado / progreso ---
        self.lbl_status = QLabel("Selecciona los predios en el mapa y pulsa Ejecutar.")
        layout.addWidget(self.lbl_status)
        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximum(100)
        layout.addWidget(self.progress_bar)

        # --- Botones ---
        btn_layout = QHBoxLayout()
        self.btn_run = QPushButton("Ejecutar")
        self.btn_run.clicked.connect(self._ejecutar)
        btn_layout.addWidget(self.btn_run)
        self.btn_close = QPushButton("Cerrar")
        self.btn_close.clicked.connect(self.close)
        btn_layout.addWidget(self.btn_close)
        layout.addLayout(btn_layout)

    def _previsualizar_direccion(self):
        """Muestra cómo se parte la dirección de un predio de ejemplo."""
        capa = self.cb_predios.currentLayer()
        campo = self.cb_predio_direccion.currentField()
        if not capa or not campo:
            self.lbl_previa_dir.setText("Selecciona la capa y el campo de dirección.")
            return
        feats = list(capa.selectedFeatures()) or list(capa.getFeatures())
        ejemplos = []
        for f in feats[:5]:
            d = f[campo]
            p, s = partir_direccion(d)
            if p is None:
                ejemplos.append(f"{d}  ->  NO RECONOCIDA")
            else:
                ejemplos.append(f"{d}  ->  principal='{p}'  secundaria='{s}'")
        self.lbl_previa_dir.setText("\n".join(ejemplos) if ejemplos else "Capa sin registros.")

    def _set_status(self, texto, valor_progreso=None):
        self.lbl_status.setText(texto)
        if valor_progreso is not None:
            self.progress_bar.setValue(valor_progreso)
        QCoreApplication.processEvents()

    # ------------------------------------------------------------ Ejecutar
    def _ejecutar(self):
        predios_layer = self.cb_predios.currentLayer()
        malla_layer = self.cb_malla.currentLayer()
        barrios_layer = self.cb_barrios.currentLayer()

        if not predios_layer or not malla_layer or not barrios_layer:
            QMessageBox.warning(self, "Faltan capas", "Selecciona las tres capas (predios, malla vial, barrios).")
            return

        predios_seleccionados = list(predios_layer.selectedFeatures())
        if not predios_seleccionados:
            QMessageBox.warning(self, "Sin selección", "No hay predios seleccionados en la capa de predios.")
            return

        predio_id_field = self.cb_predio_id.currentField()
        malla_via_prin_field = self.cb_malla_prin.currentField()
        malla_via_sec_field = self.cb_malla_sec.currentField()
        barrio_nombre_field = self.cb_barrio_nombre.currentField()
        barrio_validador_field = self.cb_barrio_validador.currentField()

        # Modo de vías: pestaña 0 = campos separados, pestaña 1 = dirección completa
        usar_direccion = (self.tabs_via.currentIndex() == 1)
        if usar_direccion:
            predio_direccion_field = self.cb_predio_direccion.currentField()
            predio_via_prin_field = predio_via_sec_field = None
            if not predio_direccion_field:
                QMessageBox.warning(self, "Falta campo", "Selecciona el campo de dirección.")
                return
        else:
            predio_direccion_field = None
            predio_via_prin_field = self.cb_predio_via_prin.currentField()
            predio_via_sec_field = self.cb_predio_via_sec.currentField()
            if not predio_via_prin_field or not predio_via_sec_field:
                QMessageBox.warning(self, "Faltan campos", "Selecciona los campos de vía principal y secundaria.")
                return

        if not all([predio_id_field, malla_via_prin_field, malla_via_sec_field,
                    barrio_nombre_field, barrio_validador_field]):
            QMessageBox.warning(self, "Faltan campos", "Revisa que todos los campos estén seleccionados.")
            return

        exclusion_prefixes = tuple(p.strip().upper() for p in self.txt_prefixes.text().split(",") if p.strip())

        try:
            radio_busqueda = float(self.txt_radio_busqueda.text())
        except ValueError:
            QMessageBox.warning(self, "Radio inválido", "El radio de búsqueda debe ser un número.")
            return

        try:
            max_arana = float(self.txt_max_arana.text())
        except ValueError:
            QMessageBox.warning(self, "Longitud inválida", "La longitud máxima de araña debe ser un número.")
            return

        self.btn_run.setEnabled(False)
        self.btn_close.setEnabled(False)
        try:
            self._procesar(
                predios_layer, malla_layer, barrios_layer, predios_seleccionados,
                predio_id_field, predio_via_prin_field, predio_via_sec_field,
                malla_via_prin_field, malla_via_sec_field,
                barrio_nombre_field, barrio_validador_field,
                exclusion_prefixes, radio_busqueda, max_arana,
                predio_direccion_field
            )
            QMessageBox.information(self, "Listo",
                                     "Proceso finalizado. Revisa las capas 'aranas_validadas_final' "
                                     "y 'predios_sin_aranas'.\n\n" + getattr(self, "ultimo_diagnostico", ""))
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error durante la ejecución:\n{e}")
        finally:
            self.btn_run.setEnabled(True)
            self.btn_close.setEnabled(True)

    # ------------------------------------------------------------- Proceso
    def _procesar(self, predios_layer, malla_layer, barrios_layer, predios_seleccionados,
                  predio_id_field, predio_via_prin_field, predio_via_sec_field,
                  malla_via_prin_field, malla_via_sec_field,
                  barrio_nombre_field, barrio_validador_field,
                  exclusion_prefixes, radio_busqueda, max_arana,
                  predio_direccion_field=None):

        proyecto = QgsProject.instance()
        total = len(predios_seleccionados)

        # --- Medición en METROS reales, sin importar el CRS de la capa ---
        # La capa está en EPSG:4326 (grados), así que .length()/.distance() dan grados.
        # Medimos longitudes reales con QgsDistanceArea (elipsoide) y convertimos los
        # umbrales de metros a grados para los filtros de bounding box.
        from qgis.core import QgsDistanceArea, QgsCoordinateReferenceSystem, QgsPointXY
        crs_capa = predios_layer.crs()
        medidor = QgsDistanceArea()
        medidor.setSourceCrs(crs_capa, proyecto.transformContext())
        medidor.setEllipsoid(proyecto.ellipsoid() or 'WGS84')

        def longitud_m(geom):
            """Longitud real de una geometría lineal, en metros."""
            try:
                return medidor.measureLength(geom)
            except Exception:
                return geom.length()

        # Factor grados->metros aproximado en la latitud del área de trabajo, para
        # convertir los umbrales de metros a grados en los grow() de bounding box.
        if crs_capa.isGeographic():
            c = predios_layer.extent().center()
            import math
            m_por_grado_lat = 111320.0
            m_por_grado_lon = 111320.0 * max(0.1, math.cos(math.radians(c.y())))
            grados_por_m = 1.0 / min(m_por_grado_lat, m_por_grado_lon)
        else:
            grados_por_m = 1.0  # ya está en metros

        def a_unidades(metros):
            """Convierte un umbral en metros a las unidades del CRS (grados si es geográfico)."""
            return metros * grados_por_m

        # --- Diagnóstico de tiempos (para saber dónde se va el tiempo) ---
        t_barrio_total = 0.0
        t_malla_busq_total = 0.0
        t_shortest_total = 0.0
        n_fallback = 0
        n_candidatos_total = 0

        # --- FASE 0: PRE-CÁLCULO (solo sobre los predios seleccionados) ---
        self._set_status("Fase 0: indexando barrios y malla vial...", 0)
        t0 = time.perf_counter()
        req_barrios = QgsFeatureRequest().setSubsetOfAttributes(
            [barrios_layer.fields().indexOf(barrio_nombre_field),
             barrios_layer.fields().indexOf(barrio_validador_field)])
        barrios_cache = {f.id(): f for f in barrios_layer.getFeatures(req_barrios)}
        idx_barrios = QgsSpatialIndex()
        for f in barrios_cache.values():
            idx_barrios.addFeature(f)
        t_carga_barrios = time.perf_counter() - t0

        predio_info_lookup = {}
        for i, predio_feat in enumerate(predios_seleccionados):
            if i % 200 == 0:
                self._set_status(f"Fase 0: analizando barrio de predios ({i}/{total})...",
                                  int((i / total) * 30))
            barrio_del_predio, multiorig_estado = "NINGUNO", "NO"
            t0 = time.perf_counter()
            for id_barrio in idx_barrios.intersects(predio_feat.geometry().boundingBox()):
                barrio_candidato = barrios_cache[id_barrio]
                if barrio_candidato.geometry().intersects(predio_feat.geometry()):
                    barrio_del_predio = barrio_candidato[barrio_nombre_field]
                    multiorig_estado = str(barrio_candidato[barrio_validador_field] or 'NO').upper().strip()
                    break
            t_barrio_total += time.perf_counter() - t0
            predio_info_lookup[predio_feat.id()] = {'barrio': barrio_del_predio, 'multiorig': multiorig_estado}

        t0 = time.perf_counter()
        idx_malla = QgsSpatialIndex()
        malla_data = {}  # id -> {'geom': geometría, 'key': (prin, sec)}
        req_malla = QgsFeatureRequest().setSubsetOfAttributes(
            [malla_layer.fields().indexOf(malla_via_prin_field),
             malla_layer.fields().indexOf(malla_via_sec_field)])
        def norm(v):
            """Normaliza un nombre de vía: mayúsculas, sin espacios extra."""
            return ' '.join(str(v or '').upper().split())

        def vias_del_predio(feat):
            """Vías (principal, secundaria) de un predio, según el modo elegido:
            campos separados, o partiendo la dirección completa."""
            if predio_direccion_field:
                p, s = partir_direccion(feat[predio_direccion_field])
                return norm(p), norm(s)
            return norm(feat[predio_via_prin_field]), norm(feat[predio_via_sec_field])

        n_malla_descartada = 0
        for via_feat in malla_layer.getFeatures(req_malla):
            a = norm(via_feat[malla_via_prin_field])
            b = norm(via_feat[malla_via_sec_field])
            if a:
                g = via_feat.geometry()
                # Descartar tramos degenerados (nodos/vértices sueltos de longitud casi
                # nula): la araña debe llegar a la LÍNEA de la vía, no a un punto de esquina.
                if g is None or g.isEmpty() or g.length() <= 0:
                    n_malla_descartada += 1
                    continue
                # Se guardan ambos órdenes: en algunos registros principal/generadora
                # vienen invertidos respecto a via_princ/via_sec del predio.
                malla_data[via_feat.id()] = {'geom': g,
                                              'key': (a, b), 'key_inv': (b, a)}
                idx_malla.addFeature(via_feat)
        print(f"MALLA: {len(malla_data)} tramos cargados, {n_malla_descartada} descartados por degenerados")
        t_carga_malla = time.perf_counter() - t0

        # --- FASE I: ARAÑAS (solo predios seleccionados) ---
        self._set_status("Fase I: creando arañas...", 35)
        capa_aranas_temp = QgsVectorLayer(f"LineString?crs={predios_layer.crs().authid()}", "temp_aranas", "memory")
        prov_aranas = capa_aranas_temp.dataProvider()
        prov_aranas.addAttributes([QgsField('id_predio_origen_fid', QVariant.Int),
                                    QgsField('via_lejos_m', QVariant.Double),
                                    QgsField('via_destino_id', QVariant.Int)])
        capa_aranas_temp.updateFields()

        capa_aranas_temp.startEditing()
        motivo_rechazo = {}
        for i, predio_feat in enumerate(predios_seleccionados):
            if i % 200 == 0:
                self._set_status(f"Fase I: generando arañas ({i}/{total})...",
                                  35 + int((i / total) * 30))

            prin, sec = vias_del_predio(predio_feat)

            if prin.startswith(exclusion_prefixes):
                continue

            lookup_key = (prin, sec)

            predio_geom = predio_feat.geometry()
            bbox_busq = QgsRectangle(predio_geom.boundingBox())
            # El radio de búsqueda es al menos max_arana: no tiene sentido encontrar
            # una vía a 200m si la araña máxima permitida es 60m.
            radio_efectivo = max(radio_busqueda, max_arana)
            bbox_busq.grow(a_unidades(radio_efectivo))

            t0 = time.perf_counter()
            # REGLA: solo match EXACTO (principal + generadora = via_princ + via_sec).
            # Si no existe un tramo con esa nomenclatura, NO se genera araña: el predio
            # queda marcado SIN_VIA_CON_ESE_NOMBRE para revisión. No se inventa un
            # destino alternativo (p.ej. un predio con generadora 'KR 60 A BIS' que no
            # existe en la malla no debe conectarse a 'KR 57 C' solo por cercanía).
            vias_a_buscar = [(cid, malla_data[cid]['geom']) for cid in idx_malla.intersects(bbox_busq)
                              if malla_data[cid]['key'] == lookup_key
                              or malla_data[cid]['key_inv'] == lookup_key]

            predio_info = predio_info_lookup[predio_feat.id()]
            if predio_info['multiorig'] == 'SI':
                lim = a_unidades(500)
                vias_a_buscar = [(cid, g) for cid, g in vias_a_buscar if g.distance(predio_geom) < lim]
            t_malla_busq_total += time.perf_counter() - t0
            n_candidatos_total += len(vias_a_buscar)

            t0 = time.perf_counter()
            if vias_a_buscar:
                # Entre los tramos con match exacto, la araña más corta.
                # (Los cruces se detectan después, en la validación de Fase II.)
                mejor_arana = None
                mejor_dist = float('inf')
                mejor_via_id = None
                for cid, via_geom in vias_a_buscar:
                    arana_cand = predio_geom.shortestLine(via_geom)
                    if arana_cand is None or arana_cand.isEmpty():
                        continue
                    long_cand = longitud_m(arana_cand)
                    if long_cand < mejor_dist:
                        mejor_dist, mejor_arana, mejor_via_id = long_cand, arana_cand, cid

                if mejor_arana and not mejor_arana.isEmpty():
                    # La araña se genera SIEMPRE. Si la vía quedó más lejos que
                    # max_arana, se marca la distancia para etiquetarla como
                    # VIA_LEJOS en la capa final (pero igual se dibuja).
                    via_lejos = mejor_dist if mejor_dist > max_arana else None
                    if via_lejos is not None:
                        motivo_rechazo[predio_feat.id()] = f"VIA_LEJOS_{mejor_dist:.0f}m"
                    out_feat = QgsFeature()
                    out_feat.setGeometry(mejor_arana)
                    out_feat.setAttributes([predio_feat.id(), via_lejos, mejor_via_id])
                    prov_aranas.addFeature(out_feat)
            else:
                # No hay ninguna vía con ese nombre dentro del radio
                motivo_rechazo[predio_feat.id()] = "SIN_VIA_CON_ESE_NOMBRE"
            t_shortest_total += time.perf_counter() - t0

        capa_aranas_temp.commitChanges()
        print(f"FASE I: {capa_aranas_temp.featureCount()} arañas generadas de {total} predios")

        # --- FASE II: VALIDACIÓN (cruces contra todos los predios de la capa) ---
        t0_fase2 = time.perf_counter()
        self._set_status("Fase II: validando geometría...", 70)
        nombre_capa_final = 'aranas_validadas_final'
        for lyr in proyecto.mapLayers().values():
            if lyr.name() == nombre_capa_final:
                proyecto.removeMapLayer(lyr.id())

        capa_final = QgsVectorLayer(f"LineString?crs={predios_layer.crs().authid()}", nombre_capa_final, "memory")
        prov_final = capa_final.dataProvider()
        prov_final.addAttributes([QgsField('id_predio', QVariant.String), QgsField('obs', QVariant.String)])
        capa_final.updateFields()

        idx_aranas = QgsSpatialIndex(capa_aranas_temp.getFeatures())
        predios_sel_by_id = {f.id(): f for f in predios_seleccionados}

        # Solo se cargan e indexan los predios cercanos a las arañas generadas
        # (antes se indexaba TODA la capa de predios, aunque solo hubiera unas
        # pocas arañas — esto es lo que más se demoraba en capas catastrales grandes).
        idx_predios = QgsSpatialIndex()
        predios_geom_cache = {}

        # Arañas "sombra" de predios vecinos NO seleccionados — solo en memoria,
        # nunca se exportan, solo sirven para detectar cruces con ellas.
        idx_vecinas = QgsSpatialIndex()
        vecinas_geom_cache = {}
        n_vecinas = 0
        _next_vid = [0]

        extent_predios_buscados = set()
        if predio_direccion_field:
            idx_campos_via = [predios_layer.fields().indexOf(predio_direccion_field)]
        else:
            idx_campos_via = [predios_layer.fields().indexOf(predio_via_prin_field),
                              predios_layer.fields().indexOf(predio_via_sec_field)]
        total_aranas = capa_aranas_temp.featureCount() or 1

        MARGEN_VECINO = 30  # metros alrededor del predio de origen para buscar vecinos contiguos
        MARGEN_VECINO_U = a_unidades(MARGEN_VECINO)  # mismo margen en unidades del CRS
        LIMITE_VECINAS = 500  # tope de seguridad para no colgarse nunca
        limite_alcanzado = False
        n_vecinos_sin_via = [0]
        for i_arana, arana_feat in enumerate(capa_aranas_temp.getFeatures()):
            if limite_alcanzado:
                break
            if i_arana % 20 == 0:
                self._set_status(f"Fase II: buscando predios vecinos ({i_arana}/{total_aranas})...",
                                  70 + int((i_arana / total_aranas) * 12))
            fid_orig = arana_feat['id_predio_origen_fid']
            p_orig = predios_sel_by_id.get(fid_orig)
            if p_orig is None:
                continue
            geom_arana = arana_feat.geometry()
            geom_orig = p_orig.geometry()
            # Predios a lo largo del TRAZADO de la araña (por donde pasa la línea),
            # con una franja de MARGEN a los lados. Si la araña es corta, es solo su
            # vecindario; si es larga y roza muchos frentes, capta todos esos predios.
            bbox_v = QgsRectangle(geom_arana.boundingBox())
            bbox_v.grow(MARGEN_VECINO_U)
            req_predios = QgsFeatureRequest().setFilterRect(bbox_v).setSubsetOfAttributes(
                idx_campos_via)
            for f in predios_layer.getFeatures(req_predios):
                if f.id() in extent_predios_buscados:
                    continue  # ya se procesó (puede aparecer cerca de más de una araña)
                extent_predios_buscados.add(f.id())

                predios_geom_cache[f.id()] = f.geometry()
                idx_predios.addFeature(f)

                if f.id() in predios_sel_by_id:
                    continue  # ya tiene su araña real, no necesita sombra
                # Solo predios que la araña realmente roza/atraviesa (a <=MARGEN de la línea)
                if f.geometry().distance(geom_arana) > MARGEN_VECINO_U:
                    continue

                prin_v, sec_v = vias_del_predio(f)
                if prin_v.startswith(exclusion_prefixes):
                    continue
                key_v = (prin_v, sec_v)
                bbox_busq_v = QgsRectangle(f.geometry().boundingBox())
                bbox_busq_v.grow(a_unidades(radio_busqueda))
                candidatas_v = [malla_data[cid]['geom'] for cid in idx_malla.intersects(bbox_busq_v)
                                 if malla_data[cid]['key'] == key_v
                                 or malla_data[cid]['key_inv'] == key_v]
                if not candidatas_v:
                    n_vecinos_sin_via[0] += 1
                    continue  # solo para validación: si no hay match exacto, se omite

                via_cercana_v = min(candidatas_v, key=lambda g: g.distance(f.geometry()))
                arana_v = f.geometry().shortestLine(via_cercana_v)
                if arana_v and not arana_v.isEmpty() and longitud_m(arana_v) <= max_arana:
                    vid = _next_vid[0]
                    _next_vid[0] += 1
                    vecinas_geom_cache[vid] = arana_v
                    feat_v = QgsFeature()
                    feat_v.setId(vid)
                    feat_v.setGeometry(arana_v)
                    idx_vecinas.addFeature(feat_v)
                    n_vecinas += 1
                    if n_vecinas >= LIMITE_VECINAS:
                        limite_alcanzado = True
                        break

        capa_final.startEditing()
        ids_con_arana_valida = set()
        ids_cruce_predio = set()
        ids_aranas_cruzan = set()
        ids_cruza_malla = set()
        for i_arana, arana_feat in enumerate(capa_aranas_temp.getFeatures()):
            if i_arana % 20 == 0:
                self._set_status(f"Fase II: validando cruces ({i_arana}/{total_aranas})...",
                                  82 + int((i_arana / total_aranas) * 8))
            geom = arana_feat.geometry()
            fid_orig = arana_feat['id_predio_origen_fid']
            p_orig = predios_sel_by_id.get(fid_orig)

            # Asegurar que TODOS los predios bajo el trazado de la araña estén en el
            # índice (no solo los vecinos a 30m del origen). Si la araña es larga y
            # cruza predios lejanos, se cargan aquí solo para la prueba de cruce.
            bbox_arana = QgsRectangle(geom.boundingBox())
            bbox_arana.grow(a_unidades(1))
            req_bajo_arana = QgsFeatureRequest().setFilterRect(bbox_arana).setSubsetOfAttributes([])
            for f in predios_layer.getFeatures(req_bajo_arana):
                if f.id() not in predios_geom_cache:
                    predios_geom_cache[f.id()] = f.geometry()
                    idx_predios.addFeature(f)

            errores = []
            # La vía quedó más lejos que max_arana (marcado en Fase I)
            via_lejos_val = arana_feat['via_lejos_m']
            if via_lejos_val is not None and str(via_lejos_val) not in ('NULL', ''):
                try:
                    errores.append(f"VIA_LEJOS_{float(via_lejos_val):.0f}m")
                except (TypeError, ValueError):
                    pass

            # Cruce con otras arañas reales (predios seleccionados)
            for cid in idx_aranas.intersects(geom.boundingBox()):
                if cid != arana_feat.id() and geom.crosses(capa_aranas_temp.getFeature(cid).geometry()):
                    errores.append("CRUCE_SPIDER")
                    break

            # Cruce con arañas fantasma (vecinos). Se usa intersects/distance en vez de
            # crosses(): crosses() da falso cuando dos líneas se TOCAN en un extremo
            # (típico: la araña larga pasa justo por donde arranca la fantasma).
            if "CRUCE_SPIDER" not in errores:
                # Punto final de esta araña (donde llega a la vía): si dos arañas
                # solo convergen ahí, NO es un cruce — es normal que varias lleguen
                # al mismo punto de la vía.
                try:
                    pts_geom = geom.asPolyline()
                    p_ini_g = QgsGeometry.fromPointXY(pts_geom[0])
                    p_fin_g = QgsGeometry.fromPointXY(pts_geom[-1])
                except Exception:
                    p_ini_g = p_fin_g = None
                tol_extremo = a_unidades(0.5)

                for vid in idx_vecinas.intersects(geom.boundingBox()):
                    geom_vecina = vecinas_geom_cache.get(vid)
                    if geom_vecina is None:
                        continue
                    inter = geom.intersection(geom_vecina)
                    if inter is None or inter.isEmpty():
                        continue
                    # Si la intersección está sólo en los extremos de esta araña
                    # (arranque en el predio o llegada a la vía), no es cruce real.
                    if p_ini_g is not None and p_fin_g is not None:
                        if (inter.distance(p_ini_g) < tol_extremo
                                or inter.distance(p_fin_g) < tol_extremo):
                            continue
                    errores.append("CRUCE_SPIDER")
                    break

            # Cruce con la malla vial: si la araña ATRAVIESA un tramo de vía para llegar
            # a su destino, está cruzando la calle -> error. Se excluye el tramo DESTINO
            # (la araña termina tocándolo, eso es normal) y las intersecciones que caen
            # justo en el punto de llegada, que es donde varios tramos se unen.
            via_destino_id = arana_feat['via_destino_id']
            try:
                pts_g = geom.asPolyline()
                p_llegada = QgsGeometry.fromPointXY(pts_g[-1])
            except Exception:
                p_llegada = None
            tol_llegada = a_unidades(0.5)
            for mid in idx_malla.intersects(geom.boundingBox()):
                if via_destino_id is not None and mid == via_destino_id:
                    continue
                geom_via = malla_data[mid]['geom']
                inter_via = geom.intersection(geom_via)
                if inter_via is None or inter_via.isEmpty():
                    continue
                if p_llegada is not None and inter_via.distance(p_llegada) < tol_llegada:
                    continue  # solo toca donde la araña llega a su vía
                errores.append("CRUZA_MALLA")
                break

            # Cruce con el interior de otro predio (la araña atraviesa un predio ajeno)
            tol_cruce_u = a_unidades(0.5)
            for pid in idx_predios.intersects(geom.boundingBox()):
                if pid == fid_orig:
                    continue
                geom_candidato = predios_geom_cache.get(pid)
                if geom_candidato is None:
                    continue
                inter = geom.intersection(geom_candidato)
                if not inter.isEmpty() and inter.length() > tol_cruce_u:
                    errores.append("CRUCE_PREDIO")
                    break

            # Todas las arañas se exportan a la capa de líneas con su observación,
            # incluidas las que tienen cruces, para poder verlas y diagnosticar.
            if "CRUCE_PREDIO" in errores:
                ids_cruce_predio.add(fid_orig)
            elif "CRUZA_MALLA" in errores:
                ids_cruza_malla.add(fid_orig)
            elif "CRUCE_SPIDER" in errores:
                ids_aranas_cruzan.add(fid_orig)
            elif any(e.startswith("VIA_LEJOS") for e in errores):
                pass  # el predio ya tiene su motivo en motivo_rechazo (VIA_LEJOS_XXm)
            else:
                ids_con_arana_valida.add(fid_orig)

            obs = ", ".join(errores) if errores else "OK"
            f_fin = QgsFeature()
            f_fin.setGeometry(geom)
            f_fin.setAttributes([str(p_orig[predio_id_field]), obs])
            prov_final.addFeature(f_fin)

        capa_final.commitChanges()
        proyecto.addMapLayer(capa_final)
        t_fase2 = time.perf_counter() - t0_fase2

        # --- FASE III: SELECCIONADOS SIN ARAÑA ---
        t0_fase3 = time.perf_counter()
        self._set_status("Fase III: identificando predios sin araña...", 90)
        nombre_capa_sin = 'predios_sin_aranas'
        for lyr in proyecto.mapLayers().values():
            if lyr.name() == nombre_capa_sin:
                proyecto.removeMapLayer(lyr.id())

        tipo_geom = QgsWkbTypes.displayString(predios_layer.wkbType())
        capa_sin = QgsVectorLayer(f"{tipo_geom}?crs={predios_layer.crs().authid()}", nombre_capa_sin, "memory")
        prov_sin = capa_sin.dataProvider()
        campos_sin = QgsFields(predios_layer.fields())
        campos_sin.append(QgsField('observacion_aranas', QVariant.String))
        prov_sin.addAttributes(campos_sin)
        capa_sin.updateFields()

        features_sin = []
        for f in predios_seleccionados:
            prin_f = vias_del_predio(f)[0]
            if prin_f.startswith(exclusion_prefixes):
                continue  # omitido por prefijo: no va a ninguna capa
            if f.id() in ids_cruce_predio:
                observacion = 'CRUCE_PREDIO'
            elif f.id() in ids_cruza_malla:
                observacion = 'CRUZA_MALLA'
            elif f.id() in ids_aranas_cruzan:
                observacion = 'CRUCE_SPIDER'
            elif f.id() not in ids_con_arana_valida:
                observacion = motivo_rechazo.get(f.id(), 'NO_CRUZA')
            else:
                continue  # tiene araña válida, no va en esta capa

            f_sin = QgsFeature(capa_sin.fields())
            f_sin.setGeometry(f.geometry())
            f_sin.setAttributes(list(f.attributes()) + [observacion])
            features_sin.append(f_sin)

        prov_sin.addFeatures(features_sin)
        proyecto.addMapLayer(capa_sin)
        t_fase3 = time.perf_counter() - t0_fase3

        # --- CUADRE: todo predio seleccionado debe estar contabilizado ---
        n_omitidos = sum(1 for f in predios_seleccionados
                          if vias_del_predio(f)[0].startswith(exclusion_prefixes))
        n_con_arana = len(ids_con_arana_valida)
        n_sin_arana = len(features_sin)
        cuadre = (f"\nCUADRE: {total} seleccionados = {n_con_arana} con araña + "
                  f"{n_sin_arana} sin araña + {n_omitidos} omitidos por prefijo")
        if n_con_arana + n_sin_arana + n_omitidos != total:
            cuadre += f"\n  *** ATENCIÓN: {total - n_con_arana - n_sin_arana - n_omitidos} predio(s) sin contabilizar ***"

        self.ultimo_diagnostico = (
            f"Tiempos totales ({total} predios seleccionados):\n"
            f"  Carga inicial malla vial: {t_carga_malla:.2f} s ({len(malla_data)} tramos)\n"
            f"  Carga inicial barrios: {t_carga_barrios:.2f} s ({len(barrios_cache)} barrios)\n"
            f"  Fase 0+I (por predio, promedio): "
            f"{(t_barrio_total + t_malla_busq_total + t_shortest_total) / total * 1000:.1f} ms/predio "
            f"({n_fallback} cayeron al escaneo completo, {n_candidatos_total / total:.1f} candidatos promedio)\n"
            f"  Fase II (validación): {t_fase2:.2f} s ({n_vecinas} arañas sombra de vecinos generadas, "
            f"{n_vecinos_sin_via[0]} vecinos omitidos sin vía coincidente)\n"
            f"  Fase III (predios sin araña): {t_fase3:.2f} s"
            + cuadre
        )
        print("--- DIAGNÓSTICO ARAÑAS CATASTRALES ---")
        print(self.ultimo_diagnostico)

        self._set_status("Proceso finalizado.", 100)