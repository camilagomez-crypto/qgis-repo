import os
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction


class AranasPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.actions = []
        self.menu = "Arañas Catastrales"
        self.toolbar = self.iface.addToolBar("Arañas Catastrales")
        self.toolbar.setObjectName("AranasCatastralesToolbar")
        self.dlg = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.svg")
        action = QAction(QIcon(icon_path), "Generar arañas", self.iface.mainWindow())
        action.triggered.connect(self.run)
        self.toolbar.addAction(action)
        self.iface.addPluginToMenu(self.menu, action)
        self.actions.append(action)

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu(self.menu, action)
            self.iface.removeToolBarIcon(action)
        del self.toolbar

    def run(self):
        from .aranas_dialog import AranasDialog
        if self.dlg is None:
            self.dlg = AranasDialog(self.iface.mainWindow())
        self.dlg.show()
