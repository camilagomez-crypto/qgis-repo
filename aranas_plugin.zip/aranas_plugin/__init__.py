def classFactory(iface):
    from .aranas_plugin import AranasPlugin
    return AranasPlugin(iface)
