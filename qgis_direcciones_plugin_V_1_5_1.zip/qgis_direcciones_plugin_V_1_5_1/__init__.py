def classFactory(iface):
    from .plugin import EstandarizacionDireccionesPlugin
    return EstandarizacionDireccionesPlugin(iface)
