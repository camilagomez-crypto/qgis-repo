import pandas as pd 
import geopandas as gpd 
from sqlalchemy import create_engine, text
from shapely.geometry import Polygon,MultiPolygon
import re

def Generar_placas(engine,predios):
    query_actualizar_dir_final = text("""
    UPDATE """+predios+""" SET via_princ = REGEXP_REPLACE(via_princ, '(KR|CL|DG|TV)(?=\\d)','\\1 ','gi')
    WHERE via_princ ~ '(KR|CL|DG|TV)(?=\\d)';
    
    UPDATE """+predios+""" SET via_sec = REGEXP_REPLACE(via_sec, '(KR|CL|DG|TV)(?=\\d)','\\1 ','gi')
    WHERE via_sec ~ '(KR|CL|DG|TV)(?=\\d)';
    
    UPDATE """+predios+""" SET compl = REGEXP_REPLACE(compl, '(KR|CL|DG|TV)(?=\\d)','\\1 ','gi')
    WHERE compl ~ '(KR|CL|DG|TV)(?=\\d)';

    UPDATE """+predios+""" SET direccion2 = REGEXP_REPLACE(direccion2, '(KR|CL|DG|TV)(?=\\d)','\\1 ','gi')
    WHERE direccion2 ~ '(KR|CL|DG|TV)(?=\\d)';
    
    DO $$
    BEGIN
        IF EXISTS (
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'public'
              AND table_name = '"""+predios+"""'
              AND column_name = 'dir_antigua'
        ) THEN
            UPDATE """+predios+""" SET dir_antigua = REGEXP_REPLACE(dir_antigua, '(KR|CL|DG|TV)(?=\\d)','\\1 ','gi')
            WHERE dir_antigua ~ '(KR|CL|DG|TV)(?=\\d)';
        END IF;
    END;
    $$ LANGUAGE plpgsql;

    Update """+predios+""" set via_princ = REPLACE(via_princ,' ET ',' ETA ') where via_princ LIKE '% ET %';
    Update """+predios+""" set direccion_final = REPLACE(direccion_final,' ET ',' ETA ') where direccion_final LIKE '% ET %';
    Update """+predios+""" set direccion2 = REPLACE(direccion2,' ET ',' ETA ') where direccion2 LIKE '% ET %';
    Update """+predios+""" set dir_antigua = REPLACE(dir_antigua,' ET ',' ETA ') where dir_antigua LIKE '% ET %';

    Update """+predios+""" set via_princ = REPLACE(via_princ,' ET',' ETA') where via_princ LIKE '% ET';
    Update """+predios+""" set direccion_final = REPLACE(direccion_final,' ET',' ETA') where direccion_final LIKE '% ET';
    Update """+predios+""" set direccion2 = REPLACE(direccion2,' ET',' ETA') where direccion2 LIKE '% ET';
    Update """+predios+""" set dir_antigua = REPLACE(dir_antigua,' ET',' ETA') where dir_antigua LIKE '% ET';

    Update """+predios+""" set via_princ = REPLACE(via_princ,' ETAPA ',' ETA ') where via_princ LIKE '% ETAPA %';
    Update """+predios+""" set direccion_final = REPLACE(direccion_final,' ETAPA ',' ETA ') where direccion_final LIKE '% ETAPA %';
    Update """+predios+""" set direccion2 = REPLACE(direccion2,' ETAPA ',' ETA ') where direccion2 LIKE '% ETAPA %';
    Update """+predios+""" set dir_antigua = REPLACE(dir_antigua,' ETAPA ',' ETA ') where dir_antigua LIKE '% ETAPA %';

    UPDATE """+predios+""" SET via_princ = regexp_replace(via_princ, '(ETA) ([IVXLCDM]+) ([A-Z])', '\\2 \\1 \\3', 'gi') WHERE via_princ ~* 'ETA [IVXLCDM]+ [A-Z]';
    UPDATE """+predios+""" SET direccion_final = regexp_replace(direccion_final, '(ETA) ([IVXLCDM]+) ([A-Z])', '\\2 \\1 \\3', 'gi') WHERE direccion_final ~* 'ETA [IVXLCDM]+ [A-Z]';
    UPDATE """+predios+""" SET direccion2 = regexp_replace(direccion2, '(ETA) ([IVXLCDM]+) ([A-Z])', '\\2 \\1 \\3', 'gi') WHERE direccion2 ~* 'ETA [IVXLCDM]+ [A-Z]';

    UPDATE """+predios+""" SET via_princ = regexp_replace(via_princ, '(\\m[IVXLCDM]+\\M) ETA', 'ETA \\1', 'gi') WHERE via_princ ~* '\\m[IVXLCDM]+\\M ETA';
    UPDATE """+predios+""" SET direccion_final = regexp_replace(direccion_final, '(\\m[IVXLCDM]+\\M) ETA', 'ETA \\1', 'gi') WHERE direccion_final ~* '\\m[IVXLCDM]+\\M ETA';
    UPDATE """+predios+""" SET direccion2 = regexp_replace(direccion2, '(\\m[IVXLCDM]+\\M) ETA', 'ETA \\1', 'gi') WHERE direccion2 ~* '\\m[IVXLCDM]+\\M ETA';

    DO $$
    BEGIN
        IF EXISTS (
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'public'
              AND table_name = '"""+predios+"""'
              AND column_name = 'dir_antigua'
        ) THEN
            UPDATE """+predios+""" SET dir_antigua = regexp_replace(dir_antigua, '(\\m[IVXLCDM]+\\M) ETA', 'ETA \\1', 'gi')
            WHERE dir_antigua ~* '\\m[IVXLCDM]+\\M ETA';
        END IF;
    END;
    $$ LANGUAGE plpgsql;

    UPDATE """+predios+""" SET via_princ = regexp_replace(via_princ, '( DE )ETA ([^ ]+)', '\\1\\2 ETA', 'gi') WHERE via_princ LIKE '% DE ETA %';
    UPDATE """+predios+""" SET direccion_final = regexp_replace(direccion_final, '( DE )ETA ([^ ]+)', '\\1\\2 ETA', 'gi') WHERE direccion_final LIKE '% DE ETA %';
    UPDATE """+predios+""" SET direccion2 = regexp_replace(direccion2, '( DE )ETA ([^ ]+)', '\\1\\2 ETA', 'gi') WHERE direccion2 LIKE '% DE ETA %';

    update """+predios+""" set via_princ = replace(via_princ,'BR ','BRR ') WHERE via_princ like 'BR %';
    update """+predios+""" set direccion_final = replace(direccion_final,'BR ','BRR ') WHERE direccion_final like 'BR %';
    update """+predios+""" set direccion2 = replace(direccion2,'BR ','BRR ') WHERE direccion2 like 'BR %';
    update """+predios+""" set dir_antigua = replace(dir_antigua,'BR ','BRR ') WHERE dir_antigua like 'BR %';

    update """+predios+""" set via_princ = replace(via_princ,'UR ','URB ') WHERE via_princ like 'UR %';
    update """+predios+""" set direccion_final = replace(direccion_final,'UR ','URB ') WHERE direccion_final like 'UR %';
    update """+predios+""" set direccion2 = replace(direccion2,'UR ','URB ') WHERE direccion2 like 'UR %';
    update """+predios+""" set dir_antigua = replace(dir_antigua,'UR ','URB ') WHERE dir_antigua like 'UR %';

    update """+predios+""" set via_princ = replace(via_princ,'UB ','URB ') WHERE via_princ like 'UB %';
    update """+predios+""" set direccion_final = replace(direccion_final,'UB ','URB ') WHERE direccion_final like 'UB %';
    update """+predios+""" set direccion2 = replace(direccion2,'UB ','URB ') WHERE direccion2 like 'UB %';
    update """+predios+""" set dir_antigua = replace(dir_antigua,'UB ','URB ') WHERE dir_antigua like 'UB %';

    update """+predios+""" set via_princ = replace(via_princ,'BBR ','BRR ') WHERE via_princ like 'BBR %';
    update """+predios+""" set direccion_final = replace(direccion_final,'BBR ','BRR ') WHERE direccion_final like 'BBR %';
    update """+predios+""" set direccion2 = replace(direccion2,'BBR ','BRR ') WHERE direccion2 like 'BBR %';
    update """+predios+""" set dir_antigua = replace(dir_antigua,'BBR ','BRR ') WHERE dir_antigua like 'BBR %';

    update """+predios+""" set via_princ = replace(via_princ,'UBR ','URB ') WHERE via_princ like 'UBR %';
    update """+predios+""" set direccion_final = replace(direccion_final,'UBR ','URB ') WHERE direccion_final like 'UBR %';
    update """+predios+""" set direccion2 = replace(direccion2,'UBR ','URB ') WHERE direccion2 like 'UBR %';
    update """+predios+""" set dir_antigua = replace(dir_antigua,'UBR ','URB ') WHERE dir_antigua like 'UBR %';

    update """+predios+""" set via_princ = replace(via_princ,'UBRR ','URB ') WHERE via_princ like 'UBRR %';
    update """+predios+""" set direccion_final = replace(direccion_final,'UBRR ','URB ') WHERE direccion_final like 'UBRR %';
    update """+predios+""" set direccion2 = replace(direccion2,'UBRR ','URB ') WHERE direccion2 like 'UBRR %';
    update """+predios+""" set dir_antigua = replace(dir_antigua,'UBRR ','URB ') WHERE dir_antigua like 'UBRR %';

    Update """+predios+""" set via_sec = REPLACE(via_sec,'MZA','MZA ') where via_sec ~ '(MZA[0-9])';
    Update """+predios+""" set direccion_final = REPLACE(direccion_final,'MZA','MZA ') where direccion_final ~ '(MZA[0-9])';
    Update """+predios+""" set direccion2 = REPLACE(direccion2,'MZA','MZA ') where direccion2 ~ '(MZA[0-9])';
    Update """+predios+""" set dir_antigua = REPLACE(dir_antigua,'MZA','MZA ') where dir_antigua ~ '(MZA[0-9])';

    Update """+predios+""" set placa = REPLACE(placa,'CAS','CAS ') where placa ~ '(CAS[0-9])';
    Update """+predios+""" set direccion_final = REPLACE(direccion_final,'CAS','CAS ') where direccion_final ~ '(CAS[0-9])';
    Update """+predios+""" set direccion2 = REPLACE(direccion2,'CAS','CAS ') where direccion2 ~ '(CAS[0-9])';
    Update """+predios+""" set dir_antigua = REPLACE(dir_antigua,'CAS','CAS ') where dir_antigua ~ '(CAS[0-9])';

    Update """+predios+""" set via_princ = REPLACE(via_princ,' SECTOR ',' SEC ') where via_princ LIKE '% SECTOR %';
    Update """+predios+""" set direccion_final = REPLACE(direccion_final,' SECTOR ',' SEC ') where direccion_final LIKE '% SECTOR %';
    Update """+predios+""" set direccion2 = REPLACE(direccion2,' SECTOR ',' SEC ') where direccion2 LIKE '% SECTOR %';
    Update """+predios+""" set dir_antigua = REPLACE(dir_antigua,' SECTOR ',' SEC ') where dir_antigua LIKE '% SECTOR %';

    Update """+predios+""" set via_princ = REPLACE(via_princ,' SC ',' SEC ') where via_princ LIKE '% SC %';
    Update """+predios+""" set direccion_final = REPLACE(direccion_final,' SC ',' SEC ') where direccion_final LIKE '% SC %';
    Update """+predios+""" set direccion2 = REPLACE(direccion2,' SC ',' SEC ') where direccion2 LIKE '% SC %';
    Update """+predios+""" set dir_antigua = REPLACE(dir_antigua,' SC ',' SEC ') where dir_antigua LIKE '% SC %';

    Update """+predios+""" set via_princ = REPLACE(via_princ,'BRR','BRR ') WHERE via_princ LIKE 'BRR%' AND via_princ NOT LIKE 'BRR %';
    Update """+predios+""" set direccion_final = REPLACE(direccion_final,'BRR','BRR ') WHERE direccion_final LIKE 'BRR%' AND direccion_final NOT LIKE 'BRR %';
    Update """+predios+""" set direccion2 = REPLACE(direccion2,'BRR','BRR ') WHERE direccion2 LIKE 'BRR%' AND direccion2 NOT LIKE 'BRR %';
    Update """+predios+""" set dir_antigua = REPLACE(dir_antigua,'BRR','BRR ') WHERE dir_antigua LIKE 'BRR%' AND dir_antigua NOT LIKE 'BRR %';

    Update """+predios+""" set via_princ = REPLACE(via_princ,'URB','URB ') WHERE via_princ LIKE 'URB%' AND via_princ NOT LIKE 'URB %';
    Update """+predios+""" set direccion_final = REPLACE(direccion_final,'URB','URB ') WHERE direccion_final LIKE 'URB%' AND direccion_final NOT LIKE 'URB %';
    Update """+predios+""" set direccion2 = REPLACE(direccion2,'URB','URB ') WHERE direccion2 LIKE 'URB%' AND direccion2 NOT LIKE 'URB %';
    Update """+predios+""" set dir_antigua = REPLACE(dir_antigua,'URB','URB ') WHERE dir_antigua LIKE 'URB%' AND dir_antigua NOT LIKE 'URB %';

    Update """+predios+""" set via_princ = REPLACE(via_princ,'CND','CND ') WHERE via_princ LIKE 'CND%' AND via_princ NOT LIKE 'CND %';
    Update """+predios+""" set direccion_final = REPLACE(direccion_final,'CND','CND ') WHERE direccion_final LIKE 'CND%' AND direccion_final NOT LIKE 'CND %';
    Update """+predios+""" set direccion2 = REPLACE(direccion2,'CND','CND ') WHERE direccion2 LIKE 'CND%' AND direccion2 NOT LIKE 'CND %';
    Update """+predios+""" set dir_antigua = REPLACE(dir_antigua,'CND','CND ') WHERE dir_antigua LIKE 'CND%' AND dir_antigua NOT LIKE 'CND %';

    Update """+predios+""" set via_princ = REPLACE(via_princ,'CJR','CJR ') WHERE via_princ LIKE 'CJR%' AND via_princ NOT LIKE 'CJR %';
    Update """+predios+""" set direccion_final = REPLACE(direccion_final,'CJR','CJR ') WHERE direccion_final LIKE 'CJR%' AND direccion_final NOT LIKE 'CJR %';
    Update """+predios+""" set direccion2 = REPLACE(direccion2,'CJR','CJR ') WHERE direccion2 LIKE 'CJR%' AND direccion2 NOT LIKE 'CJR %';
    Update """+predios+""" set dir_antigua = REPLACE(dir_antigua,'CJR','CJR ') WHERE dir_antigua LIKE 'CJR%' AND dir_antigua NOT LIKE 'CJR %';

    Update """+predios+""" set via_princ = REPLACE(via_princ,'CDE','CDE ') WHERE via_princ LIKE 'CDE%' AND via_princ NOT LIKE 'CDE %';
    Update """+predios+""" set direccion_final = REPLACE(direccion_final,'CDE','CDE ') WHERE direccion_final LIKE 'CDE%' AND direccion_final NOT LIKE 'CDE %';
    Update """+predios+""" set direccion2 = REPLACE(direccion2,'CDE','CDE ') WHERE direccion2 LIKE 'CDE%' AND direccion2 NOT LIKE 'CDE %';
    Update """+predios+""" set dir_antigua = REPLACE(dir_antigua,'CDE','CDE ') WHERE dir_antigua LIKE 'CDE%' AND dir_antigua NOT LIKE 'CDE %';

    Update """+predios+""" set via_princ = REPLACE(via_princ,' BLQ ',' BQU ') WHERE via_princ LIKE '% BLQ %';
    Update """+predios+""" set direccion_final = REPLACE(direccion_final,' BLQ ',' BQU ') WHERE direccion_final LIKE '% BLQ %';
    Update """+predios+""" set direccion2 = REPLACE(direccion2,' BLQ ',' BQU ') WHERE direccion2 LIKE '% BLQ %';
    Update """+predios+""" set dir_antigua = REPLACE(dir_antigua,' BLQ ',' BQU ') WHERE dir_antigua LIKE '% BLQ %';

    Update """+predios+""" set direccion_final = regexp_replace(direccion_final, 'BR\\.\s+', 'BRR ', 'gi') WHERE direccion_final ~* 'BR\\.';
    Update """+predios+""" set direccion2 = regexp_replace(direccion2, 'BR\\.\s+', 'BRR ', 'gi') WHERE direccion2 ~* 'BR\\.';
    Update """+predios+""" set dir_antigua = regexp_replace(dir_antigua, 'BR\\.\s+', 'BRR ', 'gi') WHERE dir_antigua ~* 'BR\\.';

    Update """+predios+""" set direccion_final = regexp_replace(direccion_final, 'UR\\.\s+', 'URB ', 'gi') WHERE direccion_final ~* 'UR\\.';
    Update """+predios+""" set direccion2 = regexp_replace(direccion2, 'UR\\.\s+', 'URB ', 'gi') WHERE direccion2 ~* 'UR\\.';
    Update """+predios+""" set dir_antigua = regexp_replace(dir_antigua, 'UR\\.\s+', 'URB ', 'gi') WHERE dir_antigua ~* 'UR\\.';

    Update """+predios+""" set direccion_final = regexp_replace(direccion_final, 'UB\\.\s+', 'URB ', 'gi') WHERE direccion_final ~* 'UB\\.';
    Update """+predios+""" set direccion2 = regexp_replace(direccion2, 'UB\\.\s+', 'URB ', 'gi') WHERE direccion2 ~* 'UB\\.';
    Update """+predios+""" set dir_antigua = regexp_replace(dir_antigua, 'UB\\.\s+', 'URB ', 'gi') WHERE dir_antigua ~* 'UB\\.';

    Update """+predios+""" set direccion_final = regexp_replace(direccion_final, '\\bMZ\\b', 'MZA', 'gi') WHERE direccion_final ~* '\\bMZ\\b';
    Update """+predios+""" set direccion2 = regexp_replace(direccion2, '\\bMZ\\b', 'MZA', 'gi') WHERE direccion2 ~* '\\bMZ\\b';
    Update """+predios+""" set dir_antigua = regexp_replace(dir_antigua, '\\bMZ\\b', 'MZA', 'gi') WHERE dir_antigua ~* '\\bMZ\\b';

    Update """+predios+""" set direccion_final = regexp_replace(direccion_final, '\\bCS\\b', 'CAS', 'gi') WHERE direccion_final ~* '\\bCS\\b';
    Update """+predios+""" set direccion2 = regexp_replace(direccion2, '\\bCS\\b', 'CAS', 'gi') WHERE direccion2 ~* '\\bCS\\b';
    Update """+predios+""" set dir_antigua = regexp_replace(dir_antigua, '\\bCS\\b', 'CAS', 'gi') WHERE dir_antigua ~* '\\bCS\\b';

    Update """+predios+""" set direccion_final = regexp_replace(direccion_final, '\\s*#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\s*', ' \\1 ', 'gi')
    WHERE direccion_final ~* '#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\b';
    Update """+predios+""" set direccion2 = regexp_replace(direccion2, '\\s*#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\s*', ' \\1 ', 'gi')
    WHERE direccion2 ~* '#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\b';
    Update """+predios+""" set dir_antigua = regexp_replace(dir_antigua, '\\s*#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\s*', ' \\1 ', 'gi')
    WHERE dir_antigua ~* '#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\b';

    Update """+predios+""" set direccion_final = regexp_replace(direccion_final, '\\s*#\\s*', ' KR ', 'gi')
    WHERE direccion_final ~* '^CL' AND direccion_final !~* '#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\b';
    Update """+predios+""" set direccion_final = regexp_replace(direccion_final, '\\s*#\\s*', ' CL ', 'gi')
    WHERE direccion_final ~* '^KR' AND direccion_final !~* '#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\b';

    Update """+predios+""" set direccion2 = regexp_replace(direccion2, '\\s*#\\s*', ' KR ', 'gi')
    WHERE direccion2 ~* '^CL' AND direccion2 !~* '#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\b';
    Update """+predios+""" set direccion2 = regexp_replace(direccion2, '\\s*#\\s*', ' CL ', 'gi')
    WHERE direccion2 ~* '^KR' AND direccion2 !~* '#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\b';

    Update """+predios+""" set dir_antigua = regexp_replace(dir_antigua, '\\s*#\\s*', ' KR ', 'gi')
    WHERE dir_antigua ~* '^CL' AND dir_antigua !~* '#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\b';
    Update """+predios+""" set dir_antigua = regexp_replace(dir_antigua, '\\s*#\\s*', ' CL ', 'gi')
    WHERE dir_antigua ~* '^KR' AND dir_antigua !~* '#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\b';

    Update """+predios+""" set direccion_final = regexp_replace(direccion_final, '\\s*-\\s*', ' ', 'g') WHERE direccion_final ~* '-';
    Update """+predios+""" set direccion2 = regexp_replace(direccion2, '\\s*-\\s*', ' ', 'g') WHERE direccion2 ~* '-';
    Update """+predios+""" set dir_antigua = regexp_replace(dir_antigua, '\\s*-\\s*', ' ', 'g') WHERE dir_antigua ~* '-';

    update """+predios+""" set via_princ = trim(via_princ) WHERE via_princ <> trim(via_princ);
    update """+predios+""" set direccion_final = trim(direccion_final) WHERE direccion_final <> trim(direccion_final);
    update """+predios+""" set direccion2 = trim(direccion2) WHERE direccion2 <> trim(direccion2);
    update """+predios+""" set dir_antigua = trim(dir_antigua) WHERE dir_antigua <> trim(dir_antigua);

    Update """+predios+""" set via_princ = REPLACE(via_princ,'  ',' ') where via_princ LIKE '%  %';
    Update """+predios+""" set direccion_final = REPLACE(direccion_final,'  ',' ') where direccion_final LIKE '%  %';
    Update """+predios+""" set direccion2 = REPLACE(direccion2,'  ',' ') where direccion2 LIKE '%  %';
    Update """+predios+""" set dir_antigua = REPLACE(dir_antigua,'  ',' ') where dir_antigua LIKE '%  %';

    Update """+predios+""" set direccion_final = replace(direccion_final,'LOTE','LTE') where direccion_final ILIKE 'LOTE%';
    Update """+predios+""" set direccion2 = replace(direccion2,'LOTE','LTE') where direccion2 ILIKE 'LOTE%';
    Update """+predios+""" set dir_antigua = replace(dir_antigua,'LOTE','LTE') where dir_antigua ILIKE 'LOTE%';
    UPDATE """+predios+""" SET compl = REGEXP_REPLACE(compl,'([A-Z])(?=(KR|CL|DG|TV))','\\1 ','gi')
    WHERE compl ~ '([A-Z])(?=(KR|CL|DG|TV))'
    AND compl NOT LIKE '%BDG%';

    UPDATE """+predios+""" SET direccion_final = REGEXP_REPLACE(direccion_final,'([A-Z])(?=(KR|CL|DG|TV))','\\1 ','gi')
    WHERE direccion_final ~ '([A-Z])(?=(KR|CL|DG|TV))'
    AND direccion_final NOT LIKE '%BDG%';

    UPDATE """+predios+""" SET direccion2 = REGEXP_REPLACE(direccion2,'([A-Z])(?=(KR|CL|DG|TV))','\\1 ','gi')
    WHERE direccion2 ~ '([A-Z])(?=(KR|CL|DG|TV))'
    AND direccion2 NOT LIKE '%BDG%';

    DO $$
    BEGIN
        IF EXISTS (
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'public'
              AND table_name = '"""+predios+"""'
              AND column_name = 'dir_antigua'
        ) THEN
            UPDATE """+predios+""" SET dir_antigua = REGEXP_REPLACE(dir_antigua,'([A-Z])(?=(KR|CL|DG|TV))','\\1 ','gi')
            WHERE dir_antigua ~ '([A-Z])(?=(KR|CL|DG|TV))'
            AND dir_antigua NOT LIKE '%BDG%';
        END IF;
    END;
    $$ LANGUAGE plpgsql;
    
    UPDATE """+predios+""" SET direccion_final = trim(replace(replace(replace(concat(via_princ,' ',via_sec,' ',placa,' ',compl),'  ',' '),'  ',' '),'  ',' '))
    WHERE direccion_final IS NULL 
    OR direccion_final <> trim(replace(replace(replace(concat(via_princ,' ',via_sec,' ',placa,' ',compl),'  ',' '),'  ',' '),'  ',' '));
    """)

    with engine.connect() as conn:
        conn.execute(query_actualizar_dir_final)
        conn.commit()

    sql = f"SELECT id, geom, direccion_final, direccion2, dir_antigua FROM {predios};"
    gdf_predios = gpd.read_postgis(sql, engine, geom_col='geom',crs= 'EPSG:4326')
    gdf_predios["geom"] = gdf_predios["geom"].apply(lambda geom: geom.representative_point() if isinstance(geom, (Polygon, MultiPolygon)) else geom)
    gdf_dir1 = gdf_predios[["id", "geom", "direccion_final"]].rename(columns={"id": "id_predio", "direccion_final": "direccion"})
    gdf_dir1 = gdf_dir1[~gdf_dir1["direccion"].isin([None, "", " "])]
    gdf_dir1 = gdf_dir1.assign(direccion=gdf_dir1["direccion"].str.split("|")).explode("direccion")
    gdf_dir1["direccion"] = gdf_dir1["direccion"].str.strip()
    gdf_dir1 = gdf_dir1.reset_index(drop=True)
    def expandir_direcciones(row):
        if "/" in row.direccion:
            base, numeros = row.direccion.rsplit(" ", 1)
            numeros_separados = numeros.split("/")
            return [{"id_predio": row.id_predio, "geom": row.geom, "direccion": f"{base} {num}"} for num in numeros_separados]
        else:
            return [row._asdict()]
    gdf_dir1_final = gpd.GeoDataFrame(
        [subfila for fila in gdf_dir1.itertuples(index=False) for subfila in expandir_direcciones(fila)]
    )

    gdf_dir1_final = gdf_dir1_final.reset_index(drop=True)

    gdf_dir1_final["categoria"] = "DIR1"
    gdf_dir2 = gdf_predios[["id", "geom", "direccion2"]].rename(columns={"id": "id_predio", "direccion2": "direccion"})
    gdf_dir2 = gdf_dir2[~gdf_dir2["direccion"].isin([None, "", " "])]
    gdf_dir2 = gdf_dir2.assign(direccion=gdf_dir2["direccion"].str.split("|")).explode("direccion")
    gdf_dir2["direccion"] = gdf_dir2["direccion"].str.strip()
    gdf_dir2 = gdf_dir2.reset_index(drop=True)
    gdf_dir2_final = gpd.GeoDataFrame(
        [subfila for fila in gdf_dir2.itertuples(index=False) for subfila in expandir_direcciones(fila)]
    )

    gdf_dir2_final = gdf_dir2_final.reset_index(drop=True)

    gdf_dir2_final["categoria"] = "DIR2"
    gdf_dir3 = gdf_predios[["id", "geom", "dir_antigua"]].rename(columns={"id": "id_predio", "dir_antigua": "direccion"})
    gdf_dir3 = gdf_dir3[~gdf_dir3["direccion"].isin([None, "", " "])]
    gdf_dir3 = gdf_dir3.assign(direccion=gdf_dir3["direccion"].str.split("|")).explode("direccion")
    gdf_dir3["direccion"] = gdf_dir3["direccion"].str.strip()
    gdf_dir3 = gdf_dir3.reset_index(drop=True)
    gdf_dir3_final = gpd.GeoDataFrame(
        [subfila for fila in gdf_dir3.itertuples(index=False) for subfila in expandir_direcciones(fila)]
    )

    gdf_dir3_final = gdf_dir3_final.reset_index(drop=True)

    gdf_dir3_final["categoria"] = "DIR3"
    gdf_placas = gpd.GeoDataFrame(pd.concat([gdf_dir1_final, gdf_dir2_final, gdf_dir3_final], ignore_index=True))

    gdf_placas['id'] = gdf_placas.index

    if 'geom' in gdf_placas.columns:
        gdf_placas = gdf_placas.set_geometry('geom')

    if gdf_placas.crs is None:
        gdf_placas.set_crs("EPSG:4326", inplace=True) 
    
    tipoCardinal = ['CL', 'KR', 'TV', 'DG', 'AV', 'AC', 'AK', 'PJ', 'CQ', 'PT']
    tipoMzCs1 = ['BRR', 'CDE', 'CND', 'CJR', 'MTF', 'URD', 'URB', 'EDI']
    tipoMzCs2_5 = ['BIF', 'KDX', 'SMA', 'MZA', 'AGP', 'BQU', 'TOR', 'INT', 'SEC', 'ZNA']
    tipoMzCs6 = ['APT', 'BDG', 'CAS', 'LCA', 'LTE', 'OFI']

    def clasCardinal(data):
        if pd.isna(data):
            return [None] * 6

        principal, generadora, placa, placa2, complemento, error = '', '', '', '', '', 'CARDINAL'
        tipo2 = [" " + i + " " for i in tipoCardinal]

        posiciones = [data.find(t) for t in tipo2 if t in data]
        if not posiciones:
            error += ' No tiene formato'
            return principal, generadora, placa, placa2, complemento, error
        prin = min(posiciones)
        principal = data[:prin]
        xgen = data[prin + 4:]
        match = re.search(r" (\d+[A-Z]?|SP)", xgen)
        if not match:
            error += ' No tiene generadora'
            return principal, generadora, placa, placa2, complemento, error

        generadora = data[prin+1:prin+match.start()+4]
        restante = xgen[match.start():].strip()

        pos_espacio = restante.find(' ')
        if pos_espacio != -1:
            placa = restante[:pos_espacio]
            complemento = restante[pos_espacio:].strip()
        else:
            placa = restante
            complemento = None
        if 'SP' in placa:
            placa2 = 'SP'
        elif placa.isdigit():
            placa2 = 'PAR' if int(placa) % 2 == 0 else 'IMPAR'
        else:
            placa2 = 'LETRA'

        return principal, generadora, placa, placa2, complemento, error

    def clasMzCasa(data):
        if pd.isna(data):
            return [None] * 4

        principal, generadora, placa, error = '', '', '', 'MZ CASA'

        posiciones = [data.find(f" {i} ") for i in tipoMzCs6 if f" {i} " in data]
        if not posiciones:
            return data, None, None, error + ' No tiene placa'
        prin_pos = min(posiciones)
        principal = data[:prin_pos]
        placa = data[prin_pos + 1:]
        posiciones_gen = [principal.find(f" {i} ") for i in tipoMzCs2_5 if f" {i} " in principal]
        if posiciones_gen:
            generadora = principal[min(posiciones_gen) + 1:]
            principal = principal[:min(posiciones_gen)]

        return principal, generadora, placa, error

    def clasOtro(data):
        posiciones = [data.find(f" {i} ") for i in tipoMzCs6 if f" {i} " in data]
        if not posiciones:
            return None, None, None, 'SIN FORMATO'
            
        dirc = data[:min(posiciones)]
        pl = data[min(posiciones):]
        ob = 'MZ CASA Sin nivel'
        
        posiciones = [dirc.find(f" {i} ") for i in tipoMzCs2_5 if f" {i} " in dirc]
        if not posiciones:
            return dirc, None, pl, ob 
        
        pr = dirc[:min(posiciones)]
        ge = dirc[min(posiciones):]
        
        if len(pr) > 0:
            return pr,ge,pl,ob
        else:
            return None,None,pl,'PENDIENTE'
            
    def procesar_direcciones(gdf_placas, columna):
        resultados = []
        for direccion in gdf_placas[columna]:
            d = str(direccion).strip()
            d = re.sub(r"\s+", " ", d)
            d = re.sub(r"BR\.\s+", "BRR ", d, flags=re.IGNORECASE)
            d = re.sub(r"UR\.\s+", "URB ", d, flags=re.IGNORECASE)
            d = re.sub(r"UB\.\s+", "URB ", d, flags=re.IGNORECASE)
            d = re.sub(r"\bMZ\b", "MZA", d, flags=re.IGNORECASE)
            d = re.sub(r"\bCS\b", "CAS", d, flags=re.IGNORECASE)
            d = re.sub(r"\bBLQ\b", "BQU", d, flags=re.IGNORECASE)
            d = re.sub(r"\bBL\b", "BQU", d, flags=re.IGNORECASE)
            d = re.sub(r"\s*#\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\s*", r" \1 ", d, flags=re.IGNORECASE)
            if re.match(r"^CL\b", d, re.IGNORECASE) and "#" in d and not re.search(r"#\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\b", d, re.IGNORECASE):
                d = re.sub(r"\s*#\s*", " KR ", d, flags=re.IGNORECASE)
            if re.match(r"^KR\b", d, re.IGNORECASE) and "#" in d and not re.search(r"#\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\b", d, re.IGNORECASE):
                d = re.sub(r"\s*#\s*", " CL ", d, flags=re.IGNORECASE)
            d = re.sub(r"\s*-\s*", " ", d)
            d = re.sub(r"\s+", " ", d).strip()
            if d.upper().startswith("LOTE"):
                d = "LTE" + d[4:]
                d = d.strip()
            if d.startswith("LTE"):
                resultados.append(["LTE", None, None, None, None, "MZ CASA"])
                continue
            if d[:2] in tipoCardinal:
                resultados.append(clasCardinal(d))
            elif d[:3] in tipoMzCs1:
                pr, ge, pl, er = clasMzCasa(d)
                resultados.append([pr, ge, pl, None, None, er])
            else:
                pr,ge,pl,er = clasOtro(d)
                resultados.append([pr, ge, pl, None, None, er])
        columnas_nuevas = [f'prin_{columna}', f'gene_{columna}', f'plac_{columna}',
                            f'cost_{columna}', f'comp_{columna}', f'obse_{columna}']

        return pd.DataFrame(resultados, columns=columnas_nuevas)  
    gdf_placas = gdf_placas.reset_index(drop=True)

    resultado = procesar_direcciones(gdf_placas, 'direccion')

    gdf_placas = gdf_placas.join(resultado)

    gdf_placas.to_postgis('gdf_placas', con=engine, if_exists='replace')
    print('gdf cargado con exito')
    
def Query_Generar_placas_municipio(municipio):

    query = """
    
    DROP TABLE IF EXISTS placas_"""+municipio+""";

    CREATE TABLE placas_"""+municipio+""" AS (
    SELECT id, geom, direccion, categoria, prin_direccion AS principal, gene_direccion AS generadora, plac_direccion AS placa, comp_direccion AS complemento,cost_direccion AS costado, obse_direccion AS tipo_direccion, id_predio
    FROM gdf_placas); 

    CREATE INDEX idx_id_id_predio ON placas_"""+municipio+""" (id, id_predio);
    CREATE INDEX spatial_placas ON placas_"""+municipio+""" USING GIST(geom);

    DROP TABLE IF EXISTS gdf_placas;  

    UPDATE placas_"""+municipio+""" SET principal = x.parte1, generadora = x.parte2
    FROM(
    SELECT 
    id,direccion,
    TRIM(SPLIT_PART(direccion, 'SMA', 1)) AS parte1,
    'SMA ' || TRIM(SPLIT_PART(direccion, 'SMA', 2)) AS parte2
    FROM placas_"""+municipio+"""
    WHERE tipo_direccion = 'MZ CASA No tiene placa'
    AND direccion LIKE '% SMA %'
    AND generadora IS NULL) AS x
    WHERE x.id = placas_"""+municipio+""".id;

    UPDATE placas_"""+municipio+""" SET principal = x.parte1, generadora = x.parte2
    FROM(
    SELECT 
    id,direccion,
    TRIM(SPLIT_PART(direccion, 'MZA', 1)) AS parte1,
    'MZA ' || TRIM(SPLIT_PART(direccion, 'MZA', 2)) AS parte2
    FROM placas_"""+municipio+"""
    WHERE tipo_direccion = 'MZ CASA No tiene placa'
    AND direccion LIKE '% MZA %'
    AND generadora IS NULL) AS x
    WHERE x.id = placas_"""+municipio+""".id;

    UPDATE placas_"""+municipio+""" SET principal = x.parte1, generadora = x.parte2
    FROM(
    SELECT 
    id,direccion,
    TRIM(SPLIT_PART(direccion, 'BQU', 1)) AS parte1,
    'BQU ' || TRIM(SPLIT_PART(direccion, 'BQU', 2)) AS parte2
    FROM placas_"""+municipio+"""
    WHERE tipo_direccion = 'MZ CASA No tiene placa'
    AND direccion LIKE '% BQU %'
    AND generadora IS NULL) AS x
    WHERE x.id = placas_"""+municipio+""".id;

    UPDATE placas_"""+municipio+""" SET principal = x.parte1, generadora = x.parte2
    FROM(
    SELECT 
    id,direccion,
    TRIM(SPLIT_PART(direccion, 'BIF', 1)) AS parte1,
    'BIF ' || TRIM(SPLIT_PART(direccion, 'BIF', 2)) AS parte2
    FROM placas_"""+municipio+"""
    WHERE tipo_direccion = 'MZ CASA No tiene placa'
    AND direccion LIKE '% BIF %'
    AND generadora IS NULL) AS x
    WHERE x.id = placas_"""+municipio+""".id;

    UPDATE placas_"""+municipio+""" SET principal = x.parte1, generadora = x.parte2
    FROM(
    SELECT 
    id,direccion,
    TRIM(SPLIT_PART(direccion, 'BDG', 1)) AS parte1,
    'BDG ' || TRIM(SPLIT_PART(direccion, 'BDG', 2)) AS parte2
    FROM placas_"""+municipio+"""
    WHERE tipo_direccion = 'MZ CASA No tiene placa'
    AND direccion LIKE '% BDG %'
    AND generadora IS NULL) AS x
    WHERE x.id = placas_"""+municipio+""".id;

    UPDATE placas_"""+municipio+""" SET principal = x.parte1, generadora = x.parte2
    FROM(
    SELECT 
    id,direccion,
    TRIM(SPLIT_PART(direccion, 'TOR', 1)) AS parte1,
    'TOR ' || TRIM(SPLIT_PART(direccion, 'TOR', 2)) AS parte2
    FROM placas_"""+municipio+"""
    WHERE tipo_direccion = 'MZ CASA No tiene placa'
    AND direccion LIKE '% TOR %'
    AND generadora IS NULL) AS x
    WHERE x.id = placas_"""+municipio+""".id;    
    
    """
    return query
    
    
def prQueryGenerarPuntosMzaCasa(municipio):

    query = """
    
    DROP TABLE IF EXISTS aux_mza_cas;

    CREATE TABLE aux_mza_cas AS (
    SELECT m.id, p.principal, p.generadora, count(*) AS conteo, ROW_NUMBER() OVER (PARTITION BY m.id ORDER BY count(*) DESC) AS ranking
    FROM placas_"""+municipio+""" p JOIN manzanas_"""+municipio+""" m ON ST_Contains(m.geom,p.geom)
    WHERE p.principal LIKE ANY (ARRAY['BRR %','CDE %','CND %','CJR %','MTF %','URD %','URB %','UND %','EDI %','AGP %','KDX %'])
    AND p.generadora IS NOT NULL
    GROUP BY m.id, p.principal, p.generadora);

    DROP TABLE IF EXISTS puntos_mza_casa_"""+municipio+""";

    CREATE TABLE puntos_mza_casa_"""+municipio+""" AS (
    SELECT a.id, a.principal, a.generadora, ST_PointOnSurface(m.geom) AS geom FROM aux_mza_cas a JOIN manzanas_"""+municipio+""" m ON a.id = m.id
    WHERE a.ranking = 1);
    
    CREATE INDEX spatial_index_puntos_mza_casa ON puntos_mza_casa_"""+municipio+""" USING GIST (geom);

    DROP TABLE IF EXISTS aux_mza_cas;   
    
    """
    
    print(query)
    return query
