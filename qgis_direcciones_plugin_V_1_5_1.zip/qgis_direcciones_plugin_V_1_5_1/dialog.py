import csv
import os
import re
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
)
from qgis.core import (
    Qgis,
    QgsDataSourceUri,
    QgsProject,
    QgsVectorLayer,
    QgsFields,
    QgsField,
    QgsWkbTypes,
    QgsProviderRegistry,
    QgsMessageLog,
)
from qgis.PyQt.QtCore import QVariant


class EstandarizacionDialog(QDialog):
    def __init__(self, iface):
        super().__init__(iface.mainWindow())
        self.iface = iface
        self._pg_conn = None
        self._pg_conn_info = None
        self._pg_dir_norm_ready_info = None
        self._dict_replacements = None
        self.setWindowTitle("Estandarizacion y Comparacion de Direcciones")
        self.resize(520, 640)

        self.layer_base = QComboBox()
        self.layer_comp = QComboBox()

        self.base_fields = self._build_field_section(
            "Campos Base (Sitidata)",
            [
                "via_princ",
                "via_sec",
                "compl",
                "placa",
                "direccion_final",
                "dir_antigua",
            ],
        )

        self.base_use_full_dir = QCheckBox("Capa base con direccion completa")
        self.base_dir_field = QComboBox()
        self.base_dir_antigua_field = QComboBox()

        self.comp_fields = self._build_field_section(
            "Campos Comparada (Telefonica)",
            [
                "via_princ",
                "via_sec",
                "compl",
                "placa",
                "direccion_final",
                "dir_antigua",
                "tipo_direccion",
            ],
        )

        self.tipo_direccion = QComboBox()
        self.srid = QLineEdit("4326")
        self.placa_sep = QLineEdit("/")
        self.use_centroids = QCheckBox("Usar centroides para capa comparada")
        self.use_centroids.setChecked(True)

        self.out_desag = QCheckBox("Crear direcciones_desagregadas")
        self.out_igual = QCheckBox("Crear similitud_igual")
        self.out_analisis = QCheckBox("Crear analisis")
        self.out_existe = QCheckBox("Crear existe_lineas")
        for box in (self.out_desag, self.out_igual, self.out_analisis, self.out_existe):
            box.setChecked(True)

        self.out_prefix = QLineEdit("comparacion_capas")

        self.btn_validate = QPushButton("Validar campos")
        self.btn_run = QPushButton("Ejecutar")
        self.btn_clear = QPushButton("Limpiar")

        self.btn_validate.clicked.connect(self.validate_fields)
        self.btn_run.clicked.connect(self.execute)
        self.btn_clear.clicked.connect(self.clear_form)

        self.layer_base.currentIndexChanged.connect(self._on_base_layer_changed)
        self.layer_comp.currentIndexChanged.connect(self._on_comp_layer_changed)
        self.base_use_full_dir.toggled.connect(self._toggle_base_dir_mode)
        self.comp_fields["combos"]["tipo_direccion"].currentIndexChanged.connect(
            self._refresh_tipo_direccion_options
        )

        self._build_layout()
        self.refresh_layers()

    def _build_layout(self):
        layout = QVBoxLayout()

        layer_form = QFormLayout()
        layer_form.addRow("Capa 1 (Base):", self.layer_base)
        layer_form.addRow("Capa 2 (Comparada):", self.layer_comp)
        layout.addLayout(layer_form)

        layout.addWidget(self.base_fields["label"])
        layout.addLayout(self.base_fields["form"])

        base_dir_form = QFormLayout()
        base_dir_form.addRow(self.base_use_full_dir)
        base_dir_form.addRow("Campo direccion base:", self.base_dir_field)
        base_dir_form.addRow("Campo dir_antigua base:", self.base_dir_antigua_field)
        layout.addLayout(base_dir_form)

        layout.addWidget(self.comp_fields["label"])
        layout.addLayout(self.comp_fields["form"])

        params_label = QLabel("Parametros")
        params_label.setStyleSheet("font-weight: bold;")
        layout.addWidget(params_label)

        params_form = QFormLayout()
        params_form.addRow("Tipo direccion:", self.tipo_direccion)
        params_form.addRow("SRID salida:", self.srid)
        params_form.addRow("Separador placas:", self.placa_sep)
        params_form.addRow("", self.use_centroids)
        layout.addLayout(params_form)

        outputs_label = QLabel("Salidas")
        outputs_label.setStyleSheet("font-weight: bold;")
        layout.addWidget(outputs_label)
        layout.addWidget(self.out_desag)
        layout.addWidget(self.out_igual)
        layout.addWidget(self.out_analisis)
        layout.addWidget(self.out_existe)

        out_form = QFormLayout()
        out_form.addRow("Prefijo salida:", self.out_prefix)
        layout.addLayout(out_form)

        buttons = QHBoxLayout()
        buttons.addWidget(self.btn_validate)
        buttons.addWidget(self.btn_run)
        buttons.addWidget(self.btn_clear)
        layout.addLayout(buttons)

        self.setLayout(layout)

    def _build_field_section(self, title, field_names):
        label = QLabel(title)
        label.setStyleSheet("font-weight: bold;")
        form = QFormLayout()
        combos = {}
        for name in field_names:
            combo = QComboBox()
            combos[name] = combo
            form.addRow(f"{name}:", combo)
        return {"label": label, "form": form, "combos": combos}

    def refresh_layers(self):
        self.layer_base.clear()
        self.layer_comp.clear()
        layers = [l for l in QgsProject.instance().mapLayers().values() if isinstance(l, QgsVectorLayer)]

        for layer in layers:
            self.layer_base.addItem(layer.name(), layer.id())
            self.layer_comp.addItem(layer.name(), layer.id())

        self._on_base_layer_changed()
        self._on_comp_layer_changed()

    def _on_base_layer_changed(self):
        layer = self._get_layer(self.layer_base)
        self._populate_field_combos(layer, self.base_fields["combos"])
        self._populate_field_combos(layer, {"direccion_base": self.base_dir_field})
        self._populate_field_combos(layer, {"dir_antigua_base": self.base_dir_antigua_field})
        if layer and "direccion_final" in [f.name() for f in layer.fields()]:
            self.base_dir_field.setCurrentText("direccion_final")
        if layer and "dir_antigua" in [f.name() for f in layer.fields()]:
            self.base_dir_antigua_field.setCurrentText("dir_antigua")
        self._toggle_base_dir_mode()

    def _on_comp_layer_changed(self):
        layer = self._get_layer(self.layer_comp)
        self._populate_field_combos(layer, self.comp_fields["combos"])
        self._refresh_tipo_direccion_options()

    def _populate_field_combos(self, layer, combos):
        fields = [f.name() for f in layer.fields()] if layer else []
        for name, combo in combos.items():
            combo.blockSignals(True)
            combo.clear()
            combo.addItems(fields)
            if name in fields:
                combo.setCurrentText(name)
            combo.blockSignals(False)

    def _refresh_tipo_direccion_options(self):
        current = self.tipo_direccion.currentText()
        self.tipo_direccion.blockSignals(True)
        self.tipo_direccion.clear()
        fixed_options = [
            "SIN FILTRO",
            "CL KR - COMPLETA",
            "CL KR - INCOMPLETA",
            "CL KR - SP",
            "INDEFINIDA",
            "LTE - ZNV",
            "MZ CASA - COMPLETA",
            "MZ CASA - INCOMPLETA",
            "SN",
        ]
        self.tipo_direccion.addItems(fixed_options)

        if current and current in [self.tipo_direccion.itemText(i) for i in range(self.tipo_direccion.count())]:
            self.tipo_direccion.setCurrentText(current)
        else:
            self.tipo_direccion.setCurrentIndex(0)
        self.tipo_direccion.blockSignals(False)

    def _toggle_base_dir_mode(self):
        use_full_dir = self.base_use_full_dir.isChecked()
        for combo in self.base_fields["combos"].values():
            combo.setEnabled(not use_full_dir)
        self.base_dir_field.setEnabled(use_full_dir)
        self.base_dir_antigua_field.setEnabled(use_full_dir)

    def _get_layer(self, combo):
        layer_id = combo.currentData()
        if not layer_id:
            return None
        return QgsProject.instance().mapLayer(layer_id)

    def validate_fields(self):
        errors = self._validate_required_fields()
        if errors:
            QMessageBox.warning(self, "Validacion", "\n".join(errors))
            return False
        message_lines = ["Campos OK."]
        base_layer = self._get_layer(self.layer_base)
        if base_layer:
            base_uri = QgsDataSourceUri(base_layer.dataProvider().dataSourceUri())
            schema, table, _ = self._get_table_info(base_layer)
            if self.base_use_full_dir.isChecked():
                field_name = self.base_dir_field.currentText().strip()
            else:
                field_name = self.base_fields["combos"]["direccion_final"].currentText().strip()
            if field_name:
                kc_msg = self._run_kc_direccion_fix(base_uri, schema, table, field_name)
                if kc_msg:
                    message_lines.append(kc_msg)
        QMessageBox.information(self, "Validacion", "\n".join(message_lines))
        return True

    def _validate_required_fields(self):
        errors = []
        base_layer = self._get_layer(self.layer_base)
        comp_layer = self._get_layer(self.layer_comp)

        if not base_layer:
            errors.append("Seleccione Capa 1 (Base).")
        if not comp_layer:
            errors.append("Seleccione Capa 2 (Comparada).")

        if base_layer:
            if self.base_use_full_dir.isChecked():
                if self.base_dir_field.currentText() == "":
                    errors.append("Campo base faltante: direccion_base.")
            else:
                for name, combo in self.base_fields["combos"].items():
                    if combo.currentText() == "":
                        errors.append(f"Campo base faltante: {name}.")

        if comp_layer:
            for name, combo in self.comp_fields["combos"].items():
                if combo.currentText() == "":
                    errors.append(f"Campo comparada faltante: {name}.")

        if base_layer and base_layer.providerType() != "postgres":
            errors.append("Capa 1 debe ser PostGIS (provider postgres).")
        if comp_layer and comp_layer.providerType() != "postgres":
            errors.append("Capa 2 debe ser PostGIS (provider postgres).")

        if base_layer and comp_layer:
            base_uri = QgsDataSourceUri(base_layer.dataProvider().dataSourceUri())
            comp_uri = QgsDataSourceUri(comp_layer.dataProvider().dataSourceUri())
            if not self._same_connection(base_uri, comp_uri):
                errors.append("Ambas capas deben estar en la misma conexion PostGIS.")

        return errors

    def _run_kc_direccion_fix(self, base_uri, schema, table, field_name):
        table_ref = f"{self._qi(schema)}.{self._qi(table)}"
        field_ref = self._qi(field_name)
        select_sql = (
            f"SELECT {self._qi('fid')}, {field_ref} "
            f"FROM {table_ref} "
            f"WHERE {field_ref} ~ '^(K[0-9]|C[0-9])';"
        )
        rows = self._fetch_pg_sql(base_uri, select_sql, "No se pudo validar errores K/C.")
        if not rows:
            return "Validacion K/C: 0 registros con K/C sin espacio."

        preview = ", ".join(
            f"{row[0]}: {row[1]}" for row in rows[:10] if row and len(row) > 1
        )
        if preview:
            QgsMessageLog.logMessage(
                f"Validacion K/C (primeros 10): {preview}",
                "Estandarizacion",
                Qgis.Info,
            )

        fix_sql = (
            f"UPDATE {table_ref} "
            f"SET {field_ref} = regexp_replace({field_ref}, '^(K|C)([0-9]+)', '\\1 \\2') "
            f"WHERE {field_ref} ~ '^(K[0-9]|C[0-9])';"
        )
        if not self._execute_pg_sql(base_uri, fix_sql, "No se pudo corregir errores K/C."):
            return "Validacion K/C: se encontraron errores pero no se corrigieron."

        estandar_sql = (
            f"UPDATE {table_ref} "
            f"SET {field_ref} = regexp_replace("
            "    regexp_replace("
            "        regexp_replace("
            "            regexp_replace("
            "                regexp_replace("
            f"                    regexp_replace({field_ref}, '^(K|C)([0-9]+)', '\\1 \\2'),"
            "                '^(CLL )', 'CL '),"
            "            '^(K )', 'KR '),"
            "        '^(C )', 'CL '),"
            "    '^(A )', 'AV '),"
            "' +', ' ') "
            f"WHERE {field_ref} ~ '^(K[0-9]|C[0-9]|CLL |K |C |A )';"
        )
        if not self._execute_pg_sql(base_uri, estandar_sql, "No se pudo estandarizar errores K/C."):
            return "Validacion K/C: se corrigio pero no se estandarizo."

        return f"Validacion K/C: {len(rows)} registros corregidos y estandarizados."

    def execute(self):
        if not self.validate_fields():
            return

        prefix = self.out_prefix.text().strip()
        if not prefix:
            QMessageBox.warning(self, "Ejecucion", "Defina un prefijo de salida.")
            return

        base_layer = self._get_layer(self.layer_base)
        comp_layer = self._get_layer(self.layer_comp)
        if not base_layer:
            QMessageBox.warning(self, "Ejecucion", "No se encontro la capa base.")
            return
        if not comp_layer:
            QMessageBox.warning(self, "Ejecucion", "No se encontro la capa comparada.")
            return

        if not self.use_centroids.isChecked():
            if comp_layer.geometryType() != QgsWkbTypes.PointGeometry:
                QMessageBox.warning(
                    self,
                    "Ejecucion",
                    "La capa comparada no es de puntos. Active 'Usar centroides'.",
                )
                return

        base_uri = QgsDataSourceUri(base_layer.dataProvider().dataSourceUri())
        comp_uri = QgsDataSourceUri(comp_layer.dataProvider().dataSourceUri())
        if not self._ensure_schema(base_uri, "proceso"):
            return

        base_schema, base_table, base_geom = self._get_table_info(base_layer)
        comp_schema, comp_table, comp_geom = self._get_table_info(comp_layer)

        base_id = self._get_id_field(base_layer)
        comp_id = self._get_id_field(comp_layer)
        if not base_id or not comp_id:
            QMessageBox.warning(
                self,
                "Ejecucion",
                "No se encontro un campo ID en una de las capas."
                " Defina clave primaria o un campo 'id'.",
            )
            return

        srid = self.srid.text().strip() or "4326"
        placa_sep = self.placa_sep.text().strip() or "/"
        tipo_dir = self.tipo_direccion.currentText().strip()

        out_schema = "proceso"
        desag_table = f"{prefix}_direcciones_desagregadas"
        igual_table = f"{prefix}_similitud_igual"
        analisis_table = f"{prefix}_analisis"
        existe_lineas_table = f"{prefix}_existe_lineas"

        base_fields = {name: combo.currentText() for name, combo in self.base_fields["combos"].items()}
        comp_fields = {name: combo.currentText() for name, combo in self.comp_fields["combos"].items()}

        if self.base_use_full_dir.isChecked():
            base_dir_field = self.base_dir_field.currentText().strip()
            if not base_dir_field:
                QMessageBox.warning(self, "Ejecucion", "Seleccione el campo de direccion base.")
                return

            base_desag_table = f"{prefix}_base_desag"
            dir_antigua_field = self.base_dir_antigua_field.currentText().strip()
            dir_antigua_expr = (
                self._qi(dir_antigua_field)
                if dir_antigua_field
                else "NULL::text"
            )
            use_pg_dir_funcs = self._ensure_dir_norm_functions(base_uri)
            if use_pg_dir_funcs:
                dir_base_expr = f"pg_temp.fn_dir_base({self._qi(base_dir_field)})"
            else:
                dir_base_expr = self._get_dir_base_sql_expr(self._qi(base_dir_field))
            dir_components = self._build_dir_component_exprs(
                self._qi(base_dir_field),
                dir_base_col="dir_base",
            )
            if use_pg_dir_funcs:
                dir_components["dir_norm_expr"] = "pg_temp.fn_dir_norm(dir_base)"
            dir_norm_expr = dir_components["dir_norm_expr"]
            via_princ_expr = dir_components["via_princ_expr"]
            via_sec_expr = dir_components["via_sec_expr"]
            placa_expr = dir_components["placa_expr"]
            compl_expr = dir_components["compl_expr"]

            base_desag_sql = (
                f"DROP TABLE IF EXISTS {self._qi(out_schema)}.{self._qi(base_desag_table)}; "
                f"CREATE UNLOGGED TABLE {self._qi(out_schema)}.{self._qi(base_desag_table)} AS "
                "WITH base_norm AS ("
                "SELECT "
                f"{self._qi(base_id)} AS id, "
                f"{self._qi(base_geom)} AS geom, "
                f"{dir_antigua_expr} AS dir_antigua, "
                f"{dir_base_expr} AS dir_base "
                f"FROM {self._qi(base_schema)}.{self._qi(base_table)}"
                ") "
                "SELECT "
                "id, geom, dir_antigua, dir_norm, dir_norm AS direccion_final, "
                f"{via_princ_expr} AS via_princ, "
                f"{via_sec_expr} AS via_sec, "
                f"{placa_expr} AS placa, "
                f"{compl_expr} AS compl "
                "FROM ("
                "SELECT "
                "id, geom, dir_antigua, "
                f"{dir_norm_expr} AS dir_norm "
                "FROM base_norm"
                ") AS base_norm_parsed; "
                f"CREATE INDEX idx_{base_desag_table}_geom ON {self._qi(out_schema)}.{self._qi(base_desag_table)} USING GIST (geom);"
            )

            if not self._execute_pg_sql(base_uri, base_desag_sql, "No se pudo crear base_desag."):
                return
            self._try_execute_pg_sql(
                base_uri,
                f"ANALYZE {self._qi(out_schema)}.{self._qi(base_desag_table)};",
            )

            base_schema = out_schema
            base_table = base_desag_table
            base_geom = "geom"
            base_id = "id"
            base_fields = {
                "via_princ": "via_princ",
                "via_sec": "via_sec",
                "compl": "compl",
                "placa": "placa",
                "direccion_final": "direccion_final",
                "dir_antigua": "dir_antigua",
            }

        created = []

        needs_desag = self.out_desag.isChecked() or self.out_igual.isChecked() or self.out_analisis.isChecked() or self.out_existe.isChecked()
        needs_igual = self.out_igual.isChecked() or self.out_analisis.isChecked() or self.out_existe.isChecked()
        needs_analisis = self.out_analisis.isChecked() or self.out_existe.isChecked()

        if needs_desag:
            geom_expr = "ST_Centroid({geom})" if self.use_centroids.isChecked() else "{geom}"
            where_tipo = ""
            if tipo_dir and tipo_dir != "SIN FILTRO":
                where_tipo = (
                    f"WHERE {self._qi(comp_fields['tipo_direccion'])}::text = '{self._sql_literal(tipo_dir)}'; "
                )
            comp_via_princ_expr = self._normalize_dir_sql_expr(self._qi(comp_fields["via_princ"]))
            comp_via_sec_expr = self._normalize_dir_sql_expr(self._qi(comp_fields["via_sec"]))
            comp_compl_expr = self._normalize_dir_sql_expr(self._qi(comp_fields["compl"]))
            comp_placa_expr = self._normalize_dir_sql_expr(self._qi(comp_fields["placa"]))
            comp_dir_final_expr = self._normalize_dir_sql_expr(self._qi(comp_fields["direccion_final"]))
            comp_dir_antigua_expr = self._normalize_dir_sql_expr(self._qi(comp_fields["dir_antigua"]))

            desag_sql = (
                f"DROP TABLE IF EXISTS {self._qi(out_schema)}.{self._qi(desag_table)}; "
                f"CREATE UNLOGGED TABLE {self._qi(out_schema)}.{self._qi(desag_table)} AS "
                "SELECT "
                f"{self._qi(comp_id)} AS id, "
                f"{geom_expr.format(geom=self._qi(comp_geom))}::geometry(Point, {srid}) AS geom_punto, "
                f"{comp_via_princ_expr} AS via_princ, "
                f"{comp_via_sec_expr} AS via_sec, "
                f"{comp_compl_expr} AS compl, "
                f"TRIM(regexp_split_to_table({comp_placa_expr}, '{self._sql_literal(placa_sep)}')) AS placa_indiv, "
                f"{comp_dir_final_expr} AS direccion_final, "
                f"{comp_dir_antigua_expr} AS dir_antigua, "
                f"CASE "
                f"    WHEN ST_SRID({self._qi(comp_geom)}) = 3116 THEN ST_Area({self._qi(comp_geom)}) "
                f"    ELSE ST_Area(ST_Transform({self._qi(comp_geom)}, 3116)) "
                f"END AS area_comp_m2, "
                f"{self._qi(comp_fields['tipo_direccion'])} AS tipo_direccion "
                f"FROM {self._qi(comp_schema)}.{self._qi(comp_table)} "
                f"{where_tipo}"
                f"; "
                f"CREATE INDEX idx_{desag_table}_geom ON {self._qi(out_schema)}.{self._qi(desag_table)} USING GIST (geom_punto); "
                f"CREATE INDEX idx_{desag_table}_id ON {self._qi(out_schema)}.{self._qi(desag_table)} (id);"
            )
            if not self._execute_pg_sql(base_uri, desag_sql, "No se pudo crear direcciones_desagregadas."):
                return
            self._try_execute_pg_sql(
                base_uri,
                f"ANALYZE {self._qi(out_schema)}.{self._qi(desag_table)};",
            )
            if self.out_desag.isChecked():
                if self._add_pg_layer(base_uri, out_schema, desag_table, "geom_punto"):
                    created.append(desag_table)

        if needs_igual:
            igual_sql = (
                f"DROP TABLE IF EXISTS {self._qi(out_schema)}.{self._qi(igual_table)}; "
                f"CREATE UNLOGGED TABLE {self._qi(out_schema)}.{self._qi(igual_table)} AS "
                "SELECT "
                f"b.id AS id_2, "
                f"a.{self._qi(base_id)} AS id_1, "
                "b.geom_punto, "
                "b.direccion_final "
                f"FROM {self._qi(out_schema)}.{self._qi(desag_table)} b "
                f"JOIN {self._qi(base_schema)}.{self._qi(base_table)} a ON a.{self._qi(base_geom)} && b.geom_punto AND ST_Intersects(a.{self._qi(base_geom)}, b.geom_punto) "
                f"WHERE b.direccion_final::text = a.{self._qi(base_fields['direccion_final'])}::text; "
                f"CREATE INDEX idx_{igual_table}_id2 ON {self._qi(out_schema)}.{self._qi(igual_table)} (id_2);"
            )
            if not self._execute_pg_sql(base_uri, igual_sql, "No se pudo crear similitud_igual."):
                return
            self._try_execute_pg_sql(
                base_uri,
                f"ANALYZE {self._qi(out_schema)}.{self._qi(igual_table)};",
            )
            if self.out_igual.isChecked():
                if self._add_pg_layer(base_uri, out_schema, igual_table, "geom_punto"):
                    created.append(igual_table)

        if needs_analisis:
            analisis_sql = (
                f"DROP TABLE IF EXISTS {self._qi(out_schema)}.{self._qi(analisis_table)}; "
                f"CREATE UNLOGGED TABLE {self._qi(out_schema)}.{self._qi(analisis_table)} AS "
                "WITH base_comparacion AS ("
                "SELECT "
                f"a.{self._qi(base_id)} AS id_1, p.id AS id_2, "
                f"split_part(TRIM(a.{self._qi(base_fields['via_princ'])}::text), ' ', 1) AS np1, "
                f"regexp_replace(regexp_replace(regexp_replace(regexp_replace(LTRIM(SUBSTRING(TRIM(a.{self._qi(base_fields['via_princ'])}::text) FROM length(split_part(TRIM(a.{self._qi(base_fields['via_princ'])}::text), ' ', 1)) + 2)), '([0-9])([A-Z])', '\\1 \\2', 'g'), '\\bETA\\b', 'ET', 'gi'), '\\bET\\.?\\b', 'ET', 'gi'), '\\s+', ' ', 'g') AS p1, "
                f"split_part(TRIM(a.{self._qi(base_fields['via_sec'])}::text), ' ', 1) AS ng1, "
                f"regexp_replace(LTRIM(SUBSTRING(TRIM(a.{self._qi(base_fields['via_sec'])}::text) FROM length(split_part(TRIM(a.{self._qi(base_fields['via_sec'])}::text), ' ', 1)) + 2)), '([0-9])([A-Z])', '\\1 \\2', 'g') AS g1, "
                f"COALESCE(a.{self._qi(base_fields['compl'])}::text, '') AS c1, "
                f"TRIM(regexp_replace(regexp_replace(COALESCE(a.{self._qi(base_fields['compl'])}::text, ''), '\\yINT\\y', 'IN', 'gi'), '\\y0+([0-9]+)\\y', '\\1', 'g')) AS c1_cmp, "
                f"a.{self._qi(base_fields['placa'])}::text AS pl1, a.{self._qi(base_fields['direccion_final'])}::text AS df1, a.{self._qi(base_fields['dir_antigua'])}::text AS da1, "
                f"split_part(TRIM(p.via_princ::text), ' ', 1) AS np2, "
                f"regexp_replace(regexp_replace(regexp_replace(regexp_replace(LTRIM(SUBSTRING(TRIM(p.via_princ::text) FROM length(split_part(TRIM(p.via_princ::text), ' ', 1)) + 2)), '([0-9])([A-Z])', '\\1 \\2', 'g'), '\\bETA\\b', 'ET', 'gi'), '\\bET\\.?\\b', 'ET', 'gi'), '\\s+', ' ', 'g') AS p2, "
                f"split_part(TRIM(p.via_sec::text), ' ', 1) AS ng2, "
                f"regexp_replace(LTRIM(SUBSTRING(TRIM(p.via_sec::text) FROM length(split_part(TRIM(p.via_sec::text), ' ', 1)) + 2)), '([0-9])([A-Z])', '\\1 \\2', 'g') AS g2, "
                f"COALESCE(p.compl::text, '') AS c2, "
                f"TRIM(regexp_replace(regexp_replace(COALESCE(p.compl::text, ''), '\\yINT\\y', 'IN', 'gi'), '\\y0+([0-9]+)\\y', '\\1', 'g')) AS c2_cmp, "
                f"p.placa_indiv::text AS pl2, p.direccion_final::text AS df2, p.dir_antigua::text AS da2, "
                f"regexp_replace(regexp_replace(p.direccion_final::text, '\\yCS\\y', 'CAS', 'gi'), '\\y0+([0-9]+)\\y', '\\1', 'g') AS df2_cmp, "
                f"CASE "
                f"    WHEN split_part(TRIM(a.{self._qi(base_fields['via_sec'])}::text), ' ', 1) IN ('MZ', 'MZA') THEN 'MZA' "
                f"    ELSE split_part(TRIM(a.{self._qi(base_fields['via_sec'])}::text), ' ', 1) "
                f"END AS ng1_cmp, "
                f"CASE "
                f"    WHEN split_part(TRIM(p.via_sec::text), ' ', 1) IN ('MZ', 'MZA') THEN 'MZA' "
                f"    ELSE split_part(TRIM(p.via_sec::text), ' ', 1) "
                f"END AS ng2_cmp, "
                f"regexp_replace(LTRIM(SUBSTRING(TRIM(a.{self._qi(base_fields['via_sec'])}::text) FROM length(split_part(TRIM(a.{self._qi(base_fields['via_sec'])}::text), ' ', 1)) + 2)), '\\y0+([0-9]+)\\y', '\\1', 'g') AS g1_cmp, "
                f"regexp_replace(LTRIM(SUBSTRING(TRIM(p.via_sec::text) FROM length(split_part(TRIM(p.via_sec::text), ' ', 1)) + 2)), '\\y0+([0-9]+)\\y', '\\1', 'g') AS g2_cmp, "
                f"TRIM(regexp_replace(regexp_replace(regexp_replace(a.{self._qi(base_fields['placa'])}::text, '\\yCS\\y', 'CAS', 'gi'), '\\y0+([0-9]+)\\y', '\\1', 'g'), '\\s+', ' ', 'g')) AS pl1_cmp, "
                f"TRIM(regexp_replace(regexp_replace(regexp_replace(p.placa_indiv::text, '\\yCS\\y', 'CAS', 'gi'), '\\y0+([0-9]+)\\y', '\\1', 'g'), '\\s+', ' ', 'g')) AS pl2_cmp, "
                "p.geom_punto, "
                f"CASE "
                f"    WHEN ST_SRID(a.{self._qi(base_geom)}) = 3116 THEN ST_Area(a.{self._qi(base_geom)}) "
                f"    ELSE ST_Area(ST_Transform(a.{self._qi(base_geom)}, 3116)) "
                f"END AS area_base_m2, "
                "p.area_comp_m2 AS area_comp_m2 "
                f"FROM {self._qi(out_schema)}.{self._qi(desag_table)} p "
                f"JOIN {self._qi(base_schema)}.{self._qi(base_table)} a ON a.{self._qi(base_geom)} && p.geom_punto AND ST_Intersects(a.{self._qi(base_geom)}, p.geom_punto) "
                f"LEFT JOIN {self._qi(out_schema)}.{self._qi(igual_table)} s ON p.id = s.id_2 "
                "WHERE s.id_2 IS NULL"
                "), "
                "base_cmp_norm AS ("
                "SELECT *, "
                "regexp_replace(p1, '\\y0+([0-9]+)\\y', '\\1', 'g') AS p1_cmp, "
                "regexp_replace(p2, '\\y0+([0-9]+)\\y', '\\1', 'g') AS p2_cmp "
                "FROM base_comparacion"
                ") "
                "SELECT "
                "id_1, id_2, "
                "CASE "
                "    WHEN NULLIF(TRIM(COALESCE(np1, '')), '') IS NULL "
                "     AND NULLIF(TRIM(COALESCE(p1, '')), '') IS NULL "
                "     AND NULLIF(TRIM(COALESCE(ng1, '')), '') IS NULL "
                "     AND NULLIF(TRIM(COALESCE(g1, '')), '') IS NULL "
                "     AND NULLIF(TRIM(COALESCE(c1, '')), '') IS NULL "
                "     AND NULLIF(TRIM(COALESCE(pl1, '')), '') IS NULL "
                "    THEN df1 "
                "    ELSE np1 "
                "END AS nivel_p1, p1, ng1 AS nivel_g1, g1, c1 AS compl1, pl1 AS placa1, df1 AS direccion_final1, da1 AS dir_antigua1, "
                "np2 AS nivel_p2, p2, ng2 AS nivel_g2, g2, c2 AS compl2, pl2 AS placa2, "
                "df2 AS direccion_final2, da2 AS dir_antigua2, "
                "TRIM(BOTH ', ' FROM "
                "    CASE WHEN np1 != np2 THEN 'nivel_p1, ' ELSE '' END || "
                "    CASE WHEN p1_cmp != p2_cmp THEN 'p1, ' ELSE '' END || "
                "    CASE WHEN ng1_cmp != ng2_cmp THEN 'nivel_g1, ' ELSE '' END || "
                "    CASE WHEN g1_cmp != g2_cmp THEN 'g1, ' ELSE '' END || "
                "    CASE WHEN c1_cmp != c2_cmp THEN 'compl, ' ELSE '' END || "
                "    CASE WHEN pl1_cmp != pl2_cmp AND pl1_cmp NOT LIKE '%' || pl2_cmp || '%' AND pl2_cmp NOT LIKE '%' || pl1_cmp || '%' AND df2_cmp NOT LIKE '%' || pl1_cmp || '%' THEN 'placa' ELSE '' END "
                ") AS validador, "
                "CASE "
                "    WHEN COALESCE(np1, '') = COALESCE(np2, '') "
                "     AND COALESCE(p1_cmp, '') = COALESCE(p2_cmp, '') "
                "     AND COALESCE(ng1_cmp, '') = COALESCE(ng2_cmp, '') "
                "     AND COALESCE(g1_cmp, '') = COALESCE(g2_cmp, '') "
                "     AND ("
                "         COALESCE(pl1_cmp, '') LIKE '%' || COALESCE(pl2_cmp, '') || '%' "
                "         OR COALESCE(pl2_cmp, '') LIKE '%' || COALESCE(pl1_cmp, '') || '%' "
                "         OR COALESCE(df2_cmp, '') LIKE '%' || COALESCE(pl1_cmp, '') || '%' "
                "     ) THEN 'contenida' "
                "    ELSE 'diferente' "
                "END AS tipo_relacion, "
                "CASE "
                "    WHEN area_base_m2 IS NULL OR area_base_m2 = 0 THEN NULL "
                "    ELSE ROUND((100.0 - ((ABS(area_base_m2 - area_comp_m2) / NULLIF(area_base_m2, 0)) * 100.0))::numeric, 2) "
                "END AS area_similitud_pct, "
                "geom_punto "
                "FROM base_cmp_norm;"
            )
            if not self._execute_pg_sql(base_uri, analisis_sql, "No se pudo crear analisis."):
                return
            self._try_execute_pg_sql(
                base_uri,
                f"CREATE INDEX idx_{analisis_table}_niveles ON {self._qi(out_schema)}.{self._qi(analisis_table)} (nivel_p2, p2, nivel_g2, g2);",
            )
            self._try_execute_pg_sql(
                base_uri,
                f"ANALYZE {self._qi(out_schema)}.{self._qi(analisis_table)};",
            )
            if self.out_analisis.isChecked():
                if self._add_pg_layer(base_uri, out_schema, analisis_table, "geom_punto"):
                    created.append(analisis_table)

        if self.out_existe.isChecked():
            existe_sql = (
                f"DROP TABLE IF EXISTS {self._qi(out_schema)}.{self._qi(existe_lineas_table)}; "
                f"CREATE UNLOGGED TABLE {self._qi(out_schema)}.{self._qi(existe_lineas_table)} AS "
                "WITH base_centroid AS ("
                "SELECT pb.*, "
                "    ST_Centroid(pb.{geom}) AS centroid_geom, "
                "    CASE "
                "        WHEN ST_SRID(ST_Centroid(pb.{geom})) = 3116 THEN ST_Centroid(pb.{geom}) "
                "        ELSE ST_Transform(ST_Centroid(pb.{geom}), 3116) "
                "    END AS centroid_geom_3116, "
                "    split_part(TRIM(pb.{via_princ}::text), ' ', 1) AS via_princ_nivel, "
                "    LTRIM(SUBSTRING(TRIM(pb.{via_princ}::text) FROM length(split_part(TRIM(pb.{via_princ}::text), ' ', 1)) + 2)) AS via_princ_resto, "
                "    split_part(TRIM(pb.{via_sec}::text), ' ', 1) AS via_sec_nivel, "
                "    LTRIM(SUBSTRING(TRIM(pb.{via_sec}::text) FROM length(split_part(TRIM(pb.{via_sec}::text), ' ', 1)) + 2)) AS via_sec_resto "
                f"FROM {self._qi(base_schema)}.{self._qi(base_table)} pb"
                "), "
                "analisis_pts AS ("
                "SELECT an.*, "
                "    CASE WHEN ST_SRID(an.geom_punto) = 3116 THEN an.geom_punto "
                "    ELSE ST_Transform(an.geom_punto, 3116) END AS geom_punto_3116 "
                f"FROM {self._qi(out_schema)}.{self._qi(analisis_table)} an"
                ") "
                "SELECT "
                "ap.id_2 AS id_punto_telef, "
                "ap.id_1 AS id_predio_donde_estaba, "
                f"bc.{self._qi(base_id)} AS id_predio_donde_se_encontro, "
                "ap.direccion_final2 AS direccion_buscada_telef, "
                f"bc.{self._qi(base_fields['direccion_final'])} AS direccion_encontrada_bogota, "
                "CASE "
                "    WHEN ap.direccion_final2 = bc.{dir_final} THEN 'igual_reubicado' "
                "    ELSE 'contenida_reubicado' "
                "END AS tipo_hallazgo, "
                "ST_Distance(ap.geom_punto_3116, bc.centroid_geom_3116)::numeric(10,2) AS distancia_salto_metros, "
                "ST_MakeLine(ap.geom_punto, bc.centroid_geom)::geometry(LineString, 4326) AS geom "
                "FROM analisis_pts ap "
                "INNER JOIN base_centroid bc ON "
                "ap.nivel_p2 = bc.via_princ_nivel AND "
                "ap.p2 = bc.via_princ_resto AND "
                "ap.nivel_g2 = bc.via_sec_nivel AND "
                "ap.g2 = bc.via_sec_resto "
                "WHERE "
                "(ap.direccion_final2 = bc.{dir_final} OR bc.{placa} LIKE '%' || ap.placa2 || '%') "
                "AND NOT ST_Intersects(bc.{geom}, ap.geom_punto);"
            ).format(
                geom=self._qi(base_geom),
                via_princ=self._qi(base_fields["via_princ"]),
                via_sec=self._qi(base_fields["via_sec"]),
                dir_final=self._qi(base_fields["direccion_final"]),
                placa=self._qi(base_fields["placa"]),
            )
            if not self._execute_pg_sql(base_uri, existe_sql, "No se pudo crear existe_lineas."):
                return
            self._try_execute_pg_sql(
                base_uri,
                f"ANALYZE {self._qi(out_schema)}.{self._qi(existe_lineas_table)};",
            )
            if self._add_pg_layer(base_uri, out_schema, existe_lineas_table, "geom"):
                created.append(existe_lineas_table)

        if created:
            stats_lines = []
            validador_lines = []
            similitud_line = ""
            if needs_analisis:
                stats_lines = self._get_tipo_relacion_stats(
                    base_uri,
                    out_schema,
                    analisis_table,
                    igual_table,
                )
                validador_lines = self._get_validador_stats(
                    base_uri,
                    out_schema,
                    analisis_table,
                )
                total_analisis = 0
                total_igual = 0
                analisis_count_sql = (
                    f"SELECT COUNT(*) FROM {self._qi(out_schema)}.{self._qi(analisis_table)};"
                )
                igual_count_sql = (
                    f"SELECT COUNT(*) FROM {self._qi(out_schema)}.{self._qi(igual_table)};"
                )
                analisis_rows = self._fetch_pg_sql(
                    base_uri,
                    analisis_count_sql,
                    "No se pudo leer total de analisis.",
                )
                igual_rows = self._fetch_pg_sql(
                    base_uri,
                    igual_count_sql,
                    "No se pudo leer total de similitud_igual.",
                )
                if analisis_rows:
                    try:
                        total_analisis = int(analisis_rows[0][0])
                    except Exception:
                        total_analisis = 0
                if igual_rows:
                    try:
                        total_igual = int(igual_rows[0][0])
                    except Exception:
                        total_igual = 0
                total_comp = total_analisis + total_igual
                if total_comp > 0:
                    porcentaje = (total_igual / total_comp) * 100.0
                    similitud_line = f"Similitud (igual/total): {porcentaje:.2f}% ({total_igual}/{total_comp})"
            stats_text = ""
            if stats_lines:
                stats_text = "\n\nEstadisticas tipo_relacion:\n" + "\n".join(stats_lines)
            if similitud_line:
                stats_text = stats_text + "\n\n" + similitud_line
            if validador_lines:
                stats_text = stats_text + "\n\nCausas mas frecuentes (validador):\n" + "\n".join(validador_lines)
            QMessageBox.information(
                self,
                "Ejecucion",
                "capas creadas en: 'proceso':\n" + "\n".join(created) + stats_text,
            )
        else:
            QMessageBox.warning(self, "Ejecucion", "No se crearon capas.")

    def _create_pg_output_layer(self, base_uri, name, geom_type):
        srid = self.srid.text().strip() or "4326"
        wkb = QgsWkbTypes.displayString(geom_type)
        geom_column = "geom"

        fields = QgsFields()
        fields.append(QgsField("id_1", QVariant.Int))
        fields.append(QgsField("id_2", QVariant.Int))
        fields.append(QgsField("direccion_final1", QVariant.String))
        fields.append(QgsField("direccion_final2", QVariant.String))

        if not self._create_pg_table(base_uri, "proceso", name, geom_column, wkb, srid, fields):
            return None

        uri = QgsDataSourceUri()
        uri.setConnection(
            base_uri.host(),
            base_uri.port(),
            base_uri.database(),
            base_uri.username(),
            base_uri.password(),
        )
        uri.setDataSource("proceso", name, geom_column, "", "")
        layer = QgsVectorLayer(uri.uri(False), name, "postgres")
        if not layer.isValid():
            QMessageBox.warning(self, "Ejecucion", f"No se pudo cargar la capa {name}.")
            return None
        return layer

    def _get_table_info(self, layer):
        uri = QgsDataSourceUri(layer.dataProvider().dataSourceUri())
        schema = uri.schema() or "public"
        table = uri.table()
        geom_column = getattr(layer, "geometryColumnName", lambda: "")() or "geom"
        return schema, table, geom_column

    def _get_id_field(self, layer):
        provider = layer.dataProvider()
        pk_attrs = []
        pk_attrs = getattr(layer, "primaryKeyAttributes", lambda: [])() or pk_attrs
        pk_attrs = getattr(provider, "primaryKeyAttributes", lambda: pk_attrs)() or pk_attrs
        pk_attrs = getattr(provider, "pkAttributeIndexes", lambda: pk_attrs)() or pk_attrs
        if pk_attrs:
            return provider.fields()[pk_attrs[0]].name()
        if "id" in [f.name() for f in provider.fields()]:
            return "id"
        return ""

    def _add_pg_layer(self, base_uri, schema, table, geom_column):
        uri = QgsDataSourceUri()
        uri.setConnection(
            base_uri.host(),
            base_uri.port(),
            base_uri.database(),
            base_uri.username(),
            base_uri.password(),
        )
        uri.setDataSource(schema, table, geom_column, "", "")
        layer = QgsVectorLayer(uri.uri(False), table, "postgres")
        if not layer.isValid():
            QMessageBox.warning(self, "Ejecucion", f"No se pudo cargar la capa {table}.")
            return False
        QgsProject.instance().addMapLayer(layer)
        return True

    def _qi(self, name):
        safe = name.replace('"', '""')
        return f"\"{safe}\""

    def _sql_literal(self, value):
        return value.replace("'", "''")

    def _load_dict_replacements(self):
        if self._dict_replacements is not None:
            return self._dict_replacements

        replacements = {
            "UB": "URB",
            "BR": "BRR",
            "CS": "CAS",
            "TO": "TOR",
            "ET": "ETA",
            "CN": "CND",
            "IN": "INT",
            "CO": "CJR",
            "CR": "CJR",
            "SM": "SMA",
            "SC": "SEC",
            "MZ": "MZA",
        }

        csv_name = "Copia de 08_Estructura_base_diccionario_barrios_vias - 02_Diccionario_maestro.csv"
        csv_path = os.path.join(os.path.dirname(__file__), csv_name)
        try:
            with open(csv_path, mode="r", encoding="utf-8-sig", newline="") as handle:
                reader = csv.reader(handle)
                next(reader, None)
                for row in reader:
                    if len(row) < 2:
                        continue
                    term = row[0].strip().upper()
                    abbr = row[1].strip().upper()
                    if term:
                        replacements[term] = abbr
        except Exception as exc:
            QgsMessageLog.logMessage(
                f"No se pudo leer el diccionario: {exc}",
                "Estandarizacion",
                Qgis.Warning,
            )

        self._dict_replacements = sorted(
            replacements.items(), key=lambda item: len(item[0]), reverse=True
        )
        terms = [re.escape(term) for term, _ in self._dict_replacements]
        if terms:
            self._dict_pattern = "\\y(?:" + "|".join(terms) + ")\\y"
        else:
            self._dict_pattern = None
        return self._dict_replacements

    def _apply_dict_replacements_sql(self, expr):
        replacements = self._load_dict_replacements()
        if not replacements:
            return expr

        guard_pattern = getattr(self, "_dict_pattern", None)
        padded = f"(' ' || {expr} || ' ')"
        current = padded
        for term, abbr in replacements:
            term_sql = self._sql_literal(term)
            abbr_sql = self._sql_literal(abbr)
            current = (
                f"REPLACE({current}, ' {term_sql} ', ' {abbr_sql} ')"
            )
        current = f"TRIM({current})"
        if guard_pattern:
            current = (
                f"CASE WHEN {expr} ~* '{self._sql_literal(guard_pattern)}' "
                f"THEN {current} ELSE {expr} END"
            )
        return current

    def _apply_base_normalization_sql(self, expr):
        current = f"UPPER({expr})"
        current = f"REPLACE({current}, '.', '')"
        current = f"REGEXP_REPLACE({current}, '\\s*\\*\\s*', ' | ', 'g')"
        current = f"REPLACE({current}, '-', ' ')"
        current = f"REGEXP_REPLACE({current}, '\\s+', ' ', 'g')"
        current = (
            "TRANSLATE("
            f"{current}, "
            "CHR(8857) || CHR(193) || CHR(161) || CHR(191), "
            "CHR(209) || CHR(209) || CHR(209) || CHR(209)"
            ")"
        )
        current = f"REGEXP_REPLACE({current}, '\\y([A-Z])BIS\\y', '\\1 BIS', 'gi')"
        current = self._apply_dict_replacements_sql(current)
        current = f"REGEXP_REPLACE({current}, '\\yZU\\y', 'ZNA URB', 'gi')"
        current = f"REGEXP_REPLACE({current}, '\\yZEU\\y', 'ZNA EXT URB', 'gi')"
        current = (
            "REGEXP_REPLACE("
            f"{current}, "
            "'\\y(JUAN\\s+PABLO\\s+(?:I{1,3}|IV|VI{0,3}|IX|X))\\y', "
            "'__JP__\\1__JP__', 'gi'"
            ")"
        )
        current = (
            "REGEXP_REPLACE("
            f"{current}, "
            "'\\yMZA\\s+(I{1,3}|IV|VI{0,3}|IX|X)\\y', "
            "'__MZA__\\1', 'gi'"
            ")"
        )
        current = (
            "REGEXP_REPLACE("
            f"{current}, "
            "'\\y((?:CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\s+\\d+(?:\\s+[A-Z](?:\\s+\\d+)?)?)\\s+(I{1,3}|IV|VI{0,3}|IX|X)\\y', "
            "'\\1 __ROMCARD__\\2', 'gi'"
            ")"
        )
        current = (
            "REGEXP_REPLACE("
            f"{current}, "
            "'(?<!ETA\\s)\\y(I{1,3}|IV|VI{0,3}|IX|X)\\y', "
            "'ETA \\1', 'gi'"
            ")"
        )
        current = (
            "REGEXP_REPLACE("
            f"{current}, "
            "'__MZA__([IVXLCDM]+)', 'MZA \\1', 'g'"
            ")"
        )
        current = (
            "REGEXP_REPLACE("
            f"{current}, "
            "'__ROMCARD__([IVXLCDM]+)', '\\1', 'gi'"
            ")"
        )
        current = f"REGEXP_REPLACE({current}, '__JP__', '', 'g')"
        current = f"REGEXP_REPLACE({current}, '\\s+', ' ', 'g')"
        current = f"TRIM({current})"
        return current

    def _get_dir_base_sql_expr(self, base_dir_expr):
        expr = (
            f"REGEXP_REPLACE({base_dir_expr}::text, "
            "'\\s*#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\s*', ' \\1 ', 'gi')"
        )
        return self._apply_base_normalization_sql(expr)

    def _build_dir_base_fn_sql(self, fn_name="pg_temp.fn_dir_base"):
        replacements = self._load_dict_replacements()
        guard_values_sql = ", ".join(
            "('{0}')".format(term.replace("'", "''"))
            for term, _ in replacements
        )

        lines = [
            f"CREATE OR REPLACE FUNCTION {fn_name}(p_in text) RETURNS text",
            "LANGUAGE plpgsql IMMUTABLE PARALLEL SAFE AS $fn_dir_base$",
            "DECLARE v text; vpad text;",
            "BEGIN",
            "  IF p_in IS NULL THEN RETURN NULL; END IF;",
            "  v := REGEXP_REPLACE(p_in, '\\s*#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\s*', ' \\1 ', 'gi');",
            "  v := UPPER(v);",
            "  v := REPLACE(v, '.', '');",
            "  v := REGEXP_REPLACE(v, '\\s*\\*\\s*', ' | ', 'g');",
            "  v := REPLACE(v, '-', ' ');",
            "  v := REGEXP_REPLACE(v, '\\s+', ' ', 'g');",
            "  v := TRANSLATE(v, CHR(8857)||CHR(193)||CHR(161)||CHR(191), CHR(209)||CHR(209)||CHR(209)||CHR(209));",
            "  v := REGEXP_REPLACE(v, '\\y([A-Z])BIS\\y', '\\1 BIS', 'gi');",
        ]

        if replacements:
            lines.append("  vpad := ' ' || v || ' ';")
            if guard_values_sql:
                lines.append(
                    "  IF EXISTS ("
                    f"SELECT 1 FROM (VALUES {guard_values_sql}) AS dict(term) "
                    "WHERE POSITION(' ' || dict.term || ' ' IN vpad) > 0"
                    ") THEN"
                )
                lines.append("    v := vpad;")
                for term, abbr in replacements:
                    t = term.replace("'", "''")
                    a = abbr.replace("'", "''")
                    lines.append(f"    v := REPLACE(v, ' {t} ', ' {a} ');")
                lines.append("    v := TRIM(v);")
                lines.append("  END IF;")
            else:
                lines.append("  v := ' ' || v || ' ';")
                for term, abbr in replacements:
                    t = term.replace("'", "''")
                    a = abbr.replace("'", "''")
                    lines.append(f"  v := REPLACE(v, ' {t} ', ' {a} ');")
                lines.append("  v := TRIM(v);")

        lines += [
            "  v := REGEXP_REPLACE(v, '\\yZU\\y', 'ZNA URB', 'gi');",
            "  v := REGEXP_REPLACE(v, '\\yZEU\\y', 'ZNA EXT URB', 'gi');",
            "  v := REGEXP_REPLACE(v, '\\y(JUAN\\s+PABLO\\s+(?:I{1,3}|IV|VI{0,3}|IX|X))\\y', '__JP__\\1__JP__', 'gi');",
            "  v := REGEXP_REPLACE(v, '\\yMZA\\s+(I{1,3}|IV|VI{0,3}|IX|X)\\y', '__MZA__\\1', 'gi');",
            "  v := REGEXP_REPLACE(v, '\\y((?:CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\s+\\d+(?:\\s+[A-Z](?:\\s+\\d+)?)?)\\s+(I{1,3}|IV|VI{0,3}|IX|X)\\y', '\\1 __ROMCARD__\\2', 'gi');",
            "  v := REGEXP_REPLACE(v, '(?<!ETA\\s)\\y(I{1,3}|IV|VI{0,3}|IX|X)\\y', 'ETA \\1', 'gi');",
            "  v := REGEXP_REPLACE(v, '__MZA__([IVXLCDM]+)', 'MZA \\1', 'g');",
            "  v := REGEXP_REPLACE(v, '__ROMCARD__([IVXLCDM]+)', '\\1', 'gi');",
            "  v := REGEXP_REPLACE(v, '__JP__', '', 'g');",
            "  v := REGEXP_REPLACE(v, '\\s+', ' ', 'g');",
            "  v := TRIM(v);",
            "  RETURN v;",
            "END;",
            "$fn_dir_base$",
        ]
        return "\n".join(lines)

    def _build_dir_norm_fn_sql(self, fn_name="pg_temp.fn_dir_norm"):
        lines = [
            f"CREATE OR REPLACE FUNCTION {fn_name}(p_in text) RETURNS text",
            "LANGUAGE plpgsql IMMUTABLE PARALLEL SAFE AS $fn_dir_norm$",
            "DECLARE v text;",
            "BEGIN",
            "  IF p_in IS NULL THEN RETURN NULL; END IF;",
            "  v := p_in;",
            "  IF v ~* '^CL' AND v ~ '#' AND v !~* '#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\b' THEN",
            "    v := REGEXP_REPLACE(v, '\\s*#\\s*', ' KR ', 'gi');",
            "  ELSIF v ~* '^KR' AND v ~ '#' AND v !~* '#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\b' THEN",
            "    v := REGEXP_REPLACE(v, '\\s*#\\s*', ' CL ', 'gi');",
            "  END IF;",
            "  v := REGEXP_REPLACE(v, 'BR\\.\\s+', 'BRR ', 'gi');",
            "  v := REGEXP_REPLACE(v, 'UR\\.\\s+', 'URB ', 'gi');",
            "  v := REGEXP_REPLACE(v, 'UB\\.\\s+', 'URB ', 'gi');",
            "  v := REGEXP_REPLACE(v, 'CR\\.\\s+', 'CJR ', 'gi');",
            "  v := REGEXP_REPLACE(v, 'CN\\.\\s+', 'CND ', 'gi');",
            "  v := REGEXP_REPLACE(v, '\\bBL\\.?\\s+', 'BQU ', 'gi');",
            "  v := REGEXP_REPLACE(v, '\\bBLQ\\b', 'BQU', 'gi');",
            "  v := REGEXP_REPLACE(v, '\\bMZ\\b', 'MZA', 'gi');",
            "  v := REGEXP_REPLACE(v, '\\bCS\\b', 'CAS', 'gi');",
            "  v := REGEXP_REPLACE(v, '\\s*-\\s*', ' ', 'g');",
            "  v := REGEXP_REPLACE(v, '\\bLOTE\\b', 'LTE', 'gi');",
            "  v := REGEXP_REPLACE(v, '\\y([A-Z])BIS\\y', '\\1 BIS', 'gi');",
            "  v := REGEXP_REPLACE(v, '([0-9])([A-Z])', '\\1 \\2', 'gi');",
            "  v := REGEXP_REPLACE(v, '([A-Z])([0-9])', '\\1 \\2', 'gi');",
            "  v := REGEXP_REPLACE(v, '^\\s*C(\\s+[0-9])', 'CL\\1', 'g');",
            "  v := REGEXP_REPLACE(v, '^\\s*K(\\s+[0-9])', 'KR\\1', 'g');",
            "  v := REGEXP_REPLACE(v, '^\\s*T(\\s+[0-9])', 'TV\\1', 'g');",
            "  v := REGEXP_REPLACE(v, '\\s+', ' ', 'g');",
            "  RETURN v;",
            "END;",
            "$fn_dir_norm$",
        ]
        return "\n".join(lines)

    def _ensure_dir_norm_functions(self, base_uri):
        try:
            conn_info = base_uri.connectionInfo(True)
        except TypeError:
            conn_info = base_uri.connectionInfo()
        if not conn_info:
            conn_info = base_uri.uri(False)

        if self._pg_dir_norm_ready_info == conn_info:
            return True

        sql = self._build_dir_base_fn_sql() + ";\n" + self._build_dir_norm_fn_sql() + ";"
        if not self._try_execute_pg_sql(base_uri, sql):
            return False

        self._pg_dir_norm_ready_info = conn_info
        return True

    def _build_dir_component_exprs(self, base_dir_expr, dir_norm_ref="dir_norm", dir_base_col=None):
        if dir_base_col is not None:
            dir_base_expr = dir_base_col
        else:
            dir_base_expr = self._get_dir_base_sql_expr(base_dir_expr)

        via_token_full = (
            "(?:\\d+|[A-Z](?:\\s+\\d+)?|BIS(?:\\s+[A-Z])?|SUR|ESTE|NORTE|OESTE)"
        )
        via_segment = (
            "(?:CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\s+\\d+"
            f"(?:\\s+{via_token_full})*"
        )
        via_token_head = (
            "(?:[A-Z](?:\\s+\\d+)?|BIS(?:\\s+[A-Z])?|SUR|ESTE|NORTE|OESTE)"
        )
        via_segment_head = (
            "(?:CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\s+\\d+"
            f"(?:\\s+{via_token_head})*"
        )
        no_type_segment = f"\\d+(?:\\s+{via_token_head})*"
        pre_compl = "(?:CAS|CS|LTE|BDG|APT|LCA|OFI|IN)\\s+\\S+"
        dir_pattern = self._sql_literal(
            f"^({via_segment})\\s+(?:{pre_compl}\\s+)?({via_segment})\\s+\\S+"
        )
        extract_pattern = self._sql_literal(
            f"^({via_segment})\\s+((?:{pre_compl}\\s+)?)({via_segment})\\s+(\\S+)\\s*(.*)$"
        )
        missing_via_pattern = self._sql_literal(
            f"^({via_segment_head})\\s+((?:{pre_compl}\\s+)?)({no_type_segment})\\s+(\\S+)\\s*(.*)$"
        )
        no_placa_pattern = self._sql_literal(
            f"^({via_segment_head})\\s+((?:{pre_compl}\\s+)?)({via_segment_head})\\s*$"
        )
        no_placa_missing_via_pattern = self._sql_literal(
            f"^({via_segment_head})\\s+((?:{pre_compl}\\s+)?)({no_type_segment})\\s*$"
        )
        hash_num_pattern = (
            "\\d+(?:\\s+(?:[A-Z](?:\\s+\\d+)?|BIS(?:\\s+[A-Z])?|SUR|ESTE|NORTE|OESTE))*"
        )
        hash_pattern = self._sql_literal(
            f"^({via_segment})\\s*#\\s*({hash_num_pattern})\\s*(?:-\\s*)?"
            "([^\\s]+)\\s*(.*)$"
        )
        mz_full_pattern = self._sql_literal(
            "^(.*?)(?:\\s+ET\\.?\\s+[^ ]+)?\\s+"
            "(MZA|MZ|SMA|BQU|BIF|KDX|TOR|AGP|INT|SEC|ZNA)\\s+([^ ]+)\\s+"
            "(CAS|CS|LTE|BDG|APT|LCA|OFI|IN)\\s+([^ ]+)(?:\\s+(.*))?$"
        )
        cs_only_pattern = self._sql_literal(
            "^(.*?)(?:\\s+ET\\.?\\s+[^ ]+)?\\s+"
            "(CAS|CS|LTE|BDG|APT|LCA|OFI|IN)\\s+([^ ]+)(?:\\s+(.*))?$"
        )
        placa_strict_pattern = "[0-9]+(?:/[0-9]+)*"
        strict_typed_pattern = self._sql_literal(
            f"^({via_segment})\\s+((?:{pre_compl}\\s+)?)({via_segment})\\s+({placa_strict_pattern})\\s+(.+)$"
        )
        strict_missing_via_pattern = self._sql_literal(
            f"^({via_segment_head})\\s+((?:{pre_compl}\\s+)?)({no_type_segment})\\s+({placa_strict_pattern})\\s+(.+)$"
        )

        dir_norm_expr = (
            "REGEXP_REPLACE("
            "REGEXP_REPLACE("
            "REGEXP_REPLACE("
            "REGEXP_REPLACE("
            "REGEXP_REPLACE("
            "REGEXP_REPLACE("
            "REGEXP_REPLACE("
            "REGEXP_REPLACE("
            "REGEXP_REPLACE("
            "REGEXP_REPLACE("
            "REGEXP_REPLACE("
            "REGEXP_REPLACE("
            "REGEXP_REPLACE("
            "REGEXP_REPLACE("
            "REGEXP_REPLACE("
            "REGEXP_REPLACE("
            "REGEXP_REPLACE("
            "CASE "
            f"    WHEN {dir_base_expr} ~* '^CL' AND {dir_base_expr} ~* '#' AND {dir_base_expr} !~* '#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\b' THEN REGEXP_REPLACE({dir_base_expr}, '\\s*#\\s*', ' KR ', 'gi') "
            f"    WHEN {dir_base_expr} ~* '^KR' AND {dir_base_expr} ~* '#' AND {dir_base_expr} !~* '#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\b' THEN REGEXP_REPLACE({dir_base_expr}, '\\s*#\\s*', ' CL ', 'gi') "
            f"    ELSE {dir_base_expr} "
            "END, "
            "'BR\\.\\s+', 'BRR ', 'gi'), "
            "'UR\\.\\s+', 'URB ', 'gi'), "
            "'UB\\.\\s+', 'URB ', 'gi'), "
            "'CR\\.\\s+', 'CJR ', 'gi'), "
            "'CN\\.\\s+', 'CND ', 'gi'), "
            "'\\bBL\\.?\\s+', 'BQU ', 'gi'), "
            "'\\bBLQ\\b', 'BQU', 'gi'), "
            "'\\bMZ\\b', 'MZA', 'gi'), "
            "'\\bCS\\b', 'CAS', 'gi'), "
            "'\\s*-\\s*', ' ', 'g'), "
            "'\\bLOTE\\b', 'LTE', 'gi'), "
            "'\\y([A-Z])BIS\\y', '\\1 BIS', 'gi'), "
            "'([0-9])([A-Z])', '\\1 \\2', 'gi'), "
            "'([A-Z])([0-9])', '\\1 \\2', 'gi'), "
            "'^\\s*C(\\s+[0-9])', 'CL\\1', 'g'), "
            "'^\\s*K(\\s+[0-9])', 'KR\\1', 'g'), "
            "'^\\s*T(\\s+[0-9])', 'TV\\1', 'g'), "
            "'\\s+', ' ', 'g')"
        )

        via_princ_expr = (
            f"CASE "
            f"    WHEN {dir_norm_ref} ~* '{strict_typed_pattern}' THEN regexp_replace({dir_norm_ref}, '{strict_typed_pattern}', '\\1') "
            f"    WHEN {dir_norm_ref} ~* '{strict_missing_via_pattern}' THEN regexp_replace({dir_norm_ref}, '{strict_missing_via_pattern}', '\\1') "
            f"    WHEN {dir_norm_ref} ~* '{mz_full_pattern}' THEN TRIM(regexp_replace({dir_norm_ref}, '{mz_full_pattern}', '\\1')) "
            f"    WHEN {dir_norm_ref} ~* '{cs_only_pattern}' AND {dir_norm_ref} !~* '{dir_pattern}' AND {dir_norm_ref} !~* '{hash_pattern}' THEN TRIM(regexp_replace({dir_norm_ref}, '{cs_only_pattern}', '\\1')) "
            f"    WHEN {dir_norm_ref} ~* '{dir_pattern}' THEN regexp_replace({dir_norm_ref}, '{extract_pattern}', '\\1') "
            f"    WHEN {dir_norm_ref} ~* '{missing_via_pattern}' THEN regexp_replace({dir_norm_ref}, '{missing_via_pattern}', '\\1') "
            f"    WHEN {dir_norm_ref} ~* '{no_placa_pattern}' THEN regexp_replace({dir_norm_ref}, '{no_placa_pattern}', '\\1') "
            f"    WHEN {dir_norm_ref} ~* '{no_placa_missing_via_pattern}' THEN regexp_replace({dir_norm_ref}, '{no_placa_missing_via_pattern}', '\\1') "
            f"    WHEN {dir_norm_ref} ~* '{hash_pattern}' THEN regexp_replace({dir_norm_ref}, '{hash_pattern}', '\\1') "
            f"    WHEN {dir_norm_ref} IS NOT NULL THEN {dir_norm_ref} "
            f"    ELSE NULL "
            f"END"
        )
        via_sec_expr = (
            f"CASE "
            f"    WHEN {dir_norm_ref} ~* '{strict_typed_pattern}' THEN regexp_replace({dir_norm_ref}, '{strict_typed_pattern}', '\\3') "
            f"    WHEN {dir_norm_ref} ~* '{strict_missing_via_pattern}' THEN "
            f"        CASE "
            f"            WHEN {dir_norm_ref} ~* '^(KR|TV|DG|PJ|CQ|PT)' THEN 'CL ' "
            f"            ELSE 'KR ' "
            f"        END || regexp_replace({dir_norm_ref}, '{strict_missing_via_pattern}', '\\3') "
            f"    WHEN {dir_norm_ref} ~* '{mz_full_pattern}' THEN TRIM(regexp_replace({dir_norm_ref}, '{mz_full_pattern}', '\\2 \\3')) "
            f"    WHEN {dir_norm_ref} ~* '{dir_pattern}' THEN regexp_replace({dir_norm_ref}, '{extract_pattern}', '\\3') "
            f"    WHEN {dir_norm_ref} ~* '{missing_via_pattern}' THEN "
            f"        CASE "
            f"            WHEN {dir_norm_ref} ~* '^(KR|TV|DG|PJ|CQ|PT)' THEN 'CL ' "
            f"            ELSE 'KR ' "
            f"        END || regexp_replace({dir_norm_ref}, '{missing_via_pattern}', '\\3') "
            f"    WHEN {dir_norm_ref} ~* '{no_placa_pattern}' THEN regexp_replace({dir_norm_ref}, '{no_placa_pattern}', '\\3') "
            f"    WHEN {dir_norm_ref} ~* '{no_placa_missing_via_pattern}' THEN "
            f"        CASE "
            f"            WHEN {dir_norm_ref} ~* '^(KR|TV|DG|PJ|CQ|PT)' THEN 'CL ' "
            f"            ELSE 'KR ' "
            f"        END || regexp_replace({dir_norm_ref}, '{no_placa_missing_via_pattern}', '\\3') "
            f"    WHEN {dir_norm_ref} ~* '{hash_pattern}' THEN "
            f"        CASE "
            f"            WHEN {dir_norm_ref} ~* '^(KR|TV|DG|PJ|CQ|PT)' THEN 'CL ' "
            f"            ELSE 'KR ' "
            f"        END || regexp_replace({dir_norm_ref}, '{hash_pattern}', '\\2') "
            f"    ELSE NULL "
            f"END"
        )
        placa_expr = (
            f"CASE "
            f"    WHEN {dir_norm_ref} ~* '{strict_typed_pattern}' THEN regexp_replace({dir_norm_ref}, '{strict_typed_pattern}', '\\4') "
            f"    WHEN {dir_norm_ref} ~* '{strict_missing_via_pattern}' THEN regexp_replace({dir_norm_ref}, '{strict_missing_via_pattern}', '\\4') "
            f"    WHEN {dir_norm_ref} ~* '{mz_full_pattern}' THEN regexp_replace({dir_norm_ref}, '{mz_full_pattern}', '\\4 \\5') "
            f"    WHEN {dir_norm_ref} ~* '{cs_only_pattern}' AND {dir_norm_ref} !~* '{dir_pattern}' AND {dir_norm_ref} !~* '{hash_pattern}' THEN regexp_replace({dir_norm_ref}, '{cs_only_pattern}', '\\2 \\3') "
            f"    WHEN {dir_norm_ref} ~* '{dir_pattern}' THEN regexp_replace({dir_norm_ref}, '{extract_pattern}', '\\4') "
            f"    WHEN {dir_norm_ref} ~* '{missing_via_pattern}' THEN regexp_replace({dir_norm_ref}, '{missing_via_pattern}', '\\4') "
            f"    WHEN {dir_norm_ref} ~* '{no_placa_pattern}' THEN 'SP' "
            f"    WHEN {dir_norm_ref} ~* '{no_placa_missing_via_pattern}' THEN 'SP' "
            f"    WHEN {dir_norm_ref} ~* '{hash_pattern}' THEN regexp_replace({dir_norm_ref}, '{hash_pattern}', '\\3') "
            f"    ELSE NULL "
            f"END"
        )
        compl_expr = (
            f"CASE "
            f"    WHEN {dir_norm_ref} ~* '{strict_typed_pattern}' THEN NULLIF(TRIM(regexp_replace({dir_norm_ref}, '{strict_typed_pattern}', '\\2\\5')), '') "
            f"    WHEN {dir_norm_ref} ~* '{strict_missing_via_pattern}' THEN NULLIF(TRIM(regexp_replace({dir_norm_ref}, '{strict_missing_via_pattern}', '\\2\\5')), '') "
            f"    WHEN {dir_norm_ref} ~* '{mz_full_pattern}' THEN NULLIF(TRIM(regexp_replace({dir_norm_ref}, '{mz_full_pattern}', '\\6')), '') "
            f"    WHEN {dir_norm_ref} ~* '{cs_only_pattern}' AND {dir_norm_ref} !~* '{dir_pattern}' AND {dir_norm_ref} !~* '{hash_pattern}' THEN NULLIF(TRIM(regexp_replace({dir_norm_ref}, '{cs_only_pattern}', '\\4')), '') "
            f"    WHEN {dir_norm_ref} ~* '{dir_pattern}' THEN NULLIF(TRIM(regexp_replace({dir_norm_ref}, '{extract_pattern}', '\\2\\5')), '') "
            f"    WHEN {dir_norm_ref} ~* '{missing_via_pattern}' THEN NULLIF(TRIM(regexp_replace({dir_norm_ref}, '{missing_via_pattern}', '\\2\\5')), '') "
            f"    WHEN {dir_norm_ref} ~* '{no_placa_pattern}' THEN NULLIF(TRIM(regexp_replace({dir_norm_ref}, '{no_placa_pattern}', '\\2')), '') "
            f"    WHEN {dir_norm_ref} ~* '{no_placa_missing_via_pattern}' THEN NULLIF(TRIM(regexp_replace({dir_norm_ref}, '{no_placa_missing_via_pattern}', '\\2')), '') "
            f"    WHEN {dir_norm_ref} ~* '{hash_pattern}' THEN NULLIF(TRIM(regexp_replace({dir_norm_ref}, '{hash_pattern}', '\\4')), '') "
            f"    ELSE NULL "
            f"END"
        )

        return {
            "dir_norm_expr": dir_norm_expr,
            "via_princ_expr": via_princ_expr,
            "via_sec_expr": via_sec_expr,
            "placa_expr": placa_expr,
            "compl_expr": compl_expr,
        }

    def _normalize_dir_sql_expr(self, expr):
        current = f"{expr}::text"
        current = f"REGEXP_REPLACE({current}, '\\y([A-Z])BIS\\y', '\\1 BIS', 'gi')"
        current = f"REGEXP_REPLACE({current}, '([0-9])([A-Z])', '\\1 \\2', 'g')"
        current = f"REGEXP_REPLACE({current}, '([A-Z])([0-9])', '\\1 \\2', 'g')"
        return current

    def _ensure_schema(self, base_uri, schema):
        sql = f"CREATE SCHEMA IF NOT EXISTS {schema};"
        return self._execute_pg_sql(base_uri, sql, "No se pudo crear el esquema proceso.")

    def _create_pg_table(self, base_uri, schema, table, geom_column, geom_type, srid, fields):
        field_sql = []
        for field in fields:
            field_type = "integer" if field.type() == QVariant.Int else "text"
            field_sql.append(f"{field.name()} {field_type}")

        sql = (
            f"CREATE TABLE IF NOT EXISTS {schema}.{table} ("
            + ", ".join(field_sql)
            + f", {geom_column} geometry({geom_type}, {srid})"
            + ");"
        )
        return self._execute_pg_sql(
            base_uri, sql, f"No se pudo crear la tabla {schema}.{table}."
        )

    def _get_pg_connection(self, base_uri):
        metadata = QgsProviderRegistry.instance().providerMetadata("postgres")
        try:
            conn_info = base_uri.connectionInfo(True)
        except TypeError:
            conn_info = base_uri.connectionInfo()
        if not conn_info:
            conn_info = base_uri.uri(False)
        if self._pg_conn and self._pg_conn_info == conn_info:
            return self._pg_conn
        self._pg_dir_norm_ready_info = None
        self._pg_conn = metadata.createConnection(conn_info, {})
        self._pg_conn_info = conn_info
        return self._pg_conn

    def _execute_pg_sql(self, base_uri, sql, error_message):
        try:
            conn = self._get_pg_connection(base_uri)
            conn.executeSql(sql)
            return True
        except Exception as exc:
            self._pg_conn = None
            self._pg_conn_info = None
            self._pg_dir_norm_ready_info = None
            QgsMessageLog.logMessage(
                f"{error_message}\n{exc}\nSQL: {sql}",
                "Estandarizacion",
                Qgis.Critical,
            )
            print(f"{error_message}\n{exc}\nSQL: {sql}")
            QMessageBox.warning(self, "PostGIS", f"{error_message}\n{exc}")
            return False

    def _fetch_pg_sql(self, base_uri, sql, error_message):
        try:
            conn = self._get_pg_connection(base_uri)
            return conn.executeSql(sql)
        except Exception as exc:
            self._pg_conn = None
            self._pg_conn_info = None
            self._pg_dir_norm_ready_info = None
            QgsMessageLog.logMessage(
                f"{error_message}\n{exc}\nSQL: {sql}",
                "Estandarizacion",
                Qgis.Critical,
            )
            print(f"{error_message}\n{exc}\nSQL: {sql}")
            QMessageBox.warning(self, "PostGIS", f"{error_message}\n{exc}")
            return []

    def _try_execute_pg_sql(self, base_uri, sql):
        try:
            conn = self._get_pg_connection(base_uri)
            conn.executeSql(sql)
            return True
        except Exception:
            self._pg_conn = None
            self._pg_conn_info = None
            self._pg_dir_norm_ready_info = None
            return False

    def _get_tipo_relacion_stats(self, base_uri, schema, analisis_table, igual_table):
        stats = []
        analisis_sql = (
            f"SELECT tipo_relacion, COUNT(*) AS total "
            f"FROM {self._qi(schema)}.{self._qi(analisis_table)} "
            "GROUP BY tipo_relacion "
            "ORDER BY total DESC;"
        )
        igual_sql = (
            f"SELECT COUNT(*) AS total "
            f"FROM {self._qi(schema)}.{self._qi(igual_table)};"
        )

        rows = self._fetch_pg_sql(base_uri, analisis_sql, "No se pudo leer estadisticas de analisis.")
        for row in rows or []:
            try:
                stats.append(f"{row[0]}: {row[1]}")
            except Exception:
                continue

        igual_rows = self._fetch_pg_sql(base_uri, igual_sql, "No se pudo leer estadisticas de similitud_igual.")
        if igual_rows:
            try:
                stats.append(f"igual: {igual_rows[0][0]}")
            except Exception:
                pass

        return stats

    def _get_validador_stats(self, base_uri, schema, analisis_table):
        stats = []
        validador_sql = (
            "SELECT TRIM(val) AS causa, COUNT(*) AS total "
            "FROM ("
            f"  SELECT UNNEST(string_to_array(COALESCE(validador, ''), ',')) AS val "
            f"  FROM {self._qi(schema)}.{self._qi(analisis_table)}"
            ") s "
            "WHERE TRIM(val) <> '' "
            "GROUP BY TRIM(val) "
            "ORDER BY total DESC;"
        )
        rows = self._fetch_pg_sql(base_uri, validador_sql, "No se pudo leer estadisticas de validador.")
        for row in rows or []:
            try:
                stats.append(f"{row[0]}: {row[1]}")
            except Exception:
                continue
        return stats

    def _same_connection(self, base_uri, comp_uri):
        return (
            base_uri.database() == comp_uri.database()
            and base_uri.host() == comp_uri.host()
            and base_uri.port() == comp_uri.port()
            and base_uri.username() == comp_uri.username()
        )

    def clear_form(self):
        self.tipo_direccion.setCurrentText("SIN FILTRO")
        self.srid.setText("4326")
        self.placa_sep.setText("/")
        self.use_centroids.setChecked(True)
        self.out_desag.setChecked(True)
        self.out_igual.setChecked(True)
        self.out_analisis.setChecked(True)
        self.out_existe.setChecked(True)
        self.out_prefix.setText("comparacion_capas")
        self.base_use_full_dir.setChecked(False)
