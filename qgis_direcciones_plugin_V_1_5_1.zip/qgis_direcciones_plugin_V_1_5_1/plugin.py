from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtWidgets import QAction
from .dialog import EstandarizacionDialog
from .estandarizar_dialog import EstandarizarDireccionDialog, DesagregarDireccionesDialog


class EstandarizacionDireccionesPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action_comparar = None
        self.action_estandarizar = None
        self.action_desagregar = None
        self.dialog_comparar = None
        self.dialog_estandarizar = None
        self.dialog_desagregar = None

    def tr(self, text):
        return QCoreApplication.translate("EstandarizacionDirecciones", text)

    def initGui(self):
        # ── Acción 1: Comparación completa (funcionalidad original) ──
        self.action_comparar = QAction(
            self.tr("Comparar Capas de Direcciones"),
            self.iface.mainWindow(),
        )
        self.action_comparar.triggered.connect(self._run_comparar)
        self.iface.addPluginToMenu(
            self.tr("Estandarizacion Direcciones"),
            self.action_comparar,
        )
        self.iface.addToolBarIcon(self.action_comparar)

        # ── Acción 2: Estandarizar capa independiente (nueva) ──
        self.action_estandarizar = QAction(
            self.tr("Estandarizar Dirección (capa independiente)"),
            self.iface.mainWindow(),
        )
        self.action_estandarizar.triggered.connect(self._run_estandarizar)
        self.iface.addPluginToMenu(
            self.tr("Estandarizacion Direcciones"),
            self.action_estandarizar,
        )

        # ── Acción 3: Desagregar direcciones ──
        self.action_desagregar = QAction(
            self.tr("Desagregar Direcciones"),
            self.iface.mainWindow(),
        )
        self.action_desagregar.triggered.connect(self._run_desagregar)
        self.iface.addPluginToMenu(
            self.tr("Estandarizacion Direcciones"),
            self.action_desagregar,
        )

    def unload(self):
        if self.action_comparar:
            self.iface.removePluginMenu(
                self.tr("Estandarizacion Direcciones"),
                self.action_comparar,
            )
            self.iface.removeToolBarIcon(self.action_comparar)
        if self.action_estandarizar:
            self.iface.removePluginMenu(
                self.tr("Estandarizacion Direcciones"),
                self.action_estandarizar,
            )
        if self.action_desagregar:
            self.iface.removePluginMenu(
                self.tr("Estandarizacion Direcciones"),
                self.action_desagregar,
            )

    def _run_comparar(self):
        """Abre el diálogo original de comparación de capas."""
        if not self.dialog_comparar:
            self.dialog_comparar = EstandarizacionDialog(self.iface)
        self.dialog_comparar.refresh_layers()
        self.dialog_comparar.show()
        self.dialog_comparar.raise_()
        self.dialog_comparar.activateWindow()

    def _run_estandarizar(self):
        """Abre el diálogo de estandarización independiente."""
        if not self.dialog_estandarizar:
            self.dialog_estandarizar = EstandarizarDireccionDialog(self.iface)
        self.dialog_estandarizar.refresh_layers()
        self.dialog_estandarizar.show()
        self.dialog_estandarizar.raise_()
        self.dialog_estandarizar.activateWindow()

    def _run_desagregar(self):
        """Abre el diálogo de desagregación de direcciones."""
        if not self.dialog_desagregar:
            self.dialog_desagregar = DesagregarDireccionesDialog(self.iface)
        self.dialog_desagregar.refresh_layers()
        self.dialog_desagregar.show()
        self.dialog_desagregar.raise_()
        self.dialog_desagregar.activateWindow()

    # Mantener compatibilidad con código externo que llame a .run()
    def run(self):
        self._run_comparar()
