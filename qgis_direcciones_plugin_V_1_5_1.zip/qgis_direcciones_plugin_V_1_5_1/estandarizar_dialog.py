"""Ventana independiente para estandarizar una sola capa de direcciones.

Acepta cualquier capa vectorial cargada en el proyecto QGIS (PostGIS,
GeoPackage, Shapefile, memoria, etc.).

El usuario indica:
  - La capa a procesar
  - El campo ID
  - El campo direccion_final (obligatorio)
  - El campo direccion2   (opcional)
  - El campo dir_antigua  (opcional)
  - El nombre de la tabla de salida (por defecto "capa_estandarizada")

Campos de salida:
  id, direccion_original, direccion_estandarizada,
  via_princ, via_sec, placa, compl,
  direccion2_original, direccion2_estandarizada,
  dir_antigua_original, dir_antigua_estandarizada,
  geom (si se activa)

Ruta PostGIS  → crea proceso.<nombre_tabla> en el servidor y la carga.
Otras fuentes → crea una capa de memoria en el proyecto.
"""

from __future__ import annotations

import re

from qgis.core import (
    Qgis,
    QgsDataSourceUri,
    QgsFeature,
    QgsMessageLog,
    QgsProject,
    QgsProviderRegistry,
    QgsVectorLayer,
    QgsWkbTypes,
)
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
)

_NONE_OPTION = "(ninguno)"


class EstandarizarDireccionDialog(QDialog):
    """Diálogo para estandarizar una capa de direcciones de forma independiente."""

    _OUT_SCHEMA = "proceso"

    def __init__(self, iface):
        super().__init__(iface.mainWindow())
        self.iface = iface
        self._pg_conn = None
        self._pg_conn_info = None
        self._pg_dir_norm_ready_info = None
        self._dict_replacements = None

        self.setWindowTitle("Estandarizar Dirección")
        self.resize(440, 360)

        # ── Widgets ──────────────────────────────────────────────────
        self.layer_combo = QComboBox()
        self.id_field_combo = QComboBox()
        self.dir_field_combo = QComboBox()       # direccion_final  (obligatorio)
        self.dir2_field_combo = QComboBox()      # direccion2       (opcional)
        self.dir_ant_field_combo = QComboBox()   # dir_antigua      (opcional)
        self.geom_check = QCheckBox("Incluir geometría en la capa de salida")
        self.geom_check.setChecked(True)
        self.out_name = QLineEdit("capa_estandarizada")

        self.btn_run = QPushButton("Estandarizar")
        self.btn_cancel = QPushButton("Cerrar")

        # ── Conexiones ───────────────────────────────────────────────
        self.layer_combo.currentIndexChanged.connect(self._on_layer_changed)
        self.btn_run.clicked.connect(self.execute)
        self.btn_cancel.clicked.connect(self.close)

        # ── Layout ───────────────────────────────────────────────────
        layout = QVBoxLayout()

        info = QLabel(
            "Estandariza y desglosa el campo de dirección indicado.\n"
            "Salida: <b>proceso.&lt;nombre&gt;</b> (PostGIS) o capa temporal."
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        form = QFormLayout()
        form.addRow("Capa:", self.layer_combo)
        form.addRow("Campo ID:", self.id_field_combo)
        form.addRow("Campo direccion_final *:", self.dir_field_combo)
        form.addRow("Campo direccion2:", self.dir2_field_combo)
        form.addRow("Campo dir_antigua:", self.dir_ant_field_combo)
        form.addRow("Nombre de salida:", self.out_name)
        form.addRow("", self.geom_check)
        layout.addLayout(form)

        note = QLabel("* Los campos opcionales con <i>(ninguno)</i> se omiten en la salida.")
        note.setWordWrap(True)
        layout.addWidget(note)

        buttons = QHBoxLayout()
        buttons.addWidget(self.btn_run)
        buttons.addWidget(self.btn_cancel)
        layout.addLayout(buttons)

        self.setLayout(layout)
        self.refresh_layers()

    # ──────────────────────────────────────────────────────────────────
    # Carga de capas y campos
    # ──────────────────────────────────────────────────────────────────

    def refresh_layers(self):
        self.layer_combo.clear()
        layers = [
            lyr
            for lyr in QgsProject.instance().mapLayers().values()
            if isinstance(lyr, QgsVectorLayer)
        ]
        for lyr in layers:
            self.layer_combo.addItem(lyr.name(), lyr.id())
        self._on_layer_changed()

    def _on_layer_changed(self):
        layer = self._get_selected_layer()
        for combo in (
            self.id_field_combo,
            self.dir_field_combo,
            self.dir2_field_combo,
            self.dir_ant_field_combo,
        ):
            combo.clear()

        if not layer:
            return

        fields = [f.name() for f in layer.fields()]

        # ID — sin opción vacía
        self.id_field_combo.addItems(fields)
        for candidate in ("id", "fid", "ogc_fid", "objectid"):
            if candidate in fields:
                self.id_field_combo.setCurrentText(candidate)
                break

        # direccion_final — obligatorio, sin opción vacía
        self.dir_field_combo.addItems(fields)
        for candidate in ("direccion_final", "direccion", "dir_final", "address"):
            if candidate in fields:
                self.dir_field_combo.setCurrentText(candidate)
                break

        # Opcionales — primera opción es "(ninguno)"
        for combo, candidates in (
            (self.dir2_field_combo, ("direccion2", "dir2", "direccion_2")),
            (self.dir_ant_field_combo, ("dir_antigua", "dir_ant", "direccion_antigua")),
        ):
            combo.addItem(_NONE_OPTION)
            combo.addItems(fields)
            for c in candidates:
                if c in fields:
                    combo.setCurrentText(c)
                    break

    def _get_selected_layer(self) -> QgsVectorLayer | None:
        layer_id = self.layer_combo.currentData()
        if not layer_id:
            return None
        return QgsProject.instance().mapLayer(layer_id)

    def _optional_field(self, combo: QComboBox) -> str | None:
        val = combo.currentText()
        return None if val == _NONE_OPTION else val

    # ──────────────────────────────────────────────────────────────────
    # Ejecución principal
    # ──────────────────────────────────────────────────────────────────

    def execute(self):
        layer = self._get_selected_layer()
        if not layer:
            QMessageBox.warning(self, "Error", "Seleccione una capa.")
            return

        id_field = self.id_field_combo.currentText().strip()
        dir_field = self.dir_field_combo.currentText().strip()
        dir2_field = self._optional_field(self.dir2_field_combo)
        dir_ant_field = self._optional_field(self.dir_ant_field_combo)
        out_name = self.out_name.text().strip()

        if not id_field or not dir_field:
            QMessageBox.warning(self, "Error", "Seleccione los campos ID y dirección final.")
            return
        if not out_name:
            QMessageBox.warning(self, "Error", "Ingrese un nombre para la capa de salida.")
            return

        if layer.providerType() == "postgres":
            self._execute_postgis(layer, id_field, dir_field, dir2_field, dir_ant_field, out_name)
        else:
            self._execute_memory(layer, id_field, dir_field, dir2_field, dir_ant_field, out_name)

    # ──────────────────────────────────────────────────────────────────
    # Ruta PostGIS
    # ──────────────────────────────────────────────────────────────────

    def _execute_postgis(
        self,
        layer: QgsVectorLayer,
        id_field: str,
        dir_field: str,
        dir2_field: str | None,
        dir_ant_field: str | None,
        out_name: str,
    ):
        base_uri = QgsDataSourceUri(layer.dataProvider().dataSourceUri())
        uri_info = QgsDataSourceUri(layer.dataProvider().dataSourceUri())
        schema = uri_info.schema() or "public"
        table = uri_info.table()
        geom_col = self._get_geom_column(layer)

        if not self._ensure_schema(base_uri, self._OUT_SCHEMA):
            return

        use_fn = self._ensure_dir_norm_functions(base_uri)

        id_q = self._qi(id_field)
        dir_q = self._qi(dir_field)
        src = f"{self._qi(schema)}.{self._qi(table)}"
        dst = f"{self._qi(self._OUT_SCHEMA)}.{self._qi(out_name)}"

        # ── Expresiones de normalización para direccion_final ────────
        if use_fn:
            dir_base_expr = f"pg_temp.fn_dir_base({dir_q}::text)"
            dir_norm_expr = f"pg_temp.fn_dir_norm(pg_temp.fn_dir_base({dir_q}::text))"
        else:
            dir_base_expr = self._get_dir_base_sql_expr(f"{dir_q}::text")
            dir_norm_expr = self._build_dir_norm_inline_expr(dir_base_expr)

        # Desglose de componentes sobre la dirección normalizada
        components = self._build_dir_component_exprs(
            f"{dir_q}::text",
            dir_norm_ref="dir_norm_cte",
        )

        # ── Columnas opcionales ──────────────────────────────────────
        dir2_cols = ""
        dir_ant_cols = ""

        if dir2_field:
            d2q = self._qi(dir2_field)
            if use_fn:
                d2_norm = f"pg_temp.fn_dir_norm(pg_temp.fn_dir_base({d2q}::text))"
            else:
                d2_norm = self._build_dir_norm_inline_expr(
                    self._get_dir_base_sql_expr(f"{d2q}::text")
                )
            dir2_cols = (
                f", {d2q}::text AS direccion2_original"
                f", {d2_norm} AS direccion2_estandarizada"
            )

        if dir_ant_field:
            daq = self._qi(dir_ant_field)
            if use_fn:
                da_norm = f"pg_temp.fn_dir_norm(pg_temp.fn_dir_base({daq}::text))"
            else:
                da_norm = self._build_dir_norm_inline_expr(
                    self._get_dir_base_sql_expr(f"{daq}::text")
                )
            dir_ant_cols = (
                f", {daq}::text AS dir_antigua_original"
                f", {da_norm} AS dir_antigua_estandarizada"
            )

        # ── Geometría ────────────────────────────────────────────────
        geom_select = ""
        geom_index = ""
        if self.geom_check.isChecked() and geom_col:
            geom_select = f", {self._qi(geom_col)} AS geom"
            geom_index = (
                f"CREATE INDEX IF NOT EXISTS idx_{out_name}_geom "
                f"ON {dst} USING GIST (geom);"
            )

        # ── SQL final con CTE para reutilizar dir_norm ───────────────
        sql = (
            f"DROP TABLE IF EXISTS {dst}; "
            f"CREATE UNLOGGED TABLE {dst} AS "
            f"WITH src AS ("
            f"  SELECT "
            f"    {id_q} AS id,"
            f"    {dir_q}::text AS direccion_original,"
            f"    {dir_norm_expr} AS dir_norm_cte"
            f"    {dir2_cols}"
            f"    {dir_ant_cols}"
            f"    {geom_select} "
            f"  FROM {src}"
            f") "
            f"SELECT "
            f"  id,"
            f"  direccion_original,"
            f"  dir_norm_cte AS direccion_estandarizada,"
            f"  {components['via_princ_expr']} AS via_princ,"
            f"  {components['via_sec_expr']}   AS via_sec,"
            f"  {components['placa_expr']}     AS placa,"
            f"  {components['compl_expr']}     AS compl"
        )

        if dir2_field:
            sql += ", direccion2_original, direccion2_estandarizada"
        if dir_ant_field:
            sql += ", dir_antigua_original, dir_antigua_estandarizada"
        if self.geom_check.isChecked() and geom_col:
            sql += ", geom"

        sql += " FROM src; "
        sql += f"CREATE INDEX IF NOT EXISTS idx_{out_name}_id ON {dst} (id); "
        sql += geom_index

        if not self._execute_pg_sql(base_uri, sql, "No se pudo crear la capa estandarizada."):
            return

        self._try_execute_pg_sql(base_uri, f"ANALYZE {dst};")

        geom_col_out = "geom" if (self.geom_check.isChecked() and geom_col) else ""
        if self._add_pg_layer(base_uri, self._OUT_SCHEMA, out_name, geom_col_out):
            QMessageBox.information(
                self,
                "Listo",
                f"Capa '{out_name}' creada en '{self._OUT_SCHEMA}' y cargada en el proyecto.",
            )
        else:
            QMessageBox.warning(
                self,
                "Advertencia",
                f"La tabla '{self._OUT_SCHEMA}.{out_name}' fue creada "
                "pero no se pudo cargar como capa.",
            )

    # ──────────────────────────────────────────────────────────────────
    # Ruta no-PostGIS: procesamiento en Python, capa de memoria
    # ──────────────────────────────────────────────────────────────────

    def _execute_memory(
        self,
        layer: QgsVectorLayer,
        id_field: str,
        dir_field: str,
        dir2_field: str | None,
        dir_ant_field: str | None,
        out_name: str,
    ):
        crs_auth = layer.crs().authid()

        if self.geom_check.isChecked():
            geom_str = QgsWkbTypes.displayString(layer.wkbType())
            uri = (
                f"{geom_str}?crs={crs_auth}"
                "&field=id:string"
                "&field=direccion_original:string"
                "&field=direccion_estandarizada:string"
                "&field=via_princ:string"
                "&field=via_sec:string"
                "&field=placa:string"
                "&field=compl:string"
                "&field=compl_aux:string"
            )
        else:
            uri = (
                "None"
                "?field=id:string"
                "&field=direccion_original:string"
                "&field=direccion_estandarizada:string"
                "&field=via_princ:string"
                "&field=via_sec:string"
                "&field=placa:string"
                "&field=compl:string"
                "&field=compl_aux:string"
            )

        if dir2_field:
            uri += "&field=direccion2_original:string&field=direccion2_estandarizada:string"
        if dir_ant_field:
            uri += "&field=dir_antigua_original:string&field=dir_antigua_estandarizada:string"

        mem_layer = QgsVectorLayer(uri, out_name, "memory")
        if not mem_layer.isValid():
            QMessageBox.warning(self, "Error", "No se pudo crear la capa de memoria.")
            return

        provider = mem_layer.dataProvider()
        features_out = []
        errors = 0

        for feat in layer.getFeatures():
            raw_id = feat[id_field]
            raw_dir = feat[dir_field]
            raw_dir2 = feat[dir2_field] if dir2_field else None
            raw_ant = feat[dir_ant_field] if dir_ant_field else None

            # Normalizar direccion_final
            dir_norm = self._normalize_py(str(raw_dir)) if raw_dir else None
            # Desglosa componentes — usa solo el primer segmento (antes del |)
            # para evitar que los segmentos alternos caigan en placa/compl
            dir_norm_principal = dir_norm.split("|")[0].strip() if dir_norm else None
            via_princ, via_sec, placa, compl = self._desglosar_py(dir_norm_principal) if dir_norm_principal else (None, None, None, None)

            # compl_aux: remanente de direcciones alternativas tras el primer |
            # Se activa si hay cualquier | en la dirección (1 o más)
            compl_aux = None
            if dir_norm and "|" in dir_norm:
                segmentos = dir_norm.split("|")
                remanente = ("| " + " | ".join(s.strip() for s in segmentos[1:])).strip()
                compl_aux = remanente

            # Normalizar opcionales
            dir2_norm = self._normalize_py(str(raw_dir2)) if raw_dir2 else None
            ant_norm = self._normalize_py(str(raw_ant)) if raw_ant else None

            f_out = QgsFeature(mem_layer.fields())
            f_out["id"] = str(raw_id) if raw_id is not None else None
            f_out["direccion_original"] = str(raw_dir) if raw_dir is not None else None
            f_out["direccion_estandarizada"] = dir_norm
            f_out["via_princ"] = via_princ
            f_out["via_sec"] = via_sec
            f_out["placa"] = placa
            f_out["compl"] = compl
            f_out["compl_aux"] = compl_aux

            if dir2_field:
                f_out["direccion2_original"] = str(raw_dir2) if raw_dir2 is not None else None
                f_out["direccion2_estandarizada"] = dir2_norm
            if dir_ant_field:
                f_out["dir_antigua_original"] = str(raw_ant) if raw_ant is not None else None
                f_out["dir_antigua_estandarizada"] = ant_norm

            if self.geom_check.isChecked() and feat.hasGeometry():
                f_out.setGeometry(feat.geometry())

            features_out.append(f_out)

        provider.addFeatures(features_out)
        mem_layer.updateExtents()
        QgsProject.instance().addMapLayer(mem_layer)

        msg = f"Capa '{out_name}' creada con {len(features_out)} registros."
        if errors:
            msg += f"\n{errors} errores de normalización (ver log)."
        QMessageBox.information(self, "Listo", msg)

    # ──────────────────────────────────────────────────────────────────
    # Normalización en Python
    # ──────────────────────────────────────────────────────────────────

    def _normalize_py(self, value: str) -> str:
        """Normaliza una dirección aplicando las mismas reglas que el SQL."""
        v = value.strip()
        if not v:
            return v

        v = v.upper()
        v = v.replace(".", "")
        v = re.sub(r"\s*\*\s*", " | ", v)
        v = v.replace("-", " ")
        v = re.sub(r"\s+", " ", v)

        # Reemplazos del diccionario de abreviaturas
        replacements = self._load_dict_replacements()
        padded = " " + v + " "
        for term, abbr in replacements:
            padded = padded.replace(f" {term} ", f" {abbr} ")
        v = padded.strip()

        v = re.sub(r"\bZU\b", "ZNA URB", v, flags=re.IGNORECASE)
        v = re.sub(r"\bZEU\b", "ZNA EXT URB", v, flags=re.IGNORECASE)

        # Manejo del símbolo #
        has_hash_with_type = re.search(
            r"#\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\b", v, re.IGNORECASE
        )
        if not has_hash_with_type and "#" in v:
            if re.match(r"^CL\b", v, re.IGNORECASE):
                v = re.sub(r"\s*#\s*", " KR ", v)
            elif re.match(r"^KR\b", v, re.IGNORECASE):
                v = re.sub(r"\s*#\s*", " CL ", v)
        elif has_hash_with_type:
            v = re.sub(
                r"\s*#\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\s*",
                r" \1 ",
                v,
                flags=re.IGNORECASE,
            )

        # Abreviaturas de puntos
        v = re.sub(r"BR\.\s+", "BRR ", v, flags=re.IGNORECASE)
        v = re.sub(r"UR\.\s+", "URB ", v, flags=re.IGNORECASE)
        v = re.sub(r"UB\.\s+", "URB ", v, flags=re.IGNORECASE)
        v = re.sub(r"CR\.\s+", "CJR ", v, flags=re.IGNORECASE)
        v = re.sub(r"CN\.\s+", "CND ", v, flags=re.IGNORECASE)
        v = re.sub(r"\bBL\.?\s+", "BQU ", v, flags=re.IGNORECASE)
        v = re.sub(r"\bBLQ\b", "BQU", v, flags=re.IGNORECASE)
        v = re.sub(r"\bMZ\b", "MZA", v, flags=re.IGNORECASE)
        v = re.sub(r"\bCS\b", "CAS", v, flags=re.IGNORECASE)
        v = re.sub(r"\bLOTE\b", "LTE", v, flags=re.IGNORECASE)
        v = re.sub(r"\bSECTOR\b", "SEC", v, flags=re.IGNORECASE)

        # Separar letra/número pegados
        v = re.sub(r"([0-9])([A-Z])", r"\1 \2", v)
        v = re.sub(r"([A-Z])([0-9])", r"\1 \2", v)

        # Prefijos abreviados
        v = re.sub(r"^\s*C(\s+[0-9])", r"CL\1", v)
        v = re.sub(r"^\s*K(\s+[0-9])", r"KR\1", v)
        v = re.sub(r"^\s*T(\s+[0-9])", r"TV\1", v)

        v = re.sub(r"\s+", " ", v).strip()
        return v

    def _desglosar_py(self, direccion: str) -> tuple[str | None, str | None, str | None, str | None]:
        """
        Desglosa una dirección normalizada en (via_princ, via_sec, placa, compl).
        Soporta formato cardinal (CL KR DG TV…) y MZ CASA.
        """
        if not direccion:
            return None, None, None, None

        d = direccion.strip()

        TIPO_CARDINAL = r"(?:CL|KR|TV|DG|AV|AC|AK|PJ|CQ|PT)"
        TIPO_MZ_CS6 = r"(?:APT|BDG|CAS|LCA|LTE|OFI)"
        TIPO_MZ_CS2_5 = r"(?:BIF|KDX|SMA|MZA|AGP|BQU|TOR|INT|SEC|ZNA)"
        TIPO_MZ_CS1 = r"(?:BRR|CDE|CND|CJR|MTF|URD|URB|EDI)"

        # ── Formato cardinal ─────────────────────────────────────────
        # Ej: "CL 5 KR 10 20"  /  "KR 8 CL 23 B 86"  /  "KR 7 A CL 23 B 85"
        # Modificadores de vía: letra suelta (A, B, D…), BIS, SUR, NORTE, ESTE, OESTE
        # seguidos opcionalmente de un número (ej: "A 2").
        MOD = r"(?:BIS(?:\s+[A-Z0-9]+)?|[A-Z]{1,3}(?:\s+\d+)?|SUR|NORTE|ESTE|OESTE)"
        cardinal_pat = re.compile(
            # via_princ: TIPO + número + cero o más modificadores (mínima expansión)
            rf"^({TIPO_CARDINAL}\s+\d+(?:\s+{MOD})*?)"
            # via_sec:   TIPO + número + cero o más modificadores
            rf"\s+({TIPO_CARDINAL}\s+\d+(?:\s+{MOD})*)"
            # placa: primer token que sigue (número, alfanumérico o SP)
            rf"\s+(\S+)"
            # compl: todo el resto (opcional)
            rf"(?:\s+(.+))?$",
            re.IGNORECASE,
        )
        m = cardinal_pat.match(d)
        if m:
            return m.group(1).strip(), m.group(2).strip(), m.group(3).strip(), (m.group(4) or "").strip() or None

        # ── Formato MZ CASA ─────────────────────────────────────────
        # Ej: "BRR EL PRADO MZA A CAS 12"  o  "URB LOS PINOS MZA 3 APT 101"
        mz_pat = re.compile(
            rf"^(.*?)\s+({TIPO_MZ_CS2_5})\s+(\S+)\s+({TIPO_MZ_CS6})\s+(\S+)(?:\s+(.+))?$",
            re.IGNORECASE,
        )
        m = mz_pat.match(d)
        if m:
            via_princ = m.group(1).strip() or None
            via_sec = f"{m.group(2)} {m.group(3)}".strip()
            placa = f"{m.group(4)} {m.group(5)}".strip()
            compl = (m.group(6) or "").strip() or None
            return via_princ, via_sec, placa, compl

        # ── Solo placa tipo CAS/LTE sin generadora ───────────────────
        cs_only = re.compile(
            rf"^(.*?)\s+({TIPO_MZ_CS6})\s+(\S+)(?:\s+(.+))?$",
            re.IGNORECASE,
        )
        m = cs_only.match(d)
        if m:
            return m.group(1).strip() or None, None, f"{m.group(2)} {m.group(3)}".strip(), (m.group(4) or "").strip() or None

        # Sin formato reconocido → devolver todo en via_princ
        return d, None, None, None

    # ──────────────────────────────────────────────────────────────────
    # Construcción de expresiones SQL de normalización y desglose
    # ──────────────────────────────────────────────────────────────────

    def _build_dir_component_exprs(
        self,
        base_dir_expr: str,
        dir_norm_ref: str = "dir_norm",
        dir_base_col: str | None = None,
    ) -> dict:
        """
        Construye las expresiones SQL para desagregar dir_norm_ref en
        via_princ, via_sec, placa y compl.
        Replica exactamente la lógica de EstandarizacionDialog._build_dir_component_exprs.
        """
        if dir_base_col is not None:
            dir_base_expr = dir_base_col
        else:
            dir_base_expr = self._get_dir_base_sql_expr(base_dir_expr)

        via_token_full = (
            "(?:\\d+|[A-Z](?:\\s+\\d+)?|BIS(?:\\s+[A-Z])?|SUR|ESTE|NORTE|OESTE)"
        )
        via_segment = (
            "(?:CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\s+\\d+"
            f"(?:\\s+{via_token_full})*"
        )
        via_token_head = (
            "(?:[A-Z](?:\\s+\\d+)?|BIS(?:\\s+[A-Z])?|SUR|ESTE|NORTE|OESTE)"
        )
        via_segment_head = (
            "(?:CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\s+\\d+"
            f"(?:\\s+{via_token_head})*"
        )
        no_type_segment = f"\\d+(?:\\s+{via_token_head})*"
        pre_compl = "(?:CAS|CS|LTE|BDG|APT|LCA|OFI|IN)\\s+\\S+"
        dir_pattern = self._sql_literal(
            f"^({via_segment})\\s+(?:{pre_compl}\\s+)?({via_segment})\\s+\\S+"
        )
        extract_pattern = self._sql_literal(
            f"^({via_segment})\\s+((?:{pre_compl}\\s+)?)({via_segment})\\s+(\\S+)\\s*(.*)$"
        )
        missing_via_pattern = self._sql_literal(
            f"^({via_segment_head})\\s+((?:{pre_compl}\\s+)?)({no_type_segment})\\s+(\\S+)\\s*(.*)$"
        )
        no_placa_pattern = self._sql_literal(
            f"^({via_segment_head})\\s+((?:{pre_compl}\\s+)?)({via_segment_head})\\s*$"
        )
        no_placa_missing_via_pattern = self._sql_literal(
            f"^({via_segment_head})\\s+((?:{pre_compl}\\s+)?)({no_type_segment})\\s*$"
        )
        hash_num_pattern = (
            "\\d+(?:\\s+(?:[A-Z](?:\\s+\\d+)?|BIS(?:\\s+[A-Z])?|SUR|ESTE|NORTE|OESTE))*"
        )
        hash_pattern = self._sql_literal(
            f"^({via_segment})\\s*#\\s*({hash_num_pattern})\\s*(?:-\\s*)?"
            "([^\\s]+)\\s*(.*)$"
        )
        mz_full_pattern = self._sql_literal(
            "^(.*?)(?:\\s+ET\\.?\\s+[^ ]+)?\\s+"
            "(MZA|MZ|SMA|BQU|BIF|KDX|TOR|AGP|INT|SEC|ZNA)\\s+([^ ]+)\\s+"
            "(CAS|CS|LTE|BDG|APT|LCA|OFI|IN)\\s+([^ ]+)(?:\\s+(.*))?$"
        )
        cs_only_pattern = self._sql_literal(
            "^(.*?)(?:\\s+ET\\.?\\s+[^ ]+)?\\s+"
            "(CAS|CS|LTE|BDG|APT|LCA|OFI|IN)\\s+([^ ]+)(?:\\s+(.*))?$"
        )
        placa_strict_pattern = "[0-9]+(?:/[0-9]+)*"
        strict_typed_pattern = self._sql_literal(
            f"^({via_segment})\\s+((?:{pre_compl}\\s+)?)({via_segment})\\s+({placa_strict_pattern})\\s+(.+)$"
        )
        strict_missing_via_pattern = self._sql_literal(
            f"^({via_segment_head})\\s+((?:{pre_compl}\\s+)?)({no_type_segment})\\s+({placa_strict_pattern})\\s+(.+)$"
        )

        r = dir_norm_ref  # alias corto

        via_princ_expr = (
            f"CASE "
            f"WHEN {r} ~* '{strict_typed_pattern}' THEN regexp_replace({r}, '{strict_typed_pattern}', '\\1') "
            f"WHEN {r} ~* '{strict_missing_via_pattern}' THEN regexp_replace({r}, '{strict_missing_via_pattern}', '\\1') "
            f"WHEN {r} ~* '{mz_full_pattern}' THEN TRIM(regexp_replace({r}, '{mz_full_pattern}', '\\1')) "
            f"WHEN {r} ~* '{cs_only_pattern}' AND {r} !~* '{dir_pattern}' AND {r} !~* '{hash_pattern}' THEN TRIM(regexp_replace({r}, '{cs_only_pattern}', '\\1')) "
            f"WHEN {r} ~* '{dir_pattern}' THEN regexp_replace({r}, '{extract_pattern}', '\\1') "
            f"WHEN {r} ~* '{missing_via_pattern}' THEN regexp_replace({r}, '{missing_via_pattern}', '\\1') "
            f"WHEN {r} ~* '{no_placa_pattern}' THEN regexp_replace({r}, '{no_placa_pattern}', '\\1') "
            f"WHEN {r} ~* '{no_placa_missing_via_pattern}' THEN regexp_replace({r}, '{no_placa_missing_via_pattern}', '\\1') "
            f"WHEN {r} ~* '{hash_pattern}' THEN regexp_replace({r}, '{hash_pattern}', '\\1') "
            f"WHEN {r} IS NOT NULL THEN {r} "
            f"ELSE NULL END"
        )
        via_sec_expr = (
            f"CASE "
            f"WHEN {r} ~* '{strict_typed_pattern}' THEN regexp_replace({r}, '{strict_typed_pattern}', '\\3') "
            f"WHEN {r} ~* '{strict_missing_via_pattern}' THEN "
            f"  CASE WHEN {r} ~* '^(KR|TV|DG|PJ|CQ|PT)' THEN 'CL ' ELSE 'KR ' END || regexp_replace({r}, '{strict_missing_via_pattern}', '\\3') "
            f"WHEN {r} ~* '{mz_full_pattern}' THEN TRIM(regexp_replace({r}, '{mz_full_pattern}', '\\2 \\3')) "
            f"WHEN {r} ~* '{dir_pattern}' THEN regexp_replace({r}, '{extract_pattern}', '\\3') "
            f"WHEN {r} ~* '{missing_via_pattern}' THEN "
            f"  CASE WHEN {r} ~* '^(KR|TV|DG|PJ|CQ|PT)' THEN 'CL ' ELSE 'KR ' END || regexp_replace({r}, '{missing_via_pattern}', '\\3') "
            f"WHEN {r} ~* '{no_placa_pattern}' THEN regexp_replace({r}, '{no_placa_pattern}', '\\3') "
            f"WHEN {r} ~* '{no_placa_missing_via_pattern}' THEN "
            f"  CASE WHEN {r} ~* '^(KR|TV|DG|PJ|CQ|PT)' THEN 'CL ' ELSE 'KR ' END || regexp_replace({r}, '{no_placa_missing_via_pattern}', '\\3') "
            f"WHEN {r} ~* '{hash_pattern}' THEN "
            f"  CASE WHEN {r} ~* '^(KR|TV|DG|PJ|CQ|PT)' THEN 'CL ' ELSE 'KR ' END || regexp_replace({r}, '{hash_pattern}', '\\2') "
            f"ELSE NULL END"
        )
        placa_expr = (
            f"CASE "
            f"WHEN {r} ~* '{strict_typed_pattern}' THEN regexp_replace({r}, '{strict_typed_pattern}', '\\4') "
            f"WHEN {r} ~* '{strict_missing_via_pattern}' THEN regexp_replace({r}, '{strict_missing_via_pattern}', '\\4') "
            f"WHEN {r} ~* '{mz_full_pattern}' THEN regexp_replace({r}, '{mz_full_pattern}', '\\4 \\5') "
            f"WHEN {r} ~* '{cs_only_pattern}' AND {r} !~* '{dir_pattern}' AND {r} !~* '{hash_pattern}' THEN regexp_replace({r}, '{cs_only_pattern}', '\\2 \\3') "
            f"WHEN {r} ~* '{dir_pattern}' THEN regexp_replace({r}, '{extract_pattern}', '\\4') "
            f"WHEN {r} ~* '{missing_via_pattern}' THEN regexp_replace({r}, '{missing_via_pattern}', '\\4') "
            f"WHEN {r} ~* '{no_placa_pattern}' THEN 'SP' "
            f"WHEN {r} ~* '{no_placa_missing_via_pattern}' THEN 'SP' "
            f"WHEN {r} ~* '{hash_pattern}' THEN regexp_replace({r}, '{hash_pattern}', '\\3') "
            f"ELSE NULL END"
        )
        compl_expr = (
            f"CASE "
            f"WHEN {r} ~* '{strict_typed_pattern}' THEN NULLIF(TRIM(regexp_replace({r}, '{strict_typed_pattern}', '\\2\\5')), '') "
            f"WHEN {r} ~* '{strict_missing_via_pattern}' THEN NULLIF(TRIM(regexp_replace({r}, '{strict_missing_via_pattern}', '\\2\\5')), '') "
            f"WHEN {r} ~* '{mz_full_pattern}' THEN NULLIF(TRIM(regexp_replace({r}, '{mz_full_pattern}', '\\6')), '') "
            f"WHEN {r} ~* '{cs_only_pattern}' AND {r} !~* '{dir_pattern}' AND {r} !~* '{hash_pattern}' THEN NULLIF(TRIM(regexp_replace({r}, '{cs_only_pattern}', '\\4')), '') "
            f"WHEN {r} ~* '{dir_pattern}' THEN NULLIF(TRIM(regexp_replace({r}, '{extract_pattern}', '\\2\\5')), '') "
            f"WHEN {r} ~* '{missing_via_pattern}' THEN NULLIF(TRIM(regexp_replace({r}, '{missing_via_pattern}', '\\2\\5')), '') "
            f"WHEN {r} ~* '{no_placa_pattern}' THEN NULLIF(TRIM(regexp_replace({r}, '{no_placa_pattern}', '\\2')), '') "
            f"WHEN {r} ~* '{no_placa_missing_via_pattern}' THEN NULLIF(TRIM(regexp_replace({r}, '{no_placa_missing_via_pattern}', '\\2')), '') "
            f"WHEN {r} ~* '{hash_pattern}' THEN NULLIF(TRIM(regexp_replace({r}, '{hash_pattern}', '\\4')), '') "
            f"ELSE NULL END"
        )

        return {
            "via_princ_expr": via_princ_expr,
            "via_sec_expr": via_sec_expr,
            "placa_expr": placa_expr,
            "compl_expr": compl_expr,
        }

    def _build_dir_norm_inline_expr(self, dir_base_expr: str) -> str:
        current = dir_base_expr
        current = (
            f"CASE "
            f"WHEN {current} ~* '^CL' AND {current} ~ '#' AND {current} !~* '#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\b' "
            f"    THEN REGEXP_REPLACE({current}, '\\s*#\\s*', ' KR ', 'gi') "
            f"WHEN {current} ~* '^KR' AND {current} ~ '#' AND {current} !~* '#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\b' "
            f"    THEN REGEXP_REPLACE({current}, '\\s*#\\s*', ' CL ', 'gi') "
            f"ELSE {current} END"
        )
        for pattern, replacement, flags in [
            ("'BR\\.\\s+'", "'BRR '", "'gi'"),
            ("'UR\\.\\s+'", "'URB '", "'gi'"),
            ("'UB\\.\\s+'", "'URB '", "'gi'"),
            ("'CR\\.\\s+'", "'CJR '", "'gi'"),
            ("'CN\\.\\s+'", "'CND '", "'gi'"),
            ("'\\bBL\\.?\\s+'", "'BQU '", "'gi'"),
            ("'\\bBLQ\\b'", "'BQU'", "'gi'"),
            ("'\\bMZ\\b'", "'MZA'", "'gi'"),
            ("'\\bCS\\b'", "'CAS'", "'gi'"),
            ("'\\s*-\\s*'", "' '", "'g'"),
            ("'\\bLOTE\\b'", "'LTE'", "'gi'"),
            ("'\\y([A-Z])BIS\\y'", "'\\1 BIS'", "'gi'"),
            ("'([0-9])([A-Z])'", "'\\1 \\2'", "'gi'"),
            ("'([A-Z])([0-9])'", "'\\1 \\2'", "'gi'"),
            ("'^\\s*C(\\s+[0-9])'", "'CL\\1'", "'g'"),
            ("'^\\s*K(\\s+[0-9])'", "'KR\\1'", "'g'"),
            ("'^\\s*T(\\s+[0-9])'", "'TV\\1'", "'g'"),
            ("'\\s+'", "' '", "'g'"),
        ]:
            current = f"REGEXP_REPLACE({current}, {pattern}, {replacement}, {flags})"
        return current

    def _get_dir_base_sql_expr(self, base_dir_expr: str) -> str:
        expr = (
            f"REGEXP_REPLACE({base_dir_expr}::text, "
            "'\\s*#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\s*', ' \\1 ', 'gi')"
        )
        return self._apply_base_normalization_sql(expr)

    def _apply_base_normalization_sql(self, expr: str) -> str:
        current = f"UPPER({expr})"
        current = f"REPLACE({current}, '.', '')"
        current = f"REGEXP_REPLACE({current}, '\\s*\\*\\s*', ' | ', 'g')"
        current = f"REPLACE({current}, '-', ' ')"
        current = f"REGEXP_REPLACE({current}, '\\s+', ' ', 'g')"
        current = (
            "TRANSLATE("
            f"{current}, "
            "CHR(8857) || CHR(193) || CHR(161) || CHR(191), "
            "CHR(209) || CHR(209) || CHR(209) || CHR(209)"
            ")"
        )
        current = f"REGEXP_REPLACE({current}, '\\y([A-Z])BIS\\y', '\\1 BIS', 'gi')"
        current = self._apply_dict_replacements_sql(current)
        current = f"REGEXP_REPLACE({current}, '\\yZU\\y', 'ZNA URB', 'gi')"
        current = f"REGEXP_REPLACE({current}, '\\yZEU\\y', 'ZNA EXT URB', 'gi')"
        current = (
            "REGEXP_REPLACE("
            f"{current}, "
            "'\\y(JUAN\\s+PABLO\\s+(?:I{{1,3}}|IV|VI{{0,3}}|IX|X))\\y', "
            "'__JP__\\1__JP__', 'gi'"
            ")"
        )
        current = (
            "REGEXP_REPLACE("
            f"{current}, "
            "'\\yMZA\\s+(I{{1,3}}|IV|VI{{0,3}}|IX|X)\\y', "
            "'__MZA__\\1', 'gi'"
            ")"
        )
        current = (
            "REGEXP_REPLACE("
            f"{current}, "
            "'\\y((?:CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\s+\\d+(?:\\s+[A-Z](?:\\s+\\d+)?)?)\\s+(I{{1,3}}|IV|VI{{0,3}}|IX|X)\\y', "
            "'\\1 __ROMCARD__\\2', 'gi'"
            ")"
        )
        current = (
            "REGEXP_REPLACE("
            f"{current}, "
            "'(?<!ETA\\s)\\y(I{{1,3}}|IV|VI{{0,3}}|IX|X)\\y', "
            "'ETA \\1', 'gi'"
            ")"
        )
        current = (
            "REGEXP_REPLACE("
            f"{current}, "
            "'__MZA__([IVXLCDM]+)', 'MZA \\1', 'g'"
            ")"
        )
        current = (
            "REGEXP_REPLACE("
            f"{current}, "
            "'__ROMCARD__([IVXLCDM]+)', '\\1', 'gi'"
            ")"
        )
        current = f"REGEXP_REPLACE({current}, '__JP__', '', 'g')"
        current = f"REGEXP_REPLACE({current}, '\\s+', ' ', 'g')"
        current = f"TRIM({current})"
        return current

    def _apply_dict_replacements_sql(self, expr: str) -> str:
        replacements = self._load_dict_replacements()
        if not replacements:
            return expr
        guard_pattern = getattr(self, "_dict_pattern", None)
        padded = f"(' ' || {expr} || ' ')"
        current = padded
        for term, abbr in replacements:
            term_sql = self._sql_literal(term)
            abbr_sql = self._sql_literal(abbr)
            current = f"REPLACE({current}, ' {term_sql} ', ' {abbr_sql} ')"
        current = f"TRIM({current})"
        if guard_pattern:
            current = (
                f"CASE WHEN {expr} ~* '{self._sql_literal(guard_pattern)}' "
                f"THEN {current} ELSE {expr} END"
            )
        return current

    def _load_dict_replacements(self):
        if self._dict_replacements is not None:
            return self._dict_replacements

        import csv
        import os

        replacements = {
            "UB": "URB", "BR": "BRR", "CS": "CAS", "TO": "TOR",
            "ET": "ETA", "CN": "CND", "IN": "INT", "CO": "CJR",
            "CR": "CJR", "SM": "SMA", "SC": "SEC", "MZ": "MZA",
        }
        csv_name = (
            "Copia de 08_Estructura_base_diccionario_barrios_vias"
            " - 02_Diccionario_maestro.csv"
        )
        csv_path = os.path.join(os.path.dirname(__file__), csv_name)
        try:
            with open(csv_path, mode="r", encoding="utf-8-sig", newline="") as handle:
                reader = csv.reader(handle)
                next(reader, None)
                for row in reader:
                    if len(row) < 2:
                        continue
                    term = row[0].strip().upper()
                    abbr = row[1].strip().upper()
                    if term:
                        replacements[term] = abbr
        except Exception as exc:
            QgsMessageLog.logMessage(
                f"No se pudo leer el diccionario: {exc}",
                "Estandarizacion",
                Qgis.Warning,
            )

        self._dict_replacements = sorted(
            replacements.items(), key=lambda item: len(item[0]), reverse=True
        )
        terms = [re.escape(t) for t, _ in self._dict_replacements]
        self._dict_pattern = "\\y(?:" + "|".join(terms) + ")\\y" if terms else None
        return self._dict_replacements

    # ──────────────────────────────────────────────────────────────────
    # Helpers PostGIS
    # ──────────────────────────────────────────────────────────────────

    def _build_dir_base_fn_sql(self, fn_name: str = "pg_temp.fn_dir_base") -> str:
        replacements = self._load_dict_replacements()
        guard_values_sql = ", ".join(
            "('{0}')".format(t.replace("'", "''")) for t, _ in replacements
        )
        lines = [
            f"CREATE OR REPLACE FUNCTION {fn_name}(p_in text) RETURNS text",
            "LANGUAGE plpgsql IMMUTABLE PARALLEL SAFE AS $fn_dir_base$",
            "DECLARE v text; vpad text;",
            "BEGIN",
            "  IF p_in IS NULL THEN RETURN NULL; END IF;",
            "  v := REGEXP_REPLACE(p_in, '\\s*#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\s*', ' \\1 ', 'gi');",
            "  v := UPPER(v);",
            "  v := REPLACE(v, '.', '');",
            "  v := REGEXP_REPLACE(v, '\\s*\\*\\s*', ' | ', 'g');",
            "  v := REPLACE(v, '-', ' ');",
            "  v := REGEXP_REPLACE(v, '\\s+', ' ', 'g');",
            "  v := TRANSLATE(v, CHR(8857)||CHR(193)||CHR(161)||CHR(191), CHR(209)||CHR(209)||CHR(209)||CHR(209));",
            "  v := REGEXP_REPLACE(v, '\\y([A-Z])BIS\\y', '\\1 BIS', 'gi');",
        ]
        if replacements:
            lines.append("  vpad := ' ' || v || ' ';")
            if guard_values_sql:
                lines.append(
                    f"  IF EXISTS (SELECT 1 FROM (VALUES {guard_values_sql}) AS dict(term) "
                    "WHERE POSITION(' ' || dict.term || ' ' IN vpad) > 0) THEN"
                )
                lines.append("    v := vpad;")
                for term, abbr in replacements:
                    t = term.replace("'", "''")
                    a = abbr.replace("'", "''")
                    lines.append(f"    v := REPLACE(v, ' {t} ', ' {a} ');")
                lines.append("    v := TRIM(v);")
                lines.append("  END IF;")
        lines += [
            "  v := REGEXP_REPLACE(v, '\\yZU\\y', 'ZNA URB', 'gi');",
            "  v := REGEXP_REPLACE(v, '\\yZEU\\y', 'ZNA EXT URB', 'gi');",
            "  v := REGEXP_REPLACE(v, '\\y(JUAN\\s+PABLO\\s+(?:I{1,3}|IV|VI{0,3}|IX|X))\\y', '__JP__\\1__JP__', 'gi');",
            "  v := REGEXP_REPLACE(v, '\\yMZA\\s+(I{1,3}|IV|VI{0,3}|IX|X)\\y', '__MZA__\\1', 'gi');",
            "  v := REGEXP_REPLACE(v, '\\y((?:CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\s+\\d+(?:\\s+[A-Z](?:\\s+\\d+)?)?)\\s+(I{1,3}|IV|VI{0,3}|IX|X)\\y', '\\1 __ROMCARD__\\2', 'gi');",
            "  v := REGEXP_REPLACE(v, '(?<!ETA\\s)\\y(I{1,3}|IV|VI{0,3}|IX|X)\\y', 'ETA \\1', 'gi');",
            "  v := REGEXP_REPLACE(v, '__MZA__([IVXLCDM]+)', 'MZA \\1', 'g');",
            "  v := REGEXP_REPLACE(v, '__ROMCARD__([IVXLCDM]+)', '\\1', 'gi');",
            "  v := REGEXP_REPLACE(v, '__JP__', '', 'g');",
            "  v := REGEXP_REPLACE(v, '\\s+', ' ', 'g');",
            "  v := TRIM(v);",
            "  RETURN v;",
            "END;",
            "$fn_dir_base$",
        ]
        return "\n".join(lines)

    def _build_dir_norm_fn_sql(self, fn_name: str = "pg_temp.fn_dir_norm") -> str:
        lines = [
            f"CREATE OR REPLACE FUNCTION {fn_name}(p_in text) RETURNS text",
            "LANGUAGE plpgsql IMMUTABLE PARALLEL SAFE AS $fn_dir_norm$",
            "DECLARE v text;",
            "BEGIN",
            "  IF p_in IS NULL THEN RETURN NULL; END IF;",
            "  v := p_in;",
            "  IF v ~* '^CL' AND v ~ '#' AND v !~* '#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\b' THEN",
            "    v := REGEXP_REPLACE(v, '\\s*#\\s*', ' KR ', 'gi');",
            "  ELSIF v ~* '^KR' AND v ~ '#' AND v !~* '#\\s*(CL|KR|DG|TV|AV|AC|AK|PJ|CQ|PT)\\b' THEN",
            "    v := REGEXP_REPLACE(v, '\\s*#\\s*', ' CL ', 'gi');",
            "  END IF;",
            "  v := REGEXP_REPLACE(v, 'BR\\.\\s+', 'BRR ', 'gi');",
            "  v := REGEXP_REPLACE(v, 'UR\\.\\s+', 'URB ', 'gi');",
            "  v := REGEXP_REPLACE(v, 'UB\\.\\s+', 'URB ', 'gi');",
            "  v := REGEXP_REPLACE(v, 'CR\\.\\s+', 'CJR ', 'gi');",
            "  v := REGEXP_REPLACE(v, 'CN\\.\\s+', 'CND ', 'gi');",
            "  v := REGEXP_REPLACE(v, '\\bBL\\.?\\s+', 'BQU ', 'gi');",
            "  v := REGEXP_REPLACE(v, '\\bBLQ\\b', 'BQU', 'gi');",
            "  v := REGEXP_REPLACE(v, '\\bMZ\\b', 'MZA', 'gi');",
            "  v := REGEXP_REPLACE(v, '\\bCS\\b', 'CAS', 'gi');",
            "  v := REGEXP_REPLACE(v, '\\s*-\\s*', ' ', 'g');",
            "  v := REGEXP_REPLACE(v, '\\bLOTE\\b', 'LTE', 'gi');",
            "  v := REGEXP_REPLACE(v, '\\y([A-Z])BIS\\y', '\\1 BIS', 'gi');",
            "  v := REGEXP_REPLACE(v, '([0-9])([A-Z])', '\\1 \\2', 'gi');",
            "  v := REGEXP_REPLACE(v, '([A-Z])([0-9])', '\\1 \\2', 'gi');",
            "  v := REGEXP_REPLACE(v, '^\\s*C(\\s+[0-9])', 'CL\\1', 'g');",
            "  v := REGEXP_REPLACE(v, '^\\s*K(\\s+[0-9])', 'KR\\1', 'g');",
            "  v := REGEXP_REPLACE(v, '^\\s*T(\\s+[0-9])', 'TV\\1', 'g');",
            "  v := REGEXP_REPLACE(v, '\\s+', ' ', 'g');",
            "  RETURN v;",
            "END;",
            "$fn_dir_norm$",
        ]
        return "\n".join(lines)

    def _ensure_dir_norm_functions(self, base_uri: QgsDataSourceUri) -> bool:
        try:
            conn_info = base_uri.connectionInfo(True)
        except TypeError:
            conn_info = base_uri.connectionInfo()
        if not conn_info:
            conn_info = base_uri.uri(False)
        if self._pg_dir_norm_ready_info == conn_info:
            return True
        sql = self._build_dir_base_fn_sql() + ";\n" + self._build_dir_norm_fn_sql() + ";"
        if not self._try_execute_pg_sql(base_uri, sql):
            return False
        self._pg_dir_norm_ready_info = conn_info
        return True

    def _ensure_schema(self, base_uri: QgsDataSourceUri, schema: str) -> bool:
        return self._execute_pg_sql(
            base_uri,
            f"CREATE SCHEMA IF NOT EXISTS {schema};",
            f"No se pudo crear el esquema {schema}.",
        )

    def _get_pg_connection(self, base_uri: QgsDataSourceUri):
        metadata = QgsProviderRegistry.instance().providerMetadata("postgres")
        try:
            conn_info = base_uri.connectionInfo(True)
        except TypeError:
            conn_info = base_uri.connectionInfo()
        if not conn_info:
            conn_info = base_uri.uri(False)
        if self._pg_conn and self._pg_conn_info == conn_info:
            return self._pg_conn
        self._pg_dir_norm_ready_info = None
        self._pg_conn = metadata.createConnection(conn_info, {})
        self._pg_conn_info = conn_info
        return self._pg_conn

    def _execute_pg_sql(
        self, base_uri: QgsDataSourceUri, sql: str, error_message: str
    ) -> bool:
        try:
            conn = self._get_pg_connection(base_uri)
            conn.executeSql(sql)
            return True
        except Exception as exc:
            self._pg_conn = None
            self._pg_conn_info = None
            self._pg_dir_norm_ready_info = None
            QgsMessageLog.logMessage(
                f"{error_message}\n{exc}\nSQL: {sql}", "Estandarizacion", Qgis.Critical
            )
            QMessageBox.warning(self, "PostGIS", f"{error_message}\n{exc}")
            return False

    def _try_execute_pg_sql(self, base_uri: QgsDataSourceUri, sql: str) -> bool:
        try:
            conn = self._get_pg_connection(base_uri)
            conn.executeSql(sql)
            return True
        except Exception:
            self._pg_conn = None
            self._pg_conn_info = None
            self._pg_dir_norm_ready_info = None
            return False

    def _add_pg_layer(
        self,
        base_uri: QgsDataSourceUri,
        schema: str,
        table: str,
        geom_column: str,
    ) -> bool:
        uri = QgsDataSourceUri()
        uri.setConnection(
            base_uri.host(),
            base_uri.port(),
            base_uri.database(),
            base_uri.username(),
            base_uri.password(),
        )
        uri.setDataSource(schema, table, geom_column or "", "", "id")
        layer = QgsVectorLayer(uri.uri(False), table, "postgres")
        if not layer.isValid():
            QMessageBox.warning(self, "Ejecucion", f"No se pudo cargar la capa {table}.")
            return False
        QgsProject.instance().addMapLayer(layer)
        return True

    def _get_geom_column(self, layer: QgsVectorLayer) -> str:
        try:
            uri = QgsDataSourceUri(layer.dataProvider().dataSourceUri())
            col = uri.geometryColumn()
            if col:
                return col
        except Exception:
            pass
        return "geom"

    def _qi(self, name: str) -> str:
        return '"' + name.replace('"', '""') + '"'

    def _sql_literal(self, value: str) -> str:
        return value.replace("'", "''")


# ══════════════════════════════════════════════════════════════════════════════
# DesagregarDireccionesDialog
# Toma una capa ya estandarizada (con via_princ, via_sec, placa, compl,
# compl_aux) y produce una capa de puntos donde cada fila es UNA dirección
# atómica:
#   - Placa doble (01/03) → 2 filas
#   - compl con tipo MZ/CAS → se mantiene como compl de la dirección base
#   - Segmentos en compl_aux (separados por |) → cada uno se desglosa y
#     genera sus propias filas (expandiendo también sus placas dobles)
#
# Campos de salida:
#   id (consecutivo), id_capa (id original), via_princ, via_sec, placa,
#   compl, direccion_final, geom (Point)
# ══════════════════════════════════════════════════════════════════════════════

class DesagregarDireccionesDialog(QDialog):
    """Diálogo para desagregar una capa estandarizada en direcciones atómicas."""

    def __init__(self, iface):
        super().__init__(iface.mainWindow())
        self.iface = iface
        self._dict_replacements = None

        self.setWindowTitle("Desagregar Direcciones")
        self.resize(460, 400)

        # ── Widgets ──────────────────────────────────────────────────
        self.layer_combo = QComboBox()

        # Campos de entrada — se autodetectan pero el usuario puede cambiarlos
        self.id_field_combo       = QComboBox()
        self.via_princ_combo      = QComboBox()
        self.via_sec_combo        = QComboBox()
        self.placa_combo          = QComboBox()
        self.compl_combo          = QComboBox()
        self.compl_aux_combo      = QComboBox()
        self.dir2_combo           = QComboBox()   # direccion2 estandarizada (opcional)

        self.out_name = QLineEdit("direcciones_desagregadas")

        self.btn_run    = QPushButton("Desagregar")
        self.btn_cancel = QPushButton("Cerrar")

        # ── Conexiones ───────────────────────────────────────────────
        self.layer_combo.currentIndexChanged.connect(self._on_layer_changed)
        self.btn_run.clicked.connect(self.execute)
        self.btn_cancel.clicked.connect(self.close)

        # ── Layout ───────────────────────────────────────────────────
        layout = QVBoxLayout()

        info = QLabel(
            "Expande una capa estandarizada en direcciones atómicas.\n"
            "Placa doble (01/03) → una fila por número.\n"
            "Segmentos en <b>compl_aux</b> → se desglosan y generan filas independientes.\n"
            "Segmentos en <b>direccion2</b> → se desglosan y se agregan a la misma capa.\n"
            "Salida: capa de <b>puntos</b> en memoria."
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        form = QFormLayout()
        form.addRow("Capa:", self.layer_combo)
        form.addRow("Campo ID:",         self.id_field_combo)
        form.addRow("via_princ:",         self.via_princ_combo)
        form.addRow("via_sec:",           self.via_sec_combo)
        form.addRow("placa:",             self.placa_combo)
        form.addRow("compl:",             self.compl_combo)
        form.addRow("compl_aux:",         self.compl_aux_combo)
        form.addRow("direccion2 (opcional):", self.dir2_combo)
        form.addRow("Nombre de salida:",  self.out_name)
        layout.addLayout(form)

        buttons = QHBoxLayout()
        buttons.addWidget(self.btn_run)
        buttons.addWidget(self.btn_cancel)
        layout.addLayout(buttons)

        self.setLayout(layout)
        self.refresh_layers()

    # ──────────────────────────────────────────────────────────────────
    # Carga de capas y campos
    # ──────────────────────────────────────────────────────────────────

    def refresh_layers(self):
        self.layer_combo.clear()
        layers = [
            lyr
            for lyr in QgsProject.instance().mapLayers().values()
            if isinstance(lyr, QgsVectorLayer)
        ]
        for lyr in layers:
            self.layer_combo.addItem(lyr.name(), lyr.id())
        self._on_layer_changed()

    def _on_layer_changed(self):
        layer = self._get_selected_layer()
        for combo in (
            self.id_field_combo,
            self.via_princ_combo,
            self.via_sec_combo,
            self.placa_combo,
            self.compl_combo,
            self.compl_aux_combo,
            self.dir2_combo,
        ):
            combo.clear()

        if not layer:
            return

        fields = [f.name() for f in layer.fields()]

        # Autodetección por nombre exacto; si no existe deja (ninguno)
        def _set(combo, candidates):
            combo.addItem(_NONE_OPTION)
            combo.addItems(fields)
            for c in candidates:
                if c in fields:
                    combo.setCurrentText(c)
                    return
            combo.setCurrentIndex(0)

        # ID — sin opción vacía
        self.id_field_combo.addItems(fields)
        for c in ("id", "fid", "ogc_fid", "objectid"):
            if c in fields:
                self.id_field_combo.setCurrentText(c)
                break

        _set(self.via_princ_combo, ["via_princ"])
        _set(self.via_sec_combo,   ["via_sec"])
        _set(self.placa_combo,     ["placa"])
        _set(self.compl_combo,     ["compl"])
        _set(self.compl_aux_combo, ["compl_aux"])
        _set(self.dir2_combo,      ["direccion2_estandarizada", "direccion2", "dir2"])

    def _get_selected_layer(self):
        layer_id = self.layer_combo.currentData()
        if not layer_id:
            return None
        return QgsProject.instance().mapLayer(layer_id)

    def _field_val(self, combo, feat):
        """Lee el valor del campo seleccionado en combo; None si es (ninguno)."""
        name = combo.currentText()
        if name == _NONE_OPTION:
            return None
        try:
            v = feat[name]
            return str(v).strip() if v is not None and str(v).strip() not in ("", "NULL", "None") else None
        except Exception:
            return None

    # ──────────────────────────────────────────────────────────────────
    # Ejecución principal
    # ──────────────────────────────────────────────────────────────────

    def execute(self):
        layer = self._get_selected_layer()
        if not layer:
            QMessageBox.warning(self, "Error", "Seleccione una capa.")
            return

        out_name = self.out_name.text().strip() or "direcciones_desagregadas"

        # Capa de salida: siempre puntos, CRS del original
        crs_auth = layer.crs().authid() or "EPSG:4326"
        uri = (
            f"Point?crs={crs_auth}"
            "&field=id:integer"
            "&field=id_capa:string"
            "&field=via_princ:string"
            "&field=via_sec:string"
            "&field=placa:string"
            "&field=compl:string"
            "&field=direccion_final:string"
        )

        mem_layer = QgsVectorLayer(uri, out_name, "memory")
        if not mem_layer.isValid():
            QMessageBox.warning(self, "Error", "No se pudo crear la capa de salida.")
            return

        provider  = mem_layer.dataProvider()
        features_out = []
        consecutive = 1

        for feat in layer.getFeatures():
            raw_id     = feat[self.id_field_combo.currentText()]
            id_capa    = str(raw_id) if raw_id is not None else None

            via_princ  = self._field_val(self.via_princ_combo,  feat)
            via_sec    = self._field_val(self.via_sec_combo,    feat)
            placa      = self._field_val(self.placa_combo,      feat)
            compl      = self._field_val(self.compl_combo,      feat)
            compl_aux  = self._field_val(self.compl_aux_combo,  feat)
            dir2       = self._field_val(self.dir2_combo,       feat)

            # Geometría → siempre punto
            geom = self._to_point(feat)

            # ── 1. Expandir segmento base ────────────────────────────
            for f_out in self._expand_segmento(
                via_princ, via_sec, placa, compl,
                id_capa, geom, consecutive, provider, mem_layer
            ):
                features_out.append(f_out)
                consecutive += 1

            # ── 2. Expandir segmentos de compl_aux ───────────────────
            if compl_aux:
                # compl_aux tiene forma "| SEG1 | SEG2 ..."
                raw_segs = compl_aux.split("|")
                for seg_raw in raw_segs:
                    seg = seg_raw.strip()
                    if not seg:
                        continue
                    # Desagregar el segmento en sus componentes
                    vp2, vs2, pl2, co2 = self._desglosar_py(seg)
                    for f_out in self._expand_segmento(
                        vp2, vs2, pl2, co2,
                        id_capa, geom, consecutive, provider, mem_layer
                    ):
                        features_out.append(f_out)
                        consecutive += 1

            # ── 3. Expandir direccion2 ───────────────────────────────
            # dir2 ya viene estandarizada; puede tener | internos propios
            if dir2:
                # Separar por | igual que compl_aux
                raw_segs2 = dir2.split("|")
                for seg_raw in raw_segs2:
                    seg = seg_raw.strip()
                    if not seg:
                        continue
                    vp3, vs3, pl3, co3 = self._desglosar_py(seg)
                    for f_out in self._expand_segmento(
                        vp3, vs3, pl3, co3,
                        id_capa, geom, consecutive, provider, mem_layer
                    ):
                        features_out.append(f_out)
                        consecutive += 1

        provider.addFeatures(features_out)
        mem_layer.updateExtents()
        QgsProject.instance().addMapLayer(mem_layer)

        QMessageBox.information(
            self,
            "Listo",
            f"Capa '{out_name}' creada con {len(features_out)} registros.",
        )

    # ──────────────────────────────────────────────────────────────────
    # Helpers internos
    # ──────────────────────────────────────────────────────────────────

    def _to_point(self, feat):
        """Devuelve siempre una geometría Point a partir de cualquier tipo."""
        from qgis.core import QgsGeometry, QgsPointXY
        if not feat.hasGeometry():
            return QgsGeometry()
        geom = feat.geometry()
        wkb_type = geom.wkbType()
        # Ya es punto
        if QgsWkbTypes.geometryType(wkb_type) == QgsWkbTypes.PointGeometry:
            return geom
        # Polígono, línea, etc. → punto representativo
        return geom.pointOnSurface()

    def _expand_segmento(
        self,
        via_princ, via_sec, placa, compl,
        id_capa, geom, consecutive_start,
        provider, mem_layer,
    ):
        """
        Dado un segmento ya desglosado (via_princ, via_sec, placa, compl),
        genera una lista de QgsFeature expandiendo placas dobles (01/03).
        Devuelve lista de features (sin agregarlas aún al provider).
        """
        feats = []

        # Expandir placa doble: "01/03" → ["01", "03"]
        if placa and "/" in placa:
            placas = [p.strip() for p in placa.split("/") if p.strip()]
        else:
            placas = [placa] if placa else [None]

        for pl in placas:
            dir_final = self._reconstruir_direccion(via_princ, via_sec, pl, compl)
            f_out = QgsFeature(mem_layer.fields())
            f_out["id"]             = consecutive_start + len(feats)
            f_out["id_capa"]        = id_capa
            f_out["via_princ"]      = via_princ
            f_out["via_sec"]        = via_sec
            f_out["placa"]          = pl
            f_out["compl"]          = compl
            f_out["direccion_final"]= dir_final
            f_out.setGeometry(geom)
            feats.append(f_out)

        return feats

    def _reconstruir_direccion(self, via_princ, via_sec, placa, compl):
        """Concatena los componentes en una cadena limpia."""
        partes = [p for p in (via_princ, via_sec, placa, compl) if p]
        return " ".join(partes) if partes else None

    # ──────────────────────────────────────────────────────────────────
    # Desglose de segmentos de compl_aux (misma lógica que
    # EstandarizarDireccionDialog._desglosar_py)
    # ──────────────────────────────────────────────────────────────────

    def _desglosar_py(self, direccion: str):
        """
        Desglosa una dirección normalizada en (via_princ, via_sec, placa, compl).
        Replica la lógica de EstandarizarDireccionDialog._desglosar_py.
        """
        if not direccion:
            return None, None, None, None

        d = direccion.strip()

        TIPO_CARDINAL  = r"(?:CL|KR|TV|DG|AV|AC|AK|PJ|CQ|PT)"
        TIPO_MZ_CS6    = r"(?:APT|BDG|CAS|LCA|LTE|OFI)"
        TIPO_MZ_CS2_5  = r"(?:BIF|KDX|SMA|MZA|AGP|BQU|TOR|INT|SEC|ZNA)"

        # Modificadores de vía: BIS+alfanum, 1-3 letras + opcional número
        MOD = r"(?:BIS(?:\s+[A-Z0-9]+)?|[A-Z]{1,3}(?:\s+\d+)?|SUR|NORTE|ESTE|OESTE)"

        cardinal_pat = re.compile(
            rf"^({TIPO_CARDINAL}\s+\d+(?:\s+{MOD})*?)"
            rf"\s+({TIPO_CARDINAL}\s+\d+(?:\s+{MOD})*)"
            rf"\s+(\S+)"
            rf"(?:\s+(.+))?$",
            re.IGNORECASE,
        )
        m = cardinal_pat.match(d)
        if m:
            return (
                m.group(1).strip(),
                m.group(2).strip(),
                m.group(3).strip(),
                (m.group(4) or "").strip() or None,
            )

        # Formato MZ CASA
        mz_pat = re.compile(
            rf"^(.*?)\s+({TIPO_MZ_CS2_5})\s+(\S+)\s+({TIPO_MZ_CS6})\s+(\S+)(?:\s+(.+))?$",
            re.IGNORECASE,
        )
        m = mz_pat.match(d)
        if m:
            return (
                m.group(1).strip() or None,
                f"{m.group(2)} {m.group(3)}".strip(),
                f"{m.group(4)} {m.group(5)}".strip(),
                (m.group(6) or "").strip() or None,
            )

        # Solo placa tipo CAS/LTE sin generadora
        cs_only = re.compile(
            rf"^(.*?)\s+({TIPO_MZ_CS6})\s+(\S+)(?:\s+(.+))?$",
            re.IGNORECASE,
        )
        m = cs_only.match(d)
        if m:
            return (
                m.group(1).strip() or None,
                None,
                f"{m.group(2)} {m.group(3)}".strip(),
                (m.group(4) or "").strip() or None,
            )

        # Sin formato reconocido → todo en via_princ
        return d, None, None, None
