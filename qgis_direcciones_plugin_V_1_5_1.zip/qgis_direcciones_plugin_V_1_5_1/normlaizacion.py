    /*XXXXXXX ESTANDARIZACION PARA LAS DIRECCIONES MZACAS XXXXXXX*/
    /*1. ESTANDARIZAR LA PALABRA ET POR ETA*/
    Update """ + predios + """ set via_princ = REPLACE(via_princ,' ET ',' ETA ') where via_princ LIKE '% ET %';
    Update """ + predios + """ set direccion_final = REPLACE(direccion_final,' ET ',' ETA ') where direccion_final LIKE '% ET %';
    Update """ + predios + """ set direccion2 = REPLACE(direccion2,' ET ',' ETA ') where direccion2 LIKE '% ET %';
    Update """ + predios + """ set dir_antigua = REPLACE(dir_antigua,' ET ',' ETA ') where dir_antigua LIKE '% ET %';
    
    Update """ + predios + """ set via_princ = REPLACE(via_princ,' ET',' ETA') where via_princ LIKE '% ET';
    Update """ + predios + """ set direccion_final = REPLACE(direccion_final,' ET',' ETA') where direccion_final LIKE '% ET';
    Update """ + predios + """ set direccion2 = REPLACE(direccion2,' ET',' ETA') where direccion2 LIKE '% ET';
    Update """ + predios + """ set dir_antigua = REPLACE(dir_antigua,' ET',' ETA') where dir_antigua LIKE '% ET';
    
    Update """ + predios + """ set via_princ = REPLACE(via_princ,' ETAPA ',' ETA ') where via_princ LIKE '% ETAPA %';
    Update """ + predios + """ set direccion_final = REPLACE(direccion_final,' ETAPA ',' ETA ') where direccion_final LIKE '% ETAPA %';
    Update """ + predios + """ set direccion2 = REPLACE(direccion2,' ETAPA ',' ETA ') where direccion2 LIKE '% ETAPA %';
    Update """ + predios + """ set dir_antigua = REPLACE(dir_antigua,' ETAPA ',' ETA ') where dir_antigua LIKE '% ETAPA %';
    
    /*1.1 MODIFICAR EL ORDEN DE LAS ETA (II ETA -> ETA IIDALLOS)*/ 
    
        /*1.1 Reordenar solo cuando ETA viene seguida de número romano y letra (ETA I A -> I ETA A)*/

        UPDATE """ + predios + """ SET via_princ = regexp_replace(via_princ, '(ETA) ([IVXLCDM]+) ([A-Z])', '\\2 \\1 \\3', 'gi') WHERE via_princ ~* 'ETA [IVXLCDM]+ [A-Z]';
        UPDATE """ + predios + """ SET direccion_final = regexp_replace(direccion_final, '(ETA) ([IVXLCDM]+) ([A-Z])', '\\2 \\1 \\3', 'gi') WHERE direccion_final ~* 'ETA [IVXLCDM]+ [A-Z]';
        UPDATE """ + predios + """ SET direccion2 = regexp_replace(direccion2, '(ETA) ([IVXLCDM]+) ([A-Z])', '\\2 \\1 \\3', 'gi') WHERE direccion2 ~* 'ETA [IVXLCDM]+ [A-Z]';

        /*1.1.1 Si el romano va antes de ETA, mover ETA antes (II ETA -> ETA II)*/

        UPDATE """ + predios + """ SET via_princ = regexp_replace(via_princ, '(\\m[IVXLCDM]+\\M) ETA', 'ETA \\1', 'gi') WHERE via_princ ~* '\\m[IVXLCDM]+\\M ETA';
        UPDATE """ + predios + """ SET direccion_final = regexp_replace(direccion_final, '(\\m[IVXLCDM]+\\M) ETA', 'ETA \\1', 'gi') WHERE direccion_final ~* '\\m[IVXLCDM]+\\M ETA';
        UPDATE """ + predios + """ SET direccion2 = regexp_replace(direccion2, '(\\m[IVXLCDM]+\\M) ETA', 'ETA \\1', 'gi') WHERE direccion2 ~* '\\m[IVXLCDM]+\\M ETA';

        DO $$
        BEGIN
            IF EXISTS (
                SELECT 1
                FROM information_schema.columns
                WHERE table_schema = 'public'
                  AND table_name = '""" + predios + """'
                  AND column_name = 'dir_antigua'
            ) THEN
                UPDATE """ + predios + """ SET dir_antigua = regexp_replace(dir_antigua, '(\\m[IVXLCDM]+\\M) ETA', 'ETA \\1', 'gi')
                WHERE dir_antigua ~* '\\m[IVXLCDM]+\\M ETA';
            END IF;
        END;
        $$ LANGUAGE plpgsql;

        /*1.2 Si aparece 'DE ETA <barrio> <romano>' reubicar ETA tras el barrio (DE LILI ETA II)*/
        UPDATE """ + predios + """ SET via_princ = regexp_replace(via_princ, '( DE )ETA ([^ ]+)', '\\1\\2 ETA', 'gi') WHERE via_princ LIKE '% DE ETA %';
        UPDATE """ + predios + """ SET direccion_final = regexp_replace(direccion_final, '( DE )ETA ([^ ]+)', '\\1\\2 ETA', 'gi') WHERE direccion_final LIKE '% DE ETA %';
        UPDATE """ + predios + """ SET direccion2 = regexp_replace(direccion2, '( DE )ETA ([^ ]+)', '\\1\\2 ETA', 'gi') WHERE direccion2 LIKE '% DE ETA %';

    /*2. ESTANDARIZAR LOS NIVELES DE LOS BARRIOS*/
    update """ + predios + """ set via_princ = replace(via_princ,'BR ','BRR ') WHERE via_princ like 'BR %';
    update """ + predios + """ set direccion_final = replace(direccion_final,'BR ','BRR ') WHERE direccion_final like 'BR %';
    update """ + predios + """ set direccion2 = replace(direccion2,'BR ','BRR ') WHERE direccion2 like 'BR %';
    update """ + predios + """ set dir_antigua = replace(dir_antigua,'BR ','BRR ') WHERE dir_antigua like 'BR %';
    
    update """ + predios + """ set via_princ = replace(via_princ,'UR ','URB ') WHERE via_princ like 'UR %';
    update """ + predios + """ set direccion_final = replace(direccion_final,'UR ','URB ') WHERE direccion_final like 'UR %';
    update """ + predios + """ set direccion2 = replace(direccion2,'UR ','URB ') WHERE direccion2 like 'UR %';
    update """ + predios + """ set dir_antigua = replace(dir_antigua,'UR ','URB ') WHERE dir_antigua like 'UR %';

    update """ + predios + """ set via_princ = replace(via_princ,'UB ','URB ') WHERE via_princ like 'UB %';
    update """ + predios + """ set direccion_final = replace(direccion_final,'UB ','URB ') WHERE direccion_final like 'UB %';
    update """ + predios + """ set direccion2 = replace(direccion2,'UB ','URB ') WHERE direccion2 like 'UB %';
    update """ + predios + """ set dir_antigua = replace(dir_antigua,'UB ','URB ') WHERE dir_antigua like 'UB %';

    update """ + predios + """ set via_princ = replace(via_princ,'BBR ','BRR ') WHERE via_princ like 'BBR %';
    update """ + predios + """ set direccion_final = replace(direccion_final,'BBR ','BRR ') WHERE direccion_final like 'BBR %';
    update """ + predios + """ set direccion2 = replace(direccion2,'BBR ','BRR ') WHERE direccion2 like 'BBR %';
    update """ + predios + """ set dir_antigua = replace(dir_antigua,'BBR ','BRR ') WHERE dir_antigua like 'BBR %';

    update """ + predios + """ set via_princ = replace(via_princ,'UBR ','URB ') WHERE via_princ like 'UBR %';
    update """ + predios + """ set direccion_final = replace(direccion_final,'UBR ','URB ') WHERE direccion_final like 'UBR %';
    update """ + predios + """ set direccion2 = replace(direccion2,'UBR ','URB ') WHERE direccion2 like 'UBR %';
    update """ + predios + """ set dir_antigua = replace(dir_antigua,'UBR ','URB ') WHERE dir_antigua like 'UBR %';

    update """ + predios + """ set via_princ = replace(via_princ,'UBRR ','URB ') WHERE via_princ like 'UBRR %';
    update """ + predios + """ set direccion_final = replace(direccion_final,'UBRR ','URB ') WHERE direccion_final like 'UBRR %';
    update """ + predios + """ set direccion2 = replace(direccion2,'UBRR ','URB ') WHERE direccion2 like 'UBRR %';
    update """ + predios + """ set dir_antigua = replace(dir_antigua,'UBRR ','URB ') WHERE dir_antigua like 'UBRR %';

    /*3. SEPARAR LOS NUMEROS DE LA PALABRA MZA*/
    Update """ + predios + """ set via_sec = REPLACE(via_sec,'MZA','MZA ') where via_sec ~ '(MZA[0-9])';
    Update """ + predios + """ set direccion_final = REPLACE(direccion_final,'MZA','MZA ') where direccion_final ~ '(MZA[0-9])';
    Update """ + predios + """ set direccion2 = REPLACE(direccion2,'MZA','MZA ') where direccion2 ~ '(MZA[0-9])';
    Update """ + predios + """ set dir_antigua = REPLACE(dir_antigua,'MZA','MZA ') where dir_antigua ~ '(MZA[0-9])';

    /*4. SEPARAR LOS NUMEROS DE LA PALABRA CAS*/
    Update """ + predios + """ set placa = REPLACE(placa,'CAS','CAS ') where placa ~ '(CAS[0-9])';
    Update """ + predios + """ set direccion_final = REPLACE(direccion_final,'CAS','CAS ') where direccion_final ~ '(CAS[0-9])';
    Update """ + predios + """ set direccion2 = REPLACE(direccion2,'CAS','CAS ') where direccion2 ~ '(CAS[0-9])';
    Update """ + predios + """ set dir_antigua = REPLACE(dir_antigua,'CAS','CAS ') where dir_antigua ~ '(CAS[0-9])';

    /*5. ESTANDARIZAR LA PALABRA SECTOR */

    Update """ + predios + """ set via_princ = REPLACE(via_princ,' SECTOR ',' SEC ') where via_princ LIKE '% SECTOR %';
    Update """ + predios + """ set direccion_final = REPLACE(direccion_final,' SECTOR ',' SEC ') where direccion_final LIKE '% SECTOR %';
    Update """ + predios + """ set direccion2 = REPLACE(direccion2,' SECTOR ',' SEC ') where direccion2 LIKE '% SECTOR %';
    Update """ + predios + """ set dir_antigua = REPLACE(dir_antigua,' SECTOR ',' SEC ') where dir_antigua LIKE '% SECTOR %';

    Update """ + predios + """ set via_princ = REPLACE(via_princ,' SC ',' SEC ') where via_princ LIKE '% SC %';
    Update """ + predios + """ set direccion_final = REPLACE(direccion_final,' SC ',' SEC ') where direccion_final LIKE '% SC %';
    Update """ + predios + """ set direccion2 = REPLACE(direccion2,' SC ',' SEC ') where direccion2 LIKE '% SC %';
    Update """ + predios + """ set dir_antigua = REPLACE(dir_antigua,' SC ',' SEC ') where dir_antigua LIKE '% SC %';
    
    /*6. PONERLE UN ESPACIO A LOS NIVELES CUANDO ESTEN JUNTO AL NOMBRE DEL BARRIO*/
    Update """ + predios + """ set via_princ = REPLACE(via_princ,'BRR','BRR ') WHERE via_princ LIKE 'BRR%' AND via_princ NOT LIKE 'BRR %';
    Update """ + predios + """ set direccion_final = REPLACE(direccion_final,'BRR','BRR ') WHERE direccion_final LIKE 'BRR%' AND direccion_final NOT LIKE 'BRR %';
    Update """ + predios + """ set direccion2 = REPLACE(direccion2,'BRR','BRR ') WHERE direccion2 LIKE 'BRR%' AND direccion2 NOT LIKE 'BRR %';
    Update """ + predios + """ set dir_antigua = REPLACE(dir_antigua,'BRR','BRR ') WHERE dir_antigua LIKE 'BRR%' AND dir_antigua NOT LIKE 'BRR %';
    
    Update """ + predios + """ set via_princ = REPLACE(via_princ,'URB','URB ') WHERE via_princ LIKE 'URB%' AND via_princ NOT LIKE 'URB %';
    Update """ + predios + """ set direccion_final = REPLACE(direccion_final,'URB','URB ') WHERE direccion_final LIKE 'URB%' AND direccion_final NOT LIKE 'URB %';
    Update """ + predios + """ set direccion2 = REPLACE(direccion2,'URB','URB ') WHERE direccion2 LIKE 'URB%' AND direccion2 NOT LIKE 'URB %';
    Update """ + predios + """ set dir_antigua = REPLACE(dir_antigua,'URB','URB ') WHERE dir_antigua LIKE 'URB%' AND dir_antigua NOT LIKE 'URB %';
    
    Update """ + predios + """ set via_princ = REPLACE(via_princ,'CND','CND ') WHERE via_princ LIKE 'CND%' AND via_princ NOT LIKE 'CND %';
    Update """ + predios + """ set direccion_final = REPLACE(direccion_final,'CND','CND ') WHERE direccion_final LIKE 'CND%' AND direccion_final NOT LIKE 'CND %';
    Update """ + predios + """ set direccion2 = REPLACE(direccion2,'CND','CND ') WHERE direccion2 LIKE 'CND%' AND direccion2 NOT LIKE 'CND %';
    Update """ + predios + """ set dir_antigua = REPLACE(dir_antigua,'CND','CND ') WHERE dir_antigua LIKE 'CND%' AND dir_antigua NOT LIKE 'CND %';
    
    Update """ + predios + """ set via_princ = REPLACE(via_princ,'CJR','CJR ') WHERE via_princ LIKE 'CJR%' AND via_princ NOT LIKE 'CJR %';
    Update """ + predios + """ set direccion_final = REPLACE(direccion_final,'CJR','CJR ') WHERE direccion_final LIKE 'CJR%' AND direccion_final NOT LIKE 'CJR %';
    Update """ + predios + """ set direccion2 = REPLACE(direccion2,'CJR','CJR ') WHERE direccion2 LIKE 'CJR%' AND direccion2 NOT LIKE 'CJR %';
    Update """ + predios + """ set dir_antigua = REPLACE(dir_antigua,'CJR','CJR ') WHERE dir_antigua LIKE 'CJR%' AND dir_antigua NOT LIKE 'CJR %';
    
    Update """ + predios + """ set via_princ = REPLACE(via_princ,'CDE','CDE ') WHERE via_princ LIKE 'CDE%' AND via_princ NOT LIKE 'CDE %';
    Update """ + predios + """ set direccion_final = REPLACE(direccion_final,'CDE','CDE ') WHERE direccion_final LIKE 'CDE%' AND direccion_final NOT LIKE 'CDE %';
    Update """ + predios + """ set direccion2 = REPLACE(direccion2,'CDE','CDE ') WHERE direccion2 LIKE 'CDE%' AND direccion2 NOT LIKE 'CDE %';
    Update """ + predios + """ set dir_antigua = REPLACE(dir_antigua,'CDE','CDE ') WHERE dir_antigua LIKE 'CDE%' AND dir_antigua NOT LIKE 'CDE %';
    
    /*7. ESTANDARIZAR LOS BQU*/
    Update """ + predios + """ set via_princ = REPLACE(via_princ,' BLQ ',' BQU ') WHERE via_princ LIKE '% BLQ %';
    Update """ + predios + """ set direccion_final = REPLACE(direccion_final,' BLQ ',' BQU ') WHERE direccion_final LIKE '% BLQ %';
    Update """ + predios + """ set direccion2 = REPLACE(direccion2,' BLQ ',' BQU ') WHERE direccion2 LIKE '% BLQ %';
    Update """ + predios + """ set dir_antigua = REPLACE(dir_antigua,' BLQ ',' BQU ') WHERE dir_antigua LIKE '% BLQ %';
    
    /*8. AGREGAR LA GENERADOORA MZA CUANDO EL DIFERENCIAL ENTRE EL NOMBRE DEL BARRIO Y EL PREDIO ES SOLO UNA LETRA*/
    /*ESTA VALIDACION LA PUSE ABAJO POR EL TEMA DE URBANIZACIONES, CON ESO TAMBIEN TENGO EN CUENTA ESA CAPA AL MOMENTO DE HACER LOS CAMBIOS*/
    
    /*QUITO ESPACIOS SOBRANTES DE LAS COLUMNAS MODIFICADAS*/
    update """ + predios + """ set via_princ = trim(via_princ) WHERE via_princ <> trim(via_princ);
    update """ + predios + """ set direccion_final = trim(direccion_final) WHERE direccion_final <> trim(direccion_final);
    update """ + predios + """ set direccion2 = trim(direccion2) WHERE direccion2 <> trim(direccion2);
    update """ + predios + """ set dir_antigua = trim(dir_antigua) WHERE dir_antigua <> trim(dir_antigua);
    
    Update """ + predios + """ set via_princ = REPLACE(via_princ,'  ',' ') where via_princ LIKE '%  %';
    Update """ + predios + """ set direccion_final = REPLACE(direccion_final,'  ',' ') where direccion_final LIKE '%  %';
    Update """ + predios + """ set direccion2 = REPLACE(direccion2,'  ',' ') where direccion2 LIKE '%  %';
    Update """ + predios + """ set dir_antigua = REPLACE(dir_antigua,'  ',' ') where dir_antigua LIKE '%  %';
    
    /*DIRECCION2: Eliminar los registros que no tengan formato o no cumplan con las abreviaturas de via_princ */
    UPDATE """ + predios + """ pr SET direccion2 = NULL FROM (
        SELECT id,direccion,categoria,tipo_direccion,id_predio FROM """ + placas + """
        WHERE direccion IS NOT NULL 
        AND categoria = 'DIR2'
        AND tipo_direccion LIKE ANY(ARRAY['SIN FORMATO','%No tiene formato%'])
        AND direccion !~ '^(ADL|ADM|AER|AGE|BRR|ALD|ALM|ALT|APD|CDE|APS|ATR|AUT|AV|AC|AK|CND|BIF|CJR|MTF|BV|CL|CJON|CAM|CAN|KR|CT|URD|CAR|CEL|CCO|CES|CHI|CQ|CRV|URB|KDX|CNT|COR|DPT|DPS|DSS|DG|EDI|ENT|ESC|ESL|ESM|ETA|EXT|FCA|GRJ|GRS|GTA|HCD|HGR|HOR|IPP|IPD|IPM|SMA|KMT|AGP|LMN|LCS|MEJ|MEZ|MOJ|MLL|MCP|NPAR|OFS|PRJ|PWA|PAQ|PQD|PJ|PT|PHO|PIS|PLA|POL|PTE|POS|PDI|PNT|PUE|RTO|RPO|SAL|SCM|SSO|SLR|STN|SUI|TER|TRZ|TV|VTE|VDA|VIA|ZFR|ZNV|ZNA)'
    ) AS ant
    WHERE pr.id = ant.id_predio
    AND direccion2 NOT LIKE '%|%';

    DELETE FROM """ + placas + """ WHERE direccion IS NOT NULL 
    AND categoria = 'DIR2'
    AND tipo_direccion LIKE ANY(ARRAY['SIN FORMATO','%No tiene formato%'])
    AND direccion !~ '^(ADL|ADM|AER|AGE|BRR|ALD|ALM|ALT|APD|CDE|APS|ATR|AUT|AV|AC|AK|CND|BIF|CJR|MTF|BV|CL|CJON|CAM|CAN|KR|CT|URD|CAR|CEL|CCO|CES|CHI|CQ|CRV|URB|KDX|CNT|COR|DPT|DPS|DSS|DG|EDI|ENT|ESC|ESL|ESM|ETA|EXT|FCA|GRJ|GRS|GTA|HCD|HGR|HOR|IPP|IPD|IPM|SMA|KMT|AGP|LMN|LCS|MEJ|MEZ|MOJ|MLL|MCP|NPAR|OFS|PRJ|PWA|PAQ|PQD|PJ|PT|PHO|PIS|PLA|POL|PTE|POS|PDI|PNT|PUE|RTO|RPO|SAL|SCM|SSO|SLR|STN|SUI|TER|TRZ|TV|VTE|VDA|VIA|ZFR|ZNV|ZNA)';


    /*DIR_ANTIGUA: Eliminar los registros que no tengan formato o no cumplan con las abreviaturas de via_princ */
    UPDATE """ + predios + """ pr SET dir_antigua = NULL FROM (
        SELECT id,direccion,categoria,tipo_direccion,id_predio FROM """ + placas + """
        WHERE direccion IS NOT NULL 
        AND categoria = 'DIR3'
        AND tipo_direccion LIKE ANY(ARRAY['SIN FORMATO','%No tiene formato%'])
        AND direccion !~ '^(ADL|ADM|AER|AGE|BRR|ALD|ALM|ALT|APD|CDE|APS|ATR|AUT|AV|AC|AK|CND|BIF|CJR|MTF|BV|CL|CJON|CAM|CAN|KR|CT|URD|CAR|CEL|CCO|CES|CHI|CQ|CRV|URB|KDX|CNT|COR|DPT|DPS|DSS|DG|EDI|ENT|ESC|ESL|ESM|ETA|EXT|FCA|GRJ|GRS|GTA|HCD|HGR|HOR|IPP|IPD|IPM|SMA|KMT|AGP|LMN|LCS|MEJ|MEZ|MOJ|MLL|MCP|NPAR|OFS|PRJ|PWA|PAQ|PQD|PJ|PT|PHO|PIS|PLA|POL|PTE|POS|PDI|PNT|PUE|RTO|RPO|SAL|SCM|SSO|SLR|STN|SUI|TER|TRZ|TV|VTE|VDA|VIA|ZFR|ZNV|ZNA)'
    ) AS ant
    WHERE pr.id = ant.id_predio
    AND dir_antigua NOT LIKE '%|%';

    DELETE FROM """ + placas + """ WHERE direccion IS NOT NULL 
    AND categoria = 'DIR3'
    AND tipo_direccion LIKE ANY(ARRAY['SIN FORMATO','%No tiene formato%'])
    AND direccion !~ '^(ADL|ADM|AER|AGE|BRR|ALD|ALM|ALT|APD|CDE|APS|ATR|AUT|AV|AC|AK|CND|BIF|CJR|MTF|BV|CL|CJON|CAM|CAN|KR|CT|URD|CAR|CEL|CCO|CES|CHI|CQ|CRV|URB|KDX|CNT|COR|DPT|DPS|DSS|DG|EDI|ENT|ESC|ESL|ESM|ETA|EXT|FCA|GRJ|GRS|GTA|HCD|HGR|HOR|IPP|IPD|IPM|SMA|KMT|AGP|LMN|LCS|MEJ|MEZ|MOJ|MLL|MCP|NPAR|OFS|PRJ|PWA|PAQ|PQD|PJ|PT|PHO|PIS|PLA|POL|PTE|POS|PDI|PNT|PUE|RTO|RPO|SAL|SCM|SSO|SLR|STN|SUI|TER|TRZ|TV|VTE|VDA|VIA|ZFR|ZNV|ZNA)';

    UPDATE """ + predios + """ SET direccion2 = NULL WHERE direccion_final = direccion2;
    

    
    /*ESTANDARIZACION DIRECCION 2*/
	update """ + predios + """ set direccion2 = UPPER(direccion2) WHERE direccion2<>UPPER(direccion2);
	update """ + predios + """ set direccion2 = replace(direccion2,'UB. ','URB ') WHERE direccion2 like '%UB. %';
    update """ + predios + """ set direccion2 = replace(direccion2,'UR. ','URB ') WHERE direccion2 like '%UR. %';
 	update """ + predios + """ set direccion2 = replace(direccion2,'BR. ','BRR ') WHERE direccion2 like '%BR. %';
    update """ + predios + """ set direccion2 = replace(direccion2,'ET. ','ETA ') WHERE direccion2 like '%ET. %';
	update """ + predios + """ set direccion2 = replace(direccion2,' CS ',' CAS ') WHERE direccion2 like '% CS %';
	update """ + predios + """ set direccion2 = replace(direccion2,' BL ',' BQU ') WHERE direccion2 like '% BL %';
	update """ + predios + """ set direccion2 = replace(direccion2,'K ','KR ') WHERE direccion2 like 'K %';
	update """ + predios + """ set direccion2 = replace(direccion2,'#',' KR ') WHERE direccion2 like '%#%' and direccion2 like 'CL %';
	update """ + predios + """ set direccion2 = replace(direccion2,'#',' CL ') WHERE direccion2 like '%#%' and direccion2 like 'KR %';
	update """ + predios + """ set direccion2 = replace(direccion2,'MZ ','MZA ') WHERE direccion2 like 'MZ %';
	update """ + predios + """ set direccion2 = replace(direccion2,' MZ ',' MZA ') WHERE direccion2 like '% MZ %';
	update """ + predios + """ set direccion2 = replace(direccion2,'BL. ',' BQU ') WHERE direccion2 like 'BL. %';
	update """ + predios + """ set direccion2 = replace(direccion2,' TO ',' TOR ') WHERE direccion2 like '% TO %';
    update """ + predios + """ set direccion2 = replace(direccion2,' TO. ',' TOR ') WHERE direccion2 like '% TO. %';
    update """ + predios + """ set direccion2 = replace(direccion2,'-',' ') WHERE direccion2 like '%-%';
    update """ + predios + """ set direccion2 = replace(direccion2,'  ',' ') WHERE direccion2 like '%  %';
	update """ + predios + """ set direccion2 = replace(direccion2,'  ',' ') WHERE direccion2 like '%  %';
	update """ + predios + """ set direccion2 = trim(direccion2) WHERE direccion2 <> trim(direccion2);