import re
import csv
from qgis.core import QgsProject, QgsField, QgsFeatureRequest
from PyQt5.QtCore import QVariant

# ===============================
# CONFIGURACIÓN
# ===============================
NOMBRE_CAPA = "predios pasto prueba — predios_pasto"
CAMPO_ORIGEN = "dir_ori"
CAMPO_DESTINO = "std_barrio"
CAMPO_DIAG = "diag_proc"

RUTA_CSV = r"C:\Users\avalverde\Documents\Copia de 08_Estructura_base_diccionario_barrios_vias - 02_Diccionario_maestro.csv"

# ===============================
# 1. CARGA DEL DICCIONARIO
# ===============================
mapa_reemplazos = {
   "UB": "URB", "BR": "BRR", "CS": "CAS", "TO": "TOR", "ET": "ETA",
   "CN": "CND", "IN": "INT", "CO": "CJR", "CR": "CJR", "SM": "SMA",
   "SC": "SEC", "MZ": "MZA"
}

try:
   with open(RUTA_CSV, mode='r', encoding='utf-8-sig') as f:
       lector = csv.reader(f)
       next(lector)
       for fila in lector:
           if len(fila) >= 2:
               termino = fila[0].strip().upper()
               abrevia = fila[1].strip().upper()
               if termino: mapa_reemplazos[termino] = abrevia
except Exception as e:
   print(f"❌ Error leyendo CSV: {e}")

# Patrón Maestro
master_patron = re.compile(r'\b(' + '|'.join(map(re.escape, mapa_reemplazos.keys())) + r')\b', re.I)

# ── Expresiones regulares de limpieza ─────────────────────────────────────
RE_LIMPIEZA_HASH_PUNTO = re.compile(r'[#.]')
RE_ASTERISCO           = re.compile(r'\s*\*\s*')
RE_GUION               = re.compile(r'-')
RE_ESPACIOS            = re.compile(r'\s+')
# ── Romanos ────────────────────────────────────────────────────────────────
RE_ROMANOS_TRAS_MZA    = re.compile(r'\bMZA\s+(I{1,3}|IV|VI{0,3}|IX|X)\b')
RE_ROMANOS_LIBRE       = re.compile(r'\b(I{1,3}|IV|VI{0,3}|IX|X)\b')
# ── Nombres propios que contienen romanos (NO agregar ETA) ─────────────────
NOMBRES_CON_ROMANO     = re.compile(
    r'\b(JUAN\s+PABLO\s+(?:I{1,3}|IV|VI{0,3}|IX|X))\b'
)
# ── Anclas ─────────────────────────────────────────────────────────────────
anclas_lista = ["BRR", "URB", "CDE", "CND", "MTF", "URD", "EDI", "AGP", "PAQ", "BIF", "KDX", "SMA", "CJR", "ZNA"]
RE_ANCLA = re.compile(r'\b(' + '|'.join(anclas_lista) + r')\b')

# ===============================
# 2. PROCESO
# ===============================
layers = QgsProject.instance().mapLayersByName(NOMBRE_CAPA)
if not layers:
   print(f"❌ Capa '{NOMBRE_CAPA}' no encontrada.")
else:
   layer = layers[0]

   # CREACIÓN SEGURA DE CAMPOS
   layer.startEditing()
   pr = layer.dataProvider()
   for nombre in [CAMPO_DESTINO, CAMPO_DIAG]:
       if layer.fields().indexFromName(nombre) == -1:
           pr.addAttributes([QgsField(nombre, QVariant.String, "String", 254)])
   layer.commitChanges()
   layer.updateFields()

   idx_orig = layer.fields().indexFromName(CAMPO_ORIGEN)
   idx_dest = layer.fields().indexFromName(CAMPO_DESTINO)
   idx_diag = layer.fields().indexFromName(CAMPO_DIAG)

   if idx_orig == -1 or idx_dest == -1 or idx_diag == -1:
       print(f"❌ ERROR: No se pudieron encontrar/crear los campos.")
       print(f"Índices: Origen({idx_orig}), Destino({idx_dest}), Diag({idx_diag})")
       print("Sugerencia: Verifica si tus campos se llaman diferente por el límite de 10 caracteres.")
   else:
       request = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry)
       request.setSubsetOfAttributes([idx_orig])

       cambios = {}
       processed = 0

       for f in layer.getFeatures(request):
           original = str(f[idx_orig]).upper() if f[idx_orig] else ""
           if not original: continue

           # A. Limpieza de caracteres
           txt = RE_LIMPIEZA_HASH_PUNTO.sub('', original)
           txt = RE_ASTERISCO.sub(' | ', txt)
           txt = RE_GUION.sub(' ', txt)
           txt = RE_ESPACIOS.sub(' ', txt).strip()

           # A1. Estandarización de Ñ
           txt = re.sub(r'[⊙Á¡¿]', 'Ñ', txt)

           diag_log = []

           def realizar_cambio(match):
               p = match.group(0)
               rep = mapa_reemplazos.get(p)
               if rep and rep != p:
                   diag_log.append(f"{p}->{rep}")
                   return rep
               return p

           txt_p = master_patron.sub(realizar_cambio, txt)

           # B. Zonas
           if "ZU" in txt_p or "ZEU" in txt_p:
               txt_p = re.sub(r'\bZU\b', 'ZNA URB', txt_p)
               txt_p = re.sub(r'\bZEU\b', 'ZNA EXT URB', txt_p)
               diag_log.append("ZNA")

           # C. Romanos — protege MZA y nombres propios con romano
           marcas_mza = {}

           def marcar_nombre_propio(m):
               token = f"__NOMBRE_PROPIO_{len(marcas_mza)}__"
               marcas_mza[token] = m.group(0)
               return token

           def marcar_romano_mza(m):
               token = f"__MZA_ROMANO_{m.group(1)}__"
               marcas_mza[token] = f"MZA {m.group(1)}"
               return token

           # Proteger primero nombres propios (JUAN PABLO II, etc.)
           txt_p = NOMBRES_CON_ROMANO.sub(marcar_nombre_propio, txt_p)
           # Luego proteger romanos tras MZA
           txt_p = RE_ROMANOS_TRAS_MZA.sub(marcar_romano_mza, txt_p)

           # Agregar ETA a romanos libres restantes
           txt_p = RE_ROMANOS_LIBRE.sub(
               lambda m: f"ETA {m.group()}" if "ETA" not in txt_p else m.group(),
               txt_p
           )

           # Restaurar tokens protegidos
           for token, valor_original in marcas_mza.items():
               txt_p = txt_p.replace(token, valor_original)

           txt_p = RE_ESPACIOS.sub(' ', txt_p).strip()

           # D. Diagnóstico
           res_diag = " | ".join(diag_log)
           if not RE_ANCLA.search(txt_p): res_diag += " | SIN ANCLA"
           if txt_p == original: res_diag = "SIN CAMBIOS"
           elif not diag_log: res_diag = "LIMPIEZA CARACTERES"

           cambios[f.id()] = {idx_dest: txt_p, idx_diag: res_diag}
           processed += 1

       layer.dataProvider().changeAttributeValues(cambios)
       print(f"✅ Éxito: {processed} registros estandarizados en '{CAMPO_DESTINO}'.")
