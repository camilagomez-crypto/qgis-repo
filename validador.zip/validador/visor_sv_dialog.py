# visor_sv_dialog.py (VERSIÓN 6.0 - FINAL ANTI-BLOQUEO)

import re
import os
import traceback
from pathlib import Path
from qgis.PyQt.QtWidgets import QDockWidget, QVBoxLayout, QWidget, QLabel, QToolBar, QAction, QMessageBox
from qgis.PyQt.QtGui import QColor, QIcon
from qgis.PyQt.QtCore import QUrl, Qt, QTimer, QPointF, QBuffer, QByteArray, QIODevice
from qgis.core import (
    QgsProject, QgsWkbTypes, QgsCoordinateReferenceSystem,
    QgsCoordinateTransform, QgsMessageLog, Qgis, 
    QgsGeometry, QgsPointXY, QgsVectorLayer, QgsField, edit
)
from qgis.gui import QgsRubberBand, QgsVertexMarker, QgsMapToolEmitPoint
from qgis.utils import iface

try:
    from qgis.PyQt.QtWebEngineWidgets import QWebEngineView
    WEB_ENGINE_DISPONIBLE = True
except ImportError:
    WEB_ENGINE_DISPONIBLE = False

JS_GET_URL = "window.location.href;"

class VisorSVMapTool(QgsMapToolEmitPoint):
    def __init__(self, canvas, dialog): super().__init__(canvas); self.dialog = dialog
    def canvasPressEvent(self, event):
        crs_src = self.canvas().mapSettings().destinationCrs()
        if not crs_src.isValid(): iface.messageBar().pushMessage( "Error del Plugin", "El proyecto no tiene un Sistema de Coordenadas (SRC) definido.", level=Qgis.Critical, duration=7); return
        point_map_crs = self.toMapCoordinates(event.pos())
        crs_dst = QgsCoordinateReferenceSystem("EPSG:4326")
        transform = QgsCoordinateTransform(crs_src, crs_dst, QgsProject.instance())
        point_wgs84 = transform.transform(point_map_crs)
        self.dialog.load_street_view(point_wgs84)
    def deactivate(self): super().deactivate(); iface.mapCanvas().setCursor(Qt.ArrowCursor); self.dialog.select_point_action.setChecked(False)

class VisorSVDialog(QDockWidget):
    def __init__(self, parent=iface.mainWindow()):
        super().__init__("Street View Cartografia", parent)
        self.setAllowedAreas(Qt.AllDockWidgetAreas); self.setFeatures(QDockWidget.DockWidgetClosable | QDockWidget.DockWidgetMovable | QDockWidget.DockWidgetFloatable)
        self.webview = None; self.tracking_timer = None; self.map_tool = None; self.vm_pegman = None; self.rb_arrow = None
        self.init_canvas_items(); self.build_ui()
    def prepare_for_display(self):
        if self.vm_pegman is None or self.rb_arrow is None: self.init_canvas_items()
    def set_canvas_items_visibility(self, visible):
        if visible: self.request_current_data()
        else:
            if self.vm_pegman: self.vm_pegman.hide()
            if self.rb_arrow: self.rb_arrow.hide()
    def build_ui(self):
        widget_contenido = QWidget(); layout = QVBoxLayout(widget_contenido); layout.setContentsMargins(0, 0, 0, 0)
        main_toolbar = QToolBar(); layout.addWidget(main_toolbar)
        self.select_point_action = main_toolbar.addAction("Seleccionar Punto en Mapa")
        self.select_point_action.setCheckable(True); self.select_point_action.setToolTip("Activa/Desactiva la seleccion de puntos en el mapa"); self.select_point_action.triggered.connect(self.toggle_select_tool)
        main_toolbar.addSeparator()
        self.capture_action = main_toolbar.addAction("Capturar Evidencia")
        self.capture_action.setToolTip("Toma una 'foto' de la vista actual y la guarda en el objeto seleccionado.")
        self.capture_action.triggered.connect(self.capturar_y_guardar_evidencia)
        main_toolbar.addSeparator()
        if WEB_ENGINE_DISPONIBLE:
            self.webview = QWebEngineView(); self.webview.setUrl(QUrl("about:blank")); self.webview.loadFinished.connect(self.start_tracking); layout.addWidget(self.webview)
            zoom_toolbar = main_toolbar
            self.zoom_out_action = zoom_toolbar.addAction("-"); self.zoom_out_action.triggered.connect(self.zoom_out)
            self.zoom_label = QLabel(" 100% "); zoom_toolbar.addWidget(self.zoom_label)
            self.zoom_in_action = zoom_toolbar.addAction("+"); self.zoom_in_action.triggered.connect(self.zoom_in)
            zoom_toolbar.addSeparator()
            self.reset_zoom_action = zoom_toolbar.addAction("Restablecer"); self.reset_zoom_action.triggered.connect(self.reset_zoom)
        else:
            label = QLabel("Componente Street View no disponible.\nInstale 'python3-pyqt5.qtwebengine' o similar."); label.setAlignment(Qt.AlignCenter); layout.addWidget(label)
        self.setWidget(widget_contenido)
    def prepare_layer(self, layer, field_name='foto_evidencia'):
        source = layer.source()
        if 'gpkg' not in Path(source).suffix.lower():
            QMessageBox.warning(self, "Capa no Soportada", f"La capa '{layer.name()}' no es un GeoPackage."); return False
        if layer.fields().indexOf(field_name) == -1:
            try:
                with edit(layer):
                    provider = layer.dataProvider(); provider.addAttributes([QgsField(field_name, 12)])
                iface.messageBar().pushMessage("Info", f"Campo '{field_name}' creado en la capa '{layer.name()}'.", level=Qgis.Info, duration=4)
            except Exception as e:
                QMessageBox.critical(self, "Error", f"No se pudo crear el campo '{field_name}'.\nLa capa podría ser de solo lectura.\nError: {e}")
                return False
        return True

    def capturar_y_guardar_evidencia(self):
        layer = iface.activeLayer()
        if not layer or not isinstance(layer, QgsVectorLayer): iface.messageBar().pushMessage("Error", "Por favor, seleccione una capa vectorial.", level=Qgis.Critical, duration=3); return
        
        selected_features = layer.selectedFeatures()
        if len(selected_features) != 1: iface.messageBar().pushMessage("Atencion", "Por favor, use la herramienta de SELECCION para elegir UN solo objeto.", level=Qgis.Warning, duration=5); return
        
        feature_id = selected_features[0].id()
        field_name = 'foto_evidencia'

        if not self.prepare_layer(layer, field_name): return
        if not self.webview: iface.messageBar().pushMessage("Error", "El visor de Street View no esta disponible.", level=Qgis.Critical); return
        
        pixmap = self.webview.grab()
        ba = QByteArray(); buffer = QBuffer(ba); buffer.open(QIODevice.WriteOnly); pixmap.save(buffer, "PNG"); image_data = ba.data()
        if len(image_data) == 0: iface.messageBar().pushMessage("Error", "La captura de la imagen fallo (imagen vacia).", level=Qgis.Critical); return
        
        try:
            # --- LÓGICA DE EDICIÓN INTELIGENTE Y ROBUSTA ---
            is_editable = layer.isEditable()
            if not is_editable:
                # Si la capa no está en edición, usamos el método seguro 'with edit'
                with edit(layer):
                    feature_fresca = layer.getFeature(feature_id)
                    idx = layer.fields().indexOf(field_name)
                    feature_fresca.setAttribute(idx, image_data)
                    layer.updateFeature(feature_fresca)
            else:
                # Si la capa YA está en edición, actualizamos directamente
                feature_fresca = layer.getFeature(feature_id)
                idx = layer.fields().indexOf(field_name)
                feature_fresca.setAttribute(idx, image_data)
                layer.updateFeature(feature_fresca)
            
            iface.messageBar().pushMessage("Exito", f"Imagen guardada para el objeto {feature_id}", level=Qgis.Success, duration=3)
            
            # Forzamos el refresco de la UI
            layer.triggerRepaint()
            iface.mapCanvas().refresh()

        except Exception as e:
            iface.messageBar().pushMessage("Error CRITICO", f"No se pudo guardar la imagen. Revise la Consola de Python.", level=Qgis.Critical, duration=10)
            print("----------- ERROR CRÍTICO AL GUARDAR -----------")
            traceback.print_exc()
            print("-------------------------------------------------")
    
    def toggle_select_tool(self, checked):
        canvas = iface.mapCanvas()
        if checked: self.map_tool = VisorSVMapTool(canvas, self); canvas.setMapTool(self.map_tool); canvas.setCursor(Qt.CrossCursor)
        else:
            if self.map_tool and canvas.mapTool() == self.map_tool: canvas.unsetMapTool(self.map_tool)
    def zoom_in(self):
        if not self.webview: return
        new_zoom = self.webview.zoomFactor() + 0.1; self.webview.setZoomFactor(new_zoom); self.update_zoom_label(new_zoom)
    def zoom_out(self):
        if not self.webview: return
        new_zoom = self.webview.zoomFactor() - 0.1
        if new_zoom < 0.1: new_zoom = 0.1
        self.webview.setZoomFactor(new_zoom); self.update_zoom_label(new_zoom)
    def reset_zoom(self):
        if not self.webview: return
        self.webview.setZoomFactor(1.0); self.update_zoom_label(1.0)
    def update_zoom_label(self, zoom_factor):
        if hasattr(self, 'zoom_label'): self.zoom_label.setText(f" {zoom_factor:.0%} ")
    def init_canvas_items(self):
        canvas = iface.mapCanvas()
        self.vm_pegman = QgsVertexMarker(canvas); self.vm_pegman.setColor(QColor(50, 200, 50)); self.vm_pegman.setIconType(QgsVertexMarker.ICON_CIRCLE); self.vm_pegman.setIconSize(12); self.vm_pegman.setPenWidth(2)
        canvas.scene().addItem(self.vm_pegman); self.vm_pegman.hide()
        self.rb_arrow = QgsRubberBand(canvas, QgsWkbTypes.PolygonGeometry); self.rb_arrow.setColor(QColor(0, 150, 255, 200)); self.rb_arrow.setWidth(1); self.base_arrow_polygon = self.create_arrow_polygon()
    def create_arrow_polygon(self):
        points = [QPointF(10, 0), QPointF(1.5, 4.5), QPointF(1.5, 2), QPointF(4, 0), QPointF(1.5, -2), QPointF(1.5, -4.5)]
        return QgsGeometry.fromPolygonXY([[QgsPointXY(p.x(), p.y()) for p in points]])
    def load_street_view(self, point_wgs84):
        lat, lon = point_wgs84.y(), point_wgs84.x()
        url = f"https://www.google.com/maps?q&layer=c&cbll={lat},{lon}&cbp=12,0,0,0,0"
        if self.webview: self.webview.load(QUrl(url))
        self.show(); self.raise_()
    def start_tracking(self, ok):
        if not ok: return
        if self.tracking_timer: self.tracking_timer.stop()
        self.tracking_timer = QTimer(self); self.tracking_timer.setInterval(500); self.tracking_timer.timeout.connect(self.request_current_data); self.tracking_timer.start()
    def request_current_data(self):
        if self.webview and self.webview.isVisible(): self.webview.page().runJavaScript(JS_GET_URL, self.process_url_data)
    def process_url_data(self, url):
        if not self.isVisible() or not url or url == "about:blank":
            if self.vm_pegman: self.vm_pegman.hide()
            if self.rb_arrow: self.rb_arrow.hide()
            return
        lat, lon, heading = None, None, 0.0
        new_format_match = re.search(r'@([-\d.]+),([-\d.]+),.*?([\d.]+)h', url)
        if new_format_match: lat, lon, heading = float(new_format_match.group(1)), float(new_format_match.group(2)), float(new_format_match.group(3))
        else:
            old_pos_match = re.search(r'cbll=([-\d.]+),([-\d.]+)', url)
            if old_pos_match:
                lat, lon = float(old_pos_match.group(1)), float(old_pos_match.group(2))
                old_heading_match = re.search(r'cbp=\d+,([-\d.]+)', url)
                if old_heading_match: heading = float(old_heading_match.group(1))
        if lat is None or lon is None:
            if self.vm_pegman: self.vm_pegman.hide()
            if self.rb_arrow: self.rb_arrow.hide()
            return
        crs_src = iface.mapCanvas().mapSettings().destinationCrs()
        if not crs_src.isValid(): return
        crs_wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        transform = QgsCoordinateTransform(crs_wgs84, crs_src, QgsProject.instance()); pegman_pos_map = transform.transform(QgsPointXY(lon, lat))
        if self.vm_pegman: self.vm_pegman.setCenter(pegman_pos_map); self.vm_pegman.show()
        map_width = iface.mapCanvas().extent().width(); scale_factor = (map_width * 0.02) / 10.0
        original_points = self.base_arrow_polygon.asPolygon()[0]; scaled_points = [QgsPointXY(p.x() * scale_factor, p.y() * scale_factor) for p in original_points]
        arrow_geom = QgsGeometry.fromPolygonXY([scaled_points]); rotation_angle = heading - 100; arrow_geom.rotate(rotation_angle, QgsPointXY(0,0)); arrow_geom.translate(pegman_pos_map.x(), pegman_pos_map.y())
        if self.rb_arrow: self.rb_arrow.setToGeometry(arrow_geom, None); self.rb_arrow.show()
    def cleanup_canvas_items(self):
        if self.tracking_timer: self.tracking_timer.stop(); self.tracking_timer = None
        if self.rb_arrow: self.rb_arrow.reset(); self.rb_arrow = None
        if self.vm_pegman:
            canvas_scene = iface.mapCanvas().scene()
            if self.vm_pegman.scene() == canvas_scene: canvas_scene.removeItem(self.vm_pegman)
            self.vm_pegman = None
        if self.map_tool: iface.mapCanvas().unsetMapTool(self.map_tool); self.map_tool = None
    def closeEvent(self, event):
        self.cleanup_canvas_items()
        super().closeEvent(event)