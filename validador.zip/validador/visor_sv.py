# -*- coding: utf-8 -*-

from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtWidgets import QAction
from qgis.utils import iface

from .visor_sv_dialog import VisorSVDialog 

class VisorSV:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None

    def tr(self, message):
        return QCoreApplication.translate('StreetViewCartografia', message)

    def initGui(self):
        self.action = QAction(self.tr("Street View Cartografia"), self.iface.mainWindow())
        self.action.setToolTip(self.tr("Muestra/Oculta la ventana de Street View"))
        self.action.setCheckable(False) 
        self.action.triggered.connect(self.run)
        
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(self.tr("&Street View Cartografia"), self.action)

    def unload(self):
        self.iface.removePluginMenu(self.tr("&Street View Cartografia"), self.action)
        self.iface.removeToolBarIcon(self.action)
        if self.dialog:
            self.dialog.close()

    def run(self):
        if self.dialog is None:
            self.dialog = VisorSVDialog(iface.mainWindow())
            self.dialog.destroyed.connect(lambda: setattr(self, 'dialog', None))

        if self.dialog.isVisible():
            self.dialog.hide()
            self.dialog.set_canvas_items_visibility(False)
        else:
            self.dialog.prepare_for_display()
            self.dialog.show()
            self.dialog.set_canvas_items_visibility(True)
            self.dialog.raise_()