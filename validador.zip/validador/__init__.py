# -*- coding: utf-8 -*-

def classFactory(iface):
    from .visor_sv import VisorSV
    return VisorSV(iface)