# sv_image_enhancer.py
# Motor de mejora de imagen para placas en Street View.
# Cubre: oscuridad, pixelado, rejas/rejillas.
# Modo automático + panel de ajuste manual con sliders.
#
# REQUIERE: pip install opencv-python-headless Pillow numpy

import numpy as np

from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QSlider, QFrame, QCheckBox, QSizePolicy
)
from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtGui import QPixmap, QImage
from qgis.core import QgsMessageLog, Qgis


# ── Conversión QPixmap ↔ numpy ────────────────────────────────────────────────

def pixmap_to_numpy(pixmap: QPixmap) -> np.ndarray:
    """QPixmap → numpy array BGR (formato OpenCV)."""
    image = pixmap.toImage().convertToFormat(QImage.Format_RGB888)
    w, h = image.width(), image.height()
    ptr = image.bits()
    ptr.setsize(h * w * 3)
    arr = np.frombuffer(ptr, dtype=np.uint8).reshape((h, w, 3)).copy()
    import cv2
    return cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)


def numpy_to_pixmap(arr: np.ndarray) -> QPixmap:
    """numpy array BGR → QPixmap."""
    import cv2
    rgb = cv2.cvtColor(arr, cv2.COLOR_BGR2RGB)
    h, w, ch = rgb.shape
    qimg = QImage(rgb.data, w, h, w * ch, QImage.Format_RGB888)
    return QPixmap.fromImage(qimg.copy())


# ── Motor de mejoras ──────────────────────────────────────────────────────────

class SVImageEnhancer:

    # ── 1. Oscuridad ──────────────────────────────────────────────────────────

    def fix_darkness(self, img: np.ndarray, strength: float = 1.0) -> np.ndarray:
        """
        CLAHE: corrige zonas oscuras sin quemar las claras.
        strength: 0.0 – 2.0
        """
        import cv2
        lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clip = max(1.0, min(8.0, 2.0 + strength * 3.0))
        clahe = cv2.createCLAHE(clipLimit=clip, tileGridSize=(8, 8))
        l_eq = clahe.apply(l)
        merged = cv2.merge([l_eq, a, b])
        return cv2.cvtColor(merged, cv2.COLOR_LAB2BGR)

    # ── 2. Pixelado ───────────────────────────────────────────────────────────

    def fix_pixelation(self, img: np.ndarray, strength: float = 1.0) -> np.ndarray:
        """
        Upscale con interpolación cúbica + unsharp mask.
        strength: 0.0 – 2.0
        """
        import cv2
        h, w = img.shape[:2]
        scale = 1.0 + strength * 0.5
        up = cv2.resize(img, (int(w * scale), int(h * scale)),
                        interpolation=cv2.INTER_CUBIC)
        amount = 0.5 + strength * 0.5
        blurred = cv2.GaussianBlur(up, (0, 0), sigmaX=3)
        sharpened = cv2.addWeighted(up, 1.0 + amount, blurred, -amount, 0)
        return cv2.resize(sharpened, (w, h), interpolation=cv2.INTER_AREA)

    # ── 3. Reja / rejilla ─────────────────────────────────────────────────────

    def fix_grid(self, img: np.ndarray, strength: float = 1.0) -> np.ndarray:
        """
        Detecta líneas de reja con Hough y las reconstruye con inpainting.
        strength: 0.0 – 2.0
        """
        import cv2
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(gray, 50, 150, apertureSize=3)
        min_length = int(img.shape[0] * 0.2)
        lines = cv2.HoughLinesP(
            edges, rho=1, theta=np.pi / 180,
            threshold=80, minLineLength=min_length, maxLineGap=10
        )
        mask = np.zeros(gray.shape, dtype=np.uint8)
        thickness = max(2, int(2 + strength * 3))

        if lines is not None:
            for line in lines:
                x1, y1, x2, y2 = line[0]
                dx, dy = abs(x2 - x1), abs(y2 - y1)
                angle = np.degrees(np.arctan2(dy, dx)) if dx > 0 else 90
                if angle < 20 or angle > 70:
                    cv2.line(mask, (x1, y1), (x2, y2), 255, thickness)

        if mask.any():
            return cv2.inpaint(img, mask, inpaintRadius=3, flags=cv2.INPAINT_TELEA)
        else:
            return cv2.bilateralFilter(img, d=9, sigmaColor=75, sigmaSpace=75)

    # ── 4. Auto ───────────────────────────────────────────────────────────────

    def auto_enhance(self, pixmap: QPixmap) -> QPixmap:
        """Analiza la imagen y aplica las correcciones automáticamente."""
        import cv2
        img = pixmap_to_numpy(pixmap)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        mean_brightness = float(np.mean(gray))
        std_brightness  = float(np.std(gray))

        if mean_brightness < 80:
            strength = min(2.0, (80 - mean_brightness) / 40)
            img = self.fix_darkness(img, strength)

        if std_brightness < 40:
            img = self.fix_pixelation(img, strength=0.8)

        kernel = np.array([[0, -0.3, 0],
                            [-0.3, 2.2, -0.3],
                            [0, -0.3, 0]])
        img = cv2.filter2D(img, -1, kernel)
        img = np.clip(img, 0, 255).astype(np.uint8)
        return numpy_to_pixmap(img)

    # ── 5. Manual ─────────────────────────────────────────────────────────────

    def apply_manual(
        self,
        pixmap: QPixmap,
        brightness: float = 0.0,
        contrast:   float = 0.0,
        sharpen:    float = 0.0,
        denoise:    float = 0.0,
        fix_grid:   bool  = False,
    ) -> QPixmap:
        import cv2
        img = pixmap_to_numpy(pixmap)

        if brightness != 0.0 or contrast != 0.0:
            alpha = 1.0 + contrast
            beta  = brightness * 127
            img = cv2.convertScaleAbs(img, alpha=alpha, beta=beta)

        if denoise > 0.0:
            h_val = int(5 + denoise * 15)
            img = cv2.fastNlMeansDenoisingColored(img, None, h_val, h_val, 7, 21)

        if sharpen > 0.0:
            blurred = cv2.GaussianBlur(img, (0, 0), sigmaX=3)
            img = cv2.addWeighted(img, 1.0 + sharpen, blurred, -sharpen, 0)

        if fix_grid:
            img = self.fix_grid(img, strength=1.0)

        img = np.clip(img, 0, 255).astype(np.uint8)
        return numpy_to_pixmap(img)


# ── Panel de controles manuales ───────────────────────────────────────────────

class SVEnhancerPanel(QWidget):
    """
    Panel con sliders para ajuste manual de imagen.
    Se conecta a SVPreviewWidget mediante la señal image_enhanced.
    """
    image_enhanced = pyqtSignal(QPixmap)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._original_pixmap = None
        self._enhancer = SVImageEnhancer()
        self._build_ui()

    def set_image(self, pixmap: QPixmap):
        """Llamar cuando llega una imagen nueva del preview."""
        self._original_pixmap = pixmap
        self._apply_auto()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(4, 4, 4, 4)
        root.setSpacing(6)

        # Encabezado
        header = QHBoxLayout()
        title = QLabel("🔧 Mejora de imagen")
        title.setStyleSheet("font-weight: bold;")
        header.addWidget(title)
        header.addStretch()

        self.btn_auto = QPushButton("✨ Auto")
        self.btn_auto.setToolTip("Aplicar mejora automática")
        self.btn_auto.setFixedWidth(70)
        self.btn_auto.clicked.connect(self._apply_auto)
        header.addWidget(self.btn_auto)

        self.btn_reset = QPushButton("↺ Reset")
        self.btn_reset.setToolTip("Volver a la imagen original")
        self.btn_reset.setFixedWidth(70)
        self.btn_reset.clicked.connect(self._apply_reset)
        header.addWidget(self.btn_reset)
        root.addLayout(header)

        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setFrameShadow(QFrame.Sunken)
        root.addWidget(sep)

        # Sliders
        grid = QGridLayout()
        grid.setSpacing(4)
        self._sliders = {}

        controls = [
            ("brightness", "☀  Brillo",         -100, 100, 0),
            ("contrast",   "◑  Contraste",       -100, 100, 0),
            ("sharpen",    "⬡  Nitidez",            0, 200, 0),
            ("denoise",    "~  Reducir ruido",      0, 200, 0),
        ]

        for row, (key, label, mn, mx, default) in enumerate(controls):
            lbl = QLabel(label)
            lbl.setFixedWidth(120)
            grid.addWidget(lbl, row, 0)

            slider = QSlider(Qt.Horizontal)
            slider.setMinimum(mn)
            slider.setMaximum(mx)
            slider.setValue(default)
            slider.valueChanged.connect(self._on_slider_changed)
            grid.addWidget(slider, row, 1)

            val_lbl = QLabel("0")
            val_lbl.setFixedWidth(32)
            val_lbl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            val_lbl.setStyleSheet("color:gray; font-size:11px;")
            grid.addWidget(val_lbl, row, 2)

            self._sliders[key] = (slider, val_lbl)

        root.addLayout(grid)

        # Checkbox reja
        self.chk_grid = QCheckBox("🔲  Eliminar reja / rejilla")
        self.chk_grid.stateChanged.connect(self._on_slider_changed)
        root.addWidget(self.chk_grid)

    def _on_slider_changed(self, _=None):
        for key, (slider, lbl) in self._sliders.items():
            lbl.setText(str(slider.value()))
        self._apply_manual()

    def _apply_auto(self):
        if self._original_pixmap is None:
            return
        result = self._enhancer.auto_enhance(self._original_pixmap)
        self.image_enhanced.emit(result)

    def _apply_reset(self):
        if self._original_pixmap is None:
            return
        for key, (slider, lbl) in self._sliders.items():
            slider.blockSignals(True)
            slider.setValue(0)
            lbl.setText("0")
            slider.blockSignals(False)
        self.chk_grid.blockSignals(True)
        self.chk_grid.setChecked(False)
        self.chk_grid.blockSignals(False)
        self.image_enhanced.emit(self._original_pixmap)

    def _apply_manual(self):
        if self._original_pixmap is None:
            return

        def sv(key):
            return self._sliders[key][0].value()

        result = self._enhancer.apply_manual(
            self._original_pixmap,
            brightness = sv("brightness") / 100.0,
            contrast   = sv("contrast")   / 100.0,
            sharpen    = sv("sharpen")    / 100.0,
            denoise    = sv("denoise")    / 100.0,
            fix_grid   = self.chk_grid.isChecked(),
        )
        self.image_enhanced.emit(result)
