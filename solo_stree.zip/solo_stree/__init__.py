import sys


class _NullStream:
    """
    En QGIS abierto como aplicación de ventana (sin consola), sys.stderr
    y sys.stdout pueden venir como None. Algunas librerías (numpy, cv2…)
    intentan escribir avisos internos ahí con sys.stderr.write(...) sin
    comprobar que exista, y truenan con AttributeError — eso es lo que
    generaba los warnings repetidos de numpy.core en el log de QGIS.
    Este flujo nulo absorbe esas escrituras sin hacer nada.
    """
    def write(self, *args, **kwargs):
        pass

    def flush(self):
        pass


if sys.stderr is None:
    sys.stderr = _NullStream()
if sys.stdout is None:
    sys.stdout = _NullStream()


def classFactory(iface):
    from .visor_sv import VisorSV
    return VisorSV(iface)

def name():
    return "Street View Cartografía"

def description():
    return "Permite visualizar Google Street View haciendo clic en el mapa y muestra la posición en la cartografía."

def version():
    return "2.0"

def author():
    return "Tu Nombre Aquí"

def icon():
    return "icon.png"
