# sv_preview.py
# Previsualización de Street View sin API Key.
# Descarga la imagen estática de Google y la muestra antes de abrir el visor completo.

from urllib.request import urlopen
from urllib.error import URLError

from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QSlider, QSizePolicy
)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal, QByteArray
from qgis.PyQt.QtGui import QPixmap
from qgis.core import QgsMessageLog, Qgis

from .sv_image_enhancer import SVEnhancerPanel


# ── Descarga en hilo separado ─────────────────────────────────────────────────

class ImageDownloader(QThread):
    finished = pyqtSignal(bytes)
    failed   = pyqtSignal(str)

    def __init__(self, url):
        super().__init__()
        self.url = url

    def run(self):
        try:
            with urlopen(self.url, timeout=8) as resp:
                data = resp.read()
            self.finished.emit(data)
        except URLError as e:
            self.failed.emit(str(e))
        except Exception as e:
            self.failed.emit(str(e))


# ── Widget principal ──────────────────────────────────────────────────────────

class SVPreviewWidget(QWidget):
    """
    Panel de previsualización con imagen estática de Street View,
    control de dirección (heading) y panel de mejora de imagen integrado.

    Señales:
        open_requested(lat, lon) — el usuario quiere abrir el SV completo
    """
    open_requested = pyqtSignal(float, float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._lat         = None
        self._lon         = None
        self._heading     = 0
        self._raw_pixmap  = None   # imagen original sin mejoras
        self._downloader  = None
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)

        # Imagen
        self.img_label = QLabel("Selecciona un punto en el mapa")
        self.img_label.setAlignment(Qt.AlignCenter)
        self.img_label.setMinimumHeight(180)
        self.img_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.img_label.setStyleSheet(
            "background:#111; color:#888; border-radius:6px; font-size:12px;"
        )
        layout.addWidget(self.img_label)

        # Coordenadas
        self.coord_label = QLabel("")
        self.coord_label.setAlignment(Qt.AlignCenter)
        self.coord_label.setStyleSheet("color:gray; font-size:11px;")
        layout.addWidget(self.coord_label)

        # Slider de heading
        heading_row = QHBoxLayout()
        heading_row.addWidget(QLabel("↻ Dirección:"))
        self.heading_slider = QSlider(Qt.Horizontal)
        self.heading_slider.setMinimum(0)
        self.heading_slider.setMaximum(359)
        self.heading_slider.setValue(0)
        self.heading_slider.valueChanged.connect(self._on_heading_changed)
        heading_row.addWidget(self.heading_slider)
        self.heading_label = QLabel("0°")
        self.heading_label.setFixedWidth(36)
        heading_row.addWidget(self.heading_label)
        layout.addLayout(heading_row)

        # Botón abrir SV completo
        self.btn_open = QPushButton("▶  Abrir Street View completo")
        self.btn_open.setEnabled(False)
        self.btn_open.setStyleSheet(
            "QPushButton { background:#1a73e8; color:white; border-radius:5px;"
            "              padding:6px; font-weight:bold; }"
            "QPushButton:hover { background:#1557b0; }"
            "QPushButton:disabled { background:#333; color:#666; }"
        )
        self.btn_open.clicked.connect(self._on_open)
        layout.addWidget(self.btn_open)

        # Panel de mejora de imagen
        self.enhancer_panel = SVEnhancerPanel(self)
        self.enhancer_panel.image_enhanced.connect(self._on_enhanced)
        layout.addWidget(self.enhancer_panel)

    # ── Carga ─────────────────────────────────────────────────────────────────

    def load_preview(self, lat, lon):
        self._lat = lat
        self._lon = lon
        self._heading = self.heading_slider.value()
        self._fetch_image()

    def _fetch_image(self):
        if self._lat is None:
            return

        self.img_label.setText("Cargando…")
        self.btn_open.setEnabled(False)
        self.coord_label.setText(
            f"Lat: {self._lat:.6f}   Lon: {self._lon:.6f}"
        )

        url = (
            f"https://maps.googleapis.com/maps/api/streetview"
            f"?size=600x300"
            f"&location={self._lat},{self._lon}"
            f"&heading={self._heading}"
            f"&fov=90"
            f"&pitch=0"
        )

        if self._downloader and self._downloader.isRunning():
            self._downloader.terminate()
            self._downloader.wait()

        self._downloader = ImageDownloader(url)
        self._downloader.finished.connect(self._on_image_received)
        self._downloader.failed.connect(self._on_image_failed)
        self._downloader.start()

    def _on_image_received(self, data):
        pixmap = QPixmap()
        loaded = pixmap.loadFromData(QByteArray(data))

        if not loaded or pixmap.isNull():
            self.img_label.setText("Sin cobertura en este punto")
            self.btn_open.setEnabled(False)
            return

        self._raw_pixmap = pixmap
        w = self.img_label.width() or 400
        scaled = pixmap.scaledToWidth(w, Qt.SmoothTransformation)
        self.img_label.setPixmap(scaled)
        self.btn_open.setEnabled(True)

        # Pasar al panel de mejora (aplica auto-mejora inmediatamente)
        self.enhancer_panel.set_image(pixmap)

    def _on_image_failed(self, msg):
        self.img_label.setText("Error al cargar imagen")
        self.btn_open.setEnabled(False)
        QgsMessageLog.logMessage(f"SVPreview error: {msg}", "VisorSV", Qgis.Warning)

    def _on_enhanced(self, pixmap: QPixmap):
        """Recibe la imagen mejorada y la muestra."""
        w = self.img_label.width() or 400
        scaled = pixmap.scaledToWidth(w, Qt.SmoothTransformation)
        self.img_label.setPixmap(scaled)

    def _on_heading_changed(self, value):
        self._heading = value
        self.heading_label.setText(f"{value}°")
        if self._lat is not None:
            self._fetch_image()

    def _on_open(self):
        if self._lat is not None:
            self.open_requested.emit(self._lat, self._lon)
