# visor_sv_dialog.py
# Versión limpia: sin preview estático, filtros CSS aplicados directo al webview.

import re
from qgis.PyQt.QtWidgets import (
    QDockWidget, QVBoxLayout, QHBoxLayout, QWidget,
    QLabel, QToolBar, QSlider, QCheckBox, QPushButton, QFrame,
    QApplication
)
from qgis.PyQt.QtGui import QColor, QImage
from qgis.PyQt.QtCore import QUrl, Qt, QTimer, QPointF
from qgis.core import (
    QgsProject, QgsWkbTypes, QgsCoordinateReferenceSystem,
    QgsCoordinateTransform, QgsMessageLog, Qgis,
    QgsGeometry, QgsPointXY
)
from qgis.gui import QgsRubberBand, QgsVertexMarker, QgsMapToolEmitPoint
from qgis.utils import iface
from .sv_enhance_panel import SVEnhancePanel, _ensure_safe_streams

try:
    from qgis.PyQt.QtWebEngineWidgets import QWebEngineView
    WEB_ENGINE_DISPONIBLE = True
except ImportError:
    WEB_ENGINE_DISPONIBLE = False

JS_GET_URL = "window.location.href;"

# JavaScript que inyecta un filtro CSS sobre todo el contenido del webview.
# Cuando hay nitidez > 0, además define un filtro SVG feConvolveMatrix real
# (un kernel de sharpen 3x3) y lo encadena en el filter: CSS. Antes, "Nitidez"
# solo volvía a escribir el valor de contraste — no aplicaba ningún realce
# de detalle real, porque CSS 'filter' no tiene una función de sharpen nativa.
JS_APPLY_FILTER = """
(function() {{
    var svgId = 'sv-sharpen-defs';
    var existingSvg = document.getElementById(svgId);
    if (existingSvg) existingSvg.remove();

    var kernel = {kernel};
    if (kernel) {{
        var svgNS = 'http://www.w3.org/2000/svg';
        var svg = document.createElementNS(svgNS, 'svg');
        svg.setAttribute('id', svgId);
        svg.setAttribute('width', '0');
        svg.setAttribute('height', '0');
        svg.style.position = 'absolute';
        var filterEl = document.createElementNS(svgNS, 'filter');
        filterEl.setAttribute('id', 'sv-sharpen-filter');
        filterEl.setAttribute('color-interpolation-filters', 'sRGB');
        var conv = document.createElementNS(svgNS, 'feConvolveMatrix');
        conv.setAttribute('order', '3');
        conv.setAttribute('kernelMatrix', kernel);
        conv.setAttribute('divisor', '1');
        conv.setAttribute('preserveAlpha', 'true');
        filterEl.appendChild(conv);
        svg.appendChild(filterEl);
        document.body.appendChild(svg);
    }}

    var styleId = 'sv-filter-style';
    var existing = document.getElementById(styleId);
    if (existing) existing.remove();
    var style = document.createElement('style');
    style.id = styleId;
    style.textContent = 'body {{ filter: {filter_str} !important; }}';
    document.head.appendChild(style);
}})();
"""

# Chequeo rápido de si el filtro sigue presente en el DOM (Street View es una
# SPA: al desplazarse dentro de la panorámica no siempre dispara loadFinished,
# así que el <style> inyectado puede perderse en un re-render interno).
JS_CHECK_FILTER = "!!document.getElementById('sv-filter-style');"


class VisorSVMapTool(QgsMapToolEmitPoint):
    def __init__(self, canvas, dialog):
        super().__init__(canvas)
        self.dialog = dialog

    def canvasPressEvent(self, event):
        crs_src = self.canvas().mapSettings().destinationCrs()
        if not crs_src.isValid():
            iface.messageBar().pushMessage(
                "Error del Plugin",
                "El proyecto no tiene un SRC definido.",
                level=Qgis.Critical, duration=7
            )
            return
        point_map_crs = self.toMapCoordinates(event.pos())
        crs_dst = QgsCoordinateReferenceSystem("EPSG:4326")
        transform = QgsCoordinateTransform(crs_src, crs_dst, QgsProject.instance())
        point_wgs84 = transform.transform(point_map_crs)
        self.dialog.load_street_view(point_wgs84)

    def deactivate(self):
        super().deactivate()
        iface.mapCanvas().setCursor(Qt.ArrowCursor)
        self.dialog.select_point_action.setChecked(False)


class VisorSVDialog(QDockWidget):
    def __init__(self, parent=iface.mainWindow()):
        super().__init__("Street View Cartografía", parent)
        self.setAllowedAreas(Qt.AllDockWidgetAreas)
        self.setFeatures(
            QDockWidget.DockWidgetClosable |
            QDockWidget.DockWidgetMovable  |
            QDockWidget.DockWidgetFloatable
        )
        self.webview        = None
        self.tracking_timer = None
        self.map_tool       = None
        self.vm_pegman      = None
        self.rb_arrow       = None
        self._last_lat      = 0.0
        self._last_lon      = 0.0

        self._enhance_panel = None   # se crea al primera uso

        # Valores actuales de filtros
        self._brightness  = 100   # % (100 = sin cambio)
        self._contrast    = 100   # %
        self._saturate    = 100   # %
        self._sharpen     = 0     # 0-10 (kernel de sharpen SVG)

        self.init_canvas_items()
        self.build_ui()

    # ── Preparación ───────────────────────────────────────────────────────────

    def prepare_for_display(self):
        if self.vm_pegman is None or self.rb_arrow is None:
            self.init_canvas_items()

    def set_canvas_items_visibility(self, visible):
        if visible:
            self.request_current_data()
        else:
            if self.vm_pegman: self.vm_pegman.hide()
            if self.rb_arrow:  self.rb_arrow.hide()

    # ── UI ────────────────────────────────────────────────────────────────────

    def build_ui(self):
        widget_contenido = QWidget()
        main_layout = QVBoxLayout(widget_contenido)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # ── Toolbar principal ──
        main_toolbar = QToolBar()
        main_toolbar.setStyleSheet("QToolBar { spacing: 4px; padding: 2px; }")
        main_layout.addWidget(main_toolbar)

        self.select_point_action = main_toolbar.addAction("📍 Seleccionar Punto")
        self.select_point_action.setCheckable(True)
        self.select_point_action.setToolTip("Activa/Desactiva la selección de puntos en el mapa")
        self.select_point_action.triggered.connect(self.toggle_select_tool)
        main_toolbar.addSeparator()

        # Botón para mostrar/ocultar panel de filtros
        self.filter_action = main_toolbar.addAction("🔧 Filtros")
        self.filter_action.setCheckable(True)
        self.filter_action.setChecked(True)
        self.filter_action.setToolTip("Mostrar/ocultar panel de mejora de imagen")
        self.filter_action.triggered.connect(self._toggle_filter_panel)
        main_toolbar.addSeparator()

        # Botón capturar y mejorar
        self.capture_action = main_toolbar.addAction("📷 Capturar y mejorar")
        self.capture_action.setToolTip(
            "Captura el Street View actual y abre el panel de mejora de imagen"
        )
        self.capture_action.triggered.connect(self._capture_and_enhance)

        # ── Panel de filtros (compacto) ──
        self.filter_panel = self._build_filter_panel()
        main_layout.addWidget(self.filter_panel)

        # ── WebView (ocupa todo el espacio restante) ──
        if WEB_ENGINE_DISPONIBLE:
            wv_bar = QToolBar()
            wv_bar.setStyleSheet("QToolBar { spacing: 2px; padding: 1px; }")

            self.zoom_out_action = wv_bar.addAction("−")
            self.zoom_out_action.setToolTip("Alejar")
            self.zoom_out_action.triggered.connect(self.zoom_out)

            self.zoom_label = QLabel(" 100% ")
            wv_bar.addWidget(self.zoom_label)

            self.zoom_in_action = wv_bar.addAction("+")
            self.zoom_in_action.setToolTip("Acercar")
            self.zoom_in_action.triggered.connect(self.zoom_in)

            wv_bar.addSeparator()
            self.reset_zoom_action = wv_bar.addAction("Restablecer")
            self.reset_zoom_action.setToolTip("Restablecer zoom")
            self.reset_zoom_action.triggered.connect(self.reset_zoom)

            main_layout.addWidget(wv_bar)

            self.webview = QWebEngineView()
            self.webview.setUrl(QUrl("about:blank"))
            self.webview.loadFinished.connect(self.start_tracking)
            self.webview.loadFinished.connect(self._reapply_filters)
            main_layout.addWidget(self.webview, stretch=1)  # stretch=1: ocupa todo
        else:
            label = QLabel(
                "Componente Street View no disponible.\n"
                "Instala 'python3-pyqt5.qtwebengine'."
            )
            label.setAlignment(Qt.AlignCenter)
            main_layout.addWidget(label)

        self.setWidget(widget_contenido)

    def _build_filter_panel(self):
        """Panel horizontal compacto con sliders de filtro."""
        panel = QWidget()
        panel.setMaximumHeight(90)
        panel.setStyleSheet("QWidget { background: #2b2b2b; }")
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(6, 4, 6, 4)
        layout.setSpacing(3)

        # Fila 1: Brillo y Contraste
        row1 = QHBoxLayout()
        row1.setSpacing(8)

        row1.addWidget(self._make_label("☀ Brillo"))
        self.sl_brightness = self._make_slider(0, 200, 100)
        self.sl_brightness.valueChanged.connect(self._on_filter_changed)
        row1.addWidget(self.sl_brightness, stretch=1)
        self.lbl_brightness = self._make_val_label("100")
        row1.addWidget(self.lbl_brightness)

        row1.addSpacing(12)

        row1.addWidget(self._make_label("◑ Contraste"))
        self.sl_contrast = self._make_slider(0, 200, 100)
        self.sl_contrast.valueChanged.connect(self._on_filter_changed)
        row1.addWidget(self.sl_contrast, stretch=1)
        self.lbl_contrast = self._make_val_label("100")
        row1.addWidget(self.lbl_contrast)

        layout.addLayout(row1)

        # Fila 2: Saturación, Nitidez y Reja
        row2 = QHBoxLayout()
        row2.setSpacing(8)

        row2.addWidget(self._make_label("🎨 Saturación"))
        self.sl_saturate = self._make_slider(0, 300, 100)
        self.sl_saturate.valueChanged.connect(self._on_filter_changed)
        row2.addWidget(self.sl_saturate, stretch=1)
        self.lbl_saturate = self._make_val_label("100")
        row2.addWidget(self.lbl_saturate)

        row2.addSpacing(12)

        row2.addWidget(self._make_label("⬡ Nitidez"))
        self.sl_sharpen = self._make_slider(0, 10, 0)
        self.sl_sharpen.valueChanged.connect(self._on_filter_changed)
        row2.addWidget(self.sl_sharpen, stretch=1)
        self.lbl_sharpen = self._make_val_label("0")
        row2.addWidget(self.lbl_sharpen)

        row2.addSpacing(12)

        nota_reja = QLabel("Para quitar reja usa 📷 Capturar y mejorar →")
        nota_reja.setStyleSheet("color:#888; font-size:10px; font-style:italic;")
        row2.addWidget(nota_reja)

        row2.addSpacing(8)

        btn_reset = QPushButton("↺ Reset")
        btn_reset.setFixedWidth(60)
        btn_reset.setStyleSheet(
            "QPushButton { background:#444; color:#ccc; border-radius:3px; "
            "              font-size:11px; padding:2px; }"
            "QPushButton:hover { background:#555; }"
        )
        btn_reset.clicked.connect(self._reset_filters)
        row2.addWidget(btn_reset)

        layout.addLayout(row2)
        return panel

    def _make_label(self, text):
        lbl = QLabel(text)
        lbl.setStyleSheet("color: #ccc; font-size: 11px;")
        lbl.setFixedWidth(80)
        return lbl

    def _make_val_label(self, text):
        lbl = QLabel(text)
        lbl.setFixedWidth(28)
        lbl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        lbl.setStyleSheet("color: #aaa; font-size: 11px;")
        return lbl

    def _make_slider(self, mn, mx, val):
        sl = QSlider(Qt.Horizontal)
        sl.setMinimum(mn)
        sl.setMaximum(mx)
        sl.setValue(val)
        sl.setFixedHeight(16)
        return sl

    def _toggle_filter_panel(self, checked):
        self.filter_panel.setVisible(checked)

    def _capture_and_enhance(self):
        """Toma screenshot del webview y lo envía al panel de mejora."""
        if not self.webview:
            iface.messageBar().pushMessage(
                "VisorSV", "No hay Street View activo.",
                level=Qgis.Warning, duration=3
            )
            return

        # QWebEngineView se compone por GPU aparte de Qt; si se llama a grab()
        # justo cuando se dispara la acción, a veces captura un frame a medio
        # renderizar (o directamente negro). Procesamos eventos pendientes y
        # damos un pequeño respiro antes de capturar de verdad.
        QApplication.processEvents()
        QTimer.singleShot(250, self._do_capture)

    def _do_capture(self):
        _ensure_safe_streams()
        pixmap = self.webview.grab()

        if pixmap.isNull():
            iface.messageBar().pushMessage(
                "VisorSV", "No se pudo capturar la imagen.",
                level=Qgis.Warning, duration=3
            )
            return

        if self._pixmap_is_blank(pixmap):
            iface.messageBar().pushMessage(
                "VisorSV",
                "La captura salió en blanco o sin detalle (limitación conocida "
                "de QtWebEngine con GPU). Prueba de nuevo, o si persiste, abre "
                "QGIS con la variable de entorno "
                "QTWEBENGINE_CHROMIUM_FLAGS=--disable-gpu (fuerza "
                "renderizado por software).",
                level=Qgis.Warning, duration=12
            )
            return

        if self._pixmap_looks_grayscale(pixmap):
            iface.messageBar().pushMessage(
                "VisorSV",
                "La captura salió sin color / con bandas — el mismo problema "
                "conocido de QtWebEngine con GPU, en otra variante. No es la "
                "reja ni el procesamiento: es la captura misma. Prueba de "
                "nuevo, y si sigue pasando abre QGIS con la variable de "
                "entorno QTWEBENGINE_CHROMIUM_FLAGS=--disable-gpu (fuerza "
                "renderizado por software — necesita reiniciar QGIS después "
                "de definirla a nivel del sistema).",
                level=Qgis.Warning, duration=14
            )
            return

        # Crear el panel si no existe aún
        if self._enhance_panel is None:
            self._enhance_panel = SVEnhancePanel(self)

        self._enhance_panel.load_capture(pixmap)

    def _pixmap_is_blank(self, pixmap, threshold=3.0):
        """
        Chequeo barato (muestreo en rejilla, no todos los píxeles) para
        detectar una captura básicamente uniforme/negra: si se le aplican
        filtros de mejora a eso, el resultado es ruido — no una plaqueta
        más legible.
        """
        img = pixmap.toImage().convertToFormat(QImage.Format_Grayscale8)
        w, h = img.width(), img.height()
        if w == 0 or h == 0:
            return True
        step_x = max(1, w // 40)
        step_y = max(1, h // 40)
        values = []
        for y in range(0, h, step_y):
            for x in range(0, w, step_x):
                values.append(img.pixelColor(x, y).red())
        if not values:
            return True
        mean = sum(values) / len(values)
        variance = sum((v - mean) ** 2 for v in values) / len(values)
        return variance ** 0.5 < threshold

    def _pixmap_looks_grayscale(self, pixmap, threshold=4.0):
        """
        Chequeo barato para detectar una captura que salió sin color real
        (canales R/G/B casi idénticos en todos lados) — Street View
        prácticamente nunca es monocromático de verdad, así que esto
        indica que la captura del webview salió mal, no que la escena
        en sí sea gris.
        """
        img = pixmap.toImage().convertToFormat(QImage.Format_RGB888)
        w, h = img.width(), img.height()
        if w == 0 or h == 0:
            return False
        step_x = max(1, w // 30)
        step_y = max(1, h // 30)
        diffs = []
        for y in range(0, h, step_y):
            for x in range(0, w, step_x):
                c = img.pixelColor(x, y)
                diffs.append(abs(c.red() - c.green()))
                diffs.append(abs(c.green() - c.blue()))
                diffs.append(abs(c.red() - c.blue()))
        if not diffs:
            return False
        return (sum(diffs) / len(diffs)) < threshold

    # ── Filtros ───────────────────────────────────────────────────────────────

    def _on_filter_changed(self, _=None):
        self._brightness  = self.sl_brightness.value()
        self._contrast    = self.sl_contrast.value()
        self._saturate    = self.sl_saturate.value()
        self._sharpen     = self.sl_sharpen.value()

        self.lbl_brightness.setText(str(self._brightness))
        self.lbl_contrast.setText(str(self._contrast))
        self.lbl_saturate.setText(str(self._saturate))
        self.lbl_sharpen.setText(str(self._sharpen))

        self._apply_filters()

    def _apply_filters(self):
        if not self.webview:
            return

        parts = [
            f"brightness({self._brightness}%)",
            f"contrast({self._contrast}%)",
            f"saturate({self._saturate}%)",
        ]

        # Nitidez real vía un filtro SVG feConvolveMatrix (kernel de sharpen),
        # en vez del truco anterior que solo reescribía el contraste.
        kernel_js = "null"
        if self._sharpen > 0:
            s = min(1.0, self._sharpen / 10.0) * 0.9
            center = 1 + 4 * s
            kernel_str = f"0 {-s:.3f} 0 {-s:.3f} {center:.3f} {-s:.3f} 0 {-s:.3f} 0"
            kernel_js = f"'{kernel_str}'"
            parts.append("url(#sv-sharpen-filter)")

        filter_str = " ".join(parts)
        js = JS_APPLY_FILTER.format(filter_str=filter_str, kernel=kernel_js)
        self.webview.page().runJavaScript(js)

    def _reapply_filters(self, ok=True):
        """Re-aplica filtros cada vez que carga una página nueva."""
        if ok:
            QTimer.singleShot(800, self._apply_filters)

    def _filters_active(self):
        return (
            self._brightness != 100 or self._contrast != 100 or
            self._saturate != 100 or self._sharpen > 0
        )

    def _ensure_filters_persist(self, filter_present):
        """
        Street View es una SPA: moverse dentro de la panorámica no siempre
        dispara loadFinished, así que el <style> inyectado puede perderse
        en un re-render interno de Google Maps sin que nos enteremos.
        Este chequeo periódico (ver request_current_data) lo reaplica si
        detecta que desapareció.
        """
        if not filter_present:
            self._apply_filters()

    def _reset_filters(self):
        for sl, val in [
            (self.sl_brightness, 100),
            (self.sl_contrast,   100),
            (self.sl_saturate,   100),
            (self.sl_sharpen,    0),
        ]:
            sl.blockSignals(True)
            sl.setValue(val)
            sl.blockSignals(False)

        self.lbl_brightness.setText("100")
        self.lbl_contrast.setText("100")
        self.lbl_saturate.setText("100")
        self.lbl_sharpen.setText("0")

        self._brightness  = 100
        self._contrast    = 100
        self._saturate    = 100
        self._sharpen     = 0

        # Quitar filtro CSS y el <svg> de nitidez
        if self.webview:
            self.webview.page().runJavaScript(
                "var s = document.getElementById('sv-filter-style'); if(s) s.remove();"
                "var d = document.getElementById('sv-sharpen-defs'); if(d) d.remove();"
            )

    # ── Herramienta de mapa ───────────────────────────────────────────────────

    def toggle_select_tool(self, checked):
        canvas = iface.mapCanvas()
        if checked:
            self.map_tool = VisorSVMapTool(canvas, self)
            canvas.setMapTool(self.map_tool)
            canvas.setCursor(Qt.CrossCursor)
        else:
            if self.map_tool and canvas.mapTool() == self.map_tool:
                canvas.unsetMapTool(self.map_tool)

    # ── Zoom ──────────────────────────────────────────────────────────────────

    def zoom_in(self):
        if not self.webview: return
        nz = self.webview.zoomFactor() + 0.1
        self.webview.setZoomFactor(nz)
        self.update_zoom_label(nz)

    def zoom_out(self):
        if not self.webview: return
        nz = max(0.1, self.webview.zoomFactor() - 0.1)
        self.webview.setZoomFactor(nz)
        self.update_zoom_label(nz)

    def reset_zoom(self):
        if not self.webview: return
        self.webview.setZoomFactor(1.0)
        self.update_zoom_label(1.0)

    def update_zoom_label(self, zoom_factor):
        if hasattr(self, 'zoom_label'):
            self.zoom_label.setText(f" {zoom_factor:.0%} ")

    # ── Canvas items ──────────────────────────────────────────────────────────

    def init_canvas_items(self):
        canvas = iface.mapCanvas()
        self.vm_pegman = QgsVertexMarker(canvas)
        self.vm_pegman.setColor(QColor(50, 200, 50))
        self.vm_pegman.setIconType(QgsVertexMarker.ICON_CIRCLE)
        self.vm_pegman.setIconSize(12)
        self.vm_pegman.setPenWidth(2)
        canvas.scene().addItem(self.vm_pegman)
        self.vm_pegman.hide()

        self.rb_arrow = QgsRubberBand(canvas, QgsWkbTypes.PolygonGeometry)
        self.rb_arrow.setColor(QColor(0, 150, 255, 200))
        self.rb_arrow.setWidth(1)
        self.base_arrow_polygon = self.create_arrow_polygon()

    def create_arrow_polygon(self):
        points = [
            QPointF(10, 0), QPointF(1.5, 4.5), QPointF(1.5, 2),
            QPointF(4, 0),  QPointF(1.5, -2),  QPointF(1.5, -4.5)
        ]
        return QgsGeometry.fromPolygonXY(
            [[QgsPointXY(p.x(), p.y()) for p in points]]
        )

    # ── Carga Street View ─────────────────────────────────────────────────────

    def load_street_view(self, point_wgs84):
        lat, lon = point_wgs84.y(), point_wgs84.x()
        self._last_lat = lat
        self._last_lon = lon
        url = f"https://www.google.com/maps?q&layer=c&cbll={lat},{lon}&cbp=12,0,0,0,0"
        if self.webview:
            self.webview.load(QUrl(url))
        self.show()
        self.raise_()

    # ── Tracking ──────────────────────────────────────────────────────────────

    def start_tracking(self, ok):
        if not ok:
            return
        if self.tracking_timer and self.tracking_timer.isActive():
            self.tracking_timer.stop()
        self.tracking_timer = QTimer(self)
        self.tracking_timer.setInterval(500)
        self.tracking_timer.timeout.connect(self.request_current_data)
        self.tracking_timer.start()

    def request_current_data(self):
        if self.webview and self.webview.isVisible():
            self.webview.page().runJavaScript(JS_GET_URL, self.process_url_data)
            if self._filters_active():
                self.webview.page().runJavaScript(
                    JS_CHECK_FILTER, self._ensure_filters_persist
                )

    def process_url_data(self, url):
        if not self.isVisible() or not url or url == "about:blank":
            if self.vm_pegman: self.vm_pegman.hide()
            if self.rb_arrow:  self.rb_arrow.hide()
            return

        lat, lon, heading = None, None, 0.0
        new_format_match = re.search(r'@([-\d.]+),([-\d.]+),.*?([\d.]+)h', url)
        if new_format_match:
            lat     = float(new_format_match.group(1))
            lon     = float(new_format_match.group(2))
            heading = float(new_format_match.group(3))
        else:
            old_pos_match = re.search(r'cbll=([-\d.]+),([-\d.]+)', url)
            if old_pos_match:
                lat = float(old_pos_match.group(1))
                lon = float(old_pos_match.group(2))
                old_heading_match = re.search(r'cbp=\d+,([-\d.]+)', url)
                if old_heading_match:
                    heading = float(old_heading_match.group(1))

        if lat is None or lon is None:
            if self.vm_pegman: self.vm_pegman.hide()
            if self.rb_arrow:  self.rb_arrow.hide()
            return

        # Si no cambió nada desde el último chequeo (mismo lat/lon/heading),
        # no hay razón para reconstruir la geometría de la flecha ni
        # repintar el lienzo del mapa principal — antes esto se hacía
        # siempre, cada 500ms, aunque no te hubieras movido dentro de
        # Street View, lo cual suma repintados innecesarios del mapa
        # mientras navegas.
        if (lat == getattr(self, '_last_heading_lat', None)
                and lon == getattr(self, '_last_heading_lon', None)
                and heading == getattr(self, '_last_heading', None)):
            return

        self._last_lat = lat
        self._last_lon = lon
        self._last_heading_lat = lat
        self._last_heading_lon = lon
        self._last_heading = heading

        crs_src = iface.mapCanvas().mapSettings().destinationCrs()
        if not crs_src.isValid():
            return

        crs_wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        transform = QgsCoordinateTransform(crs_wgs84, crs_src, QgsProject.instance())
        pegman_pos_map = transform.transform(QgsPointXY(lon, lat))

        if self.vm_pegman:
            self.vm_pegman.setCenter(pegman_pos_map)
            self.vm_pegman.show()

        map_width = iface.mapCanvas().extent().width()
        if map_width <= 0:
            return
        scale_factor = (map_width * 0.02) / 10.0

        original_points = self.base_arrow_polygon.asPolygon()[0]
        scaled_points   = [QgsPointXY(p.x() * scale_factor, p.y() * scale_factor)
                           for p in original_points]
        arrow_geom = QgsGeometry.fromPolygonXY([scaled_points])
        arrow_geom.rotate(heading - 90, QgsPointXY(0, 0))
        arrow_geom.translate(pegman_pos_map.x(), pegman_pos_map.y())

        if self.rb_arrow:
            self.rb_arrow.setToGeometry(arrow_geom, None)
            self.rb_arrow.show()

    # ── Limpieza ──────────────────────────────────────────────────────────────

    def cleanup_canvas_items(self):
        if self.tracking_timer:
            self.tracking_timer.stop()
            self.tracking_timer = None
        if self.rb_arrow:
            self.rb_arrow.reset()
            self.rb_arrow = None
        if self.vm_pegman:
            canvas_scene = iface.mapCanvas().scene()
            if self.vm_pegman.scene() == canvas_scene:
                canvas_scene.removeItem(self.vm_pegman)
            self.vm_pegman = None
        if self.map_tool:
            iface.mapCanvas().unsetMapTool(self.map_tool)
            self.map_tool = None

    def closeEvent(self, event):
        self.cleanup_canvas_items()
        super().closeEvent(event)
