# sv_enhance_panel.py
# Detección de reja por COLOR (blanca o gris clara) + inpainting controlado.

# numpy y cv2 se importan solo dentro de las funciones que los usan
# para evitar errores de stderr al cargar QGIS


from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QSlider, QCheckBox,
    QScrollArea, QFrame, QGroupBox, QProgressBar
)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal, QTimer, QPointF
from qgis.PyQt.QtGui import QPixmap, QImage, QPainter, QPen, QColor
from qgis.core import QgsMessageLog, Qgis
from qgis.utils import iface


class _NullStream:
    """Absorbe writes sin hacer nada — ver _ensure_safe_streams()."""
    def write(self, *args, **kwargs):
        pass

    def flush(self):
        pass


def _ensure_safe_streams():
    """
    numpy (y a veces cv2) intentan escribir avisos internos directo a
    sys.stderr sin comprobar que exista. En QGIS abierto sin consola,
    sys.stderr puede venir (o volver a quedar) en None — el parche del
    __init__.py del plugin lo arregla al cargar, pero algo dentro de QGIS
    puede reponerlo a None más tarde. Por eso lo revisamos de nuevo justo
    antes de cualquier operación pesada de numpy/cv2 en este archivo.
    """
    import sys
    if sys.stderr is None:
        sys.stderr = _NullStream()
    if sys.stdout is None:
        sys.stdout = _NullStream()


def _deps_ok():
    try:
        import cv2
        return True
    except ImportError:
        return False


def pixmap_to_numpy(pixmap: QPixmap):
    _ensure_safe_streams()
    import numpy as np
    img = pixmap.toImage().convertToFormat(QImage.Format_RGB888)
    w, h = img.width(), img.height()
    # QImage rellena cada fila hasta un múltiplo de 4 bytes — bytesPerLine()
    # casi nunca es exactamente w*3. Si no se tiene esto en cuenta, cada fila
    # se lee desde el offset equivocado y el desfase se acumula hacia abajo:
    # eso es lo que producía el efecto de imagen "cortada/ondulada en
    # diagonal" que aparecía en las capturas.
    bpl = img.bytesPerLine()
    ptr = img.bits()
    ptr.setsize(h * bpl)
    arr = np.frombuffer(ptr, dtype=np.uint8).reshape((h, bpl))
    arr = arr[:, : w * 3].reshape((h, w, 3)).copy()
    import cv2
    return cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)


def numpy_to_pixmap(arr) -> QPixmap:
    import cv2
    rgb = cv2.cvtColor(arr, cv2.COLOR_BGR2RGB)
    h, w, ch = rgb.shape
    qimg = QImage(rgb.data, w, h, w * ch, QImage.Format_RGB888)
    return QPixmap.fromImage(qimg.copy())


# ── Función de máscara de reja ────────────────────────────────────────────────

def build_grid_mask(img, mode='auto'):
    import numpy as np
    """
    Detecta barrotes de reja y devuelve una máscara uint8.
    mode: 'white'  → reja blanca/gris clara (como la foto)
          'dark'   → reja negra/oscura
          'auto'   → detecta cuál predomina
    """
    import cv2

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    h, w = gray.shape

    if mode == 'auto':
        # Detectar si la reja es clara u oscura comparando
        # el brillo de los píxeles con bordes fuertes
        edges = cv2.Canny(gray, 40, 120)
        edge_pixels = gray[edges > 0]
        if len(edge_pixels) > 0:
            mode = 'white' if np.mean(edge_pixels) > 140 else 'dark'
        else:
            mode = 'dark'

    # ── Máscara según color ──
    if mode == 'white':
        # Píxeles muy claros (barrotes blancos/grises claros)
        _, mask_color = cv2.threshold(gray, 180, 255, cv2.THRESH_BINARY)
    else:
        # Píxeles muy oscuros (barrotes negros)
        _, mask_color = cv2.threshold(gray, 50, 255, cv2.THRESH_BINARY_INV)

    # Detectar líneas rectas
    edges = cv2.Canny(gray, 30, 110)
    lines = cv2.HoughLinesP(
        edges, 1, np.pi / 180,
        threshold=50,
        minLineLength=int(h * 0.10),
        maxLineGap=15
    )

    mask_lines = np.zeros_like(gray)
    grid_detected = False

    if lines is not None and len(lines) > 0:
        # Una reja real tiene VARIOS barrotes paralelos y espaciados con
        # regularidad. Antes, cualquier línea suelta (un cable, el borde de
        # un techo, una sombra) se trataba igual que una reja y se le hacía
        # inpainting — sobre una franja larga y solitaria eso deforma la
        # imagen en vez de limpiarla (el "efecto derretido"). Ahora agrupamos
        # las líneas por ángulo y solo consideramos que hay reja si un mismo
        # ángulo tiene varios barrotes repetidos.
        angle_bins = {}
        for line in lines:
            # OpenCV cambió entre versiones la forma en que HoughLinesP
            # devuelve cada línea: a veces (1, 4) — hay que hacer line[0] —
            # y a veces ya viene aplanada como (4,). Usamos ravel() para que
            # funcione igual con cualquiera de las dos formas.
            x1, y1, x2, y2 = np.ravel(line)[:4]
            dx, dy = int(x2) - int(x1), int(y2) - int(y1)
            angle = np.degrees(np.arctan2(dy, dx)) % 180
            bin_key = int(round(angle / 10.0)) * 10
            angle_bins.setdefault(bin_key, []).append(
                (int(x1), int(y1), int(x2), int(y2))
            )

        MIN_BARROTES = 4
        for bin_key, group in angle_bins.items():
            if len(group) >= MIN_BARROTES:
                grid_detected = True
                for (x1, y1, x2, y2) in group:
                    cv2.line(mask_lines, (x1, y1), (x2, y2), 255, 4)

    if not grid_detected:
        # Ninguna agrupación de líneas parece un patrón de barrotes repetido
        return np.zeros_like(gray), mode, 0.0

    # INTERSECCIÓN: solo píxeles que son claros/oscuros Y forman línea
    # Esto evita cubrir áreas grandes de fondo
    mask = cv2.bitwise_and(mask_color, mask_lines)

    # Dilatar poco para cubrir borde del barrote
    kernel = np.ones((3, 3), np.uint8)
    mask   = cv2.dilate(mask, kernel, iterations=1)

    coverage = float(np.sum(mask > 0)) / (h * w)

    # Límite mucho más estricto que antes (era 40%): el inpainting funciona
    # bien sobre defectos localizados, no sobre franjas grandes que cruzan
    # fondos muy distintos (cielo, terreno, vehículo…).
    if coverage > 0.15:
        mask = cv2.dilate(mask_lines, kernel, iterations=1)
        coverage = float(np.sum(mask > 0)) / (h * w)
        if coverage > 0.15:
            # Sigue cubriendo demasiado: mejor no tocar nada a ciegas
            return np.zeros_like(gray), mode, 0.0

    return mask, mode, coverage


# ── Inpainting: clásico vs. consciente de textura (experimental) ─────────────

def _inpaint_classic(img, mask):
    """Inpainting estándar de OpenCV (TELEA). Siempre funciona si hay cv2,
    pero sobre fondos con patrón repetido (tejas, ladrillo, rejilla) deja
    un manchón borroso en vez de continuar el patrón."""
    import cv2
    return cv2.inpaint(img, mask, inpaintRadius=5, flags=cv2.INPAINT_TELEA)


def _looks_sane(original, result):
    """
    Chequeo barato antes de confiar en el resultado experimental: mismo
    tamaño/tipo que la entrada, y si la original era a color, el
    resultado no puede haberse vuelto monocromático de golpe — eso
    indicaría que algo se rompió en el camino, no un relleno real.
    """
    import numpy as np
    if result is None:
        return False
    if result.shape != original.shape or result.dtype != original.dtype:
        return False
    if original.ndim == 3 and original.shape[2] == 3:
        b, g, r = (original[..., i].astype(np.int16) for i in range(3))
        original_es_color = (
            np.std(b - g) > 2 or np.std(g - r) > 2 or np.std(b - r) > 2
        )
        if original_es_color:
            rb, rg, rr = (result[..., i].astype(np.int16) for i in range(3))
            resultado_es_color = (
                np.std(rb - rg) > 1 or np.std(rg - rr) > 1 or np.std(rb - rr) > 1
            )
            if not resultado_es_color:
                return False
    return True


def _inpaint_texture_aware(img, mask):
    """
    xphoto.INPAINT_SHIFTMAP (opencv-contrib): busca en el resto de la
    imagen fragmentos de textura que encajen, en vez de solo difuminar —
    en teoría mejor para fondos con patrón repetido. EXPERIMENTAL: si el
    resultado no pasa el chequeo de sanidad de _looks_sane (p. ej. si la
    imagen se vuelve blanco y negro de golpe, como llegó a pasar), se
    descarta y se usa el TELEA clásico en su lugar — nunca se devuelve
    un resultado roto.
    """
    import numpy as np
    import cv2
    try:
        import cv2.xphoto as xphoto
        # xphoto usa la convención contraria a cv2.inpaint: los píxeles
        # NO-cero de la máscara indican zona VÁLIDA, no zona a rellenar.
        valid_mask = cv2.bitwise_not(mask)
        dst = np.zeros_like(img)
        xphoto.inpaint(img, valid_mask, dst, xphoto.INPAINT_SHIFTMAP)
        if not _looks_sane(img, dst):
            raise ValueError("resultado de xphoto no pasó el chequeo de sanidad")
        return dst
    except Exception:
        return _inpaint_classic(img, mask)


# ── Analizador ────────────────────────────────────────────────────────────────

class ImageAnalyzer:

    def analyze(self, img) -> dict:
        _ensure_safe_streams()
        import numpy as np
        import cv2

        h, w    = img.shape[:2]
        gray    = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        zone    = gray[int(h * 0.55):, :]
        mean_z  = float(np.mean(zone))
        std_all = float(np.std(gray))
        lap_var = float(cv2.Laplacian(gray, cv2.CV_64F).var())

        problems = []
        params   = self._defaults()

        # Oscuridad zona placa
        if mean_z < 60:
            sev = min(1.0, (60 - mean_z) / 40)
            problems.append("zona oscura")
            params['clahe']      = True
            params['clahe_clip'] = 2.5 + sev * 1.5   # antes hasta 7.5: amplificaba ruido
            params['brightness'] = sev * 25
        elif mean_z < 90:
            problems.append("zona algo oscura")
            params['clahe']      = True
            params['clahe_clip'] = 2.5
            params['brightness'] = 15

        # Contraste bajo
        if std_all < 35:
            problems.append("bajo contraste")
            params['contrast'] = 1.3
            params['sharpen']  = 0.5
        elif std_all < 55:
            params['contrast'] = 1.15
            params['sharpen']  = 0.3

        # Nitidez
        if lap_var < 80:
            problems.append("imagen desenfocada")
            params['sharpen'] = max(params.get('sharpen', 0), 0.8)

        # Ruido
        if lap_var > 900:
            params['denoise'] = min(6, int(lap_var / 400))

        # Detección de reja
        mask, grid_mode, coverage = build_grid_mask(img, mode='auto')
        if coverage > 0.03:   # más del 3% de la imagen son barrotes
            problems.append(
                f"reja {'blanca' if grid_mode == 'white' else 'oscura'} "
                f"({coverage*100:.0f}% imagen)"
            )
            params['inpaint']      = True
            params['inpaint_mask'] = mask
            params['grid_mode']    = grid_mode

        params['sharpen'] = max(params.get('sharpen', 0), 0.25)

        if not problems:
            problems.append("imagen OK")
            params['sharpen']  = 0.3
            params['contrast'] = 1.1

        params['summary'] = "Detectado: " + ", ".join(problems)
        return params

    def _defaults(self):
        return {
            'clahe':        False,
            'clahe_clip':   2.0,
            'inpaint':      False,
            'inpaint_mask': None,
            'grid_mode':    'auto',
            'sharpen':      0.0,
            'denoise':      0,
            'brightness':   0.0,
            'contrast':     1.0,
            'summary':      '',
        }


# ── Worker ────────────────────────────────────────────────────────────────────

class EnhanceWorker(QThread):
    finished = pyqtSignal(object)
    error    = pyqtSignal(str)
    progress = pyqtSignal(int, str)

    def __init__(self, img, params):
        super().__init__()
        self.img    = img
        self.params = params

    def run(self):
        _ensure_safe_streams()
        try:
            self.finished.emit(self._process(self.img.copy(), self.params))
        except Exception as e:
            self.error.emit(str(e))

    def _process(self, img, p):
        import numpy as np
        import cv2

        # 1. Inpainting (quitar barrotes primero)
        if p.get('inpaint', False):
            self.progress.emit(20, "Eliminando barrotes…")
            mask = p.get('inpaint_mask', None)

            # Si no viene máscara del analizador, calcularla ahora
            if mask is None or not isinstance(mask, np.ndarray):
                mode = p.get('grid_mode', 'auto')
                mask, _, _ = build_grid_mask(img, mode=mode)

            mask = mask.astype(np.uint8)
            if p.get('use_texture_inpaint', False):
                img = _inpaint_texture_aware(img, mask)
            else:
                img = _inpaint_classic(img, mask)

        # 2. CLAHE — rejilla adaptativa al tamaño de la imagen: con una
        # rejilla fija de 8x8, una placa chica dentro de una captura grande
        # casi no se beneficia porque cada celda promedia un área enorme.
        if p.get('clahe', False):
            self.progress.emit(40, "Corrigiendo luminosidad…")
            h_img, w_img = img.shape[:2]
            tile = max(4, min(16, round(min(h_img, w_img) / 60)))
            lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
            l, a, b = cv2.split(lab)
            clahe = cv2.createCLAHE(
                clipLimit=float(p.get('clahe_clip', 3.0)),
                tileGridSize=(tile, tile)
            )
            l   = clahe.apply(l)
            img = cv2.cvtColor(cv2.merge([l, a, b]), cv2.COLOR_LAB2BGR)

        # 3. Brillo / contraste
        alpha = float(p.get('contrast', 1.0))
        beta  = float(p.get('brightness', 0.0))
        if alpha != 1.0 or beta != 0.0:
            self.progress.emit(60, "Ajustando brillo…")
            img = cv2.convertScaleAbs(img, alpha=alpha, beta=beta)

        # 4. Gamma (aclarar zonas oscuras sin tocar las claras)
        gamma_val = float(p.get('gamma_val', 1.0))
        if gamma_val != 1.0:
            self.progress.emit(70, "Ajustando gamma…")
            lut = np.array([
                min(255, int(((i / 255.0) ** gamma_val) * 255))
                for i in range(256)
            ], dtype=np.uint8)
            import cv2 as _cv2
            img = _cv2.LUT(img, lut)

        # 5. Ruido
        denoise = int(p.get('denoise', 0))
        if denoise > 0:
            self.progress.emit(80, "Reduciendo ruido…")
            h_val = int(3 + denoise * 2)
            img = cv2.fastNlMeansDenoisingColored(img, None, h_val, h_val, 7, 21)

        # 6. Nitidez — multi-escala: combina un realce fino (para el
        # detalle chico, como los trazos de una placa) con uno más amplio
        # (para el contraste general de la zona), en vez de un único paso
        # de máscara de desenfoque a una sola escala. Recupera más detalle
        # percibido en texto pequeño sin amplificar tanto el ruido de fondo
        # que un unsharp mask de una sola escala.
        sharpen = float(p.get('sharpen', 0.0))
        if sharpen > 0:
            self.progress.emit(90, "Mejorando nitidez…")
            img_f = img.astype(np.float32)
            fine  = cv2.GaussianBlur(img, (0, 0), sigmaX=1.0).astype(np.float32)
            broad = cv2.GaussianBlur(img, (0, 0), sigmaX=4.0).astype(np.float32)
            detail_fine  = img_f - fine
            detail_broad = img_f - broad
            img_f = img_f + sharpen * (0.7 * detail_fine + 0.3 * detail_broad)
            img = np.clip(img_f, 0, 255).astype(np.uint8)

        self.progress.emit(100, "Listo")
        return np.clip(img, 0, 255).astype(np.uint8)


# ── Etiqueta de imagen con pincel de marcado manual ───────────────────────────

class MaskDrawLabel(QLabel):
    """
    Muestra la imagen y permite pintar con pincel libre directamente sobre
    los barrotes de la reja. La marca se guarda como una máscara binaria a
    la resolución de la imagen ORIGINAL (no la escalada en pantalla), lista
    para pasarse tal cual a cv2.inpaint — así el usuario le dice al plugin
    exactamente dónde está la reja, sin depender de que la detección
    automática (líneas de Hough) la reconozca bien.
    """
    mask_changed = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMouseTracking(True)
        self._orig_w = 0
        self._orig_h = 0
        self._mask = None          # QImage Format_Alpha8, tamaño original
        self._base_pixmap = None   # imagen que se muestra debajo de la marca
        self._drawing_enabled = False
        self._brush_radius = 14
        self._last_pt = None

    # ── Configuración ──────────────────────────────────────────────────────

    def set_original_size(self, w, h):
        self._orig_w, self._orig_h = w, h
        # Format_Alpha8 (no Format_Grayscale8): aquí cada byte SÍ se
        # interpreta como transparencia real (0 = nada marcado,
        # 255 = marcado). Con Grayscale8 no hay canal alfa, así que al
        # usarlo de plantilla Qt lo trataba como opaco en toda la imagen
        # sin importar el valor — por eso se veía todo en rojo.
        self._mask = QImage(w, h, QImage.Format_Alpha8)
        self._mask.fill(0)

    def set_drawing_enabled(self, enabled):
        self._drawing_enabled = enabled
        self.setCursor(Qt.CrossCursor if enabled else Qt.ArrowCursor)

    def set_brush_radius(self, r):
        self._brush_radius = max(3, int(r))

    def set_base_pixmap(self, pixmap):
        """Imagen sobre la que se dibuja (se llama cada vez que cambia la
        vista: original, auto-mejorada, manual...)."""
        self._base_pixmap = pixmap
        self._redraw()

    def clear_mask(self):
        if self._mask is not None:
            self._mask.fill(0)
            self._redraw()
            self.mask_changed.emit()

    def has_marks(self):
        if self._mask is None:
            return False
        arr = self._mask_to_numpy()
        return bool(arr is not None and arr.any())

    def get_mask_numpy(self):
        """Devuelve la máscara como array uint8 (0/255) a resolución original."""
        return self._mask_to_numpy()

    def _mask_to_numpy(self):
        import numpy as np
        if self._mask is None:
            return None
        img = self._mask
        w, h = img.width(), img.height()
        bpl = img.bytesPerLine()
        ptr = img.bits()
        ptr.setsize(h * bpl)
        arr = np.frombuffer(ptr, dtype=np.uint8).reshape((h, bpl))
        return arr[:, :w].copy()

    # ── Coordenadas: widget mostrado → imagen original ─────────────────────

    def _widget_to_orig(self, pos):
        if self._base_pixmap is None or self._orig_w == 0:
            return None
        pm_w, pm_h = self._base_pixmap.width(), self._base_pixmap.height()
        offset_x = max(0, (self.width() - pm_w) // 2)
        offset_y = max(0, (self.height() - pm_h) // 2)
        x = pos.x() - offset_x
        y = pos.y() - offset_y
        if x < 0 or y < 0 or x >= pm_w or y >= pm_h:
            return None
        scale_x = self._orig_w / pm_w
        scale_y = self._orig_h / pm_h
        return QPointF(x * scale_x, y * scale_y)

    # ── Eventos de mouse ────────────────────────────────────────────────────

    def mousePressEvent(self, event):
        if self._drawing_enabled and event.button() == Qt.LeftButton:
            pt = self._widget_to_orig(event.pos())
            if pt is not None:
                self._paint_stroke(pt, None)
                self._last_pt = pt
                self.mask_changed.emit()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._drawing_enabled and (event.buttons() & Qt.LeftButton):
            pt = self._widget_to_orig(event.pos())
            if pt is not None:
                self._paint_stroke(pt, self._last_pt)
                self._last_pt = pt
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if self._last_pt is not None:
            self.mask_changed.emit()
        self._last_pt = None
        super().mouseReleaseEvent(event)

    # ── Dibujo ──────────────────────────────────────────────────────────────

    def _paint_stroke(self, pt, prev_pt):
        if self._mask is None:
            return
        painter = QPainter(self._mask)
        pen = QPen(QColor(255, 255, 255))
        pen.setWidth(self._brush_radius * 2)
        pen.setCapStyle(Qt.RoundCap)
        pen.setJoinStyle(Qt.RoundJoin)
        painter.setPen(pen)
        painter.setBrush(QColor(255, 255, 255))
        if prev_pt is not None:
            painter.drawLine(prev_pt, pt)
        else:
            painter.drawEllipse(pt, self._brush_radius, self._brush_radius)
        painter.end()
        self._redraw()

    def _redraw(self):
        """Muestra la imagen base con la marca superpuesta en rojo
        translúcido, para que el usuario vea exactamente qué quedó pintado."""
        if self._base_pixmap is None:
            return
        if self._mask is None or not self.has_marks():
            self.setPixmap(self._base_pixmap)
            return

        overlay = QPixmap(self._base_pixmap)
        mask_scaled = self._mask.scaled(
            overlay.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation
        )
        painter = QPainter(overlay)
        painter.setOpacity(0.5)
        painter.setCompositionMode(QPainter.CompositionMode_SourceOver)
        red = QImage(mask_scaled.size(), QImage.Format_ARGB32_Premultiplied)
        red.fill(QColor(255, 60, 60, 255))
        rp = QPainter(red)
        rp.setCompositionMode(QPainter.CompositionMode_DestinationIn)
        rp.drawImage(0, 0, mask_scaled)
        rp.end()
        painter.drawImage(0, 0, red)
        painter.end()
        self.setPixmap(overlay)


# ── Panel ─────────────────────────────────────────────────────────────────────

class SVEnhancePanel(QDialog):

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Mejora de imagen — Street View")
        self.setMinimumSize(760, 600)
        self.setWindowFlags(Qt.Window | Qt.WindowStaysOnTopHint)
        self._original_pixmap = None
        self._worker          = None
        self._analyzer        = ImageAnalyzer()
        self._clear_mask_after_run = False
        self._build_ui()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(6)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.img_label = MaskDrawLabel()
        self.img_label.setText("Captura una imagen con el botón 📷 del visor")
        self.img_label.setAlignment(Qt.AlignCenter)
        self.img_label.setStyleSheet("background:#1a1a1a;color:#777;font-size:13px;")
        self.img_label.setMinimumHeight(260)
        self.img_label.mask_changed.connect(self._on_mask_changed)
        self.scroll.setWidget(self.img_label)
        root.addWidget(self.scroll, stretch=1)

        # ── Marcado manual de reja ──
        mark_row = QHBoxLayout()
        self.btn_mark = QPushButton("✏️  Marcar reja")
        self.btn_mark.setCheckable(True)
        self.btn_mark.setToolTip(
            "Dibuja con el mouse directamente encima de los barrotes.\n"
            "Esa marca se usa tal cual para quitar la reja, sin depender\n"
            "de que la detección automática la reconozca."
        )
        self.btn_mark.toggled.connect(self._on_mark_toggled)
        mark_row.addWidget(self.btn_mark)

        mark_row.addWidget(QLabel("Grosor:"))
        self.sl_brush = QSlider(Qt.Horizontal)
        self.sl_brush.setMinimum(4)
        self.sl_brush.setMaximum(40)
        self.sl_brush.setValue(14)
        self.sl_brush.setFixedWidth(100)
        self.sl_brush.valueChanged.connect(
            lambda v: self.img_label.set_brush_radius(v)
        )
        mark_row.addWidget(self.sl_brush)

        self.btn_clear_mark = QPushButton("🗑  Borrar marcas")
        self.btn_clear_mark.setEnabled(False)
        self.btn_clear_mark.clicked.connect(self._on_clear_marks)
        mark_row.addWidget(self.btn_clear_mark)

        mark_row.addStretch()
        self.mark_status = QLabel("")
        self.mark_status.setStyleSheet("color:#7ec88a;font-size:11px;")
        mark_row.addWidget(self.mark_status)
        root.addLayout(mark_row)

        self.prog = QProgressBar()
        self.prog.setMaximumHeight(5)
        self.prog.setTextVisible(False)
        self.prog.setRange(0, 100); self.prog.setValue(0)
        self.prog.setStyleSheet(
            "QProgressBar{background:#2a2a2a;border-radius:2px;}"
            "QProgressBar::chunk{background:#1a73e8;border-radius:2px;}"
        )
        root.addWidget(self.prog)

        self.diag_lbl = QLabel("")
        self.diag_lbl.setWordWrap(True)
        self.diag_lbl.setStyleSheet("color:#aaa;font-size:11px;padding:2px;")
        root.addWidget(self.diag_lbl)

        sep = QFrame(); sep.setFrameShape(QFrame.HLine)
        root.addWidget(sep)

        cols = QHBoxLayout(); cols.setSpacing(12)

        # Automático
        ab = QGroupBox("✨  Automático")
        ab.setStyleSheet("QGroupBox{font-weight:bold;}")
        al = QVBoxLayout(ab); al.setSpacing(6)
        al.addWidget(QLabel(
            "Detecta reja blanca u oscura,\n"
            "oscuridad y contraste.\n"
            "Aplica correcciones en orden."
        ))
        self.btn_auto = QPushButton("✨  Mejorar automáticamente")
        self.btn_auto.setEnabled(False)
        self.btn_auto.setMinimumHeight(36)
        self.btn_auto.setStyleSheet(
            "QPushButton{background:#1a73e8;color:white;border-radius:5px;"
            "font-weight:bold;font-size:12px;}"
            "QPushButton:hover{background:#1557b0;}"
            "QPushButton:disabled{background:#333;color:#666;}"
        )
        self.btn_auto.clicked.connect(self._apply_auto)
        al.addWidget(self.btn_auto)
        self.auto_info = QLabel("")
        self.auto_info.setWordWrap(True)
        self.auto_info.setStyleSheet("color:#7ec88a;font-size:11px;")
        al.addWidget(self.auto_info)
        al.addStretch()
        cols.addWidget(ab, stretch=1)

        # Manual
        mb = QGroupBox("🔧  Ajuste manual")
        mb.setStyleSheet("QGroupBox{font-weight:bold;}")
        ml = QVBoxLayout(mb); ml.setSpacing(5)

        self._sliders = {}
        defs = [
            ("brightness", "☀  Brillo",        -80,  80,   0),
            ("contrast",   "◑  Contraste",       50, 200, 100),
            ("sharpen",    "⬡  Nitidez",          0,  30,   0),
            ("denoise",    "~  Ruido",            0,  10,   0),
            ("clahe_clip", "⚡ Correc. luz",      0,  60,   0),
            ("gamma",      "☽  Gamma",            1,  20,  10),
        ]
        for key, label, mn, mx, default in defs:
            row = QHBoxLayout()
            lbl = QLabel(label); lbl.setFixedWidth(120)
            lbl.setStyleSheet("font-size:11px;")
            row.addWidget(lbl)
            sl = QSlider(Qt.Horizontal)
            sl.setMinimum(mn); sl.setMaximum(mx); sl.setValue(default)
            sl.valueChanged.connect(self._on_manual)
            row.addWidget(sl, stretch=1)
            val = QLabel(str(default))
            val.setFixedWidth(28)
            val.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            val.setStyleSheet("color:#aaa;font-size:11px;")
            row.addWidget(val)
            self._sliders[key] = (sl, val)
            ml.addLayout(row)

        # Selector tipo de reja
        reja_row = QHBoxLayout()
        self.chk_inpaint = QCheckBox("Quitar reja")
        self.chk_inpaint.setStyleSheet("font-size:11px;")
        reja_row.addWidget(self.chk_inpaint)

        from qgis.PyQt.QtWidgets import QComboBox
        self.combo_grid = QComboBox()
        self.combo_grid.addItems(["Auto detectar", "Reja blanca/clara", "Reja oscura/negra"])
        self.combo_grid.setStyleSheet("font-size:11px;")
        reja_row.addWidget(self.combo_grid)
        ml.addLayout(reja_row)

        self.chk_texture = QCheckBox("🧪 Relleno con textura (experimental)")
        self.chk_texture.setChecked(False)
        self.chk_texture.setStyleSheet("font-size:11px; color:#aaa;")
        self.chk_texture.setToolTip(
            "Intenta reconstruir patrones repetidos (tejas, rejilla, ladrillo)\n"
            "en vez de solo difuminar. Requiere opencv-contrib. Si el resultado\n"
            "no se ve sano, el plugin usa el relleno clásico automáticamente."
        )
        ml.addWidget(self.chk_texture)

        self.btn_manual = QPushButton("▶  Aplicar manual")
        self.btn_manual.setEnabled(False)
        self.btn_manual.setMinimumHeight(28)
        self.btn_manual.setStyleSheet(
            "QPushButton{background:#444;color:#ddd;border-radius:4px;font-size:11px;}"
            "QPushButton:hover{background:#555;}"
            "QPushButton:disabled{background:#2a2a2a;color:#555;}"
        )
        self.btn_manual.clicked.connect(self._apply_manual)
        ml.addWidget(self.btn_manual)

        self.btn_grid_only = QPushButton("🧹  Solo quitar reja (sin filtros)")
        self.btn_grid_only.setEnabled(False)
        self.btn_grid_only.setMinimumHeight(28)
        self.btn_grid_only.setToolTip(
            "Quita la reja dejando brillo/contraste/nitidez/ruido/luz/gamma\n"
            "en su valor neutro (como un reset), para no mezclar el\n"
            "inpainting con otros ajustes que puedan deformar la imagen."
        )
        self.btn_grid_only.setStyleSheet(
            "QPushButton{background:#2f4d3a;color:#ddd;border-radius:4px;font-size:11px;}"
            "QPushButton:hover{background:#3b6049;}"
            "QPushButton:disabled{background:#2a2a2a;color:#555;}"
        )
        self.btn_grid_only.clicked.connect(self._apply_grid_only)
        ml.addWidget(self.btn_grid_only)

        cols.addWidget(mb, stretch=1)
        root.addLayout(cols)

        bot = QHBoxLayout()
        self.btn_reset = QPushButton("↺  Ver original")
        self.btn_reset.setEnabled(False)
        self.btn_reset.setStyleSheet(
            "QPushButton{background:#333;color:#ccc;border-radius:4px;padding:4px 10px;}"
            "QPushButton:hover{background:#444;}"
        )
        self.btn_reset.clicked.connect(self._show_original)
        bot.addWidget(self.btn_reset)
        self.status = QLabel("")
        self.status.setStyleSheet("color:#888;font-size:11px;")
        bot.addWidget(self.status, stretch=1)
        root.addLayout(bot)

    def load_capture(self, pixmap: QPixmap):
        self._original_pixmap = pixmap
        self.img_label.set_original_size(pixmap.width(), pixmap.height())
        self.btn_mark.setChecked(False)
        self.btn_clear_mark.setEnabled(False)
        self.mark_status.setText("")
        self._show_pixmap(pixmap)
        self.btn_auto.setEnabled(True)
        self.btn_manual.setEnabled(True)
        self.btn_grid_only.setEnabled(True)
        self.btn_reset.setEnabled(True)
        self.status.setText("Imagen cargada — esto es la captura tal cual, sin ningún filtro.")
        self.diag_lbl.setText("")
        self.auto_info.setText("")
        self.show(); self.raise_()
        QTimer.singleShot(200, self._preview_diagnosis)

    def _preview_diagnosis(self):
        """
        Se llama justo después de capturar: solo analiza la imagen y deja
        el diagnóstico + los sliders sugeridos a la vista, pero NO toca la
        imagen mostrada. Antes esto disparaba _apply_auto() directo, así
        que lo primero que veías tras capturar ya era la versión con
        brillo/contraste/nitidez/etc. aplicados — nunca la captura cruda.
        """
        if not self._original_pixmap:
            return
        if not _deps_ok():
            return
        img    = pixmap_to_numpy(self._original_pixmap)
        params = self._analyzer.analyze(img)
        self.diag_lbl.setText("🔍 " + params.get('summary', ''))
        self._sync_sliders(params)
        self.auto_info.setText(
            "Sugerencia calculada. Pulsa 'Mejorar automáticamente' si quieres aplicarla."
        )

    def _apply_auto(self):
        if not self._original_pixmap: return
        if not _deps_ok(): self._show_dep_error(); return
        self.btn_auto.setEnabled(False)
        self.btn_manual.setEnabled(False)
        self.btn_grid_only.setEnabled(False)
        self.prog.setValue(5)
        img    = pixmap_to_numpy(self._original_pixmap)
        params = self._analyzer.analyze(img)
        self.diag_lbl.setText("🔍 " + params.get('summary', ''))
        self._sync_sliders(params)
        self._run(params)

    def _sync_sliders(self, p):
        mapping = {
            'brightness': ('brightness', lambda v: int(v)),
            'contrast':   ('contrast',   lambda v: int(v * 100)),
            'sharpen':    ('sharpen',    lambda v: int(v * 10)),
            'denoise':    ('denoise',    lambda v: int(v)),
            'clahe_clip': ('clahe_clip', lambda v: int(v * 10)),
        }
        for sk, (pk, fn) in mapping.items():
            if sk in self._sliders and pk in p:
                sl, lbl = self._sliders[sk]
                v = max(sl.minimum(), min(sl.maximum(), fn(p[pk])))
                sl.blockSignals(True); sl.setValue(v); lbl.setText(str(v))
                sl.blockSignals(False)
        self.chk_inpaint.blockSignals(True)
        self.chk_inpaint.setChecked(p.get('inpaint', False))
        self.chk_inpaint.blockSignals(False)

    def _on_manual(self, _=None):
        for key, (sl, lbl) in self._sliders.items():
            lbl.setText(str(sl.value()))

    def _apply_manual(self):
        if not self._original_pixmap: return
        if not _deps_ok(): self._show_dep_error(); return

        def sv(k): return self._sliders[k][0].value()

        mode_map = {0: 'auto', 1: 'white', 2: 'dark'}
        grid_mode = mode_map.get(self.combo_grid.currentIndex(), 'auto')
        gamma_raw = sv('gamma')
        gamma_val = gamma_raw / 10.0

        manual_mask = None
        if self.img_label.has_marks():
            # El usuario marcó la reja a mano con el pincel: usar esa marca
            # tal cual para el inpainting, sin pasar por la detección
            # automática de líneas (más confiable cuando la detección falla
            # o cuando la reja tiene una forma irregular).
            manual_mask = self.img_label.get_mask_numpy()

        params = {
            'clahe':       sv('clahe_clip') > 0,
            'clahe_clip':  sv('clahe_clip') / 10.0,
            'inpaint':     self.chk_inpaint.isChecked(),
            'inpaint_mask': manual_mask,
            'grid_mode':   grid_mode,
            'use_texture_inpaint': self.chk_texture.isChecked(),
            'sharpen':     sv('sharpen') / 10.0,
            'denoise':     sv('denoise'),
            'brightness':  float(sv('brightness')),
            'contrast':    sv('contrast') / 100.0,
            'gamma_val':   gamma_val,
        }
        self.btn_manual.setEnabled(False)
        self.btn_grid_only.setEnabled(False)
        self._clear_mask_after_run = (
            manual_mask is not None and self.chk_inpaint.isChecked()
        )
        self._run(params)

    def _apply_grid_only(self):
        if not self._original_pixmap: return
        if not _deps_ok(): self._show_dep_error(); return

        manual_mask = None
        if self.img_label.has_marks():
            manual_mask = self.img_label.get_mask_numpy()

        mode_map = {0: 'auto', 1: 'white', 2: 'dark'}
        grid_mode = mode_map.get(self.combo_grid.currentIndex(), 'auto')

        # Dejar los sliders en su valor neutro (visual y en los parámetros):
        # así queda claro que lo único que se aplicó fue quitar la reja,
        # sin mezclarlo con brillo/contraste/nitidez/ruido/luz/gamma, que
        # son los que estaban deformando la imagen junto con el inpainting.
        neutros = {
            'brightness': 0, 'contrast': 100, 'sharpen': 0,
            'denoise': 0, 'clahe_clip': 0, 'gamma': 10,
        }
        for key, val in neutros.items():
            if key in self._sliders:
                sl, lbl = self._sliders[key]
                sl.blockSignals(True); sl.setValue(val); lbl.setText(str(val))
                sl.blockSignals(False)
        self.chk_inpaint.blockSignals(True)
        self.chk_inpaint.setChecked(True)
        self.chk_inpaint.blockSignals(False)

        params = {
            'clahe':        False,
            'clahe_clip':   2.0,
            'inpaint':      True,
            'inpaint_mask': manual_mask,
            'grid_mode':    grid_mode,
            'sharpen':      0.0,
            'denoise':      0,
            'brightness':   0.0,
            'contrast':     1.0,
            'gamma_val':    1.0,
        }
        self.btn_manual.setEnabled(False)
        self.btn_grid_only.setEnabled(False)
        self._clear_mask_after_run = manual_mask is not None
        self._run(params)

    def _run(self, params):
        img = pixmap_to_numpy(self._original_pixmap)
        if self._worker and self._worker.isRunning():
            self._worker.terminate(); self._worker.wait()
        self._worker = EnhanceWorker(img, params)
        self._worker.finished.connect(self._on_done)
        self._worker.error.connect(self._on_error)
        self._worker.progress.connect(
            lambda v, m: (self.prog.setValue(v), self.status.setText(m))
        )
        self._worker.start()

    def _on_done(self, result):
        if self._clear_mask_after_run:
            # La marca ya cumplió su función (se usó como máscara de
            # inpainting): quitarla para no dejar el tinte rojo pegado
            # encima de la zona que ya se arregló — si no, parece que se
            # aplicó un filtro de color sobre el resultado.
            self.img_label.clear_mask()
            self.btn_clear_mark.setEnabled(False)
            self._clear_mask_after_run = False
        self._show_pixmap(numpy_to_pixmap(result))
        self.prog.setValue(100)
        self.btn_auto.setEnabled(True)
        self.btn_manual.setEnabled(True)
        self.btn_grid_only.setEnabled(True)
        self.status.setText("✔ Listo.")
        self.auto_info.setText("✔ Aplicado. Usa los sliders para refinar.")
        QTimer.singleShot(2000, lambda: self.prog.setValue(0))

    def _on_error(self, msg):
        self._clear_mask_after_run = False
        self.btn_auto.setEnabled(True)
        self.btn_manual.setEnabled(True)
        self.btn_grid_only.setEnabled(True)
        self.prog.setValue(0)
        self.status.setText(f"Error: {msg}")
        QgsMessageLog.logMessage(f"SVEnhance: {msg}", "VisorSV", Qgis.Warning)

    def _show_original(self):
        if self._original_pixmap:
            self._show_pixmap(self._original_pixmap)
            self.status.setText("Imagen original.")

    def _show_pixmap(self, pixmap: QPixmap):
        w = max(self.scroll.width() - 20, 400)
        scaled = pixmap.scaledToWidth(w, Qt.SmoothTransformation)
        self.img_label.set_base_pixmap(scaled)
        self.img_label.setMinimumHeight(scaled.height())

    def _on_mark_toggled(self, checked):
        self.img_label.set_drawing_enabled(checked)
        if checked:
            self.mark_status.setText("Dibuja sobre la reja con el mouse…")
        elif not self.img_label.has_marks():
            self.mark_status.setText("")

    def _on_mask_changed(self):
        has_marks = self.img_label.has_marks()
        self.btn_clear_mark.setEnabled(has_marks)
        if has_marks:
            self.mark_status.setText("✓ Marca lista — usa 'Aplicar manual' para quitarla")
            self.chk_inpaint.setChecked(True)
        elif not self.btn_mark.isChecked():
            self.mark_status.setText("")

    def _on_clear_marks(self):
        self.img_label.clear_mask()
        self.btn_clear_mark.setEnabled(False)
        if not self.btn_mark.isChecked():
            self.mark_status.setText("")

    def _show_dep_error(self):
        iface.messageBar().pushMessage(
            "VisorSV",
            "Falta OpenCV. En consola Python de QGIS: "
            "import subprocess,sys; subprocess.run([sys.executable,'-m','pip','install','opencv-python-headless'])",
            level=Qgis.Critical, duration=8
        )
