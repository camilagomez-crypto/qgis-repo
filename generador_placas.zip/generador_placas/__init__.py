# __init__.py para el plugin RAW Numerador

def classFactory(iface):
    from .raw_numerador import RawNumeradorPlugin
    return RawNumeradorPlugin(iface)
