import os
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QDockWidget,QAction
from .gui_dock import RawNumeradorDock

class RawNumeradorPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.dock = None

    def initGui(self):
        self.action = QAction(QIcon(os.path.join(os.path.dirname(__file__), "corriendo.png")),"RAW Numerador de Placas", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&RAW Numerador", self.action)

    def unload(self):
        self.iface.removePluginMenu("&RAW Numerador", self.action)
        self.iface.removeToolBarIcon(self.action)
        if self.dock:
            self.iface.removeDockWidget(self.dock)

    def run(self):
        if self.dock:
            self.iface.removeDockWidget(self.dock)

        self.dock = QDockWidget("RAW Numerador de Placas", self.iface.mainWindow())
        self.dock.setObjectName("RawNumeradorDock")
        self.panel = RawNumeradorDock(self.iface)
        self.dock.setWidget(self.panel)
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)
        self.dock.show()
