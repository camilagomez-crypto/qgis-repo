# gui_dock.py - Panel DockWidget del plugin RAW Numerador (versión corregida)
from qgis.PyQt.QtWidgets import QWidget, QVBoxLayout, QPushButton, QInputDialog, QMessageBox, QLabel
from qgis.PyQt.QtCore import Qt
from qgis.gui import QgsMapToolIdentifyFeature
from qgis.core import QgsFeature, QgsVectorLayer
import re

class RawNumeradorDock(QWidget):
    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.layer = None
        self.orden_ids = []

        self.setWindowTitle("RAW Numerador de Placas")
        self.setMinimumWidth(320)

        layout = QVBoxLayout()

        self.label_estado = QLabel("Predios seleccionados: 0")
        layout.addWidget(self.label_estado)

        # botones
        self.btn_seleccionar = QPushButton("Iniciar selección de predios")
        self.btn_generar = QPushButton("Generar consecutivo numerico en placas")
        self.btn_mza_cas = QPushButton("Generar consecutivo de casa en placa")
        self.btn_dire2 = QPushButton("Generar consecutivo en direccion2")

        # conectar signals
        self.btn_seleccionar.clicked.connect(self.iniciar_seleccion)
        self.btn_generar.clicked.connect(self.generar_placas)
        self.btn_mza_cas.clicked.connect(self.mza_cas)
        self.btn_dire2.clicked.connect(self.dire2)

        # añadir al layout (orden lógico)
        layout.addWidget(self.btn_seleccionar)
        layout.addWidget(self.btn_generar)
        layout.addWidget(self.btn_mza_cas)
        layout.addWidget(self.btn_dire2)
        layout.addStretch()

        self.setLayout(layout)

    def iniciar_seleccion(self):
        """Inicia la herramienta de selección por click; la capa debe estar activa y editable."""
        self.layer = self.iface.activeLayer()
        if not self.layer or not isinstance(self.layer, QgsVectorLayer):
            QMessageBox.warning(self, "Error", "Selecciona una capa vectorial activa.")
            return
        if not self.layer.isEditable():
            QMessageBox.warning(self, "Error", "La capa debe estar en modo edición (activar lápiz).")
            return

        self.orden_ids = []
        self.tool = SeleccionPorClick(self.canvas, self.layer, self.orden_ids, self.actualizar_estado)
        self.canvas.setMapTool(self.tool)
        QMessageBox.information(self, "Modo selección", "Haz clic sobre los predios en el orden deseado.")

    def actualizar_estado(self):
        self.label_estado.setText(f"Predios seleccionados: {len(self.orden_ids)}")

    def generar_placas(self):
        """Genera un consecutivo numérico simple en el campo 'placa' (2 dígitos padded)."""
        if not self.layer or not self.orden_ids:
            QMessageBox.warning(self, "Error", "No hay predios seleccionados.")
            return
        if not self.layer.isEditable():
            QMessageBox.warning(self, "Error", "La capa debe estar en modo edición.")
            return

        num_inicial, ok1 = QInputDialog.getInt(self, "Número inicial", "Desde qué número comenzar:", 2, 1, 99999, 1)
        if not ok1:
            return

        incremento, ok2 = QInputDialog.getInt(self, "Incremento", "Valor de incremento:", 1, 1, 99999, 1)
        if not ok2:
            return

        idx_placa = self.layer.fields().indexFromName("placa")
        if idx_placa == -1:
            QMessageBox.critical(self, "Error", "El campo 'placa' no existe en la capa.")
            return

        numero = num_inicial
        # escribimos en los fids del orden
        for fid in self.orden_ids:
            valor = str(numero).zfill(2)
            try:
                self.layer.changeAttributeValue(fid, idx_placa, valor)
            except Exception as e:
                print(f"Error asignando placa a fid {fid}: {e}")
            numero += incremento

        QMessageBox.information(self, "Completado", f"{len(self.orden_ids)} placas asignadas.")
        self.actualizar_estado()

    def mza_cas(self):

        if not self.layer or not self.orden_ids:
            QMessageBox.warning(self, "Error", "No hay predios seleccionados.")
            return
        if not self.layer.isEditable():
            QMessageBox.warning(self, "Error", "La capa debe estar en modo edición.")
            return

        opciones = ["CAS", "TOR", "BOD", "LCA", "INT"]
        prefijo, ok = QInputDialog.getItem(self, "Seleccione prefijo", "Prefijo:", opciones, 0, False)
        if not ok or not prefijo:
            return

        # pedir número inicial e incremento
        num_inicial, ok1 = QInputDialog.getInt(self, "Número inicial", "Desde qué número comenzar:", 1, 1, 99999, 1)
        if not ok1:
            return
        incremento, ok2 = QInputDialog.getInt(self, "Incremento", "Valor de incremento:", 1, 1, 99999, 1)
        if not ok2:
            return

        idx_placa = self.layer.fields().indexFromName("placa")
        if idx_placa == -1:
            QMessageBox.critical(self, "Error", "El campo 'placa' no existe en la capa.")
            return

        numero = num_inicial
        escritos = 0
        for fid in self.orden_ids:
            if prefijo in ("CAS", "INT"):
                # padding 2 dígitos
                sufijo = str(numero).zfill(2)
            else:
                sufijo = str(numero)
            nuevo_val = f"{prefijo} {sufijo}"
            try:
                self.layer.changeAttributeValue(fid, idx_placa, nuevo_val)
                escritos += 1
            except Exception as e:
                print(f"Error asignando '{nuevo_val}' a fid {fid}: {e}")
            numero += incremento

        QMessageBox.information(self, "Completado", f"{escritos} placas asignadas con prefijo '{prefijo}'.")
        self.actualizar_estado()

    def dire2(self):
        """
        Asigna valores estandarizados al campo 'direccion2' usando la plantilla ingresada por el usuario.
        Convierte la parte textual a MAYÚSCULAS y soporta {n} o {num} (case-insensitive).
        """
        if not self.layer or not self.orden_ids:
            QMessageBox.warning(self, "Error", "No hay predios seleccionados.")
            return
        if not self.layer.isEditable():
            QMessageBox.warning(self, "Error", "La capa debe estar en modo edición.")
            return

        campo_dest = "direccion2"
        idx_dir2 = self.layer.fields().indexFromName(campo_dest)
        if idx_dir2 == -1:
            QMessageBox.critical(self, "Error", f"El campo '{campo_dest}' no existe en la capa.")
            return

        plantilla, ok = QInputDialog.getText(self, "Plantilla direccion2",
                                                 "Escriba el nombre de la URB o BRR completo ejemplo: URB LA CEIBA MAZ A CAS",
                                                 text="")
        if not ok:
            return
        plantilla = plantilla.strip()
        if plantilla == "":
            QMessageBox.warning(self, "Error", "Plantilla vacía. Cancelado.")
            return

        num_inicial, ok1 = QInputDialog.getInt(self, "Número inicial", "Desde qué número comenzar:", 1, 0, 9999999, 1)
        if not ok1:
            return
        incremento, ok2 = QInputDialog.getInt(self, "Incremento", "Valor de incremento:", 1, 1, 9999999, 1)
        if not ok2:
            return
        padding, ok3 = QInputDialog.getInt(self, "Padding de dígitos", "Cantidad de dígitos (ej. 2 -> 01, 02):", 2, 0, 10, 1)
        if not ok3:
            return

        numero = int(num_inicial)
        escritos = 0
        fallos = []

        # patrón para placeholders {n} o {num} (case-insensitive)
        placeholder_rx = re.compile(r'\{(?:n|num)\}', flags=re.IGNORECASE)

        for fid in self.orden_ids:
            try:
                s_num = str(int(numero)).zfill(padding) if padding > 0 else str(int(numero))
            except Exception:
                s_num = str(numero)

            if placeholder_rx.search(plantilla):
                # reemplazar placeholder (independiente de mayúsculas) por el número
                valor_raw = placeholder_rx.sub(s_num, plantilla)
            else:
                # añadir número al final
                if plantilla.endswith(" "):
                    valor_raw = f"{plantilla}{s_num}"
                else:
                    valor_raw = f"{plantilla} {s_num}"

            # Convertir el texto final a MAYÚSCULAS (números no cambian)
            valor_final = valor_raw.upper()

            # escribir en la capa
            try:
                ok_change = self.layer.changeAttributeValue(fid, idx_dir2, valor_final)
                if ok_change is False:
                    fallos.append((fid, f"Provider returned False when setting '{valor_final}'"))
                else:
                    escritos += 1
            except Exception as e:
                fallos.append((fid, str(e)))

            numero += int(incremento)

        # reporte
        msg = f"Proceso terminado. Direcciones escritas: {escritos}.\n"
        if fallos:
            msg += f"Fallos: {len(fallos)} (ver consola para detalle)\n"
            print("Errores al asignar direccion2:")
            for fid, err in fallos:
                print(f"  - fid {fid}: {err}")

        QMessageBox.information(self, "dire2", msg)
        self.actualizar_estado()
      

class SeleccionPorClick(QgsMapToolIdentifyFeature):
    def __init__(self, canvas, layer, orden_ids, callback):
        super().__init__(canvas)
        self.canvas = canvas
        self.layer = layer
        self.orden_ids = orden_ids
        self.callback = callback
        self.setCursor(Qt.CrossCursor)

    def canvasReleaseEvent(self, event):
        # identificar feature en la capa activa
        results = self.identify(event.x(), event.y(), [self.layer], QgsMapToolIdentifyFeature.TopDownAll)
        feature = None
        if results:
            # tomar la primera
            try:
                feature = results[0].mFeature
            except Exception:
                # compatibilidad con otras versiones
                feature = results[0].feature()

        if feature:
            fid = feature.id()
            if fid not in self.orden_ids:
                self.orden_ids.append(fid)
                # seleccionar el fid (usar selectByIds para compatibilidad)
                try:
                    self.layer.selectByIds(self.orden_ids)
                except Exception:
                    # fallback: intentar select
                    try:
                        self.layer.select(fid)
                    except Exception:
                        pass
                self.callback()
