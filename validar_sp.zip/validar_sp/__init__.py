# __init__.py - Archivo para registrar el plugin

def classFactory(iface):
    from .validador_sp import ValidadorSP
    return ValidadorSP(iface)
