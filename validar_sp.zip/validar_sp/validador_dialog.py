# validador_dialog.py (CON FUNCIONALIDAD DE ZOOM AÑADIDA)

import re
from qgis.PyQt.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QFormLayout, QComboBox, QMessageBox, QToolBar
)
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtCore import QUrl, Qt, QTimer, QPointF
from qgis.core import (
    QgsProject, QgsSpatialIndex, QgsWkbTypes,
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsGeometry,
    QgsPointXY
)
from qgis.gui import QgsRubberBand, QgsVertexMarker
from qgis.utils import iface

try:
    from qgis.PyQt.QtWebEngineWidgets import QWebEngineView
    WEB_ENGINE_DISPONIBLE = True
except ImportError:
    WEB_ENGINE_DISPONIBLE = False

JS_GET_URL = "window.location.href;"

class ValidadorPlacasDock(QDockWidget):
    def __init__(self, capa, parent=iface.mainWindow()):
        super().__init__("Validador SP", parent)
        self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self.setFeatures(QDockWidget.DockWidgetClosable | QDockWidget.DockWidgetMovable)
        self.capa, self.sugerencias, self.indice_actual = capa, [], 0
        self.webview, self.tracking_timer = None, None
        self.init_canvas_items()
        self.build_config_ui()
        iface.addDockWidget(Qt.RightDockWidgetArea, self)

    def init_canvas_items(self):
        canvas = iface.mapCanvas()
        self.rb_highlight = QgsRubberBand(canvas, QgsWkbTypes.PolygonGeometry)
        self.rb_highlight.setColor(QColor(255, 0, 0, 90)); self.rb_highlight.setWidth(2)
        
        self.vm_target = QgsVertexMarker(canvas)
        self.vm_target.setColor(QColor(255, 140, 0)); self.vm_target.setIconType(QgsVertexMarker.ICON_CROSS); self.vm_target.setIconSize(14); self.vm_target.setPenWidth(3)
        canvas.scene().addItem(self.vm_target); self.vm_target.hide()

        self.vm_pegman = QgsVertexMarker(canvas)
        self.vm_pegman.setColor(QColor(50, 200, 50)); self.vm_pegman.setIconType(QgsVertexMarker.ICON_CIRCLE); self.vm_pegman.setIconSize(12); self.vm_pegman.setPenWidth(2)
        canvas.scene().addItem(self.vm_pegman); self.vm_pegman.hide()

        self.rb_arrow = QgsRubberBand(canvas, QgsWkbTypes.PolygonGeometry)
        self.rb_arrow.setColor(QColor(0, 150, 255, 200)); self.rb_arrow.setWidth(1)
        self.base_arrow_polygon = self.create_arrow_polygon()

    def create_arrow_polygon(self):
        points = [QPointF(0, 10), QPointF(3, 1), QPointF(1.5, 1), QPointF(0, 3), QPointF(-1.5, 1), QPointF(-3, 1)]
        return QgsGeometry.fromPolygonXY([[QgsPointXY(p.x(), p.y()) for p in points]])

    def build_config_ui(self):
        self.setWindowTitle("Validador SP - Configuración")
        campos = [f.name() for f in self.capa.fields()]
        self.combo_via_princ, self.combo_via_sec, self.combo_placa, self.combo_marca = QComboBox(), QComboBox(), QComboBox(), QComboBox()
        for combo in [self.combo_via_princ, self.combo_via_sec, self.combo_placa, self.combo_marca]: combo.addItems(campos)
        for i, campo in enumerate(campos):
            if 'via_princ' in campo.lower(): self.combo_via_princ.setCurrentIndex(i)
            if 'via_sec' in campo.lower(): self.combo_via_sec.setCurrentIndex(i)
            if 'placa' in campo.lower(): self.combo_placa.setCurrentIndex(i)
            if 'asignac' in campo.lower(): self.combo_marca.setCurrentIndex(i)
        btn_iniciar = QPushButton("Iniciar Validación"); btn_iniciar.clicked.connect(self.iniciar_analisis)
        layout_config = QFormLayout(); layout_config.addRow("Campo vía principal:", self.combo_via_princ); layout_config.addRow("Campo vía secundaria:", self.combo_via_sec); layout_config.addRow("Campo de placa:", self.combo_placa); layout_config.addRow("Campo de marca:", self.combo_marca); layout_config.addRow(btn_iniciar)
        config_widget = QWidget(); config_widget.setLayout(layout_config); self.setWidget(config_widget)

    def iniciar_analisis(self):
        via_princ, via_sec, placa, marca = self.combo_via_princ.currentText(), self.combo_via_sec.currentText(), self.combo_placa.currentText(), self.combo_marca.currentText()
        self.sugerencias = analizar_predios(self.capa, via_princ, via_sec, placa, marca)
        if not self.sugerencias: QMessageBox.information(self, "Análisis Completo", "No se encontraron sugerencias."); return
        self.build_validator_ui(via_princ, via_sec, placa, marca)

    def build_validator_ui(self, via_princ, via_sec, campo_placa, campo_marca):
        self.setWindowTitle("Validador SP")
        self.via_princ, self.via_sec, self.campo_placa, self.campo_marca = via_princ, via_sec, campo_placa, campo_marca
        self.indice_actual = 0; widget_contenido = QWidget(); layout_principal = QVBoxLayout(widget_contenido)
        
        if WEB_ENGINE_DISPONIBLE:
            self.webview = QWebEngineView()
            self.webview.setUrl(QUrl("about:blank"))
            self.webview.loadFinished.connect(self.start_tracking)
            layout_principal.addWidget(self.webview, stretch=3)

            # --- AÑADIDO: Barra de Herramientas para el Zoom ---
            zoom_toolbar = QToolBar()
            layout_principal.addWidget(zoom_toolbar)

            zoom_out_action = zoom_toolbar.addAction("-")
            zoom_out_action.setToolTip("Alejar")
            zoom_out_action.triggered.connect(self.zoom_out)

            self.zoom_label = QLabel(" 100% ")
            zoom_toolbar.addWidget(self.zoom_label)

            zoom_in_action = zoom_toolbar.addAction("+")
            zoom_in_action.setToolTip("Acercar")
            zoom_in_action.triggered.connect(self.zoom_in)
            
            zoom_toolbar.addSeparator()

            reset_zoom_action = zoom_toolbar.addAction("Restablecer")
            reset_zoom_action.setToolTip("Restablecer zoom al 100%")
            reset_zoom_action.triggered.connect(self.reset_zoom)
            # --- FIN DE LA SECCIÓN AÑADIDA ---

        else: 
            layout_principal.addWidget(QLabel("Componente Street View no disponible."))
        
        form_container = QWidget(); form_layout = QFormLayout(form_container)
        self.info_label, self.id_label, self.vecino1_label, self.vecino2_label, self.sugerencia_label = QLabel(), QLabel(), QLabel(), QLabel(), QLabel()
        self.placa_edit = QLineEdit()
        form_layout.addRow("Predio Actual:", self.info_label); form_layout.addRow("Feature ID:", self.id_label); form_layout.addRow("Placa Vecino 1:", self.vecino1_label); form_layout.addRow("Placa Vecino 2:", self.vecino2_label); form_layout.addRow("<b>Placa Sugerida:</b>", self.sugerencia_label); form_layout.addRow("Placa a Aplicar:", self.placa_edit)
        btn_layout = QHBoxLayout(); self.btn_anterior, self.btn_siguiente, self.btn_aplicar, self.btn_cerrar = QPushButton("Anterior"), QPushButton("Siguiente"), QPushButton("Aplicar y Siguiente"), QPushButton("Cerrar")
        btn_layout.addWidget(self.btn_anterior); btn_layout.addWidget(self.btn_siguiente); btn_layout.addStretch(); btn_layout.addWidget(self.btn_aplicar); btn_layout.addWidget(self.btn_cerrar)
        
        layout_principal.addWidget(form_container, stretch=1); layout_principal.addLayout(btn_layout)
        
        self.setWidget(widget_contenido)
        self.campo_placa_idx = self.capa.fields().lookupField(campo_placa); self.campo_marca_idx = self.capa.fields().lookupField(campo_marca)
        self.btn_anterior.clicked.connect(self.anterior_predio); self.btn_siguiente.clicked.connect(self.siguiente_predio); self.btn_aplicar.clicked.connect(self.aplicar_y_siguiente); self.btn_cerrar.clicked.connect(self.close)
        self.mostrar_sugerencia_actual()

    # --- AÑADIDO: Funciones para controlar el Zoom ---
    def zoom_in(self):
        if not self.webview: return
        new_zoom = self.webview.zoomFactor() + 0.1
        self.webview.setZoomFactor(new_zoom)
        self.update_zoom_label(new_zoom)

    def zoom_out(self):
        if not self.webview: return
        new_zoom = self.webview.zoomFactor() - 0.1
        if new_zoom < 0.1: new_zoom = 0.1
        self.webview.setZoomFactor(new_zoom)
        self.update_zoom_label(new_zoom)

    def reset_zoom(self):
        if not self.webview: return
        self.webview.setZoomFactor(1.0)
        self.update_zoom_label(1.0)
    
    def update_zoom_label(self, zoom_factor):
        if hasattr(self, 'zoom_label'):
            self.zoom_label.setText(f" {zoom_factor:.0%} ")
    # --- FIN DE LAS FUNCIONES DE ZOOM ---

    def mostrar_sugerencia_actual(self):
        if not (0 <= self.indice_actual < len(self.sugerencias)): return
        sug = self.sugerencias[self.indice_actual]
        feature = self.capa.getFeature(sug['Feature_ID'])
        self.info_label.setText(f"<b>{self.indice_actual + 1} de {len(self.sugerencias)}</b>")
        self.id_label.setText(str(sug['Feature_ID'])); self.vecino1_label.setText(str(sug['Vecino1_Placa'])); self.vecino2_label.setText(str(sug['Vecino2_Placa']))
        self.sugerencia_label.setText(f"<i>{sug['Placa_Sugerida']}</i>"); self.placa_edit.setText(sug['Placa_Sugerida'])
        
        self.vm_pegman.hide(); self.rb_arrow.hide()

        if feature.hasGeometry():
            geom = feature.geometry()
            self.rb_highlight.setToGeometry(geom, self.capa)
            self.vm_target.setCenter(geom.centroid().asPoint())
            iface.mapCanvas().zoomToFeatureIds(self.capa, [feature.id()])
            self.rb_highlight.show(); self.vm_target.show()
            if WEB_ENGINE_DISPONIBLE: self.actualizar_street_view(feature)

    def actualizar_street_view(self, feature):
        geom = feature.geometry()
        if not geom: return
        centroide = geom.centroid().asPoint()
        crs_src = self.capa.crs(); crs_dst = QgsCoordinateReferenceSystem("EPSG:4326")
        transform = QgsCoordinateTransform(crs_src, crs_dst, QgsProject.instance()) if crs_src != crs_dst else None
        punto_wgs84 = transform.transform(centroide) if transform else centroide
        lat, lon = punto_wgs84.y(), punto_wgs84.x()
        url = f"https://www.google.com/maps?q&layer=c&cbll={lat},{lon}&cbp=12,0,0,0,0"
        if self.webview:
            self.reset_zoom() # Restablece el zoom al cargar nueva ubicación
            self.webview.load(QUrl(url))

    def anterior_predio(self):
        if self.indice_actual > 0: self.indice_actual -= 1; self.mostrar_sugerencia_actual()

    def siguiente_predio(self):
        if self.indice_actual < len(self.sugerencias) - 1: self.indice_actual += 1; self.mostrar_sugerencia_actual()

    def aplicar_y_siguiente(self):
        sug = self.sugerencias[self.indice_actual]; nueva_placa = self.placa_edit.text().strip().upper()
        if not nueva_placa: QMessageBox.warning(self, "Error", "La placa no puede estar vacía."); return
        self.capa.startEditing(); self.capa.changeAttributeValue(sug['Feature_ID'], self.campo_placa_idx, nueva_placa)
        if self.campo_marca_idx != -1: self.capa.changeAttributeValue(sug['Feature_ID'], self.campo_marca_idx, 5)
        self.capa.commitChanges()
        if self.indice_actual < len(self.sugerencias) - 1: self.indice_actual += 1; self.mostrar_sugerencia_actual()
        else: QMessageBox.information(self, "Validación Completa", "Todos los predios han sido validados."); self.close()

    def start_tracking(self, ok):
        if not ok or self.tracking_timer: return
        self.tracking_timer = QTimer(self); self.tracking_timer.setInterval(500)
        self.tracking_timer.timeout.connect(self.request_current_data)
        self.tracking_timer.start()
        
    def request_current_data(self):
        if self.webview and self.webview.isVisible():
            self.webview.page().runJavaScript(JS_GET_URL, self.process_url_data)
            
    def process_url_data(self, url):
        if not url:
            self.vm_pegman.hide(); self.rb_arrow.hide(); return
        
        lat, lon, heading = None, None, 0.0
        new_format_match = re.search(r'@([-\d.]+),([-\d.]+),.*?([\d.]+)h', url)
        if new_format_match:
            lat, lon, heading = float(new_format_match.group(1)), float(new_format_match.group(2)), float(new_format_match.group(3))
        else:
            old_pos_match = re.search(r'cbll=([-\d.]+),([-\d.]+)', url)
            if old_pos_match:
                lat, lon = float(old_pos_match.group(1)), float(old_pos_match.group(2))
                old_heading_match = re.search(r'cbp=\d+,([-\d.]+)', url)
                if old_heading_match:
                    heading = float(old_heading_match.group(1))

        if lat is None or lon is None:
            self.vm_pegman.hide(); self.rb_arrow.hide(); return
        
        crs_wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        transform = QgsCoordinateTransform(crs_wgs84, iface.mapCanvas().mapSettings().destinationCrs(), QgsProject.instance())
        pegman_pos_map = transform.transform(QgsPointXY(lon, lat))
        
        self.vm_pegman.setCenter(pegman_pos_map); self.vm_pegman.show()
        
        map_width = iface.mapCanvas().extent().width()
        scale_factor = (map_width * 0.02) / 10.0
        
        original_points = self.base_arrow_polygon.asPolygon()[0]
        scaled_points = [QgsPointXY(p.x() * scale_factor, p.y() * scale_factor) for p in original_points]
        arrow_geom = QgsGeometry.fromPolygonXY([scaled_points])
        
        arrow_geom.rotate(-heading, QgsPointXY(0,0))
        arrow_geom.translate(pegman_pos_map.x(), pegman_pos_map.y())
        
        self.rb_arrow.setToGeometry(arrow_geom, None); self.rb_arrow.show()

    def cleanup_canvas_items(self):
        if self.tracking_timer:
            self.tracking_timer.stop()
            self.tracking_timer = None
        canvas = iface.mapCanvas()
        if canvas:
            if self.rb_highlight: self.rb_highlight.reset()
            if self.rb_arrow: self.rb_arrow.reset()
            if self.vm_target and self.vm_target in canvas.scene().items(): canvas.scene().removeItem(self.vm_target)
            if self.vm_pegman and self.vm_pegman in canvas.scene().items(): canvas.scene().removeItem(self.vm_pegman)
        self.vm_target = self.vm_pegman = self.rb_highlight = self.rb_arrow = None

    def closeEvent(self, event):
        self.cleanup_canvas_items(); event.accept()

def extraer_numero_placa(placa):
    if not isinstance(placa, str): return None
    match = re.search(r'(\d+)\s*$', placa.strip()); return int(match.group(1)) if match else None

def es_par(numero): return numero % 2 == 0 if isinstance(numero, int) else None

def analizar_predios(capa, via_princ_field, via_sec_field, placa_field, marca_field):
    predios_objetivo, vecinos_potenciales, idx_espacial = [], {}, QgsSpatialIndex()
    for feat in capa.getFeatures():
        placa = feat[placa_field]
        if isinstance(placa, str) and placa.strip().upper() == 'SP': predios_objetivo.append({'id': feat.id(), 'via_sec': feat[via_sec_field], 'via_princ': feat[via_princ_field], 'geom': QgsGeometry(feat.geometry())})
        elif placa:
            num = extraer_numero_placa(placa)
            if num is not None: vecinos_potenciales[feat.id()] = {'placa': placa, 'via_sec': feat[via_sec_field], 'via_princ': feat[via_princ_field], 'geom': QgsGeometry(feat.geometry()), 'numero_placa': num}; idx_espacial.addFeature(feat)
    resultados = []
    for predio in predios_objetivo:
        if not predio['geom'] or predio['geom'].isEmpty(): continue
        vecinos = [vecinos_potenciales[cid] for cid in idx_espacial.intersects(predio['geom'].boundingBox()) if cid in vecinos_potenciales and predio['via_princ'] == vecinos_potenciales[cid]['via_princ'] and predio['via_sec'] == vecinos_potenciales[cid]['via_sec'] and predio['geom'].touches(vecinos_potenciales[cid]['geom'])]
        if len(vecinos) == 2:
            v1, v2 = vecinos; n1, n2 = v1['numero_placa'], v2['numero_placa']; par1, par2 = es_par(n1), es_par(n2)
            if par1 is not None and par1 == par2:
                nsug = int(round((n1 + n2) / 2.0))
                if nsug > 0 and es_par(nsug) != par1:
                    if min(n1, n2) < nsug < max(n1, n2): nsug = nsug - 1 if nsug > (n1+n2)/2.0 else nsug + 1
                    else: continue
                if nsug != n1 and nsug != n2:
                    prefijo_match = re.match(r'^\D*', v1['placa'].strip()); prefijo = prefijo_match.group(0) if prefijo_match else ""
                    resultados.append({'Feature_ID': predio['id'], 'Placa_Sugerida': f"{prefijo}{nsug}".strip(), 'Vecino1_Placa': v1['placa'], 'Vecino2_Placa': v2['placa']})
    return resultados