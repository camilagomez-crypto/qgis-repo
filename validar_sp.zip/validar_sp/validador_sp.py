# validador_sp.py (Punto de entrada del plugin y gestión del DockWidget)

from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtWidgets import QAction, QInputDialog, QMessageBox
from qgis.core import QgsProject
from qgis.utils import iface
from .validador_dialog import ValidadorPlacasDock

class ValidadorSP:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dock_widget = None # Referencia al panel

    def tr(self, message):
        return QCoreApplication.translate('ValidadorSP', message)

    def initGui(self):
        """Crea la acción de la barra de herramientas y del menú."""
        self.action = QAction(self.tr("Validador SP con Street View"), self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(self.tr("&ValidadorSP"), self.action)

    def unload(self):
        """
        Se llama al desinstalar/desactivar el plugin.
        Solo elimina los elementos de la UI de QGIS. No intenta cerrar el panel.
        QGIS se encarga de cerrar y destruir los paneles al cerrar la aplicación o
        al desinstalar el plugin, lo que activará la señal 'destroyed'.
        """
        self.iface.removePluginMenu(self.tr("&ValidadorSP"), self.action)
        self.iface.removeToolBarIcon(self.action)
        # No se cierra el dock aquí para evitar el 'RuntimeError'.

    def run(self):
        """
        Ejecuta el plugin. Si el panel ya existe, lo muestra.
        Si no, lo crea.
        """
        if self.dock_widget:
            # Si el panel ya existe (puede estar oculto), simplemente lo muestra.
            self.dock_widget.show()
            self.dock_widget.raise_() # Lo trae al frente
            return

        # --- Selección de Capa ---
        capas_vectoriales = [c for c in QgsProject.instance().mapLayers().values() if c.type() == 0]
        if not capas_vectoriales:
            QMessageBox.warning(self.iface.mainWindow(), "Validador SP", "No hay capas vectoriales cargadas en el proyecto.")
            return

        nombres_capas = [c.name() for c in capas_vectoriales]
        capa_nombre, ok = QInputDialog.getItem(
            self.iface.mainWindow(), 
            "Seleccionar Capa de Predios",
            "Capa:", nombres_capas, 0, False
        )
        if not ok or not capa_nombre:
            return

        capa_seleccionada = QgsProject.instance().mapLayersByName(capa_nombre)[0]
        
        # --- Creación del Panel ---
        self.dock_widget = ValidadorPlacasDock(capa_seleccionada, self.iface.mainWindow())
        
        # Conectar la señal 'destroyed' del panel a un método de limpieza.
        # Esto asegura que nuestra referencia (self.dock_widget) se limpie
        # cuando QGIS destruya el objeto del panel, evitando punteros colgantes.
        self.dock_widget.destroyed.connect(self.on_dock_widget_destroyed)
        
        self.dock_widget.show()

    def on_dock_widget_destroyed(self):
        """
        Slot que se activa cuando el panel es destruido por QGIS.
        Limpia la referencia interna para que el plugin sepa que el panel ya no existe.
        """
        self.dock_widget = None