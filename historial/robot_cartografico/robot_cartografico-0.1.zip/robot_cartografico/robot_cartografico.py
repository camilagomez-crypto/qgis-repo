import os
import json
import sqlite3
from pathlib import Path
from datetime import datetime

import processing
from qgis.PyQt.QtCore import QFileSystemWatcher, QObject, QTimer
from qgis.PyQt.QtWidgets import (
    QAction, QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QTextEdit, QDialogButtonBox, QCheckBox, QGroupBox, QGridLayout,
    QFrame, QPushButton
)
from qgis.PyQt.QtGui import QFont, QColor
from qgis.core import QgsProject, QgsVectorLayer

BASE = Path(os.environ["LOCALAPPDATA"]) / "RobotCartografico"

CREAR_TABLA = """
CREATE TABLE IF NOT EXISTS eventos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    sesion_id TEXT NOT NULL,
    app TEXT NOT NULL DEFAULT 'qgis',
    fuente TEXT NOT NULL,
    tipo_evento TEXT NOT NULL,
    objetivo TEXT,
    payload_json TEXT
);
"""
CREAR_INDICES = [
    "CREATE INDEX IF NOT EXISTS idx_eventos_sesion ON eventos(sesion_id)",
    "CREATE INDEX IF NOT EXISTS idx_eventos_tipo ON eventos(tipo_evento)",
]

CREAR_TABLA_CASOS = """
CREATE TABLE IF NOT EXISTS casos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    capa TEXT,
    fid INTEGER,
    problema TEXT,
    solucion TEXT,
    razon TEXT
);
"""

CREAR_TABLA_DECISIONES = """
CREATE TABLE IF NOT EXISTS decisiones (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp   TEXT    NOT NULL,
    sesion_id   TEXT    NOT NULL,
    municipio   TEXT,
    capa        TEXT    NOT NULL,
    fid         INTEGER NOT NULL,
    tipo_inc    TEXT    NOT NULL,
    valor_inc   TEXT,
    resolucion  TEXT    NOT NULL,
    fuente_sv   INTEGER DEFAULT 0,
    fuente_igac INTEGER DEFAULT 0,
    fuente_geo  INTEGER DEFAULT 0,
    fuente_otro TEXT,
    razon       TEXT
);
"""

# Campos que indican resolución de inconsistencia → campo de inconsistencia que leen
CAMPOS_RESOLUCION = {
    'r_inc_card':   'inc_card',
    'r_inc_dup':    'inc_dup',
    'r_inc_estd':   'inconsistencias',
    'r_inc_gnral':  'inconsistencias',
    'r_inc_mzcs':   'inconsiste',
    'r_inc_cptud':  'inconsistencias',
}


class DialogoCaso(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Registrar decisión")
        layout = QVBoxLayout(self)

        layout.addWidget(QLabel("¿Qué problema o situación era?"))
        self.campo_problema = QLineEdit()
        layout.addWidget(self.campo_problema)

        layout.addWidget(QLabel("¿Qué solución aplicaste?"))
        self.campo_solucion = QLineEdit()
        layout.addWidget(self.campo_solucion)

        layout.addWidget(QLabel("¿Por qué esa solución?"))
        self.campo_razon = QTextEdit()
        layout.addWidget(self.campo_razon)

        botones = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        botones.accepted.connect(self.accept)
        botones.rejected.connect(self.reject)
        layout.addWidget(botones)

    def datos(self):
        return self.campo_problema.text(), self.campo_solucion.text(), self.campo_razon.toPlainText()


class DialogoDecision(QDialog):
    """Panel contextual que aparece automaticamente al resolver una inconsistencia.
    Pre-llena todo lo que el robot ya conoce; solo pide fuente consultada y razon."""

    def __init__(self, capa, fid, municipio, tipo_inc, valor_inc, resolucion, parent=None):
        super().__init__(parent)
        self.setWindowTitle("¿Cómo resolviste esta inconsistencia?")
        self.setMinimumWidth(480)
        layout = QVBoxLayout(self)
        layout.setSpacing(10)

        # --- bloque informativo (lo que el robot ya sabe) -----------------
        info = QFrame()
        info.setFrameShape(QFrame.StyledPanel)
        info_layout = QGridLayout(info)
        info_layout.setSpacing(4)

        fuente_negrita = QFont()
        fuente_negrita.setBold(True)

        def fila(grid, row, etiqueta, valor):
            lbl = QLabel(etiqueta)
            lbl.setFont(fuente_negrita)
            grid.addWidget(lbl, row, 0)
            grid.addWidget(QLabel(str(valor) if valor else "—"), row, 1)

        fila(info_layout, 0, "Municipio:",   municipio or "—")
        fila(info_layout, 1, "Capa:",        capa)
        fila(info_layout, 2, "Feature ID:",  fid)
        fila(info_layout, 3, "Tipo inc.:",   tipo_inc)
        fila(info_layout, 4, "Descripción:", valor_inc or "—")
        fila(info_layout, 5, "Resolución:",  resolucion)
        layout.addWidget(info)

        # --- fuentes consultadas ------------------------------------------
        grp = QGroupBox("¿Qué fuentes consultaste?")
        grp_layout = QVBoxLayout(grp)

        self.chk_sv   = QCheckBox("Street View")
        self.chk_igac = QCheckBox("Geoportal IGAC")
        self.chk_geo  = QCheckBox("Geoportal del municipio")
        self.chk_otro = QCheckBox("Otra fuente:")
        self.txt_otro = QLineEdit()
        self.txt_otro.setPlaceholderText("Nombre o URL")
        self.txt_otro.setEnabled(False)
        self.chk_otro.toggled.connect(self.txt_otro.setEnabled)

        grp_layout.addWidget(self.chk_sv)
        grp_layout.addWidget(self.chk_igac)
        grp_layout.addWidget(self.chk_geo)

        fila_otro = QHBoxLayout()
        fila_otro.addWidget(self.chk_otro)
        fila_otro.addWidget(self.txt_otro)
        grp_layout.addLayout(fila_otro)
        layout.addWidget(grp)

        # --- razón --------------------------------------------------------
        layout.addWidget(QLabel("¿Por qué esa solución? (opcional)"))
        self.txt_razon = QTextEdit()
        self.txt_razon.setMaximumHeight(70)
        self.txt_razon.setPlaceholderText(
            "Ej: Street View confirma que la vía es CL 32, no KR 32"
        )
        layout.addWidget(self.txt_razon)

        # --- botones ------------------------------------------------------
        botones = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Discard)
        botones.button(QDialogButtonBox.Save).setText("Guardar decisión")
        botones.button(QDialogButtonBox.Discard).setText("Omitir")
        botones.accepted.connect(self.accept)
        botones.rejected.connect(self.reject)
        layout.addWidget(botones)

    def datos(self):
        return {
            'fuente_sv':   int(self.chk_sv.isChecked()),
            'fuente_igac': int(self.chk_igac.isChecked()),
            'fuente_geo':  int(self.chk_geo.isChecked()),
            'fuente_otro': self.txt_otro.text() if self.chk_otro.isChecked() else None,
            'razon':       self.txt_razon.toPlainText().strip() or None,
        }


class RobotCartografico(QObject):
    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self._activo = False
        self._acciones = []
        self._processing_run_original = None
        self._buffer_eventos = []          # acumula filas antes de hacer commit
        self._BUFFER_MAX = 20              # flush cada 20 eventos o cada 5 s

    # --- ciclo de vida del plugin -----------------------------------------

    def initGui(self):
        BASE.mkdir(parents=True, exist_ok=True)
        self.sesion_id = f"qgis_{datetime.now():%Y%m%d_%H%M%S}"
        self.ruta_estado = BASE / "estado.json"

        self.conexion_bd = sqlite3.connect(str(BASE / "conocimiento.db"))
        self.conexion_bd.execute("PRAGMA journal_mode=WAL")
        self.conexion_bd.execute(CREAR_TABLA)
        self.conexion_bd.execute(CREAR_TABLA_CASOS)
        self.conexion_bd.execute(CREAR_TABLA_DECISIONES)
        for indice in CREAR_INDICES:
            self.conexion_bd.execute(indice)
        self.conexion_bd.commit()

        # Timer para flush periodico del buffer (cada 5 segundos)
        self._timer_flush = QTimer(self)
        self._timer_flush.setInterval(5000)
        self._timer_flush.timeout.connect(self._flush_buffer)
        self._timer_flush.start()

        self.watcher = QFileSystemWatcher([str(self.ruta_estado)])
        self.watcher.fileChanged.connect(self._aplicar_estado)
        self._aplicar_estado()  # respeta lo que ya estaba guardado al abrir QGIS

        # Boton manual: siempre disponible, sin importar el estado del interruptor.
        self.accion_registrar_caso = QAction("Registrar decisión", self.iface.mainWindow())
        self.accion_registrar_caso.triggered.connect(self._registrar_caso)
        self.iface.addToolBarIcon(self.accion_registrar_caso)
        self.iface.addPluginToMenu("Robot Cartografico", self.accion_registrar_caso)

    def unload(self):
        self._timer_flush.stop()
        self._flush_buffer()   # vaciar lo que quede antes de cerrar
        if self._activo:
            self._desconectar_señales()
        self.iface.removeToolBarIcon(self.accion_registrar_caso)
        self.iface.removePluginMenu("Robot Cartografico", self.accion_registrar_caso)
        self.conexion_bd.close()

    # --- interruptor -------------------------------------------------------

    def _leer_estado(self):
        if self.ruta_estado.exists():
            return json.loads(self.ruta_estado.read_text())["estado"]
        return "apagado"

    def _aplicar_estado(self, _ruta=None):
        # QFileSystemWatcher puede "soltar" la ruta tras un reemplazo atomico
        # (el patron .tmp -> replace() de la bandeja); reagregarla es gratis
        # si ya la esta vigilando.
        self.watcher.addPath(str(self.ruta_estado))

        nuevo_estado = self._leer_estado()
        nuevo_activo = nuevo_estado != "apagado"

        if nuevo_activo and not self._activo:
            self._conectar_señales()
        elif not nuevo_activo and self._activo:
            self._desconectar_señales()

        self._activo = nuevo_activo
        self.estado_actual = nuevo_estado

    # --- conectar / desconectar ---------------------------------------------

    def _conectar_señales(self):
        proyecto = QgsProject.instance()
        proyecto.layersAdded.connect(self._on_capas_agregadas)
        proyecto.layersRemoved.connect(self._on_capas_eliminadas)

        for capa in proyecto.mapLayers().values():
            self._conectar_capa(capa)

        # Un solo listener para cualquier boton o menu de QGIS, en vez de
        # instrumentar cada accion por separado.
        self._acciones = self.iface.mainWindow().findChildren(QAction)
        for accion in self._acciones:
            accion.triggered.connect(self._on_accion_disparada)

        # Processing: se envuelve la funcion publica processing.run(). Esto
        # cubre con certeza los algoritmos corridos desde scripts o la
        # consola de Python. Si tambien cubre los que corres desde el panel
        # "Caja de herramientas" depende de tu version de QGIS -- pruebalo
        # corriendo uno desde ahi y revisando que aparezca en conocimiento.db
        # antes de confiar en que quedo cubierto.
        self._processing_run_original = processing.run
        processing.run = self._envolver_processing_run(self._processing_run_original)

    def _desconectar_señales(self):
        proyecto = QgsProject.instance()
        try:
            proyecto.layersAdded.disconnect(self._on_capas_agregadas)
        except (RuntimeError, TypeError):
            pass
        try:
            proyecto.layersRemoved.disconnect(self._on_capas_eliminadas)
        except (RuntimeError, TypeError):
            pass

        for capa in proyecto.mapLayers().values():
            self._desconectar_capa(capa)

        for accion in self._acciones:
            try:
                accion.triggered.disconnect(self._on_accion_disparada)
            except (RuntimeError, TypeError):
                pass
        self._acciones = []

        if self._processing_run_original is not None:
            processing.run = self._processing_run_original
            self._processing_run_original = None

    def _conectar_capa(self, capa):
        if not isinstance(capa, QgsVectorLayer):
            return
        capa.attributeValueChanged.connect(self._on_atributo_cambiado)
        capa.geometryChanged.connect(self._on_geometria_cambiada)

    def _desconectar_capa(self, capa):
        if not isinstance(capa, QgsVectorLayer):
            return
        try:
            capa.attributeValueChanged.disconnect(self._on_atributo_cambiado)
        except (RuntimeError, TypeError):
            pass
        try:
            capa.geometryChanged.disconnect(self._on_geometria_cambiada)
        except (RuntimeError, TypeError):
            pass

    # --- handlers ------------------------------------------------------------

    def _on_capas_agregadas(self, capas):
        for capa in capas:
            self._conectar_capa(capa)
            self._registrar_evento("proyecto", "capa_agregada", objetivo=capa.name())

    def _on_capas_eliminadas(self, ids_capas):
        for id_capa in ids_capas:
            # Desconectar explicitamente si la capa sigue viva en memoria.
            # Si ya fue destruida, Qt habra limpiado las conexiones solo,
            # pero _desconectar_capa lo maneja sin error gracias al try/except.
            capa = QgsProject.instance().mapLayer(id_capa)
            if capa:
                self._desconectar_capa(capa)
            self._registrar_evento("proyecto", "capa_removida", objetivo=id_capa)

    def _on_accion_disparada(self):
        accion = self.sender()
        self._registrar_evento("qaction", "accion_ejecutada", objetivo=accion.text())

    def _on_atributo_cambiado(self, fid, idx, valor):
        capa = self.sender()
        buffer = capa.editBuffer()
        cambios_fid = buffer.changedAttributeValues().get(fid, {}) if buffer else {}
        if idx not in cambios_fid:
            return  # no esta en tu buffer local -- viene de una sincronizacion remota
        campo = capa.fields().at(idx).name()
        self._registrar_evento(
            "atributo", "cambio_atributo", objetivo=capa.name(),
            payload={"campo": campo, "fid": fid, "valor_nuevo": valor},
        )

        # --- deteccion de resolucion de inconsistencia --------------------
        # Solo actua si el campo es un r_inc_* y el valor no es NULL/vacio
        if campo in CAMPOS_RESOLUCION and valor not in (None, '', 'NULL'):
            self._capturar_decision(capa, fid, campo, valor)

    def _on_geometria_cambiada(self, fid, _geometria):
        capa = self.sender()
        buffer = capa.editBuffer()
        if not buffer or fid not in buffer.changedGeometries():
            return  # no esta en tu buffer local -- viene de una sincronizacion remota
        self._registrar_evento(
            "geometria", "geometria_modificada", objetivo=capa.name(),
            payload={"fid": fid},
        )

    def _envolver_processing_run(self, original):
        def envoltura(algoritmo_id, parametros, *args, **kwargs):
            self._registrar_evento(
                "processing", "ejecutar_algoritmo", objetivo=algoritmo_id,
                payload={"parametros": {k: str(v) for k, v in parametros.items()}},
            )
            return original(algoritmo_id, parametros, *args, **kwargs)
        return envoltura

    # --- captura automatica de decisiones sobre inconsistencias -------------

    def _capturar_decision(self, capa, fid, campo_resolucion, resolucion):
        """Lanzado automaticamente cuando r_inc_* pasa de NULL a un valor.
        Lee el campo inc correspondiente de la misma feature para pre-llenar
        el dialogo con el contexto completo."""

        campo_inc = CAMPOS_RESOLUCION.get(campo_resolucion, '')
        valor_inc = None
        municipio = None

        feature = next(capa.getFeatures(f'$id = {fid}'), None)
        if feature:
            # leer el valor de la inconsistencia original
            if campo_inc and campo_inc in [f.name() for f in capa.fields()]:
                valor_inc = feature[campo_inc]
                if valor_inc in (None, 'NULL', ''):
                    valor_inc = None
            # leer municipio si existe el campo
            for nombre_mun in ('municipio', 'MUNICIPIO'):
                if nombre_mun in [f.name() for f in capa.fields()]:
                    municipio = feature[nombre_mun]
                    break

        dialogo = DialogoDecision(
            capa=capa.name(),
            fid=fid,
            municipio=municipio,
            tipo_inc=campo_resolucion,
            valor_inc=str(valor_inc) if valor_inc else None,
            resolucion=str(resolucion),
            parent=self.iface.mainWindow(),
        )

        if dialogo.exec_() != QDialog.Accepted:
            return  # eligio Omitir -- no se guarda nada

        datos = dialogo.datos()
        self.conexion_bd.execute(
            """INSERT INTO decisiones
               (timestamp, sesion_id, municipio, capa, fid,
                tipo_inc, valor_inc, resolucion,
                fuente_sv, fuente_igac, fuente_geo, fuente_otro, razon)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                datetime.now().isoformat(),
                self.sesion_id,
                municipio,
                capa.name(),
                fid,
                campo_resolucion,
                str(valor_inc) if valor_inc else None,
                str(resolucion),
                datos['fuente_sv'],
                datos['fuente_igac'],
                datos['fuente_geo'],
                datos['fuente_otro'],
                datos['razon'],
            ),
        )
        self.conexion_bd.commit()

    # --- registro manual de casos -----------------------------------------------

    def _registrar_caso(self):
        capa = self.iface.activeLayer()
        fid = None
        if capa and isinstance(capa, QgsVectorLayer):
            seleccion = capa.selectedFeatures()
            if seleccion:
                fid = seleccion[0].id()

        dialogo = DialogoCaso(self.iface.mainWindow())
        if dialogo.exec_() != QDialog.Accepted:
            return

        problema, solucion, razon = dialogo.datos()
        if not problema and not solucion and not razon:
            return  # no escribio nada, no guarda vacio

        self.conexion_bd.execute(
            "INSERT INTO casos (timestamp, capa, fid, problema, solucion, razon) VALUES (?, ?, ?, ?, ?, ?)",
            (datetime.now().isoformat(), capa.name() if capa else None, fid, problema, solucion, razon),
        )
        self.conexion_bd.commit()

    # --- almacenamiento --------------------------------------------------------

    def _registrar_evento(self, fuente, tipo_evento, objetivo=None, payload=None):
        self._buffer_eventos.append((
            datetime.now().isoformat(),
            self.sesion_id,
            fuente,
            tipo_evento,
            objetivo,
            json.dumps(payload) if payload else None,
        ))
        # Flush inmediato si se supera el tamaño maximo del buffer
        if len(self._buffer_eventos) >= self._BUFFER_MAX:
            self._flush_buffer()

    def _flush_buffer(self):
        if not self._buffer_eventos:
            return
        self.conexion_bd.executemany(
            "INSERT INTO eventos (timestamp, sesion_id, fuente, tipo_evento, objetivo, payload_json) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            self._buffer_eventos,
        )
        self.conexion_bd.commit()
        self._buffer_eventos.clear()