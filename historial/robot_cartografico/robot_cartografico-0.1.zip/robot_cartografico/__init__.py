def classFactory(iface):
    from .robot_cartografico import RobotCartografico
    return RobotCartografico(iface)
