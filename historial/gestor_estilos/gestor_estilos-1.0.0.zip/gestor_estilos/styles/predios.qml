<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis styleCategories="AllStyleCategories" version="3.34.11-Prizren" maxScale="0" simplifyLocal="1" simplifyMaxScale="1" simplifyDrawingHints="1" readOnly="0" hasScaleBasedVisibilityFlag="0" minScale="100000000" simplifyAlgorithm="0" simplifyDrawingTol="1" symbologyReferenceScale="-1" labelsEnabled="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal mode="0" enabled="0" startField="" limitMode="0" durationUnit="min" accumulate="0" durationField="id" fixedDuration="0" startExpression="" endExpression="" endField="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation extrusion="0" clamping="Terrain" symbology="Line" zoffset="0" extrusionEnabled="0" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0" binding="Centroid" zscale="1" type="IndividualFeatures">
    <data-defined-properties>
      <Option type="Map">
        <Option value="" name="name" type="QString"/>
        <Option name="properties"/>
        <Option value="collection" name="type" type="QString"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol frame_rate="10" alpha="1" is_animated="0" clip_to_extent="1" force_rhr="0" name="" type="line">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" id="{3318d683-bddd-4d2f-b980-29f423b0a177}" pass="0" locked="0" class="SimpleLine">
          <Option type="Map">
            <Option value="0" name="align_dash_pattern" type="QString"/>
            <Option value="square" name="capstyle" type="QString"/>
            <Option value="5;2" name="customdash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
            <Option value="MM" name="customdash_unit" type="QString"/>
            <Option value="0" name="dash_pattern_offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
            <Option value="0" name="draw_inside_polygon" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="225,89,137,255" name="line_color" type="QString"/>
            <Option value="solid" name="line_style" type="QString"/>
            <Option value="0.6" name="line_width" type="QString"/>
            <Option value="MM" name="line_width_unit" type="QString"/>
            <Option value="0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0" name="ring_filter" type="QString"/>
            <Option value="0" name="trim_distance_end" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_end_unit" type="QString"/>
            <Option value="0" name="trim_distance_start" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_start_unit" type="QString"/>
            <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
            <Option value="0" name="use_custom_dash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol frame_rate="10" alpha="1" is_animated="0" clip_to_extent="1" force_rhr="0" name="" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" id="{86a65b4e-aba6-49ab-ac1b-e565560a4671}" pass="0" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="225,89,137,255" name="color" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="161,64,98,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol frame_rate="10" alpha="1" is_animated="0" clip_to_extent="1" force_rhr="0" name="" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" id="{11265054-0b27-486a-b34a-0686434b142f}" pass="0" locked="0" class="SimpleMarker">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="225,89,137,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="diamond" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="161,64,98,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 forceraster="0" enableorderby="0" symbollevels="0" type="singleSymbol" referencescale="-1">
    <symbols>
      <symbol frame_rate="10" alpha="1" is_animated="0" clip_to_extent="1" force_rhr="0" name="0" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" id="{1748d58b-0e38-457f-bea7-407b16870a83}" pass="0" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="229,182,54,255" name="color" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="35,35,35,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.26" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="no" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol frame_rate="10" alpha="1" is_animated="0" clip_to_extent="1" force_rhr="0" name="" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" id="{5b7b123e-8eae-4ef8-a89e-cd6549a04e94}" pass="0" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="0,0,255,255" name="color" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="35,35,35,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.26" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <labeling type="rule-based">
    <rules key="{6ec0049c-bb4f-4b84-abbe-7e9810920ee7}">
      <rule key="{17286f58-d997-40c5-9db9-680b6ca2dbeb}">
        <settings calloutType="simple">
          <text-style fontStrikeout="0" isExpression="1" fontLetterSpacing="0" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" forcedItalic="0" textColor="50,50,50,255" multilineHeightUnit="Percentage" fontKerning="1" fieldName="&quot;via_princ&quot; +' '+ &quot;via_sec&quot; +' '+ &quot;placa&quot; + ' '+  &quot;compl&quot; " namedStyle="" fontWordSpacing="0" blendMode="0" fontItalic="0" allowHtml="0" fontFamily="Open Sans" previewBkgrdColor="255,255,255,255" useSubstitutions="0" fontUnderline="0" legendString="Aa" textOrientation="horizontal" fontSize="10" forcedBold="0" textOpacity="1" fontWeight="50" fontSizeUnit="Point" capitalization="0">
            <families/>
            <text-buffer bufferColor="250,250,250,255" bufferBlendMode="0" bufferOpacity="1" bufferJoinStyle="128" bufferSize="1" bufferNoFill="1" bufferDraw="0" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0"/>
            <text-mask maskSizeUnits="MM" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskJoinStyle="128" maskSize="1.5" maskType="0" maskOpacity="1" maskSize2="1.5" maskedSymbolLayers=""/>
            <background shapeType="0" shapeRotation="0" shapeBorderWidthUnit="Point" shapeBlendMode="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="Point" shapeJoinStyle="64" shapeBorderWidth="0" shapeOffsetX="0" shapeSVGFile="" shapeSizeUnit="Point" shapeOffsetY="0" shapeSizeType="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeOffsetUnit="Point" shapeDraw="0" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRotationType="0" shapeRadiiY="0" shapeSizeY="0" shapeFillColor="255,255,255,255" shapeRadiiX="0">
              <symbol frame_rate="10" alpha="1" is_animated="0" clip_to_extent="1" force_rhr="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option value="" name="name" type="QString"/>
                    <Option name="properties"/>
                    <Option value="collection" name="type" type="QString"/>
                  </Option>
                </data_defined_properties>
                <layer enabled="1" id="" pass="0" locked="0" class="SimpleMarker">
                  <Option type="Map">
                    <Option value="0" name="angle" type="QString"/>
                    <Option value="square" name="cap_style" type="QString"/>
                    <Option value="196,60,57,255" name="color" type="QString"/>
                    <Option value="1" name="horizontal_anchor_point" type="QString"/>
                    <Option value="bevel" name="joinstyle" type="QString"/>
                    <Option value="circle" name="name" type="QString"/>
                    <Option value="0,0" name="offset" type="QString"/>
                    <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                    <Option value="MM" name="offset_unit" type="QString"/>
                    <Option value="35,35,35,255" name="outline_color" type="QString"/>
                    <Option value="solid" name="outline_style" type="QString"/>
                    <Option value="0" name="outline_width" type="QString"/>
                    <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                    <Option value="MM" name="outline_width_unit" type="QString"/>
                    <Option value="diameter" name="scale_method" type="QString"/>
                    <Option value="2" name="size" type="QString"/>
                    <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                    <Option value="MM" name="size_unit" type="QString"/>
                    <Option value="1" name="vertical_anchor_point" type="QString"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol frame_rate="10" alpha="1" is_animated="0" clip_to_extent="1" force_rhr="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option value="" name="name" type="QString"/>
                    <Option name="properties"/>
                    <Option value="collection" name="type" type="QString"/>
                  </Option>
                </data_defined_properties>
                <layer enabled="1" id="" pass="0" locked="0" class="SimpleFill">
                  <Option type="Map">
                    <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                    <Option value="255,255,255,255" name="color" type="QString"/>
                    <Option value="bevel" name="joinstyle" type="QString"/>
                    <Option value="0,0" name="offset" type="QString"/>
                    <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                    <Option value="MM" name="offset_unit" type="QString"/>
                    <Option value="128,128,128,255" name="outline_color" type="QString"/>
                    <Option value="no" name="outline_style" type="QString"/>
                    <Option value="0" name="outline_width" type="QString"/>
                    <Option value="Point" name="outline_width_unit" type="QString"/>
                    <Option value="solid" name="style" type="QString"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowScale="100" shadowBlendMode="6" shadowRadiusAlphaOnly="0" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetUnit="MM" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowDraw="0" shadowRadius="1.5" shadowOpacity="0.69999999999999996"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format autoWrapLength="0" placeDirectionSymbol="0" reverseDirectionSymbol="0" decimals="3" addDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" rightDirectionSymbol=">" formatNumbers="0" plussign="0" wrapChar="" multilineAlign="3" leftDirectionSymbol="&lt;"/>
          <placement overrunDistance="0" distMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" rotationUnit="AngleDegrees" overrunDistanceUnit="MM" preserveRotation="1" geometryGeneratorType="PointGeometry" maxCurvedCharAngleIn="25" placementFlags="10" xOffset="0" dist="0" geometryGeneratorEnabled="0" fitInPolygonOnly="0" lineAnchorClipping="0" geometryGenerator="" centroidWhole="0" layerType="PolygonGeometry" repeatDistance="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placement="0" centroidInside="0" repeatDistanceUnits="MM" lineAnchorTextPoint="FollowPlacement" offsetUnits="MM" polygonPlacementFlags="2" lineAnchorPercent="0.5" rotationAngle="0" overlapHandling="PreventOverlap" priority="5" offsetType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" lineAnchorType="0" yOffset="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" quadOffset="4" maxCurvedCharAngleOut="-25"/>
          <rendering zIndex="0" scaleVisibility="0" fontMinPixelSize="3" limitNumLabels="0" scaleMax="0" obstacleFactor="1" minFeatureSize="0" upsidedownLabels="0" unplacedVisibility="0" obstacle="1" obstacleType="1" labelPerPart="0" maxNumLabels="2000" fontLimitPixelSize="0" fontMaxPixelSize="10000" scaleMin="0" drawLabels="1" mergeLines="0"/>
          <dd_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
              <Option value="0" name="blendMode" type="int"/>
              <Option name="ddProperties" type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
              <Option value="false" name="drawToAllParts" type="bool"/>
              <Option value="0" name="enabled" type="QString"/>
              <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
              <Option value="&lt;symbol frame_rate=&quot;10&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; id=&quot;{1b154f6f-acb1-4712-8cc9-a8e11de1c5aa}&quot; pass=&quot;0&quot; locked=&quot;0&quot; class=&quot;SimpleLine&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
              <Option value="0" name="minLength" type="double"/>
              <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
              <Option value="MM" name="minLengthUnit" type="QString"/>
              <Option value="0" name="offsetFromAnchor" type="double"/>
              <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
              <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
              <Option value="0" name="offsetFromLabel" type="double"/>
              <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
              <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule key="{1f803b91-3999-4b58-956b-e587ef1553b8}">
        <settings calloutType="simple">
          <text-style fontStrikeout="0" isExpression="0" fontLetterSpacing="0" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" forcedItalic="0" textColor="50,50,255,255" multilineHeightUnit="Percentage" fontKerning="1" fieldName="direccion2" namedStyle="" fontWordSpacing="0" blendMode="0" fontItalic="0" allowHtml="0" fontFamily="Open Sans" previewBkgrdColor="255,255,255,255" useSubstitutions="0" fontUnderline="0" legendString="Aa" textOrientation="horizontal" fontSize="10" forcedBold="0" textOpacity="1" fontWeight="50" fontSizeUnit="Point" capitalization="0">
            <families/>
            <text-buffer bufferColor="250,250,250,255" bufferBlendMode="0" bufferOpacity="1" bufferJoinStyle="128" bufferSize="1" bufferNoFill="1" bufferDraw="0" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0"/>
            <text-mask maskSizeUnits="MM" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskJoinStyle="128" maskSize="1.5" maskType="0" maskOpacity="1" maskSize2="1.5" maskedSymbolLayers=""/>
            <background shapeType="0" shapeRotation="0" shapeBorderWidthUnit="Point" shapeBlendMode="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="Point" shapeJoinStyle="64" shapeBorderWidth="0" shapeOffsetX="0" shapeSVGFile="" shapeSizeUnit="Point" shapeOffsetY="0" shapeSizeType="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeOffsetUnit="Point" shapeDraw="0" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRotationType="0" shapeRadiiY="0" shapeSizeY="0" shapeFillColor="255,255,255,255" shapeRadiiX="0">
              <symbol frame_rate="10" alpha="1" is_animated="0" clip_to_extent="1" force_rhr="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option value="" name="name" type="QString"/>
                    <Option name="properties"/>
                    <Option value="collection" name="type" type="QString"/>
                  </Option>
                </data_defined_properties>
                <layer enabled="1" id="" pass="0" locked="0" class="SimpleMarker">
                  <Option type="Map">
                    <Option value="0" name="angle" type="QString"/>
                    <Option value="square" name="cap_style" type="QString"/>
                    <Option value="190,178,151,255" name="color" type="QString"/>
                    <Option value="1" name="horizontal_anchor_point" type="QString"/>
                    <Option value="bevel" name="joinstyle" type="QString"/>
                    <Option value="circle" name="name" type="QString"/>
                    <Option value="0,0" name="offset" type="QString"/>
                    <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                    <Option value="MM" name="offset_unit" type="QString"/>
                    <Option value="35,35,35,255" name="outline_color" type="QString"/>
                    <Option value="solid" name="outline_style" type="QString"/>
                    <Option value="0" name="outline_width" type="QString"/>
                    <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                    <Option value="MM" name="outline_width_unit" type="QString"/>
                    <Option value="diameter" name="scale_method" type="QString"/>
                    <Option value="2" name="size" type="QString"/>
                    <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                    <Option value="MM" name="size_unit" type="QString"/>
                    <Option value="1" name="vertical_anchor_point" type="QString"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol frame_rate="10" alpha="1" is_animated="0" clip_to_extent="1" force_rhr="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option value="" name="name" type="QString"/>
                    <Option name="properties"/>
                    <Option value="collection" name="type" type="QString"/>
                  </Option>
                </data_defined_properties>
                <layer enabled="1" id="" pass="0" locked="0" class="SimpleFill">
                  <Option type="Map">
                    <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                    <Option value="255,255,255,255" name="color" type="QString"/>
                    <Option value="bevel" name="joinstyle" type="QString"/>
                    <Option value="0,0" name="offset" type="QString"/>
                    <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                    <Option value="MM" name="offset_unit" type="QString"/>
                    <Option value="128,128,128,255" name="outline_color" type="QString"/>
                    <Option value="no" name="outline_style" type="QString"/>
                    <Option value="0" name="outline_width" type="QString"/>
                    <Option value="Point" name="outline_width_unit" type="QString"/>
                    <Option value="solid" name="style" type="QString"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowScale="100" shadowBlendMode="6" shadowRadiusAlphaOnly="0" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetUnit="MM" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowDraw="0" shadowRadius="1.5" shadowOpacity="0.69999999999999996"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format autoWrapLength="0" placeDirectionSymbol="0" reverseDirectionSymbol="0" decimals="3" addDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" rightDirectionSymbol=">" formatNumbers="0" plussign="0" wrapChar="" multilineAlign="3" leftDirectionSymbol="&lt;"/>
          <placement overrunDistance="0" distMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" rotationUnit="AngleDegrees" overrunDistanceUnit="MM" preserveRotation="1" geometryGeneratorType="PointGeometry" maxCurvedCharAngleIn="25" placementFlags="10" xOffset="0" dist="0" geometryGeneratorEnabled="0" fitInPolygonOnly="0" lineAnchorClipping="0" geometryGenerator="" centroidWhole="0" layerType="PolygonGeometry" repeatDistance="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placement="0" centroidInside="0" repeatDistanceUnits="MM" lineAnchorTextPoint="FollowPlacement" offsetUnits="MM" polygonPlacementFlags="2" lineAnchorPercent="0.5" rotationAngle="0" overlapHandling="PreventOverlap" priority="5" offsetType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" lineAnchorType="0" yOffset="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" quadOffset="4" maxCurvedCharAngleOut="-25"/>
          <rendering zIndex="0" scaleVisibility="0" fontMinPixelSize="3" limitNumLabels="0" scaleMax="0" obstacleFactor="1" minFeatureSize="0" upsidedownLabels="0" unplacedVisibility="0" obstacle="1" obstacleType="1" labelPerPart="0" maxNumLabels="2000" fontLimitPixelSize="0" fontMaxPixelSize="10000" scaleMin="0" drawLabels="1" mergeLines="0"/>
          <dd_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
              <Option value="0" name="blendMode" type="int"/>
              <Option name="ddProperties" type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
              <Option value="false" name="drawToAllParts" type="bool"/>
              <Option value="0" name="enabled" type="QString"/>
              <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
              <Option value="&lt;symbol frame_rate=&quot;10&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; id=&quot;{556cc053-fe3f-4de8-89f4-014d93898ef2}&quot; pass=&quot;0&quot; locked=&quot;0&quot; class=&quot;SimpleLine&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
              <Option value="0" name="minLength" type="double"/>
              <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
              <Option value="MM" name="minLengthUnit" type="QString"/>
              <Option value="0" name="offsetFromAnchor" type="double"/>
              <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
              <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
              <Option value="0" name="offsetFromLabel" type="double"/>
              <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
              <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
            </Option>
          </callout>
        </settings>
      </rule>
    </rules>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option value="0" name="embeddedWidgets/count" type="int"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer attributeLegend="1" diagramType="Histogram">
    <DiagramCategory spacing="5" enabled="0" lineSizeScale="3x:0,0,0,0,0,0" maxScaleDenominator="1e+08" direction="0" penWidth="0" height="15" sizeScale="3x:0,0,0,0,0,0" labelPlacementMethod="XHeight" scaleDependency="Area" backgroundColor="#ffffff" sizeType="MM" minimumSize="0" spacingUnit="MM" diagramOrientation="Up" rotationOffset="270" opacity="1" lineSizeType="MM" spacingUnitScale="3x:0,0,0,0,0,0" penAlpha="255" backgroundAlpha="255" width="15" penColor="#000000" scaleBasedVisibility="0" minScaleDenominator="0" barWidth="5" showAxis="1">
      <fontProperties underline="0" strikethrough="0" style="" italic="0" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" bold="0"/>
      <axisSymbol>
        <symbol frame_rate="10" alpha="1" is_animated="0" clip_to_extent="1" force_rhr="0" name="" type="line">
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
          <layer enabled="1" id="{66215d47-8831-45cb-bfe3-a29d8a30170e}" pass="0" locked="0" class="SimpleLine">
            <Option type="Map">
              <Option value="0" name="align_dash_pattern" type="QString"/>
              <Option value="square" name="capstyle" type="QString"/>
              <Option value="5;2" name="customdash" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
              <Option value="MM" name="customdash_unit" type="QString"/>
              <Option value="0" name="dash_pattern_offset" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
              <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
              <Option value="0" name="draw_inside_polygon" type="QString"/>
              <Option value="bevel" name="joinstyle" type="QString"/>
              <Option value="35,35,35,255" name="line_color" type="QString"/>
              <Option value="solid" name="line_style" type="QString"/>
              <Option value="0.26" name="line_width" type="QString"/>
              <Option value="MM" name="line_width_unit" type="QString"/>
              <Option value="0" name="offset" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
              <Option value="MM" name="offset_unit" type="QString"/>
              <Option value="0" name="ring_filter" type="QString"/>
              <Option value="0" name="trim_distance_end" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
              <Option value="MM" name="trim_distance_end_unit" type="QString"/>
              <Option value="0" name="trim_distance_start" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
              <Option value="MM" name="trim_distance_start_unit" type="QString"/>
              <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
              <Option value="0" name="use_custom_dash" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings showAll="1" obstacle="0" priority="0" dist="0" zIndex="0" placement="1" linePlacementFlags="18">
    <properties>
      <Option type="Map">
        <Option value="" name="name" type="QString"/>
        <Option name="properties"/>
        <Option value="collection" name="type" type="QString"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration type="Map">
      <Option name="QgsGeometryGapCheck" type="Map">
        <Option value="0" name="allowedGapsBuffer" type="double"/>
        <Option value="false" name="allowedGapsEnabled" type="bool"/>
        <Option value="" name="allowedGapsLayer" type="QString"/>
      </Option>
    </checkConfiguration>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="id">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="id_capa">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="dane">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="municipio">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="direccion">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="nse">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="observacio">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="uh">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="codpred">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="codman">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="para_proce">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="id_unico">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="codv2_2021">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="dirorigina">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="direccion1">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="dirmzcasa">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="nivsocio1">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="marca_actu">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="fecha">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="version">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="municipio1">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="igac">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="manzana_co">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="igacanteri">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ciudad">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="cod_mun1">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="dir1">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="dir2">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="via_princ">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="via_sec">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="placa">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="compl">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="direccion_final">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="direccion2">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="dir_antigua">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="tipo_direccion">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="tipo_predio">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="tipo_costado">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="inconsistencias_gen">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="inconsistencias_est">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="inconsistencias_vec">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="inconsistencias_dup">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="duplicados">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="val_mavvial_princ">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="val_mavvial_sec">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="resultado_est">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="resultado_dup">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="asignacion_est">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="asignacion_dup">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="fecha_rev_est">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="fecha_rev_dup">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="observaciones">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="cx">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="cy">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="asignacion_val_mavvial">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="resultado_val_mavvial">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="fecha_val_mavvial">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="asignacion_vec">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="resultado_vec">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="fecha_vec">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="asignacion_par_impar">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="resultado_par_impar">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="fecha_par_impar">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="asignacion_mavvial_sec">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="resultado_mavvial_sec">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="fecha_val_mavvial_sec">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="osp_dir">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="Marca">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="Fecha">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="Version">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="obs_cod">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="codpred_2023">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" index="0" field="id"/>
    <alias name="" index="1" field="id_capa"/>
    <alias name="" index="2" field="dane"/>
    <alias name="" index="3" field="municipio"/>
    <alias name="" index="4" field="direccion"/>
    <alias name="" index="5" field="nse"/>
    <alias name="" index="6" field="observacio"/>
    <alias name="" index="7" field="uh"/>
    <alias name="" index="8" field="codpred"/>
    <alias name="" index="9" field="codman"/>
    <alias name="" index="10" field="para_proce"/>
    <alias name="" index="11" field="id_unico"/>
    <alias name="" index="12" field="codv2_2021"/>
    <alias name="" index="13" field="dirorigina"/>
    <alias name="" index="14" field="direccion1"/>
    <alias name="" index="15" field="dirmzcasa"/>
    <alias name="" index="16" field="nivsocio1"/>
    <alias name="" index="17" field="marca_actu"/>
    <alias name="" index="18" field="fecha"/>
    <alias name="" index="19" field="version"/>
    <alias name="" index="20" field="municipio1"/>
    <alias name="" index="21" field="igac"/>
    <alias name="" index="22" field="manzana_co"/>
    <alias name="" index="23" field="igacanteri"/>
    <alias name="" index="24" field="ciudad"/>
    <alias name="" index="25" field="cod_mun1"/>
    <alias name="" index="26" field="dir1"/>
    <alias name="" index="27" field="dir2"/>
    <alias name="" index="28" field="via_princ"/>
    <alias name="" index="29" field="via_sec"/>
    <alias name="" index="30" field="placa"/>
    <alias name="" index="31" field="compl"/>
    <alias name="" index="32" field="direccion_final"/>
    <alias name="" index="33" field="direccion2"/>
    <alias name="" index="34" field="dir_antigua"/>
    <alias name="" index="35" field="tipo_direccion"/>
    <alias name="" index="36" field="tipo_predio"/>
    <alias name="" index="37" field="tipo_costado"/>
    <alias name="" index="38" field="inconsistencias_gen"/>
    <alias name="" index="39" field="inconsistencias_est"/>
    <alias name="" index="40" field="inconsistencias_vec"/>
    <alias name="" index="41" field="inconsistencias_dup"/>
    <alias name="" index="42" field="duplicados"/>
    <alias name="" index="43" field="val_mavvial_princ"/>
    <alias name="" index="44" field="val_mavvial_sec"/>
    <alias name="" index="45" field="resultado_est"/>
    <alias name="" index="46" field="resultado_dup"/>
    <alias name="" index="47" field="asignacion_est"/>
    <alias name="" index="48" field="asignacion_dup"/>
    <alias name="" index="49" field="fecha_rev_est"/>
    <alias name="" index="50" field="fecha_rev_dup"/>
    <alias name="" index="51" field="observaciones"/>
    <alias name="" index="52" field="cx"/>
    <alias name="" index="53" field="cy"/>
    <alias name="" index="54" field="asignacion_val_mavvial"/>
    <alias name="" index="55" field="resultado_val_mavvial"/>
    <alias name="" index="56" field="fecha_val_mavvial"/>
    <alias name="" index="57" field="asignacion_vec"/>
    <alias name="" index="58" field="resultado_vec"/>
    <alias name="" index="59" field="fecha_vec"/>
    <alias name="" index="60" field="asignacion_par_impar"/>
    <alias name="" index="61" field="resultado_par_impar"/>
    <alias name="" index="62" field="fecha_par_impar"/>
    <alias name="" index="63" field="asignacion_mavvial_sec"/>
    <alias name="" index="64" field="resultado_mavvial_sec"/>
    <alias name="" index="65" field="fecha_val_mavvial_sec"/>
    <alias name="" index="66" field="osp_dir"/>
    <alias name="" index="67" field="Marca"/>
    <alias name="" index="68" field="Fecha"/>
    <alias name="" index="69" field="Version"/>
    <alias name="" index="70" field="obs_cod"/>
    <alias name="" index="71" field="codpred_2023"/>
  </aliases>
  <splitPolicies>
    <policy field="id" policy="Duplicate"/>
    <policy field="id_capa" policy="Duplicate"/>
    <policy field="dane" policy="Duplicate"/>
    <policy field="municipio" policy="Duplicate"/>
    <policy field="direccion" policy="Duplicate"/>
    <policy field="nse" policy="Duplicate"/>
    <policy field="observacio" policy="Duplicate"/>
    <policy field="uh" policy="Duplicate"/>
    <policy field="codpred" policy="Duplicate"/>
    <policy field="codman" policy="Duplicate"/>
    <policy field="para_proce" policy="Duplicate"/>
    <policy field="id_unico" policy="Duplicate"/>
    <policy field="codv2_2021" policy="Duplicate"/>
    <policy field="dirorigina" policy="Duplicate"/>
    <policy field="direccion1" policy="Duplicate"/>
    <policy field="dirmzcasa" policy="Duplicate"/>
    <policy field="nivsocio1" policy="Duplicate"/>
    <policy field="marca_actu" policy="Duplicate"/>
    <policy field="fecha" policy="Duplicate"/>
    <policy field="version" policy="Duplicate"/>
    <policy field="municipio1" policy="Duplicate"/>
    <policy field="igac" policy="Duplicate"/>
    <policy field="manzana_co" policy="Duplicate"/>
    <policy field="igacanteri" policy="Duplicate"/>
    <policy field="ciudad" policy="Duplicate"/>
    <policy field="cod_mun1" policy="Duplicate"/>
    <policy field="dir1" policy="Duplicate"/>
    <policy field="dir2" policy="Duplicate"/>
    <policy field="via_princ" policy="Duplicate"/>
    <policy field="via_sec" policy="Duplicate"/>
    <policy field="placa" policy="Duplicate"/>
    <policy field="compl" policy="Duplicate"/>
    <policy field="direccion_final" policy="Duplicate"/>
    <policy field="direccion2" policy="Duplicate"/>
    <policy field="dir_antigua" policy="Duplicate"/>
    <policy field="tipo_direccion" policy="Duplicate"/>
    <policy field="tipo_predio" policy="Duplicate"/>
    <policy field="tipo_costado" policy="Duplicate"/>
    <policy field="inconsistencias_gen" policy="Duplicate"/>
    <policy field="inconsistencias_est" policy="Duplicate"/>
    <policy field="inconsistencias_vec" policy="Duplicate"/>
    <policy field="inconsistencias_dup" policy="Duplicate"/>
    <policy field="duplicados" policy="Duplicate"/>
    <policy field="val_mavvial_princ" policy="Duplicate"/>
    <policy field="val_mavvial_sec" policy="Duplicate"/>
    <policy field="resultado_est" policy="Duplicate"/>
    <policy field="resultado_dup" policy="Duplicate"/>
    <policy field="asignacion_est" policy="Duplicate"/>
    <policy field="asignacion_dup" policy="Duplicate"/>
    <policy field="fecha_rev_est" policy="Duplicate"/>
    <policy field="fecha_rev_dup" policy="Duplicate"/>
    <policy field="observaciones" policy="Duplicate"/>
    <policy field="cx" policy="Duplicate"/>
    <policy field="cy" policy="Duplicate"/>
    <policy field="asignacion_val_mavvial" policy="Duplicate"/>
    <policy field="resultado_val_mavvial" policy="Duplicate"/>
    <policy field="fecha_val_mavvial" policy="Duplicate"/>
    <policy field="asignacion_vec" policy="Duplicate"/>
    <policy field="resultado_vec" policy="Duplicate"/>
    <policy field="fecha_vec" policy="Duplicate"/>
    <policy field="asignacion_par_impar" policy="Duplicate"/>
    <policy field="resultado_par_impar" policy="Duplicate"/>
    <policy field="fecha_par_impar" policy="Duplicate"/>
    <policy field="asignacion_mavvial_sec" policy="Duplicate"/>
    <policy field="resultado_mavvial_sec" policy="Duplicate"/>
    <policy field="fecha_val_mavvial_sec" policy="Duplicate"/>
    <policy field="osp_dir" policy="Duplicate"/>
    <policy field="Marca" policy="Duplicate"/>
    <policy field="Fecha" policy="Duplicate"/>
    <policy field="Version" policy="Duplicate"/>
    <policy field="obs_cod" policy="Duplicate"/>
    <policy field="codpred_2023" policy="Duplicate"/>
  </splitPolicies>
  <defaults>
    <default expression="" applyOnUpdate="0" field="id"/>
    <default expression="" applyOnUpdate="0" field="id_capa"/>
    <default expression="" applyOnUpdate="0" field="dane"/>
    <default expression="" applyOnUpdate="0" field="municipio"/>
    <default expression="" applyOnUpdate="0" field="direccion"/>
    <default expression="" applyOnUpdate="0" field="nse"/>
    <default expression="" applyOnUpdate="0" field="observacio"/>
    <default expression="" applyOnUpdate="0" field="uh"/>
    <default expression="" applyOnUpdate="0" field="codpred"/>
    <default expression="" applyOnUpdate="0" field="codman"/>
    <default expression="" applyOnUpdate="0" field="para_proce"/>
    <default expression="" applyOnUpdate="0" field="id_unico"/>
    <default expression="" applyOnUpdate="0" field="codv2_2021"/>
    <default expression="" applyOnUpdate="0" field="dirorigina"/>
    <default expression="" applyOnUpdate="0" field="direccion1"/>
    <default expression="" applyOnUpdate="0" field="dirmzcasa"/>
    <default expression="" applyOnUpdate="0" field="nivsocio1"/>
    <default expression="" applyOnUpdate="0" field="marca_actu"/>
    <default expression="" applyOnUpdate="0" field="fecha"/>
    <default expression="" applyOnUpdate="0" field="version"/>
    <default expression="" applyOnUpdate="0" field="municipio1"/>
    <default expression="" applyOnUpdate="0" field="igac"/>
    <default expression="" applyOnUpdate="0" field="manzana_co"/>
    <default expression="" applyOnUpdate="0" field="igacanteri"/>
    <default expression="" applyOnUpdate="0" field="ciudad"/>
    <default expression="" applyOnUpdate="0" field="cod_mun1"/>
    <default expression="" applyOnUpdate="0" field="dir1"/>
    <default expression="" applyOnUpdate="0" field="dir2"/>
    <default expression="" applyOnUpdate="0" field="via_princ"/>
    <default expression="" applyOnUpdate="0" field="via_sec"/>
    <default expression="" applyOnUpdate="0" field="placa"/>
    <default expression="" applyOnUpdate="0" field="compl"/>
    <default expression="" applyOnUpdate="0" field="direccion_final"/>
    <default expression="" applyOnUpdate="0" field="direccion2"/>
    <default expression="" applyOnUpdate="0" field="dir_antigua"/>
    <default expression="" applyOnUpdate="0" field="tipo_direccion"/>
    <default expression="" applyOnUpdate="0" field="tipo_predio"/>
    <default expression="" applyOnUpdate="0" field="tipo_costado"/>
    <default expression="" applyOnUpdate="0" field="inconsistencias_gen"/>
    <default expression="" applyOnUpdate="0" field="inconsistencias_est"/>
    <default expression="" applyOnUpdate="0" field="inconsistencias_vec"/>
    <default expression="" applyOnUpdate="0" field="inconsistencias_dup"/>
    <default expression="" applyOnUpdate="0" field="duplicados"/>
    <default expression="" applyOnUpdate="0" field="val_mavvial_princ"/>
    <default expression="" applyOnUpdate="0" field="val_mavvial_sec"/>
    <default expression="" applyOnUpdate="0" field="resultado_est"/>
    <default expression="" applyOnUpdate="0" field="resultado_dup"/>
    <default expression="" applyOnUpdate="0" field="asignacion_est"/>
    <default expression="" applyOnUpdate="0" field="asignacion_dup"/>
    <default expression="" applyOnUpdate="0" field="fecha_rev_est"/>
    <default expression="" applyOnUpdate="0" field="fecha_rev_dup"/>
    <default expression="" applyOnUpdate="0" field="observaciones"/>
    <default expression="" applyOnUpdate="0" field="cx"/>
    <default expression="" applyOnUpdate="0" field="cy"/>
    <default expression="" applyOnUpdate="0" field="asignacion_val_mavvial"/>
    <default expression="" applyOnUpdate="0" field="resultado_val_mavvial"/>
    <default expression="" applyOnUpdate="0" field="fecha_val_mavvial"/>
    <default expression="" applyOnUpdate="0" field="asignacion_vec"/>
    <default expression="" applyOnUpdate="0" field="resultado_vec"/>
    <default expression="" applyOnUpdate="0" field="fecha_vec"/>
    <default expression="" applyOnUpdate="0" field="asignacion_par_impar"/>
    <default expression="" applyOnUpdate="0" field="resultado_par_impar"/>
    <default expression="" applyOnUpdate="0" field="fecha_par_impar"/>
    <default expression="" applyOnUpdate="0" field="asignacion_mavvial_sec"/>
    <default expression="" applyOnUpdate="0" field="resultado_mavvial_sec"/>
    <default expression="" applyOnUpdate="0" field="fecha_val_mavvial_sec"/>
    <default expression="" applyOnUpdate="0" field="osp_dir"/>
    <default expression="" applyOnUpdate="0" field="Marca"/>
    <default expression="" applyOnUpdate="0" field="Fecha"/>
    <default expression="" applyOnUpdate="0" field="Version"/>
    <default expression="" applyOnUpdate="0" field="obs_cod"/>
    <default expression="" applyOnUpdate="0" field="codpred_2023"/>
  </defaults>
  <constraints>
    <constraint unique_strength="1" exp_strength="0" constraints="3" field="id" notnull_strength="1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="id_capa" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="dane" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="municipio" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="direccion" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="nse" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="observacio" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="uh" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="codpred" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="codman" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="para_proce" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="id_unico" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="codv2_2021" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="dirorigina" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="direccion1" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="dirmzcasa" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="nivsocio1" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="marca_actu" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="fecha" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="version" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="municipio1" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="igac" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="manzana_co" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="igacanteri" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="ciudad" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="cod_mun1" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="dir1" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="dir2" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="via_princ" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="via_sec" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="placa" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="compl" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="direccion_final" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="direccion2" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="dir_antigua" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="tipo_direccion" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="tipo_predio" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="tipo_costado" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="inconsistencias_gen" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="inconsistencias_est" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="inconsistencias_vec" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="inconsistencias_dup" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="duplicados" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="val_mavvial_princ" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="val_mavvial_sec" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="resultado_est" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="resultado_dup" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="asignacion_est" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="asignacion_dup" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="fecha_rev_est" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="fecha_rev_dup" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="observaciones" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="cx" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="cy" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="asignacion_val_mavvial" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="resultado_val_mavvial" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="fecha_val_mavvial" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="asignacion_vec" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="resultado_vec" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="fecha_vec" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="asignacion_par_impar" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="resultado_par_impar" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="fecha_par_impar" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="asignacion_mavvial_sec" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="resultado_mavvial_sec" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="fecha_val_mavvial_sec" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="osp_dir" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="Marca" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="Fecha" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="Version" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="obs_cod" notnull_strength="0"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" field="codpred_2023" notnull_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" exp="" field="id"/>
    <constraint desc="" exp="" field="id_capa"/>
    <constraint desc="" exp="" field="dane"/>
    <constraint desc="" exp="" field="municipio"/>
    <constraint desc="" exp="" field="direccion"/>
    <constraint desc="" exp="" field="nse"/>
    <constraint desc="" exp="" field="observacio"/>
    <constraint desc="" exp="" field="uh"/>
    <constraint desc="" exp="" field="codpred"/>
    <constraint desc="" exp="" field="codman"/>
    <constraint desc="" exp="" field="para_proce"/>
    <constraint desc="" exp="" field="id_unico"/>
    <constraint desc="" exp="" field="codv2_2021"/>
    <constraint desc="" exp="" field="dirorigina"/>
    <constraint desc="" exp="" field="direccion1"/>
    <constraint desc="" exp="" field="dirmzcasa"/>
    <constraint desc="" exp="" field="nivsocio1"/>
    <constraint desc="" exp="" field="marca_actu"/>
    <constraint desc="" exp="" field="fecha"/>
    <constraint desc="" exp="" field="version"/>
    <constraint desc="" exp="" field="municipio1"/>
    <constraint desc="" exp="" field="igac"/>
    <constraint desc="" exp="" field="manzana_co"/>
    <constraint desc="" exp="" field="igacanteri"/>
    <constraint desc="" exp="" field="ciudad"/>
    <constraint desc="" exp="" field="cod_mun1"/>
    <constraint desc="" exp="" field="dir1"/>
    <constraint desc="" exp="" field="dir2"/>
    <constraint desc="" exp="" field="via_princ"/>
    <constraint desc="" exp="" field="via_sec"/>
    <constraint desc="" exp="" field="placa"/>
    <constraint desc="" exp="" field="compl"/>
    <constraint desc="" exp="" field="direccion_final"/>
    <constraint desc="" exp="" field="direccion2"/>
    <constraint desc="" exp="" field="dir_antigua"/>
    <constraint desc="" exp="" field="tipo_direccion"/>
    <constraint desc="" exp="" field="tipo_predio"/>
    <constraint desc="" exp="" field="tipo_costado"/>
    <constraint desc="" exp="" field="inconsistencias_gen"/>
    <constraint desc="" exp="" field="inconsistencias_est"/>
    <constraint desc="" exp="" field="inconsistencias_vec"/>
    <constraint desc="" exp="" field="inconsistencias_dup"/>
    <constraint desc="" exp="" field="duplicados"/>
    <constraint desc="" exp="" field="val_mavvial_princ"/>
    <constraint desc="" exp="" field="val_mavvial_sec"/>
    <constraint desc="" exp="" field="resultado_est"/>
    <constraint desc="" exp="" field="resultado_dup"/>
    <constraint desc="" exp="" field="asignacion_est"/>
    <constraint desc="" exp="" field="asignacion_dup"/>
    <constraint desc="" exp="" field="fecha_rev_est"/>
    <constraint desc="" exp="" field="fecha_rev_dup"/>
    <constraint desc="" exp="" field="observaciones"/>
    <constraint desc="" exp="" field="cx"/>
    <constraint desc="" exp="" field="cy"/>
    <constraint desc="" exp="" field="asignacion_val_mavvial"/>
    <constraint desc="" exp="" field="resultado_val_mavvial"/>
    <constraint desc="" exp="" field="fecha_val_mavvial"/>
    <constraint desc="" exp="" field="asignacion_vec"/>
    <constraint desc="" exp="" field="resultado_vec"/>
    <constraint desc="" exp="" field="fecha_vec"/>
    <constraint desc="" exp="" field="asignacion_par_impar"/>
    <constraint desc="" exp="" field="resultado_par_impar"/>
    <constraint desc="" exp="" field="fecha_par_impar"/>
    <constraint desc="" exp="" field="asignacion_mavvial_sec"/>
    <constraint desc="" exp="" field="resultado_mavvial_sec"/>
    <constraint desc="" exp="" field="fecha_val_mavvial_sec"/>
    <constraint desc="" exp="" field="osp_dir"/>
    <constraint desc="" exp="" field="Marca"/>
    <constraint desc="" exp="" field="Fecha"/>
    <constraint desc="" exp="" field="Version"/>
    <constraint desc="" exp="" field="obs_cod"/>
    <constraint desc="" exp="" field="codpred_2023"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="" sortOrder="0">
    <columns>
      <column name="id" hidden="0" width="-1" type="field"/>
      <column name="id_capa" hidden="0" width="-1" type="field"/>
      <column name="dane" hidden="0" width="-1" type="field"/>
      <column name="municipio" hidden="0" width="-1" type="field"/>
      <column name="direccion" hidden="0" width="-1" type="field"/>
      <column name="nse" hidden="0" width="-1" type="field"/>
      <column name="observacio" hidden="0" width="-1" type="field"/>
      <column name="uh" hidden="0" width="-1" type="field"/>
      <column name="codpred" hidden="0" width="-1" type="field"/>
      <column name="codman" hidden="0" width="-1" type="field"/>
      <column name="para_proce" hidden="0" width="-1" type="field"/>
      <column name="id_unico" hidden="0" width="-1" type="field"/>
      <column name="codv2_2021" hidden="0" width="-1" type="field"/>
      <column name="dirorigina" hidden="0" width="-1" type="field"/>
      <column name="direccion1" hidden="0" width="-1" type="field"/>
      <column name="dirmzcasa" hidden="0" width="-1" type="field"/>
      <column name="nivsocio1" hidden="0" width="-1" type="field"/>
      <column name="marca_actu" hidden="0" width="-1" type="field"/>
      <column name="fecha" hidden="0" width="-1" type="field"/>
      <column name="version" hidden="0" width="-1" type="field"/>
      <column name="municipio1" hidden="0" width="-1" type="field"/>
      <column name="igac" hidden="0" width="-1" type="field"/>
      <column name="manzana_co" hidden="0" width="-1" type="field"/>
      <column name="igacanteri" hidden="0" width="-1" type="field"/>
      <column name="ciudad" hidden="0" width="-1" type="field"/>
      <column name="cod_mun1" hidden="0" width="-1" type="field"/>
      <column name="dir1" hidden="0" width="-1" type="field"/>
      <column name="dir2" hidden="0" width="-1" type="field"/>
      <column name="via_princ" hidden="0" width="-1" type="field"/>
      <column name="via_sec" hidden="0" width="-1" type="field"/>
      <column name="placa" hidden="0" width="-1" type="field"/>
      <column name="compl" hidden="0" width="-1" type="field"/>
      <column name="direccion_final" hidden="0" width="-1" type="field"/>
      <column name="direccion2" hidden="0" width="-1" type="field"/>
      <column name="dir_antigua" hidden="0" width="-1" type="field"/>
      <column name="tipo_direccion" hidden="0" width="-1" type="field"/>
      <column name="tipo_predio" hidden="0" width="-1" type="field"/>
      <column name="tipo_costado" hidden="0" width="-1" type="field"/>
      <column name="inconsistencias_gen" hidden="0" width="-1" type="field"/>
      <column name="inconsistencias_est" hidden="0" width="-1" type="field"/>
      <column name="inconsistencias_vec" hidden="0" width="-1" type="field"/>
      <column name="inconsistencias_dup" hidden="0" width="-1" type="field"/>
      <column name="duplicados" hidden="0" width="-1" type="field"/>
      <column name="val_mavvial_princ" hidden="0" width="-1" type="field"/>
      <column name="val_mavvial_sec" hidden="0" width="-1" type="field"/>
      <column name="resultado_est" hidden="0" width="-1" type="field"/>
      <column name="resultado_dup" hidden="0" width="-1" type="field"/>
      <column name="asignacion_est" hidden="0" width="-1" type="field"/>
      <column name="asignacion_dup" hidden="0" width="-1" type="field"/>
      <column name="fecha_rev_est" hidden="0" width="-1" type="field"/>
      <column name="fecha_rev_dup" hidden="0" width="-1" type="field"/>
      <column name="observaciones" hidden="0" width="-1" type="field"/>
      <column name="cx" hidden="0" width="-1" type="field"/>
      <column name="cy" hidden="0" width="-1" type="field"/>
      <column name="asignacion_val_mavvial" hidden="0" width="-1" type="field"/>
      <column name="resultado_val_mavvial" hidden="0" width="-1" type="field"/>
      <column name="fecha_val_mavvial" hidden="0" width="-1" type="field"/>
      <column name="asignacion_vec" hidden="0" width="-1" type="field"/>
      <column name="resultado_vec" hidden="0" width="-1" type="field"/>
      <column name="fecha_vec" hidden="0" width="-1" type="field"/>
      <column name="asignacion_par_impar" hidden="0" width="-1" type="field"/>
      <column name="resultado_par_impar" hidden="0" width="-1" type="field"/>
      <column name="fecha_par_impar" hidden="0" width="-1" type="field"/>
      <column name="asignacion_mavvial_sec" hidden="0" width="-1" type="field"/>
      <column name="resultado_mavvial_sec" hidden="0" width="-1" type="field"/>
      <column name="fecha_val_mavvial_sec" hidden="0" width="-1" type="field"/>
      <column name="osp_dir" hidden="0" width="-1" type="field"/>
      <column name="Marca" hidden="0" width="-1" type="field"/>
      <column name="Fecha" hidden="0" width="-1" type="field"/>
      <column name="Version" hidden="0" width="-1" type="field"/>
      <column name="obs_cod" hidden="0" width="-1" type="field"/>
      <column name="codpred_2023" hidden="0" width="-1" type="field"/>
      <column hidden="1" width="-1" type="actions"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[QGISQGIS# -*- coding: utf-8 -*-
"""
Los formularios QGIS pueden tener una función de Python a la que se llama cuando el formulario es abierto.

Utilice esta función para agregar lógica adicional a sus formularios.

Ingrese el nombre de la función en el campo"Función de inicio de Python" .
A continuación se muestra un ejemplo:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="Fecha"/>
    <field editable="1" name="Marca"/>
    <field editable="1" name="Version"/>
    <field editable="1" name="asignacion_dup"/>
    <field editable="1" name="asignacion_est"/>
    <field editable="1" name="asignacion_mavvial_sec"/>
    <field editable="1" name="asignacion_par_impar"/>
    <field editable="1" name="asignacion_val_mavvial"/>
    <field editable="1" name="asignacion_vec"/>
    <field editable="1" name="ciudad"/>
    <field editable="1" name="cod_mun1"/>
    <field editable="1" name="codman"/>
    <field editable="1" name="codpred"/>
    <field editable="1" name="codpred_2023"/>
    <field editable="1" name="codv2_2021"/>
    <field editable="1" name="compl"/>
    <field editable="1" name="cx"/>
    <field editable="1" name="cy"/>
    <field editable="1" name="dane"/>
    <field editable="1" name="dir1"/>
    <field editable="1" name="dir2"/>
    <field editable="1" name="dir_antigua"/>
    <field editable="1" name="direccion"/>
    <field editable="1" name="direccion1"/>
    <field editable="1" name="direccion2"/>
    <field editable="1" name="direccion_final"/>
    <field editable="1" name="dirmzcasa"/>
    <field editable="1" name="dirorigina"/>
    <field editable="1" name="duplicados"/>
    <field editable="1" name="fecha"/>
    <field editable="1" name="fecha_par_impar"/>
    <field editable="1" name="fecha_rev_dup"/>
    <field editable="1" name="fecha_rev_est"/>
    <field editable="1" name="fecha_val_mavvial"/>
    <field editable="1" name="fecha_val_mavvial_sec"/>
    <field editable="1" name="fecha_vec"/>
    <field editable="1" name="id"/>
    <field editable="1" name="id_capa"/>
    <field editable="1" name="id_unico"/>
    <field editable="1" name="igac"/>
    <field editable="1" name="igacanteri"/>
    <field editable="1" name="inconsistencias_dup"/>
    <field editable="1" name="inconsistencias_est"/>
    <field editable="1" name="inconsistencias_gen"/>
    <field editable="1" name="inconsistencias_vec"/>
    <field editable="1" name="manzana_co"/>
    <field editable="1" name="marca_actu"/>
    <field editable="1" name="municipio"/>
    <field editable="1" name="municipio1"/>
    <field editable="1" name="nivsocio1"/>
    <field editable="1" name="nse"/>
    <field editable="1" name="obs_cod"/>
    <field editable="1" name="observacio"/>
    <field editable="1" name="observaciones"/>
    <field editable="1" name="osp_dir"/>
    <field editable="1" name="para_proce"/>
    <field editable="1" name="placa"/>
    <field editable="1" name="resultado_dup"/>
    <field editable="1" name="resultado_est"/>
    <field editable="1" name="resultado_mavvial_sec"/>
    <field editable="1" name="resultado_par_impar"/>
    <field editable="1" name="resultado_val_mavvial"/>
    <field editable="1" name="resultado_vec"/>
    <field editable="1" name="tipo_costado"/>
    <field editable="1" name="tipo_direccion"/>
    <field editable="1" name="tipo_predio"/>
    <field editable="1" name="uh"/>
    <field editable="1" name="val_mavvial_princ"/>
    <field editable="1" name="val_mavvial_sec"/>
    <field editable="1" name="version"/>
    <field editable="1" name="via_princ"/>
    <field editable="1" name="via_sec"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="Fecha"/>
    <field labelOnTop="0" name="Marca"/>
    <field labelOnTop="0" name="Version"/>
    <field labelOnTop="0" name="asignacion_dup"/>
    <field labelOnTop="0" name="asignacion_est"/>
    <field labelOnTop="0" name="asignacion_mavvial_sec"/>
    <field labelOnTop="0" name="asignacion_par_impar"/>
    <field labelOnTop="0" name="asignacion_val_mavvial"/>
    <field labelOnTop="0" name="asignacion_vec"/>
    <field labelOnTop="0" name="ciudad"/>
    <field labelOnTop="0" name="cod_mun1"/>
    <field labelOnTop="0" name="codman"/>
    <field labelOnTop="0" name="codpred"/>
    <field labelOnTop="0" name="codpred_2023"/>
    <field labelOnTop="0" name="codv2_2021"/>
    <field labelOnTop="0" name="compl"/>
    <field labelOnTop="0" name="cx"/>
    <field labelOnTop="0" name="cy"/>
    <field labelOnTop="0" name="dane"/>
    <field labelOnTop="0" name="dir1"/>
    <field labelOnTop="0" name="dir2"/>
    <field labelOnTop="0" name="dir_antigua"/>
    <field labelOnTop="0" name="direccion"/>
    <field labelOnTop="0" name="direccion1"/>
    <field labelOnTop="0" name="direccion2"/>
    <field labelOnTop="0" name="direccion_final"/>
    <field labelOnTop="0" name="dirmzcasa"/>
    <field labelOnTop="0" name="dirorigina"/>
    <field labelOnTop="0" name="duplicados"/>
    <field labelOnTop="0" name="fecha"/>
    <field labelOnTop="0" name="fecha_par_impar"/>
    <field labelOnTop="0" name="fecha_rev_dup"/>
    <field labelOnTop="0" name="fecha_rev_est"/>
    <field labelOnTop="0" name="fecha_val_mavvial"/>
    <field labelOnTop="0" name="fecha_val_mavvial_sec"/>
    <field labelOnTop="0" name="fecha_vec"/>
    <field labelOnTop="0" name="id"/>
    <field labelOnTop="0" name="id_capa"/>
    <field labelOnTop="0" name="id_unico"/>
    <field labelOnTop="0" name="igac"/>
    <field labelOnTop="0" name="igacanteri"/>
    <field labelOnTop="0" name="inconsistencias_dup"/>
    <field labelOnTop="0" name="inconsistencias_est"/>
    <field labelOnTop="0" name="inconsistencias_gen"/>
    <field labelOnTop="0" name="inconsistencias_vec"/>
    <field labelOnTop="0" name="manzana_co"/>
    <field labelOnTop="0" name="marca_actu"/>
    <field labelOnTop="0" name="municipio"/>
    <field labelOnTop="0" name="municipio1"/>
    <field labelOnTop="0" name="nivsocio1"/>
    <field labelOnTop="0" name="nse"/>
    <field labelOnTop="0" name="obs_cod"/>
    <field labelOnTop="0" name="observacio"/>
    <field labelOnTop="0" name="observaciones"/>
    <field labelOnTop="0" name="osp_dir"/>
    <field labelOnTop="0" name="para_proce"/>
    <field labelOnTop="0" name="placa"/>
    <field labelOnTop="0" name="resultado_dup"/>
    <field labelOnTop="0" name="resultado_est"/>
    <field labelOnTop="0" name="resultado_mavvial_sec"/>
    <field labelOnTop="0" name="resultado_par_impar"/>
    <field labelOnTop="0" name="resultado_val_mavvial"/>
    <field labelOnTop="0" name="resultado_vec"/>
    <field labelOnTop="0" name="tipo_costado"/>
    <field labelOnTop="0" name="tipo_direccion"/>
    <field labelOnTop="0" name="tipo_predio"/>
    <field labelOnTop="0" name="uh"/>
    <field labelOnTop="0" name="val_mavvial_princ"/>
    <field labelOnTop="0" name="val_mavvial_sec"/>
    <field labelOnTop="0" name="version"/>
    <field labelOnTop="0" name="via_princ"/>
    <field labelOnTop="0" name="via_sec"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="Fecha" reuseLastValue="0"/>
    <field name="Marca" reuseLastValue="0"/>
    <field name="Version" reuseLastValue="0"/>
    <field name="asignacion_dup" reuseLastValue="0"/>
    <field name="asignacion_est" reuseLastValue="0"/>
    <field name="asignacion_mavvial_sec" reuseLastValue="0"/>
    <field name="asignacion_par_impar" reuseLastValue="0"/>
    <field name="asignacion_val_mavvial" reuseLastValue="0"/>
    <field name="asignacion_vec" reuseLastValue="0"/>
    <field name="ciudad" reuseLastValue="0"/>
    <field name="cod_mun1" reuseLastValue="0"/>
    <field name="codman" reuseLastValue="0"/>
    <field name="codpred" reuseLastValue="0"/>
    <field name="codpred_2023" reuseLastValue="0"/>
    <field name="codv2_2021" reuseLastValue="0"/>
    <field name="compl" reuseLastValue="0"/>
    <field name="cx" reuseLastValue="0"/>
    <field name="cy" reuseLastValue="0"/>
    <field name="dane" reuseLastValue="0"/>
    <field name="dir1" reuseLastValue="0"/>
    <field name="dir2" reuseLastValue="0"/>
    <field name="dir_antigua" reuseLastValue="0"/>
    <field name="direccion" reuseLastValue="0"/>
    <field name="direccion1" reuseLastValue="0"/>
    <field name="direccion2" reuseLastValue="0"/>
    <field name="direccion_final" reuseLastValue="0"/>
    <field name="dirmzcasa" reuseLastValue="0"/>
    <field name="dirorigina" reuseLastValue="0"/>
    <field name="duplicados" reuseLastValue="0"/>
    <field name="fecha" reuseLastValue="0"/>
    <field name="fecha_par_impar" reuseLastValue="0"/>
    <field name="fecha_rev_dup" reuseLastValue="0"/>
    <field name="fecha_rev_est" reuseLastValue="0"/>
    <field name="fecha_val_mavvial" reuseLastValue="0"/>
    <field name="fecha_val_mavvial_sec" reuseLastValue="0"/>
    <field name="fecha_vec" reuseLastValue="0"/>
    <field name="id" reuseLastValue="0"/>
    <field name="id_capa" reuseLastValue="0"/>
    <field name="id_unico" reuseLastValue="0"/>
    <field name="igac" reuseLastValue="0"/>
    <field name="igacanteri" reuseLastValue="0"/>
    <field name="inconsistencias_dup" reuseLastValue="0"/>
    <field name="inconsistencias_est" reuseLastValue="0"/>
    <field name="inconsistencias_gen" reuseLastValue="0"/>
    <field name="inconsistencias_vec" reuseLastValue="0"/>
    <field name="manzana_co" reuseLastValue="0"/>
    <field name="marca_actu" reuseLastValue="0"/>
    <field name="municipio" reuseLastValue="0"/>
    <field name="municipio1" reuseLastValue="0"/>
    <field name="nivsocio1" reuseLastValue="0"/>
    <field name="nse" reuseLastValue="0"/>
    <field name="obs_cod" reuseLastValue="0"/>
    <field name="observacio" reuseLastValue="0"/>
    <field name="observaciones" reuseLastValue="0"/>
    <field name="osp_dir" reuseLastValue="0"/>
    <field name="para_proce" reuseLastValue="0"/>
    <field name="placa" reuseLastValue="0"/>
    <field name="resultado_dup" reuseLastValue="0"/>
    <field name="resultado_est" reuseLastValue="0"/>
    <field name="resultado_mavvial_sec" reuseLastValue="0"/>
    <field name="resultado_par_impar" reuseLastValue="0"/>
    <field name="resultado_val_mavvial" reuseLastValue="0"/>
    <field name="resultado_vec" reuseLastValue="0"/>
    <field name="tipo_costado" reuseLastValue="0"/>
    <field name="tipo_direccion" reuseLastValue="0"/>
    <field name="tipo_predio" reuseLastValue="0"/>
    <field name="uh" reuseLastValue="0"/>
    <field name="val_mavvial_princ" reuseLastValue="0"/>
    <field name="val_mavvial_sec" reuseLastValue="0"/>
    <field name="version" reuseLastValue="0"/>
    <field name="via_princ" reuseLastValue="0"/>
    <field name="via_sec" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"dane"</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
