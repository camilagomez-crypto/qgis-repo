<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyLocal="1" maxScale="0" labelsEnabled="1" version="3.44.0-Solothurn" symbologyReferenceScale="-1" readOnly="0" styleCategories="AllStyleCategories" simplifyDrawingHints="1" simplifyMaxScale="1" autoRefreshMode="Disabled" simplifyDrawingTol="1" minScale="100000000" hasScaleBasedVisibilityFlag="0" autoRefreshTime="0" simplifyAlgorithm="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal limitMode="0" endExpression="" endField="" durationUnit="min" enabled="0" mode="0" startField="sv_fecha" fixedDuration="0" accumulate="0" startExpression="" durationField="id">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation showMarkerSymbolInSurfacePlots="0" type="IndividualFeatures" extrusionEnabled="0" zoffset="0" clamping="Terrain" symbology="Line" zscale="1" binding="Centroid" extrusion="0" respectLayerSymbol="1" customToleranceEnabled="1">
    <data-defined-properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol type="line" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1" frame_rate="10" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" id="{340ab3fa-cf87-4704-bc11-598cba0eba78}" locked="0" pass="0" class="SimpleLine">
          <Option type="Map">
            <Option value="0" type="QString" name="align_dash_pattern"/>
            <Option value="square" type="QString" name="capstyle"/>
            <Option value="5;2" type="QString" name="customdash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
            <Option value="MM" type="QString" name="customdash_unit"/>
            <Option value="0" type="QString" name="dash_pattern_offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
            <Option value="0" type="QString" name="draw_inside_polygon"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="190,178,151,255,rgb:0.745098,0.6980392,0.5921569,1" type="QString" name="line_color"/>
            <Option value="solid" type="QString" name="line_style"/>
            <Option value="0.6" type="QString" name="line_width"/>
            <Option value="MM" type="QString" name="line_width_unit"/>
            <Option value="0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0" type="QString" name="ring_filter"/>
            <Option value="0" type="QString" name="trim_distance_end"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_end_unit"/>
            <Option value="0" type="QString" name="trim_distance_start"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_start_unit"/>
            <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
            <Option value="0" type="QString" name="use_custom_dash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol type="fill" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1" frame_rate="10" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" id="{bba64646-4c34-4f89-afcd-646afb99cd86}" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="190,178,151,255,rgb:0.745098,0.6980392,0.5921569,1" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="136,127,108,255,rgb:0.5322042,0.4985885,0.4229648,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol type="marker" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1" frame_rate="10" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" id="{7c66fad8-22b3-42d0-93b4-79321d088464}" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option value="0" type="QString" name="angle"/>
            <Option value="square" type="QString" name="cap_style"/>
            <Option value="190,178,151,255,rgb:0.745098,0.6980392,0.5921569,1" type="QString" name="color"/>
            <Option value="1" type="QString" name="horizontal_anchor_point"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="diamond" type="QString" name="name"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="136,127,108,255,rgb:0.5322042,0.4985885,0.4229648,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="outline_width_map_unit_scale"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="diameter" type="QString" name="scale_method"/>
            <Option value="3" type="QString" name="size"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="size_map_unit_scale"/>
            <Option value="MM" type="QString" name="size_unit"/>
            <Option value="1" type="QString" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 symbollevels="0" type="singleSymbol" forceraster="0" enableorderby="0" referencescale="-1">
    <symbols>
      <symbol type="fill" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1" frame_rate="10" name="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" id="{182eaf2c-1018-4761-9588-3a6cc1890db7}" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="196,60,57,255,rgb:0.7686275,0.2352941,0.2235294,1" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="35,35,186,255,rgb:0.1372549,0.1372549,0.7286488,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="1" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="no" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol type="fill" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1" frame_rate="10" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" id="{fc9cc361-04df-49e2-9b1e-8f44a4e26821}" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="0,0,255,255,rgb:0,0,1,1" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.26" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style isExpression="0" tabStopDistanceUnit="Point" fontWeight="50" textOrientation="horizontal" fontLetterSpacing="0" capitalization="0" fontKerning="1" fontStrikeout="0" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="80" fontSize="10" fontItalic="0" legendString="Aa" forcedItalic="0" multilineHeight="1" namedStyle="Regular" fontFamily="Open Sans" multilineHeightUnit="Percentage" useSubstitutions="0" fontUnderline="0" textColor="50,50,222,255,rgb:0.1960784,0.1960784,0.8693523,1" textOpacity="1" forcedBold="0" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" stretchFactor="100" allowHtml="0" blendMode="0" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" fontWordSpacing="0" fieldName="nombre">
        <families/>
        <text-buffer bufferNoFill="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferDraw="0" bufferSize="1" bufferColor="250,250,250,255,rgb:0.9803922,0.9803922,0.9803922,1" bufferBlendMode="0" bufferJoinStyle="128" bufferSizeUnits="MM"/>
        <text-mask maskEnabled="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskedSymbolLayers="" maskType="0" maskOpacity="1" maskSize2="1.5" maskJoinStyle="128" maskSize="1.5"/>
        <background shapeSizeUnit="Point" shapeBorderWidthUnit="Point" shapeOffsetY="0" shapeType="0" shapeOffsetX="0" shapeBlendMode="0" shapeSizeType="0" shapeOpacity="1" shapeRadiiUnit="Point" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeSVGFile="" shapeSizeX="0" shapeOffsetUnit="Point" shapeRadiiX="0" shapeRotationType="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeJoinStyle="64" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSizeY="0" shapeBorderWidth="0" shapeRotation="0" shapeDraw="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0">
          <symbol type="marker" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1" frame_rate="10" name="markerSymbol">
            <data_defined_properties>
              <Option type="Map">
                <Option value="" type="QString" name="name"/>
                <Option name="properties"/>
                <Option value="collection" type="QString" name="type"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" id="" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option value="0" type="QString" name="angle"/>
                <Option value="square" type="QString" name="cap_style"/>
                <Option value="229,182,54,255,rgb:0.8980392,0.7137255,0.2117647,1" type="QString" name="color"/>
                <Option value="1" type="QString" name="horizontal_anchor_point"/>
                <Option value="bevel" type="QString" name="joinstyle"/>
                <Option value="circle" type="QString" name="name"/>
                <Option value="0,0" type="QString" name="offset"/>
                <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
                <Option value="MM" type="QString" name="offset_unit"/>
                <Option value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" type="QString" name="outline_color"/>
                <Option value="solid" type="QString" name="outline_style"/>
                <Option value="0" type="QString" name="outline_width"/>
                <Option value="3x:0,0,0,0,0,0" type="QString" name="outline_width_map_unit_scale"/>
                <Option value="MM" type="QString" name="outline_width_unit"/>
                <Option value="diameter" type="QString" name="scale_method"/>
                <Option value="2" type="QString" name="size"/>
                <Option value="3x:0,0,0,0,0,0" type="QString" name="size_map_unit_scale"/>
                <Option value="MM" type="QString" name="size_unit"/>
                <Option value="1" type="QString" name="vertical_anchor_point"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option value="" type="QString" name="name"/>
                  <Option name="properties"/>
                  <Option value="collection" type="QString" name="type"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol type="fill" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1" frame_rate="10" name="fillSymbol">
            <data_defined_properties>
              <Option type="Map">
                <Option value="" type="QString" name="name"/>
                <Option name="properties"/>
                <Option value="collection" type="QString" name="type"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" id="" locked="0" pass="0" class="SimpleFill">
              <Option type="Map">
                <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
                <Option value="255,255,255,255,rgb:1,1,1,1" type="QString" name="color"/>
                <Option value="bevel" type="QString" name="joinstyle"/>
                <Option value="0,0" type="QString" name="offset"/>
                <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
                <Option value="MM" type="QString" name="offset_unit"/>
                <Option value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" type="QString" name="outline_color"/>
                <Option value="no" type="QString" name="outline_style"/>
                <Option value="0" type="QString" name="outline_width"/>
                <Option value="Point" type="QString" name="outline_width_unit"/>
                <Option value="solid" type="QString" name="style"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option value="" type="QString" name="name"/>
                  <Option name="properties"/>
                  <Option value="collection" type="QString" name="type"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusAlphaOnly="0" shadowRadius="1.5" shadowOffsetDist="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowOffsetGlobal="1" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowOffsetAngle="135" shadowBlendMode="6" shadowDraw="0" shadowUnder="0"/>
        <dd_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format multilineAlign="3" addDirectionSymbol="0" wrapChar="" autoWrapLength="0" useMaxLineLengthForAutoWrap="1" formatNumbers="0" rightDirectionSymbol=">" leftDirectionSymbol="&lt;" reverseDirectionSymbol="0" decimals="3" plussign="0" placeDirectionSymbol="0"/>
      <placement rotationUnit="AngleDegrees" centroidInside="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="3" centroidWhole="0" geometryGeneratorType="PointGeometry" lineAnchorClipping="0" distUnits="MM" maxCurvedCharAngleIn="25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" lineAnchorPercent="0.5" quadOffset="4" priority="5" offsetType="0" lineAnchorTextPoint="FollowPlacement" dist="0" geometryGenerator="" maximumDistance="0" geometryGeneratorEnabled="0" overrunDistance="0" maxCurvedCharAngleOut="-25" yOffset="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" repeatDistanceUnits="MM" rotationAngle="0" placement="0" layerType="PolygonGeometry" overlapHandling="PreventOverlap" repeatDistance="0" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" placementFlags="10" distMapUnitScale="3x:0,0,0,0,0,0" preserveRotation="1" allowDegraded="0" xOffset="0" offsetUnits="MM" prioritization="PreferCloser" fitInPolygonOnly="0" overrunDistanceUnit="MM"/>
      <rendering obstacle="1" maxNumLabels="2000" obstacleFactor="1" obstacleType="1" minFeatureSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" limitNumLabels="0" upsidedownLabels="0" mergeLines="0" unplacedVisibility="0" fontLimitPixelSize="0" drawLabels="1" scaleMax="0" fontMinPixelSize="3" zIndex="0" labelPerPart="0"/>
      <dd_properties>
        <Option type="Map">
          <Option value="" type="QString" name="name"/>
          <Option name="properties"/>
          <Option value="collection" type="QString" name="type"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option value="pole_of_inaccessibility" type="QString" name="anchorPoint"/>
          <Option value="0" type="int" name="blendMode"/>
          <Option type="Map" name="ddProperties">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
          <Option value="false" type="bool" name="drawToAllParts"/>
          <Option value="0" type="QString" name="enabled"/>
          <Option value="point_on_exterior" type="QString" name="labelAnchorPoint"/>
          <Option value="&lt;symbol type=&quot;line&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; is_animated=&quot;0&quot; alpha=&quot;1&quot; frame_rate=&quot;10&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; type=&quot;QString&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; type=&quot;QString&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; id=&quot;{2db3d026-7212-48b8-9142-9bb22f3bbfe2}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option value=&quot;square&quot; type=&quot;QString&quot; name=&quot;capstyle&quot;/>&lt;Option value=&quot;5;2&quot; type=&quot;QString&quot; name=&quot;customdash&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;customdash_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option value=&quot;bevel&quot; type=&quot;QString&quot; name=&quot;joinstyle&quot;/>&lt;Option value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot; type=&quot;QString&quot; name=&quot;line_color&quot;/>&lt;Option value=&quot;solid&quot; type=&quot;QString&quot; name=&quot;line_style&quot;/>&lt;Option value=&quot;0.3&quot; type=&quot;QString&quot; name=&quot;line_width&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;line_width_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;offset&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;offset_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;ring_filter&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;trim_distance_end&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;trim_distance_start&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;use_custom_dash&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; type=&quot;QString&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; type=&quot;QString&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString" name="lineSymbol"/>
          <Option value="0" type="double" name="minLength"/>
          <Option value="3x:0,0,0,0,0,0" type="QString" name="minLengthMapUnitScale"/>
          <Option value="MM" type="QString" name="minLengthUnit"/>
          <Option value="0" type="double" name="offsetFromAnchor"/>
          <Option value="3x:0,0,0,0,0,0" type="QString" name="offsetFromAnchorMapUnitScale"/>
          <Option value="MM" type="QString" name="offsetFromAnchorUnit"/>
          <Option value="0" type="double" name="offsetFromLabel"/>
          <Option value="3x:0,0,0,0,0,0" type="QString" name="offsetFromLabelMapUnitScale"/>
          <Option value="MM" type="QString" name="offsetFromLabelUnit"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option value="0" type="int" name="embeddedWidgets/count"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration type="Map">
      <Option type="Map" name="QgsGeometryGapCheck">
        <Option value="0" type="double" name="allowedGapsBuffer"/>
        <Option value="false" type="bool" name="allowedGapsEnabled"/>
        <Option value="" type="QString" name="allowedGapsLayer"/>
      </Option>
    </checkConfiguration>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="id">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="id_capa">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="dane">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="municipio">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="cod_barrio">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="nombre">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="nombre_lar">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="multiorig">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="obs_cod">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="atis">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="topologia">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="marca_actu">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="fecha">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="version">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="inconsistencias">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="estado">
      <editWidget type="Enumeration">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="asignacion">
      <editWidget type="Enumeration">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="sv_marca1">
      <editWidget type="Enumeration">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="sv_marca2">
      <editWidget type="Enumeration">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="sv_fecha">
      <editWidget type="DateTime">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="sv_asignado">
      <editWidget type="Enumeration">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="dg_fecha">
      <editWidget type="DateTime">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="observaciones">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="resultado">
      <editWidget type="Enumeration">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" name="" field="id"/>
    <alias index="1" name="" field="id_capa"/>
    <alias index="2" name="" field="dane"/>
    <alias index="3" name="" field="municipio"/>
    <alias index="4" name="" field="cod_barrio"/>
    <alias index="5" name="" field="nombre"/>
    <alias index="6" name="" field="nombre_lar"/>
    <alias index="7" name="" field="multiorig"/>
    <alias index="8" name="" field="obs_cod"/>
    <alias index="9" name="" field="atis"/>
    <alias index="10" name="" field="topologia"/>
    <alias index="11" name="" field="marca_actu"/>
    <alias index="12" name="" field="fecha"/>
    <alias index="13" name="" field="version"/>
    <alias index="14" name="" field="inconsistencias"/>
    <alias index="15" name="" field="estado"/>
    <alias index="16" name="" field="asignacion"/>
    <alias index="17" name="" field="sv_marca1"/>
    <alias index="18" name="" field="sv_marca2"/>
    <alias index="19" name="" field="sv_fecha"/>
    <alias index="20" name="" field="sv_asignado"/>
    <alias index="21" name="" field="dg_fecha"/>
    <alias index="22" name="" field="observaciones"/>
    <alias index="23" name="" field="resultado"/>
  </aliases>
  <defaults>
    <default expression="" applyOnUpdate="0" field="id"/>
    <default expression="" applyOnUpdate="0" field="id_capa"/>
    <default expression="" applyOnUpdate="0" field="dane"/>
    <default expression="" applyOnUpdate="0" field="municipio"/>
    <default expression="" applyOnUpdate="0" field="cod_barrio"/>
    <default expression="" applyOnUpdate="0" field="nombre"/>
    <default expression="" applyOnUpdate="0" field="nombre_lar"/>
    <default expression="" applyOnUpdate="0" field="multiorig"/>
    <default expression="" applyOnUpdate="0" field="obs_cod"/>
    <default expression="" applyOnUpdate="0" field="atis"/>
    <default expression="" applyOnUpdate="0" field="topologia"/>
    <default expression="" applyOnUpdate="0" field="marca_actu"/>
    <default expression="" applyOnUpdate="0" field="fecha"/>
    <default expression="" applyOnUpdate="0" field="version"/>
    <default expression="" applyOnUpdate="0" field="inconsistencias"/>
    <default expression="" applyOnUpdate="0" field="estado"/>
    <default expression="" applyOnUpdate="0" field="asignacion"/>
    <default expression="" applyOnUpdate="0" field="sv_marca1"/>
    <default expression="" applyOnUpdate="0" field="sv_marca2"/>
    <default expression="" applyOnUpdate="0" field="sv_fecha"/>
    <default expression="" applyOnUpdate="0" field="sv_asignado"/>
    <default expression="" applyOnUpdate="0" field="dg_fecha"/>
    <default expression="" applyOnUpdate="0" field="observaciones"/>
    <default expression="" applyOnUpdate="0" field="resultado"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" constraints="3" unique_strength="1" notnull_strength="1" field="id"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="id_capa"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="dane"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="municipio"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="cod_barrio"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="nombre"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="nombre_lar"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="multiorig"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="obs_cod"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="atis"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="topologia"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="marca_actu"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="fecha"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="version"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="inconsistencias"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="estado"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="asignacion"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="sv_marca1"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="sv_marca2"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="sv_fecha"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="sv_asignado"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="dg_fecha"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="observaciones"/>
    <constraint exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0" field="resultado"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="id"/>
    <constraint exp="" desc="" field="id_capa"/>
    <constraint exp="" desc="" field="dane"/>
    <constraint exp="" desc="" field="municipio"/>
    <constraint exp="" desc="" field="cod_barrio"/>
    <constraint exp="" desc="" field="nombre"/>
    <constraint exp="" desc="" field="nombre_lar"/>
    <constraint exp="" desc="" field="multiorig"/>
    <constraint exp="" desc="" field="obs_cod"/>
    <constraint exp="" desc="" field="atis"/>
    <constraint exp="" desc="" field="topologia"/>
    <constraint exp="" desc="" field="marca_actu"/>
    <constraint exp="" desc="" field="fecha"/>
    <constraint exp="" desc="" field="version"/>
    <constraint exp="" desc="" field="inconsistencias"/>
    <constraint exp="" desc="" field="estado"/>
    <constraint exp="" desc="" field="asignacion"/>
    <constraint exp="" desc="" field="sv_marca1"/>
    <constraint exp="" desc="" field="sv_marca2"/>
    <constraint exp="" desc="" field="sv_fecha"/>
    <constraint exp="" desc="" field="sv_asignado"/>
    <constraint exp="" desc="" field="dg_fecha"/>
    <constraint exp="" desc="" field="observaciones"/>
    <constraint exp="" desc="" field="resultado"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
  </attributeactions>
  <attributetableconfig sortOrder="0" sortExpression="" actionWidgetStyle="dropDown">
    <columns>
      <column width="-1" type="field" hidden="0" name="id"/>
      <column width="-1" type="field" hidden="0" name="id_capa"/>
      <column width="-1" type="field" hidden="0" name="dane"/>
      <column width="-1" type="field" hidden="0" name="municipio"/>
      <column width="-1" type="field" hidden="0" name="cod_barrio"/>
      <column width="-1" type="field" hidden="0" name="nombre"/>
      <column width="-1" type="field" hidden="0" name="nombre_lar"/>
      <column width="-1" type="field" hidden="0" name="multiorig"/>
      <column width="-1" type="field" hidden="0" name="obs_cod"/>
      <column width="-1" type="field" hidden="0" name="atis"/>
      <column width="-1" type="field" hidden="0" name="topologia"/>
      <column width="-1" type="field" hidden="0" name="marca_actu"/>
      <column width="-1" type="field" hidden="0" name="fecha"/>
      <column width="-1" type="field" hidden="0" name="version"/>
      <column width="-1" type="field" hidden="0" name="inconsistencias"/>
      <column width="-1" type="field" hidden="0" name="estado"/>
      <column width="-1" type="field" hidden="0" name="asignacion"/>
      <column width="-1" type="field" hidden="0" name="sv_marca1"/>
      <column width="-1" type="field" hidden="0" name="sv_marca2"/>
      <column width="-1" type="field" hidden="0" name="sv_fecha"/>
      <column width="-1" type="field" hidden="0" name="sv_asignado"/>
      <column width="-1" type="field" hidden="0" name="dg_fecha"/>
      <column width="-1" type="field" hidden="0" name="observaciones"/>
      <column width="-1" type="field" hidden="0" name="resultado"/>
      <column width="-1" type="actions" hidden="1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[QGISQGIS# -*- coding: utf-8 -*-
"""
Los formularios QGIS pueden tener una función de Python a la que se llama cuando el formulario es abierto.

Utilice esta función para agregar lógica adicional a sus formularios.

Ingrese el nombre de la función en el campo"Función de inicio de Python" .
A continuación se muestra un ejemplo:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="asignacion"/>
    <field editable="1" name="atis"/>
    <field editable="1" name="cod_barrio"/>
    <field editable="1" name="dane"/>
    <field editable="1" name="dg_fecha"/>
    <field editable="1" name="estado"/>
    <field editable="1" name="fecha"/>
    <field editable="1" name="id"/>
    <field editable="1" name="id_capa"/>
    <field editable="1" name="inconsistencias"/>
    <field editable="1" name="marca_actu"/>
    <field editable="1" name="multiorig"/>
    <field editable="1" name="municipio"/>
    <field editable="1" name="nombre"/>
    <field editable="1" name="nombre_lar"/>
    <field editable="1" name="obs_cod"/>
    <field editable="1" name="observaciones"/>
    <field editable="1" name="resultado"/>
    <field editable="1" name="sv_asignado"/>
    <field editable="1" name="sv_fecha"/>
    <field editable="1" name="sv_marca1"/>
    <field editable="1" name="sv_marca2"/>
    <field editable="1" name="topologia"/>
    <field editable="1" name="version"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="asignacion"/>
    <field labelOnTop="0" name="atis"/>
    <field labelOnTop="0" name="cod_barrio"/>
    <field labelOnTop="0" name="dane"/>
    <field labelOnTop="0" name="dg_fecha"/>
    <field labelOnTop="0" name="estado"/>
    <field labelOnTop="0" name="fecha"/>
    <field labelOnTop="0" name="id"/>
    <field labelOnTop="0" name="id_capa"/>
    <field labelOnTop="0" name="inconsistencias"/>
    <field labelOnTop="0" name="marca_actu"/>
    <field labelOnTop="0" name="multiorig"/>
    <field labelOnTop="0" name="municipio"/>
    <field labelOnTop="0" name="nombre"/>
    <field labelOnTop="0" name="nombre_lar"/>
    <field labelOnTop="0" name="obs_cod"/>
    <field labelOnTop="0" name="observaciones"/>
    <field labelOnTop="0" name="resultado"/>
    <field labelOnTop="0" name="sv_asignado"/>
    <field labelOnTop="0" name="sv_fecha"/>
    <field labelOnTop="0" name="sv_marca1"/>
    <field labelOnTop="0" name="sv_marca2"/>
    <field labelOnTop="0" name="topologia"/>
    <field labelOnTop="0" name="version"/>
  </labelOnTop>
  <reuseLastValue>
    <field reuseLastValue="0" name="asignacion"/>
    <field reuseLastValue="0" name="atis"/>
    <field reuseLastValue="0" name="cod_barrio"/>
    <field reuseLastValue="0" name="dane"/>
    <field reuseLastValue="0" name="dg_fecha"/>
    <field reuseLastValue="0" name="estado"/>
    <field reuseLastValue="0" name="fecha"/>
    <field reuseLastValue="0" name="id"/>
    <field reuseLastValue="0" name="id_capa"/>
    <field reuseLastValue="0" name="inconsistencias"/>
    <field reuseLastValue="0" name="marca_actu"/>
    <field reuseLastValue="0" name="multiorig"/>
    <field reuseLastValue="0" name="municipio"/>
    <field reuseLastValue="0" name="nombre"/>
    <field reuseLastValue="0" name="nombre_lar"/>
    <field reuseLastValue="0" name="obs_cod"/>
    <field reuseLastValue="0" name="observaciones"/>
    <field reuseLastValue="0" name="resultado"/>
    <field reuseLastValue="0" name="sv_asignado"/>
    <field reuseLastValue="0" name="sv_fecha"/>
    <field reuseLastValue="0" name="sv_marca1"/>
    <field reuseLastValue="0" name="sv_marca2"/>
    <field reuseLastValue="0" name="topologia"/>
    <field reuseLastValue="0" name="version"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"nombre"</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
