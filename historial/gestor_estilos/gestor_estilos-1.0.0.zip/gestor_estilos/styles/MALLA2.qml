<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis maxScale="0" styleCategories="AllStyleCategories" simplifyLocal="1" hasScaleBasedVisibilityFlag="0" simplifyDrawingHints="1" readOnly="0" version="3.44.0-Solothurn" simplifyMaxScale="1" simplifyDrawingTol="1" autoRefreshTime="0" simplifyAlgorithm="0" symbologyReferenceScale="-1" minScale="100000000" autoRefreshMode="Disabled" labelsEnabled="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal mode="0" endExpression="" durationField="id" limitMode="0" durationUnit="min" fixedDuration="0" enabled="0" endField="" startField="sv_fecha" startExpression="" accumulate="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation customToleranceEnabled="0" binding="Centroid" zoffset="0" extrusion="0" type="IndividualFeatures" extrusionEnabled="0" showMarkerSymbolInSurfacePlots="0" clamping="Terrain" symbology="Line" respectLayerSymbol="1" zscale="1">
    <data-defined-properties>
      <Option type="Map">
        <Option value="" name="name" type="QString"/>
        <Option name="properties"/>
        <Option value="collection" name="type" type="QString"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol force_rhr="0" frame_rate="10" name="" type="line" is_animated="0" clip_to_extent="1" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleLine" enabled="1" pass="0" id="{6a786d98-de00-49a0-9093-5f98ace3a680}">
          <Option type="Map">
            <Option value="0" name="align_dash_pattern" type="QString"/>
            <Option value="square" name="capstyle" type="QString"/>
            <Option value="5;2" name="customdash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
            <Option value="MM" name="customdash_unit" type="QString"/>
            <Option value="0" name="dash_pattern_offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
            <Option value="0" name="draw_inside_polygon" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="183,72,75,255,rgb:0.7176471,0.2823529,0.2941176,1" name="line_color" type="QString"/>
            <Option value="solid" name="line_style" type="QString"/>
            <Option value="0.6" name="line_width" type="QString"/>
            <Option value="MM" name="line_width_unit" type="QString"/>
            <Option value="0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0" name="ring_filter" type="QString"/>
            <Option value="0" name="trim_distance_end" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_end_unit" type="QString"/>
            <Option value="0" name="trim_distance_start" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_start_unit" type="QString"/>
            <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
            <Option value="0" name="use_custom_dash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol force_rhr="0" frame_rate="10" name="" type="fill" is_animated="0" clip_to_extent="1" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleFill" enabled="1" pass="0" id="{a775f560-9ed3-42d9-b44a-eb4d9c205253}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="183,72,75,255,rgb:0.7176471,0.2823529,0.2941176,1" name="color" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="131,51,54,255,rgb:0.5137255,0.2,0.2117647,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol force_rhr="0" frame_rate="10" name="" type="marker" is_animated="0" clip_to_extent="1" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleMarker" enabled="1" pass="0" id="{57b767ed-04f0-4645-9869-11d99c18bdb9}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="183,72,75,255,rgb:0.7176471,0.2823529,0.2941176,1" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="diamond" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="131,51,54,255,rgb:0.5137255,0.2,0.2117647,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 symbollevels="0" type="singleSymbol" forceraster="0" enableorderby="0" referencescale="-1">
    <symbols>
      <symbol force_rhr="0" frame_rate="10" name="0" type="line" is_animated="0" clip_to_extent="1" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleLine" enabled="1" pass="0" id="{4628071b-2853-46db-8365-8187db17e024}">
          <Option type="Map">
            <Option value="0" name="align_dash_pattern" type="QString"/>
            <Option value="square" name="capstyle" type="QString"/>
            <Option value="5;2" name="customdash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
            <Option value="MM" name="customdash_unit" type="QString"/>
            <Option value="0" name="dash_pattern_offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
            <Option value="0" name="draw_inside_polygon" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="246,23,236,255,rgb:0.964828,0.0911421,0.9257649,1" name="line_color" type="QString"/>
            <Option value="solid" name="line_style" type="QString"/>
            <Option value="0.5" name="line_width" type="QString"/>
            <Option value="MM" name="line_width_unit" type="QString"/>
            <Option value="0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0" name="ring_filter" type="QString"/>
            <Option value="0" name="trim_distance_end" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_end_unit" type="QString"/>
            <Option value="0" name="trim_distance_start" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_start_unit" type="QString"/>
            <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
            <Option value="0" name="use_custom_dash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option value="" name="name" type="QString"/>
        <Option name="properties"/>
        <Option value="collection" name="type" type="QString"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol force_rhr="0" frame_rate="10" name="" type="line" is_animated="0" clip_to_extent="1" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleLine" enabled="1" pass="0" id="{35e68b6f-cec4-46d4-9f70-1f36493b7cbb}">
          <Option type="Map">
            <Option value="0" name="align_dash_pattern" type="QString"/>
            <Option value="square" name="capstyle" type="QString"/>
            <Option value="5;2" name="customdash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
            <Option value="MM" name="customdash_unit" type="QString"/>
            <Option value="0" name="dash_pattern_offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
            <Option value="0" name="draw_inside_polygon" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="line_color" type="QString"/>
            <Option value="solid" name="line_style" type="QString"/>
            <Option value="0.26" name="line_width" type="QString"/>
            <Option value="MM" name="line_width_unit" type="QString"/>
            <Option value="0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0" name="ring_filter" type="QString"/>
            <Option value="0" name="trim_distance_end" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_end_unit" type="QString"/>
            <Option value="0" name="trim_distance_start" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_start_unit" type="QString"/>
            <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
            <Option value="0" name="use_custom_dash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <labeling type="rule-based">
    <rules key="{2e7a3ed4-c328-4685-a572-02d9dc31f096}">
      <rule key="{8ca4b8b1-80e0-4732-a3fc-8bccf14609ee}">
        <settings calloutType="simple">
          <text-style fontItalic="0" fontStrikeout="0" fontKerning="1" fontWordSpacing="0" namedStyle="Normal" stretchFactor="100" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" multilineHeightUnit="Percentage" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" forcedItalic="0" tabStopDistanceUnit="Point" useSubstitutions="0" textOpacity="1" multilineHeight="1" fontLetterSpacing="0" fieldName="principal" allowHtml="0" legendString="Aa" fontSize="12" isExpression="0" blendMode="0" capitalization="0" fontFamily="Franklin Gothic Demi" textColor="255,0,221,255,hsv:0.85524999999999995,1,1,1" tabStopDistance="80" forcedBold="0" fontUnderline="0" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" textOrientation="horizontal">
            <families/>
            <text-buffer bufferOpacity="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferDraw="0" bufferSize="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="250,250,250,255,rgb:0.9803922,0.9803922,0.9803922,1"/>
            <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskOpacity="1" maskEnabled="0" maskSize2="1.5" maskJoinStyle="128" maskType="0" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0"/>
            <background shapeType="0" shapeBlendMode="0" shapeOpacity="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeRadiiY="0" shapeBorderWidthUnit="Point" shapeSizeType="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeY="0" shapeOffsetY="0" shapeSizeX="0" shapeOffsetUnit="Point" shapeJoinStyle="64" shapeRadiiX="0" shapeBorderWidth="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="Point" shapeSizeUnit="Point" shapeSVGFile="" shapeOffsetX="0" shapeRotationType="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRotation="0">
              <symbol force_rhr="0" frame_rate="10" name="markerSymbol" type="marker" is_animated="0" clip_to_extent="1" alpha="1">
                <data_defined_properties>
                  <Option type="Map">
                    <Option value="" name="name" type="QString"/>
                    <Option name="properties"/>
                    <Option value="collection" name="type" type="QString"/>
                  </Option>
                </data_defined_properties>
                <layer locked="0" class="SimpleMarker" enabled="1" pass="0" id="">
                  <Option type="Map">
                    <Option value="0" name="angle" type="QString"/>
                    <Option value="square" name="cap_style" type="QString"/>
                    <Option value="232,113,141,255,rgb:0.9098039,0.4431373,0.5529412,1" name="color" type="QString"/>
                    <Option value="1" name="horizontal_anchor_point" type="QString"/>
                    <Option value="bevel" name="joinstyle" type="QString"/>
                    <Option value="circle" name="name" type="QString"/>
                    <Option value="0,0" name="offset" type="QString"/>
                    <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                    <Option value="MM" name="offset_unit" type="QString"/>
                    <Option value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" type="QString"/>
                    <Option value="solid" name="outline_style" type="QString"/>
                    <Option value="0" name="outline_width" type="QString"/>
                    <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                    <Option value="MM" name="outline_width_unit" type="QString"/>
                    <Option value="diameter" name="scale_method" type="QString"/>
                    <Option value="2" name="size" type="QString"/>
                    <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                    <Option value="MM" name="size_unit" type="QString"/>
                    <Option value="1" name="vertical_anchor_point" type="QString"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol force_rhr="0" frame_rate="10" name="fillSymbol" type="fill" is_animated="0" clip_to_extent="1" alpha="1">
                <data_defined_properties>
                  <Option type="Map">
                    <Option value="" name="name" type="QString"/>
                    <Option name="properties"/>
                    <Option value="collection" name="type" type="QString"/>
                  </Option>
                </data_defined_properties>
                <layer locked="0" class="SimpleFill" enabled="1" pass="0" id="">
                  <Option type="Map">
                    <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                    <Option value="255,255,255,255,rgb:1,1,1,1" name="color" type="QString"/>
                    <Option value="bevel" name="joinstyle" type="QString"/>
                    <Option value="0,0" name="offset" type="QString"/>
                    <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                    <Option value="MM" name="offset_unit" type="QString"/>
                    <Option value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" name="outline_color" type="QString"/>
                    <Option value="no" name="outline_style" type="QString"/>
                    <Option value="0" name="outline_width" type="QString"/>
                    <Option value="Point" name="outline_width_unit" type="QString"/>
                    <Option value="solid" name="style" type="QString"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowDraw="0" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowUnder="0" shadowOffsetGlobal="1" shadowOffsetUnit="MM" shadowOffsetDist="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowBlendMode="6" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowOffsetAngle="135" shadowScale="100"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format autoWrapLength="0" useMaxLineLengthForAutoWrap="1" decimals="3" wrapChar="" placeDirectionSymbol="0" rightDirectionSymbol=">" addDirectionSymbol="0" formatNumbers="0" leftDirectionSymbol="&lt;" reverseDirectionSymbol="0" multilineAlign="0" plussign="0"/>
          <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" centroidInside="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" yOffset="0" quadOffset="4" priority="5" overlapHandling="PreventOverlap" lineAnchorTextPoint="FollowPlacement" rotationAngle="0" geometryGeneratorEnabled="0" overrunDistance="0" distUnits="MM" rotationUnit="AngleDegrees" maxCurvedCharAngleIn="25" overrunDistanceUnit="MM" geometryGeneratorType="PointGeometry" lineAnchorClipping="0" fitInPolygonOnly="0" geometryGenerator="" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleOut="-25" offsetType="0" preserveRotation="1" repeatDistanceUnits="MM" placementFlags="10" lineAnchorPercent="0.5" maximumDistance="0" repeatDistance="0" layerType="LineGeometry" dist="0" maximumDistanceUnit="MM" allowDegraded="0" offsetUnits="MM" lineAnchorType="0" centroidWhole="0" placement="2" distMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" polygonPlacementFlags="2" prioritization="PreferCloser" xOffset="0"/>
          <rendering scaleMax="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleFactor="1" obstacleType="1" fontMinPixelSize="3" labelPerPart="0" upsidedownLabels="0" limitNumLabels="0" minFeatureSize="0" fontMaxPixelSize="10000" maxNumLabels="2000" obstacle="1" scaleMin="0" zIndex="0" drawLabels="1" mergeLines="0" unplacedVisibility="0"/>
          <dd_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
              <Option value="0" name="blendMode" type="int"/>
              <Option name="ddProperties" type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
              <Option value="false" name="drawToAllParts" type="bool"/>
              <Option value="0" name="enabled" type="QString"/>
              <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
              <Option value="&lt;symbol force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; name=&quot;symbol&quot; type=&quot;line&quot; is_animated=&quot;0&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot; pass=&quot;0&quot; id=&quot;{3be4392c-09f4-4a6f-91ea-00fd35726d83}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
              <Option value="0" name="minLength" type="double"/>
              <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
              <Option value="MM" name="minLengthUnit" type="QString"/>
              <Option value="0" name="offsetFromAnchor" type="double"/>
              <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
              <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
              <Option value="0" name="offsetFromLabel" type="double"/>
              <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
              <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule key="{d29fb600-110f-4868-9085-ba39e7a219db}">
        <settings calloutType="simple">
          <text-style fontItalic="0" fontStrikeout="0" fontKerning="1" fontWordSpacing="0" namedStyle="Normal" stretchFactor="100" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" multilineHeightUnit="Percentage" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" forcedItalic="0" tabStopDistanceUnit="Point" useSubstitutions="0" textOpacity="1" multilineHeight="1" fontLetterSpacing="0" fieldName="generadora" allowHtml="0" legendString="Aa" fontSize="10" isExpression="0" blendMode="0" capitalization="0" fontFamily="Franklin Gothic Book" textColor="154,50,182,255,rgb:0.6030213,0.1960784,0.7135729,1" tabStopDistance="80" forcedBold="0" fontUnderline="0" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" textOrientation="horizontal">
            <families/>
            <text-buffer bufferOpacity="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferDraw="0" bufferSize="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="250,250,250,255,rgb:0.9803922,0.9803922,0.9803922,1"/>
            <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskOpacity="1" maskEnabled="0" maskSize2="1.5" maskJoinStyle="128" maskType="0" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0"/>
            <background shapeType="0" shapeBlendMode="0" shapeOpacity="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeRadiiY="0" shapeBorderWidthUnit="Point" shapeSizeType="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeY="0" shapeOffsetY="0" shapeSizeX="0" shapeOffsetUnit="Point" shapeJoinStyle="64" shapeRadiiX="0" shapeBorderWidth="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="Point" shapeSizeUnit="Point" shapeSVGFile="" shapeOffsetX="0" shapeRotationType="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRotation="0">
              <symbol force_rhr="0" frame_rate="10" name="markerSymbol" type="marker" is_animated="0" clip_to_extent="1" alpha="1">
                <data_defined_properties>
                  <Option type="Map">
                    <Option value="" name="name" type="QString"/>
                    <Option name="properties"/>
                    <Option value="collection" name="type" type="QString"/>
                  </Option>
                </data_defined_properties>
                <layer locked="0" class="SimpleMarker" enabled="1" pass="0" id="">
                  <Option type="Map">
                    <Option value="0" name="angle" type="QString"/>
                    <Option value="square" name="cap_style" type="QString"/>
                    <Option value="141,90,153,255,rgb:0.5529412,0.3529412,0.6,1" name="color" type="QString"/>
                    <Option value="1" name="horizontal_anchor_point" type="QString"/>
                    <Option value="bevel" name="joinstyle" type="QString"/>
                    <Option value="circle" name="name" type="QString"/>
                    <Option value="0,0" name="offset" type="QString"/>
                    <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                    <Option value="MM" name="offset_unit" type="QString"/>
                    <Option value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" type="QString"/>
                    <Option value="solid" name="outline_style" type="QString"/>
                    <Option value="0" name="outline_width" type="QString"/>
                    <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                    <Option value="MM" name="outline_width_unit" type="QString"/>
                    <Option value="diameter" name="scale_method" type="QString"/>
                    <Option value="2" name="size" type="QString"/>
                    <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                    <Option value="MM" name="size_unit" type="QString"/>
                    <Option value="1" name="vertical_anchor_point" type="QString"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol force_rhr="0" frame_rate="10" name="fillSymbol" type="fill" is_animated="0" clip_to_extent="1" alpha="1">
                <data_defined_properties>
                  <Option type="Map">
                    <Option value="" name="name" type="QString"/>
                    <Option name="properties"/>
                    <Option value="collection" name="type" type="QString"/>
                  </Option>
                </data_defined_properties>
                <layer locked="0" class="SimpleFill" enabled="1" pass="0" id="">
                  <Option type="Map">
                    <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                    <Option value="255,255,255,255,rgb:1,1,1,1" name="color" type="QString"/>
                    <Option value="bevel" name="joinstyle" type="QString"/>
                    <Option value="0,0" name="offset" type="QString"/>
                    <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                    <Option value="MM" name="offset_unit" type="QString"/>
                    <Option value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" name="outline_color" type="QString"/>
                    <Option value="no" name="outline_style" type="QString"/>
                    <Option value="0" name="outline_width" type="QString"/>
                    <Option value="Point" name="outline_width_unit" type="QString"/>
                    <Option value="solid" name="style" type="QString"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowDraw="0" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowUnder="0" shadowOffsetGlobal="1" shadowOffsetUnit="MM" shadowOffsetDist="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowBlendMode="6" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowOffsetAngle="135" shadowScale="100"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format autoWrapLength="0" useMaxLineLengthForAutoWrap="1" decimals="3" wrapChar="" placeDirectionSymbol="0" rightDirectionSymbol=">" addDirectionSymbol="0" formatNumbers="0" leftDirectionSymbol="&lt;" reverseDirectionSymbol="0" multilineAlign="0" plussign="0"/>
          <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" centroidInside="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" yOffset="0" quadOffset="4" priority="5" overlapHandling="PreventOverlap" lineAnchorTextPoint="FollowPlacement" rotationAngle="0" geometryGeneratorEnabled="0" overrunDistance="0" distUnits="MM" rotationUnit="AngleDegrees" maxCurvedCharAngleIn="25" overrunDistanceUnit="MM" geometryGeneratorType="PointGeometry" lineAnchorClipping="0" fitInPolygonOnly="0" geometryGenerator="" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleOut="-25" offsetType="0" preserveRotation="1" repeatDistanceUnits="MM" placementFlags="12" lineAnchorPercent="0.5" maximumDistance="0" repeatDistance="0" layerType="LineGeometry" dist="0" maximumDistanceUnit="MM" allowDegraded="0" offsetUnits="MM" lineAnchorType="0" centroidWhole="0" placement="2" distMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" polygonPlacementFlags="2" prioritization="PreferCloser" xOffset="0"/>
          <rendering scaleMax="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleFactor="1" obstacleType="1" fontMinPixelSize="3" labelPerPart="0" upsidedownLabels="0" limitNumLabels="0" minFeatureSize="0" fontMaxPixelSize="10000" maxNumLabels="2000" obstacle="1" scaleMin="0" zIndex="0" drawLabels="1" mergeLines="0" unplacedVisibility="0"/>
          <dd_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
              <Option value="0" name="blendMode" type="int"/>
              <Option name="ddProperties" type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
              <Option value="false" name="drawToAllParts" type="bool"/>
              <Option value="0" name="enabled" type="QString"/>
              <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
              <Option value="&lt;symbol force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; name=&quot;symbol&quot; type=&quot;line&quot; is_animated=&quot;0&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot; pass=&quot;0&quot; id=&quot;{d7f3381b-b184-45ff-83e7-637f59c850aa}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
              <Option value="0" name="minLength" type="double"/>
              <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
              <Option value="MM" name="minLengthUnit" type="QString"/>
              <Option value="0" name="offsetFromAnchor" type="double"/>
              <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
              <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
              <Option value="0" name="offsetFromLabel" type="double"/>
              <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
              <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
            </Option>
          </callout>
        </settings>
      </rule>
    </rules>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option value="0" name="embeddedWidgets/count" type="int"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <LinearlyInterpolatedDiagramRenderer upperHeight="5" lowerWidth="0" diagramType="Histogram" attributeLegend="1" upperWidth="5" lowerValue="0" lowerHeight="0" classificationAttributeExpression="" upperValue="0">
    <DiagramCategory scaleBasedVisibility="0" backgroundAlpha="255" minScaleDenominator="0" lineSizeType="MM" spacing="5" barWidth="5" sizeScale="3x:0,0,0,0,0,0" maxScaleDenominator="1e+08" rotationOffset="270" minimumSize="0" stackedDiagramSpacing="0" stackedDiagramSpacingUnitScale="3x:0,0,0,0,0,0" diagramOrientation="Up" lineSizeScale="3x:0,0,0,0,0,0" backgroundColor="#ffffff" enabled="0" penAlpha="255" stackedDiagramMode="Horizontal" opacity="1" sizeType="MM" penColor="#000000" height="15" penWidth="0" width="15" scaleDependency="Area" spacingUnit="MM" stackedDiagramSpacingUnit="MM" spacingUnitScale="3x:0,0,0,0,0,0" direction="0" showAxis="1" labelPlacementMethod="XHeight">
      <fontProperties underline="0" italic="0" style="" bold="0" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" strikethrough="0"/>
      <attribute colorOpacity="1" label="" field="" color="#000000"/>
      <axisSymbol>
        <symbol force_rhr="0" frame_rate="10" name="" type="line" is_animated="0" clip_to_extent="1" alpha="1">
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
          <layer locked="0" class="SimpleLine" enabled="1" pass="0" id="{ecb00ca1-b573-417e-8474-5257f0d2fd46}">
            <Option type="Map">
              <Option value="0" name="align_dash_pattern" type="QString"/>
              <Option value="square" name="capstyle" type="QString"/>
              <Option value="5;2" name="customdash" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
              <Option value="MM" name="customdash_unit" type="QString"/>
              <Option value="0" name="dash_pattern_offset" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
              <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
              <Option value="0" name="draw_inside_polygon" type="QString"/>
              <Option value="bevel" name="joinstyle" type="QString"/>
              <Option value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="line_color" type="QString"/>
              <Option value="solid" name="line_style" type="QString"/>
              <Option value="0.26" name="line_width" type="QString"/>
              <Option value="MM" name="line_width_unit" type="QString"/>
              <Option value="0" name="offset" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
              <Option value="MM" name="offset_unit" type="QString"/>
              <Option value="0" name="ring_filter" type="QString"/>
              <Option value="0" name="trim_distance_end" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
              <Option value="MM" name="trim_distance_end_unit" type="QString"/>
              <Option value="0" name="trim_distance_start" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
              <Option value="MM" name="trim_distance_start_unit" type="QString"/>
              <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
              <Option value="0" name="use_custom_dash" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </LinearlyInterpolatedDiagramRenderer>
  <DiagramLayerSettings linePlacementFlags="18" showAll="1" placement="2" dist="0" zIndex="0" priority="0" obstacle="0">
    <properties>
      <Option type="Map">
        <Option value="" name="name" type="QString"/>
        <Option name="properties"/>
        <Option value="collection" name="type" type="QString"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field name="id" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="id_capa" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dane" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="municipio" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="principal" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="generadora" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="costado" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="para_proce" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="id_unico" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="costado1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="principal1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="generado_1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="prin2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="gen2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ciudad" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cod_mun" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="marca_actu" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="fecha" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="version" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="inconsistencias" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sn_qa" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="estado" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="asignacion" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sv_marca1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sv_marca2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sv_fecha" configurationFlags="NoFlag">
      <editWidget type="DateTime">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sv_asignado" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dg_fecha" configurationFlags="NoFlag">
      <editWidget type="DateTime">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="observaciones" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="resultado" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="marca_direcc" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="multiorig" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="oneway" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="velocidad" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="tipovia" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="concat" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" index="0" field="id"/>
    <alias name="" index="1" field="id_capa"/>
    <alias name="" index="2" field="dane"/>
    <alias name="" index="3" field="municipio"/>
    <alias name="" index="4" field="principal"/>
    <alias name="" index="5" field="generadora"/>
    <alias name="" index="6" field="costado"/>
    <alias name="" index="7" field="para_proce"/>
    <alias name="" index="8" field="id_unico"/>
    <alias name="" index="9" field="costado1"/>
    <alias name="" index="10" field="principal1"/>
    <alias name="" index="11" field="generado_1"/>
    <alias name="" index="12" field="prin2"/>
    <alias name="" index="13" field="gen2"/>
    <alias name="" index="14" field="ciudad"/>
    <alias name="" index="15" field="cod_mun"/>
    <alias name="" index="16" field="marca_actu"/>
    <alias name="" index="17" field="fecha"/>
    <alias name="" index="18" field="version"/>
    <alias name="" index="19" field="inconsistencias"/>
    <alias name="" index="20" field="sn_qa"/>
    <alias name="" index="21" field="estado"/>
    <alias name="" index="22" field="asignacion"/>
    <alias name="" index="23" field="sv_marca1"/>
    <alias name="" index="24" field="sv_marca2"/>
    <alias name="" index="25" field="sv_fecha"/>
    <alias name="" index="26" field="sv_asignado"/>
    <alias name="" index="27" field="dg_fecha"/>
    <alias name="" index="28" field="observaciones"/>
    <alias name="" index="29" field="resultado"/>
    <alias name="" index="30" field="marca_direcc"/>
    <alias name="" index="31" field="multiorig"/>
    <alias name="" index="32" field="oneway"/>
    <alias name="" index="33" field="velocidad"/>
    <alias name="" index="34" field="tipovia"/>
    <alias name="" index="35" field="concat"/>
  </aliases>
  <defaults>
    <default applyOnUpdate="0" field="id" expression=""/>
    <default applyOnUpdate="0" field="id_capa" expression=""/>
    <default applyOnUpdate="0" field="dane" expression=""/>
    <default applyOnUpdate="0" field="municipio" expression=""/>
    <default applyOnUpdate="0" field="principal" expression=""/>
    <default applyOnUpdate="0" field="generadora" expression=""/>
    <default applyOnUpdate="0" field="costado" expression=""/>
    <default applyOnUpdate="0" field="para_proce" expression=""/>
    <default applyOnUpdate="0" field="id_unico" expression=""/>
    <default applyOnUpdate="0" field="costado1" expression=""/>
    <default applyOnUpdate="0" field="principal1" expression=""/>
    <default applyOnUpdate="0" field="generado_1" expression=""/>
    <default applyOnUpdate="0" field="prin2" expression=""/>
    <default applyOnUpdate="0" field="gen2" expression=""/>
    <default applyOnUpdate="0" field="ciudad" expression=""/>
    <default applyOnUpdate="0" field="cod_mun" expression=""/>
    <default applyOnUpdate="0" field="marca_actu" expression=""/>
    <default applyOnUpdate="0" field="fecha" expression=""/>
    <default applyOnUpdate="0" field="version" expression=""/>
    <default applyOnUpdate="0" field="inconsistencias" expression=""/>
    <default applyOnUpdate="0" field="sn_qa" expression=""/>
    <default applyOnUpdate="0" field="estado" expression=""/>
    <default applyOnUpdate="0" field="asignacion" expression=""/>
    <default applyOnUpdate="0" field="sv_marca1" expression=""/>
    <default applyOnUpdate="0" field="sv_marca2" expression=""/>
    <default applyOnUpdate="0" field="sv_fecha" expression=""/>
    <default applyOnUpdate="0" field="sv_asignado" expression=""/>
    <default applyOnUpdate="0" field="dg_fecha" expression=""/>
    <default applyOnUpdate="0" field="observaciones" expression=""/>
    <default applyOnUpdate="0" field="resultado" expression=""/>
    <default applyOnUpdate="0" field="marca_direcc" expression=""/>
    <default applyOnUpdate="0" field="multiorig" expression=""/>
    <default applyOnUpdate="0" field="oneway" expression=""/>
    <default applyOnUpdate="0" field="velocidad" expression=""/>
    <default applyOnUpdate="0" field="tipovia" expression=""/>
    <default applyOnUpdate="0" field="concat" expression=""/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" notnull_strength="1" constraints="3" field="id" unique_strength="1"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="id_capa" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="dane" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="municipio" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="principal" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="generadora" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="costado" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="para_proce" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="id_unico" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="costado1" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="principal1" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="generado_1" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="prin2" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="gen2" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="ciudad" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="cod_mun" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="marca_actu" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="fecha" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="version" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="inconsistencias" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="sn_qa" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="estado" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="asignacion" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="sv_marca1" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="sv_marca2" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="sv_fecha" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="sv_asignado" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="dg_fecha" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="observaciones" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="resultado" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="marca_direcc" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="multiorig" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="oneway" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="velocidad" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="tipovia" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="concat" unique_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" exp="" field="id"/>
    <constraint desc="" exp="" field="id_capa"/>
    <constraint desc="" exp="" field="dane"/>
    <constraint desc="" exp="" field="municipio"/>
    <constraint desc="" exp="" field="principal"/>
    <constraint desc="" exp="" field="generadora"/>
    <constraint desc="" exp="" field="costado"/>
    <constraint desc="" exp="" field="para_proce"/>
    <constraint desc="" exp="" field="id_unico"/>
    <constraint desc="" exp="" field="costado1"/>
    <constraint desc="" exp="" field="principal1"/>
    <constraint desc="" exp="" field="generado_1"/>
    <constraint desc="" exp="" field="prin2"/>
    <constraint desc="" exp="" field="gen2"/>
    <constraint desc="" exp="" field="ciudad"/>
    <constraint desc="" exp="" field="cod_mun"/>
    <constraint desc="" exp="" field="marca_actu"/>
    <constraint desc="" exp="" field="fecha"/>
    <constraint desc="" exp="" field="version"/>
    <constraint desc="" exp="" field="inconsistencias"/>
    <constraint desc="" exp="" field="sn_qa"/>
    <constraint desc="" exp="" field="estado"/>
    <constraint desc="" exp="" field="asignacion"/>
    <constraint desc="" exp="" field="sv_marca1"/>
    <constraint desc="" exp="" field="sv_marca2"/>
    <constraint desc="" exp="" field="sv_fecha"/>
    <constraint desc="" exp="" field="sv_asignado"/>
    <constraint desc="" exp="" field="dg_fecha"/>
    <constraint desc="" exp="" field="observaciones"/>
    <constraint desc="" exp="" field="resultado"/>
    <constraint desc="" exp="" field="marca_direcc"/>
    <constraint desc="" exp="" field="multiorig"/>
    <constraint desc="" exp="" field="oneway"/>
    <constraint desc="" exp="" field="velocidad"/>
    <constraint desc="" exp="" field="tipovia"/>
    <constraint desc="" exp="" field="concat"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortOrder="0" sortExpression="">
    <columns>
      <column name="id" type="field" width="-1" hidden="0"/>
      <column name="id_capa" type="field" width="-1" hidden="0"/>
      <column name="dane" type="field" width="-1" hidden="0"/>
      <column name="municipio" type="field" width="-1" hidden="0"/>
      <column name="principal" type="field" width="-1" hidden="0"/>
      <column name="generadora" type="field" width="-1" hidden="0"/>
      <column name="costado" type="field" width="-1" hidden="0"/>
      <column name="para_proce" type="field" width="-1" hidden="0"/>
      <column name="id_unico" type="field" width="-1" hidden="0"/>
      <column name="costado1" type="field" width="-1" hidden="0"/>
      <column name="principal1" type="field" width="-1" hidden="0"/>
      <column name="generado_1" type="field" width="-1" hidden="0"/>
      <column name="prin2" type="field" width="-1" hidden="0"/>
      <column name="gen2" type="field" width="-1" hidden="0"/>
      <column name="oneway" type="field" width="-1" hidden="0"/>
      <column name="velocidad" type="field" width="-1" hidden="0"/>
      <column name="tipovia" type="field" width="-1" hidden="0"/>
      <column name="marca_actu" type="field" width="-1" hidden="0"/>
      <column name="fecha" type="field" width="-1" hidden="0"/>
      <column name="version" type="field" width="-1" hidden="0"/>
      <column name="inconsistencias" type="field" width="-1" hidden="0"/>
      <column name="ciudad" type="field" width="-1" hidden="0"/>
      <column name="cod_mun" type="field" width="-1" hidden="0"/>
      <column name="sn_qa" type="field" width="-1" hidden="0"/>
      <column name="estado" type="field" width="-1" hidden="0"/>
      <column name="asignacion" type="field" width="-1" hidden="0"/>
      <column name="sv_marca1" type="field" width="-1" hidden="0"/>
      <column name="sv_marca2" type="field" width="-1" hidden="0"/>
      <column name="sv_fecha" type="field" width="-1" hidden="0"/>
      <column name="sv_asignado" type="field" width="-1" hidden="0"/>
      <column name="dg_fecha" type="field" width="-1" hidden="0"/>
      <column name="observaciones" type="field" width="-1" hidden="0"/>
      <column name="resultado" type="field" width="-1" hidden="0"/>
      <column name="marca_direcc" type="field" width="-1" hidden="0"/>
      <column name="multiorig" type="field" width="-1" hidden="0"/>
      <column name="concat" type="field" width="-1" hidden="0"/>
      <column type="actions" width="-1" hidden="1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[QGISQGIS# -*- coding: utf-8 -*-
"""
Los formularios QGIS pueden tener una función de Python a la que se llama cuando el formulario es abierto.

Utilice esta función para agregar lógica adicional a sus formularios.

Ingrese el nombre de la función en el campo"Función de inicio de Python" .
A continuación se muestra un ejemplo:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="asignacion" editable="1"/>
    <field name="ciudad" editable="1"/>
    <field name="cod_mun" editable="1"/>
    <field name="concat" editable="1"/>
    <field name="costado" editable="1"/>
    <field name="costado1" editable="1"/>
    <field name="dane" editable="1"/>
    <field name="dg_fecha" editable="1"/>
    <field name="direcc" editable="1"/>
    <field name="estado" editable="1"/>
    <field name="fecha" editable="1"/>
    <field name="gen2" editable="1"/>
    <field name="generado_1" editable="1"/>
    <field name="generadora" editable="1"/>
    <field name="id" editable="1"/>
    <field name="id_capa" editable="1"/>
    <field name="id_unico" editable="1"/>
    <field name="idmeg" editable="1"/>
    <field name="inconsistencias" editable="1"/>
    <field name="marca_actu" editable="1"/>
    <field name="marca_direcc" editable="1"/>
    <field name="multiorig" editable="1"/>
    <field name="multiorige" editable="1"/>
    <field name="municipio" editable="1"/>
    <field name="observaciones" editable="1"/>
    <field name="oneway" editable="1"/>
    <field name="para_proce" editable="1"/>
    <field name="prin2" editable="1"/>
    <field name="principal" editable="1"/>
    <field name="principal1" editable="1"/>
    <field name="resultado" editable="1"/>
    <field name="sn_qa" editable="1"/>
    <field name="sv_asignado" editable="1"/>
    <field name="sv_fecha" editable="1"/>
    <field name="sv_marca1" editable="1"/>
    <field name="sv_marca2" editable="1"/>
    <field name="tipovia" editable="1"/>
    <field name="velocidad" editable="1"/>
    <field name="version" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="asignacion" labelOnTop="0"/>
    <field name="ciudad" labelOnTop="0"/>
    <field name="cod_mun" labelOnTop="0"/>
    <field name="concat" labelOnTop="0"/>
    <field name="costado" labelOnTop="0"/>
    <field name="costado1" labelOnTop="0"/>
    <field name="dane" labelOnTop="0"/>
    <field name="dg_fecha" labelOnTop="0"/>
    <field name="direcc" labelOnTop="0"/>
    <field name="estado" labelOnTop="0"/>
    <field name="fecha" labelOnTop="0"/>
    <field name="gen2" labelOnTop="0"/>
    <field name="generado_1" labelOnTop="0"/>
    <field name="generadora" labelOnTop="0"/>
    <field name="id" labelOnTop="0"/>
    <field name="id_capa" labelOnTop="0"/>
    <field name="id_unico" labelOnTop="0"/>
    <field name="idmeg" labelOnTop="0"/>
    <field name="inconsistencias" labelOnTop="0"/>
    <field name="marca_actu" labelOnTop="0"/>
    <field name="marca_direcc" labelOnTop="0"/>
    <field name="multiorig" labelOnTop="0"/>
    <field name="multiorige" labelOnTop="0"/>
    <field name="municipio" labelOnTop="0"/>
    <field name="observaciones" labelOnTop="0"/>
    <field name="oneway" labelOnTop="0"/>
    <field name="para_proce" labelOnTop="0"/>
    <field name="prin2" labelOnTop="0"/>
    <field name="principal" labelOnTop="0"/>
    <field name="principal1" labelOnTop="0"/>
    <field name="resultado" labelOnTop="0"/>
    <field name="sn_qa" labelOnTop="0"/>
    <field name="sv_asignado" labelOnTop="0"/>
    <field name="sv_fecha" labelOnTop="0"/>
    <field name="sv_marca1" labelOnTop="0"/>
    <field name="sv_marca2" labelOnTop="0"/>
    <field name="tipovia" labelOnTop="0"/>
    <field name="velocidad" labelOnTop="0"/>
    <field name="version" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="asignacion" reuseLastValue="0"/>
    <field name="ciudad" reuseLastValue="0"/>
    <field name="cod_mun" reuseLastValue="0"/>
    <field name="concat" reuseLastValue="0"/>
    <field name="costado" reuseLastValue="0"/>
    <field name="costado1" reuseLastValue="0"/>
    <field name="dane" reuseLastValue="0"/>
    <field name="dg_fecha" reuseLastValue="0"/>
    <field name="direcc" reuseLastValue="0"/>
    <field name="estado" reuseLastValue="0"/>
    <field name="fecha" reuseLastValue="0"/>
    <field name="gen2" reuseLastValue="0"/>
    <field name="generado_1" reuseLastValue="0"/>
    <field name="generadora" reuseLastValue="0"/>
    <field name="id" reuseLastValue="0"/>
    <field name="id_capa" reuseLastValue="0"/>
    <field name="id_unico" reuseLastValue="0"/>
    <field name="idmeg" reuseLastValue="0"/>
    <field name="inconsistencias" reuseLastValue="0"/>
    <field name="marca_actu" reuseLastValue="0"/>
    <field name="marca_direcc" reuseLastValue="0"/>
    <field name="multiorig" reuseLastValue="0"/>
    <field name="multiorige" reuseLastValue="0"/>
    <field name="municipio" reuseLastValue="0"/>
    <field name="observaciones" reuseLastValue="0"/>
    <field name="oneway" reuseLastValue="0"/>
    <field name="para_proce" reuseLastValue="0"/>
    <field name="prin2" reuseLastValue="0"/>
    <field name="principal" reuseLastValue="0"/>
    <field name="principal1" reuseLastValue="0"/>
    <field name="resultado" reuseLastValue="0"/>
    <field name="sn_qa" reuseLastValue="0"/>
    <field name="sv_asignado" reuseLastValue="0"/>
    <field name="sv_fecha" reuseLastValue="0"/>
    <field name="sv_marca1" reuseLastValue="0"/>
    <field name="sv_marca2" reuseLastValue="0"/>
    <field name="tipovia" reuseLastValue="0"/>
    <field name="velocidad" reuseLastValue="0"/>
    <field name="version" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"dane"</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>1</layerGeometryType>
</qgis>
