<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis labelsEnabled="1" hasScaleBasedVisibilityFlag="0" maxScale="0" simplifyAlgorithm="0" readOnly="0" version="3.44.0-Solothurn" simplifyLocal="1" minScale="100000000" autoRefreshMode="Disabled" simplifyDrawingHints="1" simplifyDrawingTol="1" styleCategories="AllStyleCategories" autoRefreshTime="0" simplifyMaxScale="1" symbologyReferenceScale="-1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal startExpression="" enabled="0" durationField="id" accumulate="0" startField="fecha" endExpression="" durationUnit="min" mode="0" fixedDuration="0" endField="" limitMode="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation extrusionEnabled="0" showMarkerSymbolInSurfacePlots="0" respectLayerSymbol="1" customToleranceEnabled="0" clamping="Terrain" symbology="Line" binding="Centroid" zoffset="0" zscale="1" extrusion="0" type="IndividualFeatures">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties"/>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol name="" clip_to_extent="1" force_rhr="0" is_animated="0" frame_rate="10" alpha="1" type="line">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" locked="0" id="{3318d683-bddd-4d2f-b980-29f423b0a177}" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" value="0" type="QString"/>
            <Option name="capstyle" value="square" type="QString"/>
            <Option name="customdash" value="5;2" type="QString"/>
            <Option name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="customdash_unit" value="MM" type="QString"/>
            <Option name="dash_pattern_offset" value="0" type="QString"/>
            <Option name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="dash_pattern_offset_unit" value="MM" type="QString"/>
            <Option name="draw_inside_polygon" value="0" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="line_color" value="225,89,137,255,rgb:0.8823529,0.3490196,0.5372549,1" type="QString"/>
            <Option name="line_style" value="solid" type="QString"/>
            <Option name="line_width" value="0.6" type="QString"/>
            <Option name="line_width_unit" value="MM" type="QString"/>
            <Option name="offset" value="0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="ring_filter" value="0" type="QString"/>
            <Option name="trim_distance_end" value="0" type="QString"/>
            <Option name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_end_unit" value="MM" type="QString"/>
            <Option name="trim_distance_start" value="0" type="QString"/>
            <Option name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_start_unit" value="MM" type="QString"/>
            <Option name="tweak_dash_pattern_on_corners" value="0" type="QString"/>
            <Option name="use_custom_dash" value="0" type="QString"/>
            <Option name="width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol name="" clip_to_extent="1" force_rhr="0" is_animated="0" frame_rate="10" alpha="1" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" locked="0" id="{86a65b4e-aba6-49ab-ac1b-e565560a4671}" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="225,89,137,255,rgb:0.8823529,0.3490196,0.5372549,1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="161,64,98,255,rgb:0.6313725,0.2509804,0.3843137,1" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol name="" clip_to_extent="1" force_rhr="0" is_animated="0" frame_rate="10" alpha="1" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" enabled="1" locked="0" id="{11265054-0b27-486a-b34a-0686434b142f}" pass="0">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="225,89,137,255,rgb:0.8823529,0.3490196,0.5372549,1" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="diamond" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="161,64,98,255,rgb:0.6313725,0.2509804,0.3843137,1" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 referencescale="-1" forceraster="0" enableorderby="0" type="singleSymbol" symbollevels="0">
    <symbols>
      <symbol name="0" clip_to_extent="1" force_rhr="0" is_animated="0" frame_rate="10" alpha="1" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" locked="0" id="{1748d58b-0e38-457f-bea7-407b16870a83}" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="229,182,54,255,rgb:0.8980392,0.7137255,0.2117647,1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.26" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="no" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties"/>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol name="" clip_to_extent="1" force_rhr="0" is_animated="0" frame_rate="10" alpha="1" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" locked="0" id="{5b7b123e-8eae-4ef8-a89e-cd6549a04e94}" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="0,0,255,255,rgb:0,0,1,1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.26" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <labeling type="rule-based">
    <rules key="{6ec0049c-bb4f-4b84-abbe-7e9810920ee7}">
      <rule key="{17286f58-d997-40c5-9db9-680b6ca2dbeb}">
        <settings calloutType="simple">
          <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" fontFamily="Open Sans" fontSizeUnit="Point" fontUnderline="0" multilineHeight="1" useSubstitutions="0" fontWeight="50" textColor="50,50,50,255,rgb:0.1960784,0.1960784,0.1960784,1" textOrientation="horizontal" fieldName="&quot;via_princ&quot; +' '+ &quot;via_sec&quot; +' '+ &quot;placa&quot; + ' '+  &quot;compl&quot; " isExpression="1" textOpacity="1" blendMode="0" legendString="Aa" namedStyle="" fontItalic="0" tabStopDistanceUnit="Point" tabStopDistance="80" forcedItalic="0" forcedBold="0" allowHtml="0" fontKerning="1" fontLetterSpacing="0" capitalization="0" stretchFactor="100" fontStrikeout="0" multilineHeightUnit="Percentage" fontWordSpacing="0" fontSize="10" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0">
            <families/>
            <text-buffer bufferColor="250,250,250,255,rgb:0.9803922,0.9803922,0.9803922,1" bufferJoinStyle="128" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferDraw="0" bufferSize="1" bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM"/>
            <text-mask maskType="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskOpacity="1" maskSize2="1.5" maskJoinStyle="128" maskedSymbolLayers="" maskSize="1.5" maskSizeUnits="MM"/>
            <background shapeOffsetUnit="Point" shapeSizeX="0" shapeOffsetY="0" shapeSizeUnit="Point" shapeBorderWidth="0" shapeBorderWidthUnit="Point" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeRadiiX="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeDraw="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="Point" shapeOpacity="1" shapeSVGFile="" shapeSizeType="0" shapeBlendMode="0" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeRotationType="0" shapeSizeY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeRotation="0" shapeOffsetX="0">
              <symbol name="markerSymbol" clip_to_extent="1" force_rhr="0" is_animated="0" frame_rate="10" alpha="1" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" value="" type="QString"/>
                    <Option name="properties"/>
                    <Option name="type" value="collection" type="QString"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleMarker" enabled="1" locked="0" id="" pass="0">
                  <Option type="Map">
                    <Option name="angle" value="0" type="QString"/>
                    <Option name="cap_style" value="square" type="QString"/>
                    <Option name="color" value="196,60,57,255,rgb:0.7686275,0.2352941,0.2235294,1" type="QString"/>
                    <Option name="horizontal_anchor_point" value="1" type="QString"/>
                    <Option name="joinstyle" value="bevel" type="QString"/>
                    <Option name="name" value="circle" type="QString"/>
                    <Option name="offset" value="0,0" type="QString"/>
                    <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                    <Option name="offset_unit" value="MM" type="QString"/>
                    <Option name="outline_color" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" type="QString"/>
                    <Option name="outline_style" value="solid" type="QString"/>
                    <Option name="outline_width" value="0" type="QString"/>
                    <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                    <Option name="outline_width_unit" value="MM" type="QString"/>
                    <Option name="scale_method" value="diameter" type="QString"/>
                    <Option name="size" value="2" type="QString"/>
                    <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                    <Option name="size_unit" value="MM" type="QString"/>
                    <Option name="vertical_anchor_point" value="1" type="QString"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol name="fillSymbol" clip_to_extent="1" force_rhr="0" is_animated="0" frame_rate="10" alpha="1" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" value="" type="QString"/>
                    <Option name="properties"/>
                    <Option name="type" value="collection" type="QString"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" locked="0" id="" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                    <Option name="color" value="255,255,255,255,rgb:1,1,1,1" type="QString"/>
                    <Option name="joinstyle" value="bevel" type="QString"/>
                    <Option name="offset" value="0,0" type="QString"/>
                    <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                    <Option name="offset_unit" value="MM" type="QString"/>
                    <Option name="outline_color" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" type="QString"/>
                    <Option name="outline_style" value="no" type="QString"/>
                    <Option name="outline_width" value="0" type="QString"/>
                    <Option name="outline_width_unit" value="Point" type="QString"/>
                    <Option name="style" value="solid" type="QString"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowRadiusUnit="MM" shadowRadiusAlphaOnly="0" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOpacity="0.69999999999999996" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowBlendMode="6" shadowOffsetDist="1" shadowOffsetUnit="MM" shadowScale="100" shadowDraw="0" shadowRadius="1.5" shadowOffsetAngle="135" shadowUnder="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format reverseDirectionSymbol="0" formatNumbers="0" multilineAlign="3" leftDirectionSymbol="&lt;" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" placeDirectionSymbol="0" decimals="3" useMaxLineLengthForAutoWrap="1" wrapChar="" autoWrapLength="0"/>
          <placement maxCurvedCharAngleOut="-25" lineAnchorClipping="0" repeatDistanceUnits="MM" polygonPlacementFlags="2" overlapHandling="PreventOverlap" centroidInside="0" fitInPolygonOnly="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" quadOffset="4" geometryGeneratorType="PointGeometry" allowDegraded="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" distUnits="MM" maxCurvedCharAngleIn="25" xOffset="0" distMapUnitScale="3x:0,0,0,0,0,0" centroidWhole="0" maximumDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PolygonGeometry" placementFlags="10" repeatDistance="0" offsetType="0" rotationAngle="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" priority="5" preserveRotation="1" lineAnchorTextPoint="FollowPlacement" placement="0" geometryGeneratorEnabled="0" dist="0" lineAnchorPercent="0.5" geometryGenerator="" overrunDistanceUnit="MM" overrunDistance="0" prioritization="PreferCloser" lineAnchorType="0" maximumDistanceUnit="MM" offsetUnits="MM" rotationUnit="AngleDegrees"/>
          <rendering scaleMax="0" upsidedownLabels="0" fontLimitPixelSize="0" scaleMin="0" unplacedVisibility="0" obstacleFactor="1" minFeatureSize="0" fontMinPixelSize="3" maxNumLabels="2000" limitNumLabels="0" fontMaxPixelSize="10000" scaleVisibility="0" zIndex="0" drawLabels="1" obstacle="1" labelPerPart="0" obstacleType="1" mergeLines="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
              <Option name="blendMode" value="0" type="int"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
              <Option name="drawToAllParts" value="false" type="bool"/>
              <Option name="enabled" value="0" type="QString"/>
              <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
              <Option name="lineSymbol" value="&lt;symbol name=&quot;symbol&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; is_animated=&quot;0&quot; frame_rate=&quot;10&quot; alpha=&quot;1&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; locked=&quot;0&quot; id=&quot;{1b154f6f-acb1-4712-8cc9-a8e11de1c5aa}&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
              <Option name="minLength" value="0" type="double"/>
              <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="minLengthUnit" value="MM" type="QString"/>
              <Option name="offsetFromAnchor" value="0" type="double"/>
              <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
              <Option name="offsetFromLabel" value="0" type="double"/>
              <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule key="{1f803b91-3999-4b58-956b-e587ef1553b8}">
        <settings calloutType="simple">
          <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" fontFamily="Open Sans" fontSizeUnit="Point" fontUnderline="0" multilineHeight="1" useSubstitutions="0" fontWeight="50" textColor="50,50,255,255,rgb:0.1960784,0.1960784,1,1" textOrientation="horizontal" fieldName="direccion2" isExpression="0" textOpacity="1" blendMode="0" legendString="Aa" namedStyle="" fontItalic="0" tabStopDistanceUnit="Point" tabStopDistance="80" forcedItalic="0" forcedBold="0" allowHtml="0" fontKerning="1" fontLetterSpacing="0" capitalization="0" stretchFactor="100" fontStrikeout="0" multilineHeightUnit="Percentage" fontWordSpacing="0" fontSize="10" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0">
            <families/>
            <text-buffer bufferColor="250,250,250,255,rgb:0.9803922,0.9803922,0.9803922,1" bufferJoinStyle="128" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferDraw="0" bufferSize="1" bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM"/>
            <text-mask maskType="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskOpacity="1" maskSize2="1.5" maskJoinStyle="128" maskedSymbolLayers="" maskSize="1.5" maskSizeUnits="MM"/>
            <background shapeOffsetUnit="Point" shapeSizeX="0" shapeOffsetY="0" shapeSizeUnit="Point" shapeBorderWidth="0" shapeBorderWidthUnit="Point" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeRadiiX="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeDraw="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="Point" shapeOpacity="1" shapeSVGFile="" shapeSizeType="0" shapeBlendMode="0" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeRotationType="0" shapeSizeY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeRotation="0" shapeOffsetX="0">
              <symbol name="markerSymbol" clip_to_extent="1" force_rhr="0" is_animated="0" frame_rate="10" alpha="1" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" value="" type="QString"/>
                    <Option name="properties"/>
                    <Option name="type" value="collection" type="QString"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleMarker" enabled="1" locked="0" id="" pass="0">
                  <Option type="Map">
                    <Option name="angle" value="0" type="QString"/>
                    <Option name="cap_style" value="square" type="QString"/>
                    <Option name="color" value="190,178,151,255,rgb:0.745098,0.6980392,0.5921569,1" type="QString"/>
                    <Option name="horizontal_anchor_point" value="1" type="QString"/>
                    <Option name="joinstyle" value="bevel" type="QString"/>
                    <Option name="name" value="circle" type="QString"/>
                    <Option name="offset" value="0,0" type="QString"/>
                    <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                    <Option name="offset_unit" value="MM" type="QString"/>
                    <Option name="outline_color" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" type="QString"/>
                    <Option name="outline_style" value="solid" type="QString"/>
                    <Option name="outline_width" value="0" type="QString"/>
                    <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                    <Option name="outline_width_unit" value="MM" type="QString"/>
                    <Option name="scale_method" value="diameter" type="QString"/>
                    <Option name="size" value="2" type="QString"/>
                    <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                    <Option name="size_unit" value="MM" type="QString"/>
                    <Option name="vertical_anchor_point" value="1" type="QString"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol name="fillSymbol" clip_to_extent="1" force_rhr="0" is_animated="0" frame_rate="10" alpha="1" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" value="" type="QString"/>
                    <Option name="properties"/>
                    <Option name="type" value="collection" type="QString"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" locked="0" id="" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                    <Option name="color" value="255,255,255,255,rgb:1,1,1,1" type="QString"/>
                    <Option name="joinstyle" value="bevel" type="QString"/>
                    <Option name="offset" value="0,0" type="QString"/>
                    <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                    <Option name="offset_unit" value="MM" type="QString"/>
                    <Option name="outline_color" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" type="QString"/>
                    <Option name="outline_style" value="no" type="QString"/>
                    <Option name="outline_width" value="0" type="QString"/>
                    <Option name="outline_width_unit" value="Point" type="QString"/>
                    <Option name="style" value="solid" type="QString"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowRadiusUnit="MM" shadowRadiusAlphaOnly="0" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOpacity="0.69999999999999996" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowBlendMode="6" shadowOffsetDist="1" shadowOffsetUnit="MM" shadowScale="100" shadowDraw="0" shadowRadius="1.5" shadowOffsetAngle="135" shadowUnder="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format reverseDirectionSymbol="0" formatNumbers="0" multilineAlign="3" leftDirectionSymbol="&lt;" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" placeDirectionSymbol="0" decimals="3" useMaxLineLengthForAutoWrap="1" wrapChar="" autoWrapLength="0"/>
          <placement maxCurvedCharAngleOut="-25" lineAnchorClipping="0" repeatDistanceUnits="MM" polygonPlacementFlags="2" overlapHandling="PreventOverlap" centroidInside="0" fitInPolygonOnly="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" quadOffset="4" geometryGeneratorType="PointGeometry" allowDegraded="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" distUnits="MM" maxCurvedCharAngleIn="25" xOffset="0" distMapUnitScale="3x:0,0,0,0,0,0" centroidWhole="0" maximumDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PolygonGeometry" placementFlags="10" repeatDistance="0" offsetType="0" rotationAngle="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" priority="5" preserveRotation="1" lineAnchorTextPoint="FollowPlacement" placement="0" geometryGeneratorEnabled="0" dist="0" lineAnchorPercent="0.5" geometryGenerator="" overrunDistanceUnit="MM" overrunDistance="0" prioritization="PreferCloser" lineAnchorType="0" maximumDistanceUnit="MM" offsetUnits="MM" rotationUnit="AngleDegrees"/>
          <rendering scaleMax="0" upsidedownLabels="0" fontLimitPixelSize="0" scaleMin="0" unplacedVisibility="0" obstacleFactor="1" minFeatureSize="0" fontMinPixelSize="3" maxNumLabels="2000" limitNumLabels="0" fontMaxPixelSize="10000" scaleVisibility="0" zIndex="0" drawLabels="1" obstacle="1" labelPerPart="0" obstacleType="1" mergeLines="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
              <Option name="blendMode" value="0" type="int"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
              <Option name="drawToAllParts" value="false" type="bool"/>
              <Option name="enabled" value="0" type="QString"/>
              <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
              <Option name="lineSymbol" value="&lt;symbol name=&quot;symbol&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; is_animated=&quot;0&quot; frame_rate=&quot;10&quot; alpha=&quot;1&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; locked=&quot;0&quot; id=&quot;{556cc053-fe3f-4de8-89f4-014d93898ef2}&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
              <Option name="minLength" value="0" type="double"/>
              <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="minLengthUnit" value="MM" type="QString"/>
              <Option name="offsetFromAnchor" value="0" type="double"/>
              <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
              <Option name="offsetFromLabel" value="0" type="double"/>
              <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
            </Option>
          </callout>
        </settings>
      </rule>
    </rules>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option name="dualview/previewExpressions" type="List">
        <Option value="&quot;dane&quot;" type="QString"/>
      </Option>
      <Option name="embeddedWidgets/count" value="0" type="int"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <LinearlyInterpolatedDiagramRenderer attributeLegend="1" upperWidth="5" lowerValue="0" upperHeight="5" classificationAttributeExpression="" diagramType="Histogram" upperValue="0" lowerWidth="0" lowerHeight="0">
    <DiagramCategory spacingUnitScale="3x:0,0,0,0,0,0" spacingUnit="MM" spacing="5" penWidth="0" opacity="1" scaleBasedVisibility="0" stackedDiagramSpacingUnit="MM" sizeScale="3x:0,0,0,0,0,0" labelPlacementMethod="XHeight" minScaleDenominator="0" showAxis="1" barWidth="5" height="15" lineSizeScale="3x:0,0,0,0,0,0" maxScaleDenominator="1e+08" width="15" minimumSize="0" backgroundAlpha="255" diagramOrientation="Up" lineSizeType="MM" stackedDiagramMode="Horizontal" penColor="#000000" stackedDiagramSpacing="0" backgroundColor="#ffffff" direction="0" stackedDiagramSpacingUnitScale="3x:0,0,0,0,0,0" sizeType="MM" rotationOffset="270" enabled="0" penAlpha="255" scaleDependency="Area">
      <fontProperties description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" bold="0" strikethrough="0" style="" italic="0" underline="0"/>
      <attribute label="" colorOpacity="1" field="" color="#000000"/>
      <axisSymbol>
        <symbol name="" clip_to_extent="1" force_rhr="0" is_animated="0" frame_rate="10" alpha="1" type="line">
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <layer class="SimpleLine" enabled="1" locked="0" id="{66215d47-8831-45cb-bfe3-a29d8a30170e}" pass="0">
            <Option type="Map">
              <Option name="align_dash_pattern" value="0" type="QString"/>
              <Option name="capstyle" value="square" type="QString"/>
              <Option name="customdash" value="5;2" type="QString"/>
              <Option name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="customdash_unit" value="MM" type="QString"/>
              <Option name="dash_pattern_offset" value="0" type="QString"/>
              <Option name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="dash_pattern_offset_unit" value="MM" type="QString"/>
              <Option name="draw_inside_polygon" value="0" type="QString"/>
              <Option name="joinstyle" value="bevel" type="QString"/>
              <Option name="line_color" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" type="QString"/>
              <Option name="line_style" value="solid" type="QString"/>
              <Option name="line_width" value="0.26" type="QString"/>
              <Option name="line_width_unit" value="MM" type="QString"/>
              <Option name="offset" value="0" type="QString"/>
              <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="offset_unit" value="MM" type="QString"/>
              <Option name="ring_filter" value="0" type="QString"/>
              <Option name="trim_distance_end" value="0" type="QString"/>
              <Option name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="trim_distance_end_unit" value="MM" type="QString"/>
              <Option name="trim_distance_start" value="0" type="QString"/>
              <Option name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="trim_distance_start_unit" value="MM" type="QString"/>
              <Option name="tweak_dash_pattern_on_corners" value="0" type="QString"/>
              <Option name="use_custom_dash" value="0" type="QString"/>
              <Option name="width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </LinearlyInterpolatedDiagramRenderer>
  <DiagramLayerSettings priority="0" dist="0" zIndex="0" obstacle="0" placement="1" showAll="1" linePlacementFlags="18">
    <properties>
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties"/>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration type="Map">
      <Option name="QgsGeometryGapCheck" type="Map">
        <Option name="allowedGapsBuffer" value="0" type="double"/>
        <Option name="allowedGapsEnabled" value="false" type="bool"/>
        <Option name="allowedGapsLayer" value="" type="QString"/>
      </Option>
    </checkConfiguration>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field name="id" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="id_capa" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="nse" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="observacio" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="uh" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="codpred" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="via_princ" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="via_sec" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="placa" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="compl" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="direccion_final" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="direccion2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="dir_antigua" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="tipo_direccion" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="tipo_pred" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="inc_gnral" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="r_inc_gnral" configurationFlags="NoFlag">
      <editWidget type="Enumeration">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="inc_estd" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="r_inc_estd" configurationFlags="NoFlag">
      <editWidget type="Enumeration">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="inc_card" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="r_inc_card" configurationFlags="NoFlag">
      <editWidget type="Enumeration">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="inc_mzcs" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="r_inc_mzcs" configurationFlags="NoFlag">
      <editWidget type="Enumeration">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="inc_dup" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="duplicados" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="r_inc_dup" configurationFlags="NoFlag">
      <editWidget type="Enumeration">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="inc_cptud" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="r_inc_cptud" configurationFlags="NoFlag">
      <editWidget type="Enumeration">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="total_inc" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="porc_rev" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="estado" configurationFlags="NoFlag">
      <editWidget type="Enumeration">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="asignacion" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="observac_1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="fecha" configurationFlags="NoFlag">
      <editWidget type="DateTime">
        <config>
          <Option type="Map">
            <Option name="allow_null" value="true" type="bool"/>
            <Option name="calendar_popup" value="true" type="bool"/>
            <Option name="display_format" value="dd/MM/yyyy" type="QString"/>
            <Option name="field_format" value="yyyy-MM-dd" type="QString"/>
            <Option name="field_format_overwrite" value="false" type="bool"/>
            <Option name="field_iso_format" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="marca_actu" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="version" configurationFlags="NoFlag">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="inc_cod" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sv_marca1" configurationFlags="NoFlag">
      <editWidget type="Enumeration">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sv_marca2" configurationFlags="NoFlag">
      <editWidget type="Enumeration">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sv_fecha" configurationFlags="NoFlag">
      <editWidget type="DateTime">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sv_asignad" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sn_qa" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cc_revisar" configurationFlags="NoFlag">
      <editWidget type="Enumeration">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cc_fecha" configurationFlags="NoFlag">
      <editWidget type="DateTime">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="tipo_predio" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dg_fecha" configurationFlags="NoFlag">
      <editWidget type="DateTime">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="observaciones" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" field="id" index="0"/>
    <alias name="" field="id_capa" index="1"/>
    <alias name="" field="nse" index="2"/>
    <alias name="" field="observacio" index="3"/>
    <alias name="" field="uh" index="4"/>
    <alias name="" field="codpred" index="5"/>
    <alias name="" field="via_princ" index="6"/>
    <alias name="" field="via_sec" index="7"/>
    <alias name="" field="placa" index="8"/>
    <alias name="" field="compl" index="9"/>
    <alias name="" field="direccion_final" index="10"/>
    <alias name="" field="direccion2" index="11"/>
    <alias name="" field="dir_antigua" index="12"/>
    <alias name="" field="tipo_direccion" index="13"/>
    <alias name="" field="tipo_pred" index="14"/>
    <alias name="" field="inc_gnral" index="15"/>
    <alias name="" field="r_inc_gnral" index="16"/>
    <alias name="" field="inc_estd" index="17"/>
    <alias name="" field="r_inc_estd" index="18"/>
    <alias name="" field="inc_card" index="19"/>
    <alias name="" field="r_inc_card" index="20"/>
    <alias name="" field="inc_mzcs" index="21"/>
    <alias name="" field="r_inc_mzcs" index="22"/>
    <alias name="" field="inc_dup" index="23"/>
    <alias name="" field="duplicados" index="24"/>
    <alias name="" field="r_inc_dup" index="25"/>
    <alias name="" field="inc_cptud" index="26"/>
    <alias name="" field="r_inc_cptud" index="27"/>
    <alias name="" field="total_inc" index="28"/>
    <alias name="" field="porc_rev" index="29"/>
    <alias name="" field="estado" index="30"/>
    <alias name="" field="asignacion" index="31"/>
    <alias name="" field="observac_1" index="32"/>
    <alias name="" field="fecha" index="33"/>
    <alias name="" field="marca_actu" index="34"/>
    <alias name="" field="version" index="35"/>
    <alias name="" field="inc_cod" index="36"/>
    <alias name="" field="sv_marca1" index="37"/>
    <alias name="" field="sv_marca2" index="38"/>
    <alias name="" field="sv_fecha" index="39"/>
    <alias name="" field="sv_asignad" index="40"/>
    <alias name="" field="sn_qa" index="41"/>
    <alias name="" field="cc_revisar" index="42"/>
    <alias name="" field="cc_fecha" index="43"/>
    <alias name="" field="tipo_predio" index="44"/>
    <alias name="" field="dg_fecha" index="45"/>
    <alias name="" field="observaciones" index="46"/>
  </aliases>
  <defaults>
    <default expression="" field="id" applyOnUpdate="0"/>
    <default expression="" field="id_capa" applyOnUpdate="0"/>
    <default expression="" field="nse" applyOnUpdate="0"/>
    <default expression="" field="observacio" applyOnUpdate="0"/>
    <default expression="" field="uh" applyOnUpdate="0"/>
    <default expression="" field="codpred" applyOnUpdate="0"/>
    <default expression="" field="via_princ" applyOnUpdate="0"/>
    <default expression="" field="via_sec" applyOnUpdate="0"/>
    <default expression="" field="placa" applyOnUpdate="0"/>
    <default expression="" field="compl" applyOnUpdate="0"/>
    <default expression="" field="direccion_final" applyOnUpdate="0"/>
    <default expression="" field="direccion2" applyOnUpdate="0"/>
    <default expression="" field="dir_antigua" applyOnUpdate="0"/>
    <default expression="" field="tipo_direccion" applyOnUpdate="0"/>
    <default expression="" field="tipo_pred" applyOnUpdate="0"/>
    <default expression="" field="inc_gnral" applyOnUpdate="0"/>
    <default expression="" field="r_inc_gnral" applyOnUpdate="0"/>
    <default expression="" field="inc_estd" applyOnUpdate="0"/>
    <default expression="" field="r_inc_estd" applyOnUpdate="0"/>
    <default expression="" field="inc_card" applyOnUpdate="0"/>
    <default expression="" field="r_inc_card" applyOnUpdate="0"/>
    <default expression="" field="inc_mzcs" applyOnUpdate="0"/>
    <default expression="" field="r_inc_mzcs" applyOnUpdate="0"/>
    <default expression="" field="inc_dup" applyOnUpdate="0"/>
    <default expression="" field="duplicados" applyOnUpdate="0"/>
    <default expression="" field="r_inc_dup" applyOnUpdate="0"/>
    <default expression="" field="inc_cptud" applyOnUpdate="0"/>
    <default expression="" field="r_inc_cptud" applyOnUpdate="0"/>
    <default expression="" field="total_inc" applyOnUpdate="0"/>
    <default expression="" field="porc_rev" applyOnUpdate="0"/>
    <default expression="" field="estado" applyOnUpdate="0"/>
    <default expression="" field="asignacion" applyOnUpdate="0"/>
    <default expression="" field="observac_1" applyOnUpdate="0"/>
    <default expression="" field="fecha" applyOnUpdate="0"/>
    <default expression="" field="marca_actu" applyOnUpdate="0"/>
    <default expression="'V1-25'" field="version" applyOnUpdate="0"/>
    <default expression="" field="inc_cod" applyOnUpdate="0"/>
    <default expression="" field="sv_marca1" applyOnUpdate="0"/>
    <default expression="" field="sv_marca2" applyOnUpdate="0"/>
    <default expression="" field="sv_fecha" applyOnUpdate="0"/>
    <default expression="" field="sv_asignad" applyOnUpdate="0"/>
    <default expression="" field="sn_qa" applyOnUpdate="0"/>
    <default expression="" field="cc_revisar" applyOnUpdate="0"/>
    <default expression="" field="cc_fecha" applyOnUpdate="0"/>
    <default expression="" field="tipo_predio" applyOnUpdate="0"/>
    <default expression="" field="dg_fecha" applyOnUpdate="0"/>
    <default expression="" field="observaciones" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint constraints="3" unique_strength="1" exp_strength="0" field="id" notnull_strength="1"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="id_capa" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="nse" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="observacio" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="uh" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="codpred" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="via_princ" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="via_sec" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="placa" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="compl" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="direccion_final" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="direccion2" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="dir_antigua" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="tipo_direccion" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="tipo_pred" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="inc_gnral" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="r_inc_gnral" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="inc_estd" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="r_inc_estd" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="inc_card" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="r_inc_card" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="inc_mzcs" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="r_inc_mzcs" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="inc_dup" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="duplicados" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="r_inc_dup" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="inc_cptud" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="r_inc_cptud" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="total_inc" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="porc_rev" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="estado" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="asignacion" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="observac_1" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="fecha" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="marca_actu" notnull_strength="0"/>
    <constraint constraints="6" unique_strength="1" exp_strength="2" field="version" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="inc_cod" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="sv_marca1" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="sv_marca2" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="sv_fecha" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="sv_asignad" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="sn_qa" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="cc_revisar" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="cc_fecha" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="tipo_predio" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="dg_fecha" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" field="observaciones" notnull_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="id"/>
    <constraint exp="" desc="" field="id_capa"/>
    <constraint exp="" desc="" field="nse"/>
    <constraint exp="" desc="" field="observacio"/>
    <constraint exp="" desc="" field="uh"/>
    <constraint exp="" desc="" field="codpred"/>
    <constraint exp="" desc="" field="via_princ"/>
    <constraint exp="" desc="" field="via_sec"/>
    <constraint exp="" desc="" field="placa"/>
    <constraint exp="" desc="" field="compl"/>
    <constraint exp="" desc="" field="direccion_final"/>
    <constraint exp="" desc="" field="direccion2"/>
    <constraint exp="" desc="" field="dir_antigua"/>
    <constraint exp="" desc="" field="tipo_direccion"/>
    <constraint exp="" desc="" field="tipo_pred"/>
    <constraint exp="" desc="" field="inc_gnral"/>
    <constraint exp="" desc="" field="r_inc_gnral"/>
    <constraint exp="" desc="" field="inc_estd"/>
    <constraint exp="" desc="" field="r_inc_estd"/>
    <constraint exp="" desc="" field="inc_card"/>
    <constraint exp="" desc="" field="r_inc_card"/>
    <constraint exp="" desc="" field="inc_mzcs"/>
    <constraint exp="" desc="" field="r_inc_mzcs"/>
    <constraint exp="" desc="" field="inc_dup"/>
    <constraint exp="" desc="" field="duplicados"/>
    <constraint exp="" desc="" field="r_inc_dup"/>
    <constraint exp="" desc="" field="inc_cptud"/>
    <constraint exp="" desc="" field="r_inc_cptud"/>
    <constraint exp="" desc="" field="total_inc"/>
    <constraint exp="" desc="" field="porc_rev"/>
    <constraint exp="" desc="" field="estado"/>
    <constraint exp="" desc="" field="asignacion"/>
    <constraint exp="" desc="" field="observac_1"/>
    <constraint exp="" desc="" field="fecha"/>
    <constraint exp="" desc="" field="marca_actu"/>
    <constraint exp="'V1-25'" desc="" field="version"/>
    <constraint exp="" desc="" field="inc_cod"/>
    <constraint exp="" desc="" field="sv_marca1"/>
    <constraint exp="" desc="" field="sv_marca2"/>
    <constraint exp="" desc="" field="sv_fecha"/>
    <constraint exp="" desc="" field="sv_asignad"/>
    <constraint exp="" desc="" field="sn_qa"/>
    <constraint exp="" desc="" field="cc_revisar"/>
    <constraint exp="" desc="" field="cc_fecha"/>
    <constraint exp="" desc="" field="tipo_predio"/>
    <constraint exp="" desc="" field="dg_fecha"/>
    <constraint exp="" desc="" field="observaciones"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
  </attributeactions>
  <attributetableconfig sortOrder="0" sortExpression="&quot;fecha&quot;" actionWidgetStyle="dropDown">
    <columns>
      <column name="id" hidden="0" type="field" width="-1"/>
      <column name="id_capa" hidden="0" type="field" width="-1"/>
      <column name="nse" hidden="0" type="field" width="-1"/>
      <column name="observacio" hidden="0" type="field" width="-1"/>
      <column name="uh" hidden="0" type="field" width="-1"/>
      <column name="codpred" hidden="0" type="field" width="-1"/>
      <column name="marca_actu" hidden="0" type="field" width="-1"/>
      <column name="fecha" hidden="0" type="field" width="-1"/>
      <column name="version" hidden="0" type="field" width="-1"/>
      <column name="via_princ" hidden="0" type="field" width="149"/>
      <column name="via_sec" hidden="0" type="field" width="-1"/>
      <column name="placa" hidden="0" type="field" width="-1"/>
      <column name="compl" hidden="0" type="field" width="258"/>
      <column name="direccion_final" hidden="0" type="field" width="184"/>
      <column name="direccion2" hidden="0" type="field" width="311"/>
      <column name="dir_antigua" hidden="0" type="field" width="213"/>
      <column name="tipo_direccion" hidden="0" type="field" width="-1"/>
      <column name="tipo_predio" hidden="0" type="field" width="-1"/>
      <column name="duplicados" hidden="0" type="field" width="-1"/>
      <column name="observaciones" hidden="0" type="field" width="-1"/>
      <column name="tipo_pred" hidden="0" type="field" width="-1"/>
      <column name="inc_gnral" hidden="0" type="field" width="-1"/>
      <column name="r_inc_gnral" hidden="0" type="field" width="-1"/>
      <column name="inc_estd" hidden="0" type="field" width="-1"/>
      <column name="r_inc_estd" hidden="0" type="field" width="-1"/>
      <column name="inc_card" hidden="0" type="field" width="284"/>
      <column name="r_inc_card" hidden="0" type="field" width="-1"/>
      <column name="inc_mzcs" hidden="0" type="field" width="-1"/>
      <column name="r_inc_mzcs" hidden="0" type="field" width="-1"/>
      <column name="inc_dup" hidden="0" type="field" width="-1"/>
      <column name="r_inc_dup" hidden="0" type="field" width="-1"/>
      <column name="inc_cptud" hidden="0" type="field" width="-1"/>
      <column name="r_inc_cptud" hidden="0" type="field" width="-1"/>
      <column name="total_inc" hidden="0" type="field" width="-1"/>
      <column name="porc_rev" hidden="0" type="field" width="-1"/>
      <column name="estado" hidden="0" type="field" width="-1"/>
      <column name="asignacion" hidden="0" type="field" width="-1"/>
      <column name="observac_1" hidden="0" type="field" width="-1"/>
      <column name="inc_cod" hidden="0" type="field" width="-1"/>
      <column name="sv_marca1" hidden="0" type="field" width="-1"/>
      <column name="sv_marca2" hidden="0" type="field" width="-1"/>
      <column name="sv_fecha" hidden="0" type="field" width="-1"/>
      <column name="sv_asignad" hidden="0" type="field" width="-1"/>
      <column name="sn_qa" hidden="0" type="field" width="-1"/>
      <column name="cc_revisar" hidden="0" type="field" width="-1"/>
      <column name="cc_fecha" hidden="0" type="field" width="-1"/>
      <column name="dg_fecha" hidden="0" type="field" width="-1"/>
      <column hidden="1" type="actions" width="-1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[QGISQGIS# -*- coding: utf-8 -*-
"""
Los formularios QGIS pueden tener una función de Python a la que se llama cuando el formulario es abierto.

Utilice esta función para agregar lógica adicional a sus formularios.

Ingrese el nombre de la función en el campo"Función de inicio de Python" .
A continuación se muestra un ejemplo:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="Fecha" editable="1"/>
    <field name="Marca" editable="1"/>
    <field name="Version" editable="1"/>
    <field name="asignacion" editable="1"/>
    <field name="asignacion_dup" editable="1"/>
    <field name="asignacion_est" editable="1"/>
    <field name="asignacion_mavvial_sec" editable="1"/>
    <field name="asignacion_par_impar" editable="1"/>
    <field name="asignacion_val_mavvial" editable="1"/>
    <field name="asignacion_vec" editable="1"/>
    <field name="cc_fecha" editable="1"/>
    <field name="cc_revisar" editable="1"/>
    <field name="ciudad" editable="1"/>
    <field name="cod_mun1" editable="1"/>
    <field name="codman" editable="1"/>
    <field name="codpred" editable="1"/>
    <field name="codpred_2023" editable="1"/>
    <field name="codv2_2021" editable="1"/>
    <field name="compl" editable="1"/>
    <field name="cx" editable="1"/>
    <field name="cy" editable="1"/>
    <field name="dane" editable="1"/>
    <field name="dg_fecha" editable="1"/>
    <field name="dir1" editable="1"/>
    <field name="dir2" editable="1"/>
    <field name="dir_antigua" editable="1"/>
    <field name="direccion" editable="1"/>
    <field name="direccion1" editable="1"/>
    <field name="direccion2" editable="1"/>
    <field name="direccion_final" editable="1"/>
    <field name="dirmzcasa" editable="1"/>
    <field name="dirorigina" editable="1"/>
    <field name="duplicados" editable="1"/>
    <field name="estado" editable="1"/>
    <field name="fecha" editable="1"/>
    <field name="fecha_par_impar" editable="1"/>
    <field name="fecha_rev_dup" editable="1"/>
    <field name="fecha_rev_est" editable="1"/>
    <field name="fecha_val_mavvial" editable="1"/>
    <field name="fecha_val_mavvial_sec" editable="1"/>
    <field name="fecha_vec" editable="1"/>
    <field name="id" editable="1"/>
    <field name="id_capa" editable="1"/>
    <field name="id_unico" editable="1"/>
    <field name="igac" editable="1"/>
    <field name="igacanteri" editable="1"/>
    <field name="inc_card" editable="1"/>
    <field name="inc_cod" editable="1"/>
    <field name="inc_cptud" editable="1"/>
    <field name="inc_dup" editable="1"/>
    <field name="inc_estd" editable="1"/>
    <field name="inc_gnral" editable="1"/>
    <field name="inc_mzcs" editable="1"/>
    <field name="inconsistencias_dup" editable="1"/>
    <field name="inconsistencias_est" editable="1"/>
    <field name="inconsistencias_gen" editable="1"/>
    <field name="inconsistencias_vec" editable="1"/>
    <field name="manzana_co" editable="1"/>
    <field name="marca_actu" editable="1"/>
    <field name="municipio" editable="1"/>
    <field name="municipio1" editable="1"/>
    <field name="nivsocio1" editable="1"/>
    <field name="nse" editable="1"/>
    <field name="obs_cod" editable="1"/>
    <field name="observac_1" editable="1"/>
    <field name="observacio" editable="1"/>
    <field name="observaciones" editable="1"/>
    <field name="osp_dir" editable="1"/>
    <field name="para_proce" editable="1"/>
    <field name="placa" editable="1"/>
    <field name="porc_rev" editable="1"/>
    <field name="r_inc_card" editable="1"/>
    <field name="r_inc_cptud" editable="1"/>
    <field name="r_inc_dup" editable="1"/>
    <field name="r_inc_estd" editable="1"/>
    <field name="r_inc_gnral" editable="1"/>
    <field name="r_inc_mzcs" editable="1"/>
    <field name="resultado_dup" editable="1"/>
    <field name="resultado_est" editable="1"/>
    <field name="resultado_mavvial_sec" editable="1"/>
    <field name="resultado_par_impar" editable="1"/>
    <field name="resultado_val_mavvial" editable="1"/>
    <field name="resultado_vec" editable="1"/>
    <field name="sn_qa" editable="1"/>
    <field name="sv_asignad" editable="1"/>
    <field name="sv_fecha" editable="1"/>
    <field name="sv_marca1" editable="1"/>
    <field name="sv_marca2" editable="1"/>
    <field name="tipo_costado" editable="1"/>
    <field name="tipo_direccion" editable="1"/>
    <field name="tipo_pred" editable="1"/>
    <field name="tipo_predio" editable="1"/>
    <field name="total_inc" editable="1"/>
    <field name="uh" editable="1"/>
    <field name="val_mavvial_princ" editable="1"/>
    <field name="val_mavvial_sec" editable="1"/>
    <field name="version" editable="1"/>
    <field name="via_princ" editable="1"/>
    <field name="via_sec" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="Fecha" labelOnTop="0"/>
    <field name="Marca" labelOnTop="0"/>
    <field name="Version" labelOnTop="0"/>
    <field name="asignacion" labelOnTop="0"/>
    <field name="asignacion_dup" labelOnTop="0"/>
    <field name="asignacion_est" labelOnTop="0"/>
    <field name="asignacion_mavvial_sec" labelOnTop="0"/>
    <field name="asignacion_par_impar" labelOnTop="0"/>
    <field name="asignacion_val_mavvial" labelOnTop="0"/>
    <field name="asignacion_vec" labelOnTop="0"/>
    <field name="cc_fecha" labelOnTop="0"/>
    <field name="cc_revisar" labelOnTop="0"/>
    <field name="ciudad" labelOnTop="0"/>
    <field name="cod_mun1" labelOnTop="0"/>
    <field name="codman" labelOnTop="0"/>
    <field name="codpred" labelOnTop="0"/>
    <field name="codpred_2023" labelOnTop="0"/>
    <field name="codv2_2021" labelOnTop="0"/>
    <field name="compl" labelOnTop="0"/>
    <field name="cx" labelOnTop="0"/>
    <field name="cy" labelOnTop="0"/>
    <field name="dane" labelOnTop="0"/>
    <field name="dg_fecha" labelOnTop="0"/>
    <field name="dir1" labelOnTop="0"/>
    <field name="dir2" labelOnTop="0"/>
    <field name="dir_antigua" labelOnTop="0"/>
    <field name="direccion" labelOnTop="0"/>
    <field name="direccion1" labelOnTop="0"/>
    <field name="direccion2" labelOnTop="0"/>
    <field name="direccion_final" labelOnTop="0"/>
    <field name="dirmzcasa" labelOnTop="0"/>
    <field name="dirorigina" labelOnTop="0"/>
    <field name="duplicados" labelOnTop="0"/>
    <field name="estado" labelOnTop="0"/>
    <field name="fecha" labelOnTop="0"/>
    <field name="fecha_par_impar" labelOnTop="0"/>
    <field name="fecha_rev_dup" labelOnTop="0"/>
    <field name="fecha_rev_est" labelOnTop="0"/>
    <field name="fecha_val_mavvial" labelOnTop="0"/>
    <field name="fecha_val_mavvial_sec" labelOnTop="0"/>
    <field name="fecha_vec" labelOnTop="0"/>
    <field name="id" labelOnTop="0"/>
    <field name="id_capa" labelOnTop="0"/>
    <field name="id_unico" labelOnTop="0"/>
    <field name="igac" labelOnTop="0"/>
    <field name="igacanteri" labelOnTop="0"/>
    <field name="inc_card" labelOnTop="0"/>
    <field name="inc_cod" labelOnTop="0"/>
    <field name="inc_cptud" labelOnTop="0"/>
    <field name="inc_dup" labelOnTop="0"/>
    <field name="inc_estd" labelOnTop="0"/>
    <field name="inc_gnral" labelOnTop="0"/>
    <field name="inc_mzcs" labelOnTop="0"/>
    <field name="inconsistencias_dup" labelOnTop="0"/>
    <field name="inconsistencias_est" labelOnTop="0"/>
    <field name="inconsistencias_gen" labelOnTop="0"/>
    <field name="inconsistencias_vec" labelOnTop="0"/>
    <field name="manzana_co" labelOnTop="0"/>
    <field name="marca_actu" labelOnTop="0"/>
    <field name="municipio" labelOnTop="0"/>
    <field name="municipio1" labelOnTop="0"/>
    <field name="nivsocio1" labelOnTop="0"/>
    <field name="nse" labelOnTop="0"/>
    <field name="obs_cod" labelOnTop="0"/>
    <field name="observac_1" labelOnTop="0"/>
    <field name="observacio" labelOnTop="0"/>
    <field name="observaciones" labelOnTop="0"/>
    <field name="osp_dir" labelOnTop="0"/>
    <field name="para_proce" labelOnTop="0"/>
    <field name="placa" labelOnTop="0"/>
    <field name="porc_rev" labelOnTop="0"/>
    <field name="r_inc_card" labelOnTop="0"/>
    <field name="r_inc_cptud" labelOnTop="0"/>
    <field name="r_inc_dup" labelOnTop="0"/>
    <field name="r_inc_estd" labelOnTop="0"/>
    <field name="r_inc_gnral" labelOnTop="0"/>
    <field name="r_inc_mzcs" labelOnTop="0"/>
    <field name="resultado_dup" labelOnTop="0"/>
    <field name="resultado_est" labelOnTop="0"/>
    <field name="resultado_mavvial_sec" labelOnTop="0"/>
    <field name="resultado_par_impar" labelOnTop="0"/>
    <field name="resultado_val_mavvial" labelOnTop="0"/>
    <field name="resultado_vec" labelOnTop="0"/>
    <field name="sn_qa" labelOnTop="0"/>
    <field name="sv_asignad" labelOnTop="0"/>
    <field name="sv_fecha" labelOnTop="0"/>
    <field name="sv_marca1" labelOnTop="0"/>
    <field name="sv_marca2" labelOnTop="0"/>
    <field name="tipo_costado" labelOnTop="0"/>
    <field name="tipo_direccion" labelOnTop="0"/>
    <field name="tipo_pred" labelOnTop="0"/>
    <field name="tipo_predio" labelOnTop="0"/>
    <field name="total_inc" labelOnTop="0"/>
    <field name="uh" labelOnTop="0"/>
    <field name="val_mavvial_princ" labelOnTop="0"/>
    <field name="val_mavvial_sec" labelOnTop="0"/>
    <field name="version" labelOnTop="0"/>
    <field name="via_princ" labelOnTop="0"/>
    <field name="via_sec" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="Fecha" reuseLastValue="0"/>
    <field name="Marca" reuseLastValue="0"/>
    <field name="Version" reuseLastValue="0"/>
    <field name="asignacion" reuseLastValue="0"/>
    <field name="asignacion_dup" reuseLastValue="0"/>
    <field name="asignacion_est" reuseLastValue="0"/>
    <field name="asignacion_mavvial_sec" reuseLastValue="0"/>
    <field name="asignacion_par_impar" reuseLastValue="0"/>
    <field name="asignacion_val_mavvial" reuseLastValue="0"/>
    <field name="asignacion_vec" reuseLastValue="0"/>
    <field name="cc_fecha" reuseLastValue="0"/>
    <field name="cc_revisar" reuseLastValue="0"/>
    <field name="ciudad" reuseLastValue="0"/>
    <field name="cod_mun1" reuseLastValue="0"/>
    <field name="codman" reuseLastValue="0"/>
    <field name="codpred" reuseLastValue="0"/>
    <field name="codpred_2023" reuseLastValue="0"/>
    <field name="codv2_2021" reuseLastValue="0"/>
    <field name="compl" reuseLastValue="0"/>
    <field name="cx" reuseLastValue="0"/>
    <field name="cy" reuseLastValue="0"/>
    <field name="dane" reuseLastValue="0"/>
    <field name="dg_fecha" reuseLastValue="0"/>
    <field name="dir1" reuseLastValue="0"/>
    <field name="dir2" reuseLastValue="0"/>
    <field name="dir_antigua" reuseLastValue="0"/>
    <field name="direccion" reuseLastValue="0"/>
    <field name="direccion1" reuseLastValue="0"/>
    <field name="direccion2" reuseLastValue="0"/>
    <field name="direccion_final" reuseLastValue="0"/>
    <field name="dirmzcasa" reuseLastValue="0"/>
    <field name="dirorigina" reuseLastValue="0"/>
    <field name="duplicados" reuseLastValue="0"/>
    <field name="estado" reuseLastValue="0"/>
    <field name="fecha" reuseLastValue="0"/>
    <field name="fecha_par_impar" reuseLastValue="0"/>
    <field name="fecha_rev_dup" reuseLastValue="0"/>
    <field name="fecha_rev_est" reuseLastValue="0"/>
    <field name="fecha_val_mavvial" reuseLastValue="0"/>
    <field name="fecha_val_mavvial_sec" reuseLastValue="0"/>
    <field name="fecha_vec" reuseLastValue="0"/>
    <field name="id" reuseLastValue="0"/>
    <field name="id_capa" reuseLastValue="0"/>
    <field name="id_unico" reuseLastValue="0"/>
    <field name="igac" reuseLastValue="0"/>
    <field name="igacanteri" reuseLastValue="0"/>
    <field name="inc_card" reuseLastValue="0"/>
    <field name="inc_cod" reuseLastValue="0"/>
    <field name="inc_cptud" reuseLastValue="0"/>
    <field name="inc_dup" reuseLastValue="0"/>
    <field name="inc_estd" reuseLastValue="0"/>
    <field name="inc_gnral" reuseLastValue="0"/>
    <field name="inc_mzcs" reuseLastValue="0"/>
    <field name="inconsistencias_dup" reuseLastValue="0"/>
    <field name="inconsistencias_est" reuseLastValue="0"/>
    <field name="inconsistencias_gen" reuseLastValue="0"/>
    <field name="inconsistencias_vec" reuseLastValue="0"/>
    <field name="manzana_co" reuseLastValue="0"/>
    <field name="marca_actu" reuseLastValue="0"/>
    <field name="municipio" reuseLastValue="0"/>
    <field name="municipio1" reuseLastValue="0"/>
    <field name="nivsocio1" reuseLastValue="0"/>
    <field name="nse" reuseLastValue="0"/>
    <field name="obs_cod" reuseLastValue="0"/>
    <field name="observac_1" reuseLastValue="0"/>
    <field name="observacio" reuseLastValue="0"/>
    <field name="observaciones" reuseLastValue="0"/>
    <field name="osp_dir" reuseLastValue="0"/>
    <field name="para_proce" reuseLastValue="0"/>
    <field name="placa" reuseLastValue="0"/>
    <field name="porc_rev" reuseLastValue="0"/>
    <field name="r_inc_card" reuseLastValue="0"/>
    <field name="r_inc_cptud" reuseLastValue="0"/>
    <field name="r_inc_dup" reuseLastValue="0"/>
    <field name="r_inc_estd" reuseLastValue="0"/>
    <field name="r_inc_gnral" reuseLastValue="0"/>
    <field name="r_inc_mzcs" reuseLastValue="0"/>
    <field name="resultado_dup" reuseLastValue="0"/>
    <field name="resultado_est" reuseLastValue="0"/>
    <field name="resultado_mavvial_sec" reuseLastValue="0"/>
    <field name="resultado_par_impar" reuseLastValue="0"/>
    <field name="resultado_val_mavvial" reuseLastValue="0"/>
    <field name="resultado_vec" reuseLastValue="0"/>
    <field name="sn_qa" reuseLastValue="0"/>
    <field name="sv_asignad" reuseLastValue="0"/>
    <field name="sv_fecha" reuseLastValue="0"/>
    <field name="sv_marca1" reuseLastValue="0"/>
    <field name="sv_marca2" reuseLastValue="0"/>
    <field name="tipo_costado" reuseLastValue="0"/>
    <field name="tipo_direccion" reuseLastValue="0"/>
    <field name="tipo_pred" reuseLastValue="0"/>
    <field name="tipo_predio" reuseLastValue="0"/>
    <field name="total_inc" reuseLastValue="0"/>
    <field name="uh" reuseLastValue="0"/>
    <field name="val_mavvial_princ" reuseLastValue="0"/>
    <field name="val_mavvial_sec" reuseLastValue="0"/>
    <field name="version" reuseLastValue="0"/>
    <field name="via_princ" reuseLastValue="0"/>
    <field name="via_sec" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"dane"</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
