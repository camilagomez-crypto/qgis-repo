# -*- coding: utf-8 -*-
"""
StyleChooserDialog
==================
Ventana modal que le pregunta al usuario qué quiere hacer con el estilo
de una entrada:

  - OPCIÓN A: Escoger un .qml existente  →  abre explorador de archivos.
  - OPCIÓN B: Crear un estilo nuevo       →  abre el editor nativo de QGIS
              sobre la capa indicada, y al cerrar guarda el resultado como
              <entry_id>_custom.qml en styles/.

Uso:
    dlg = StyleChooserDialog(iface, entry_id, layer, parent=self)
    result = dlg.exec_()          # QDialog.Accepted / Rejected
    if result == QDialog.Accepted:
        path = dlg.chosen_path    # ruta absoluta al .qml resultante
"""

import os
import re

from qgis.PyQt.QtCore import Qt, QSize
from qgis.PyQt.QtGui import QIcon, QFont
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFileDialog, QMessageBox, QFrame, QSizePolicy,
)

from . import config as cfg
from . import theme

PLUGIN_DIR = os.path.dirname(__file__)


class StyleChooserDialog(QDialog):
    """
    Devuelve el .qml elegido o creado en ``self.chosen_path``.
    ``layer`` puede ser None; en ese caso la opción "Crear nuevo" queda
    deshabilitada con un aviso.
    """

    def __init__(self, iface, entry_id, entry_label, layer, parent=None):
        super().__init__(parent)
        self.iface        = iface
        self.entry_id     = entry_id
        self.entry_label  = entry_label
        self.layer        = layer
        self.chosen_path  = ""          # resultado final

        self.setWindowTitle("Asignar estilo — {}".format(entry_label))
        self.setMinimumWidth(420)
        self.setStyleSheet(theme.stylesheet())
        self._build_ui()

    # ------------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)

        # Título
        title = QLabel("¿Qué quieres hacer con el estilo\nde <b>{}</b>?".format(
            self.entry_label))
        title.setAlignment(Qt.AlignCenter)
        title.setWordWrap(True)
        font = QFont()
        font.setPointSize(11)
        title.setFont(font)
        layout.addWidget(title)

        # Separador
        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setFrameShadow(QFrame.Sunken)
        layout.addWidget(sep)

        # --- Botón A: estilo existente ---
        btn_existing = QPushButton("  Escoger estilo existente (.qml)")
        btn_existing.setObjectName("Primary")
        btn_existing.setMinimumHeight(48)
        folder_icon_path = os.path.join(PLUGIN_DIR, "icon.svg")
        from qgis.PyQt.QtWidgets import QStyle
        btn_existing.setIcon(
            self.style().standardIcon(QStyle.SP_DirOpenIcon)
        )
        btn_existing.setIconSize(QSize(20, 20))
        btn_existing.setToolTip("Buscar un archivo .qml ya existente en tu equipo.")
        btn_existing.clicked.connect(self._pick_existing)
        layout.addWidget(btn_existing)

        # Descripción A
        desc_a = QLabel("Abre el explorador para seleccionar un archivo .qml "
                        "que ya tengas guardado.")
        desc_a.setObjectName("HintLabel")
        desc_a.setWordWrap(True)
        layout.addWidget(desc_a)

        # Espacio
        layout.addSpacing(6)

        # --- Botón B: crear nuevo ---
        pencil_path = os.path.join(PLUGIN_DIR, "pencil.svg")
        btn_new = QPushButton("  Crear estilo nuevo con el editor de QGIS")
        btn_new.setObjectName("Accent")
        btn_new.setMinimumHeight(48)
        if os.path.isfile(pencil_path):
            btn_new.setIcon(QIcon(pencil_path))
            btn_new.setIconSize(QSize(20, 20))
        btn_new.setToolTip(
            "Abre el editor de simbología nativo de QGIS.\n"
            "Al cerrar, el estilo se guarda en styles/ y queda vinculado."
        )
        if self.layer is None:
            btn_new.setEnabled(False)
            btn_new.setToolTip(
                "Primero selecciona una capa en la fila para poder editar su estilo."
            )
        btn_new.clicked.connect(self._create_new)
        layout.addWidget(btn_new)

        # Descripción B
        desc_b = QLabel(
            "Diseña el estilo desde cero usando el editor completo de QGIS "
            "(simbología, reglas, etiquetas…). "
            "El resultado se guarda automáticamente en la biblioteca del plugin."
        )
        desc_b.setObjectName("HintLabel")
        desc_b.setWordWrap(True)
        layout.addWidget(desc_b)

        layout.addStretch()

        # Cancelar
        sep2 = QFrame()
        sep2.setFrameShape(QFrame.HLine)
        sep2.setFrameShadow(QFrame.Sunken)
        layout.addWidget(sep2)

        cancel_row = QHBoxLayout()
        cancel_row.addStretch()
        btn_cancel = QPushButton("Cancelar")
        btn_cancel.clicked.connect(self.reject)
        cancel_row.addWidget(btn_cancel)
        layout.addLayout(cancel_row)

    # ------------------------------------------------------------------
    def _pick_existing(self):
        """Opción A: explorador de archivos."""
        path, _ = QFileDialog.getOpenFileName(
            self, "Seleccionar estilo .qml", "", "Estilos QGIS (*.qml)"
        )
        if not path:
            return          # usuario canceló, no cerrar el diálogo
        self.chosen_path = path
        self.accept()

    # ------------------------------------------------------------------
    def _create_new(self):
        """Opción B: editor nativo de QGIS + exportar .qml a styles/."""
        layer = self.layer

        # Backup del renderer actual
        renderer_backup = layer.renderer().clone() if layer.renderer() else None

        # Abrir editor nativo (puede ser no-modal en algunas versiones)
        self.iface.showLayerProperties(layer)

        # Preguntar si guardar
        resp = QMessageBox.question(
            self,
            "Guardar estilo",
            "¿Guardar el estilo que acabas de diseñar como estilo "
            "personalizado de <b>{}</b>?<br><br>"
            "Se exportará a <i>styles/</i> y quedará disponible "
            "en futuros proyectos.".format(self.entry_label),
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes,
        )

        if resp == QMessageBox.Yes:
            ok, path, msg = _export_style(layer, self.entry_id)
            if ok:
                self.chosen_path = path
                self.accept()
            else:
                QMessageBox.warning(self, "Gestor de Estilos",
                                    "No se pudo guardar el estilo:\n{}".format(msg))
        else:
            # Revertir cambios en la capa
            if renderer_backup is not None:
                layer.setRenderer(renderer_backup)
                layer.triggerRepaint()


# ----------------------------------------------------------------------
# Utilidad compartida: exportar estilo de una capa a styles/
# ----------------------------------------------------------------------
def _export_style(layer, entry_id):
    """
    Exporta el estilo actual de la capa como <entry_id>_custom.qml
    en la carpeta styles/ del plugin.
    Devuelve (ok: bool, ruta: str, mensaje: str).
    """
    nombre = re.sub(r"[^\w\-]", "_", entry_id.lower()) + "_custom.qml"
    destino = os.path.join(cfg.STYLES_DIR, nombre)

    ok = False
    mensaje = ""

    # Intento 1: saveNamedStyle (el más fiable en QGIS 3.x)
    try:
        mensaje, ok = layer.saveNamedStyle(destino)
    except Exception as e:
        mensaje = str(e)

    # Intento 2: writeStyleFile
    if not ok:
        try:
            ok = layer.writeStyleFile(destino)
        except Exception:
            pass

    # Intento 3: writeStyle + QDomDocument
    if not ok:
        try:
            from qgis.PyQt.QtXml import QDomDocument
            from qgis.core import QgsReadWriteContext
            doc = QDomDocument()
            root = doc.createElement("qgis")
            doc.appendChild(root)
            err = ""
            layer.writeStyle(root, doc, err, QgsReadWriteContext())
            with open(destino, "w", encoding="utf-8") as fh:
                fh.write(doc.toString(2))
            ok = True
        except Exception as e:
            return False, "", "No se pudo exportar el estilo: {}".format(e)

    if not ok:
        return False, "", "No se pudo guardar el archivo: {}".format(mensaje)

    return True, destino, ""
