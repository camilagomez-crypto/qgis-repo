def classFactory(iface):
    from .plugin import GestorEstilosPlugin
    return GestorEstilosPlugin(iface)
