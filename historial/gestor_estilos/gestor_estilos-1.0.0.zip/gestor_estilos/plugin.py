# -*- coding: utf-8 -*-
"""
Punto de entrada del plugin "Gestor de Estilos".

Registra un icono (pincel) en la barra de herramientas y una entrada de menu.
Al activarlo abre el dialogo principal.
"""

import os

from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

from .dialog import GestorEstilosDialog

PLUGIN_DIR = os.path.dirname(__file__)
MENU_NAME = "Gestor de Estilos"


class GestorEstilosPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None

    def tr(self, text):
        return QCoreApplication.translate("GestorEstilos", text)

    def initGui(self):
        icon_path = os.path.join(PLUGIN_DIR, "icon.svg")
        icon = QIcon(icon_path) if os.path.isfile(icon_path) else QIcon()

        self.action = QAction(icon, self.tr("Gestor de Estilos"), self.iface.mainWindow())
        self.action.setToolTip(self.tr("Aplicar estilos a capas por prefijo"))
        self.action.triggered.connect(self.run)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(self.tr(MENU_NAME), self.action)

    def unload(self):
        if self.action:
            self.iface.removePluginMenu(self.tr(MENU_NAME), self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action = None
        if self.dialog:
            self.dialog.close()
            self.dialog = None

    def run(self):
        if self.dialog is None:
            self.dialog = GestorEstilosDialog(self.iface, self.iface.mainWindow())
        self.dialog.reload_from_config()
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
