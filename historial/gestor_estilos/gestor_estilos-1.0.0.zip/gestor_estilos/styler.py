# -*- coding: utf-8 -*-
"""
Logica de aplicacion de estilos y autodeteccion de capas por prefijo.

- find_layers_by_prefix: busca capas vectoriales cuyo nombre empiece por un prefijo.
- apply_qml: aplica un archivo .qml a una capa.
- apply_inconsistencias: reproduce la logica de Estilo_inconsistencias.py
  (renderer basado en reglas por familia inc_* y campos revisados r_* en transparente).
"""

import os

from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsRuleBasedRenderer,
    QgsRuleBasedLabeling,
    QgsSymbol,
    QgsReadWriteContext,
)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtXml import QDomDocument

# Ruta al estilo de predios (para heredar su etiquetado)
STYLES_DIR = os.path.join(os.path.dirname(__file__), "styles")
PREDIOS_QML = os.path.join(STYLES_DIR, "predios.qml")


# ---------------------------------------------------------------------------
# Autodeteccion de capas
# ---------------------------------------------------------------------------
def list_vector_layers():
    """Devuelve todas las capas vectoriales cargadas en el proyecto."""
    layers = []
    for lyr in QgsProject.instance().mapLayers().values():
        if isinstance(lyr, QgsVectorLayer):
            layers.append(lyr)
    return layers


def find_layers_by_prefix(prefix):
    """
    Devuelve las capas vectoriales cuyo nombre empieza por 'prefix'
    (sin distinguir mayusculas/minusculas). Ordenadas por nombre.
    """
    if not prefix:
        return []
    pref = prefix.lower()
    result = [
        lyr for lyr in list_vector_layers()
        if lyr.name().lower().startswith(pref)
    ]
    result.sort(key=lambda l: l.name().lower())
    return result


def layer_by_name(name):
    """Obtiene una capa por su nombre exacto (o None)."""
    if not name:
        return None
    matches = QgsProject.instance().mapLayersByName(name)
    for m in matches:
        if isinstance(m, QgsVectorLayer):
            return m
    return matches[0] if matches else None


# ---------------------------------------------------------------------------
# Aplicacion de estilos QML
# ---------------------------------------------------------------------------
def apply_qml(layer, qml_path):
    """
    Aplica un archivo .qml a la capa dada.
    Devuelve (ok, mensaje).
    """
    if layer is None:
        return False, "Capa no valida."
    if not qml_path or not os.path.isfile(qml_path):
        return False, "No se encontro el archivo de estilo: {}".format(qml_path)

    # loadNamedStyle devuelve (mensaje, exito) en QGIS 3.x
    message, ok = layer.loadNamedStyle(qml_path)
    if not ok:
        return False, "No se pudo aplicar el estilo. {}".format(message or "")
    layer.triggerRepaint()
    try:
        layer.emitStyleChanged()
    except Exception:
        pass
    return True, "Estilo aplicado a '{}'.".format(layer.name())


# ---------------------------------------------------------------------------
# Estilo de inconsistencias (basado en Estilo_inconsistencias.py)
# ---------------------------------------------------------------------------
# Familias de inconsistencias y color asignado.
COLORES_INCONSISTENCIAS = {
    "inc_card": "red",
    "inc_cod": "orange",
    "inc_cptud": "green",
    "inc_dup": "black",
    "inc_estd": "purple",
    "inc_gnral": "blue",
    "inc_mzcs": "yellow",
}

# Campos de revision (se pintan transparentes con borde negro).
CAMPOS_REVISADOS = [
    "r_inc_gnral", "r_inc_estd", "r_inc_card",
    "r_inc_mzcs", "r_inc_dup", "r_inc_cptud",
]


def apply_inconsistencias(layer):
    """
    Aplica el estilo de inconsistencias a la capa:
      - Una regla por familia inc_* : pinta con su color cuando el campo tiene
        valor y su equivalente r_inc_* aun es NULL (no revisado).
      - Reglas para campos revisados r_* : simbolo transparente.
    Solo usa las familias/campos cuyos atributos existen en la capa, para
    evitar errores si la capa no tiene todas las columnas.
    Devuelve (ok, mensaje).
    """
    if layer is None:
        return False, "Capa no valida."
    if not isinstance(layer, QgsVectorLayer):
        return False, "La capa seleccionada no es vectorial."

    field_names = {f.name() for f in layer.fields()}

    root_rule = QgsRuleBasedRenderer.Rule(
        QgsSymbol.defaultSymbol(layer.geometryType())
    )

    aplicadas = 0

    # Reglas por familia de inconsistencia (pinta si tiene valor y no esta revisado)
    for campo, color in COLORES_INCONSISTENCIAS.items():
        if campo not in field_names:
            continue
        campo_rev = "r_{}".format(campo)

        simbolo = QgsSymbol.defaultSymbol(layer.geometryType())
        if simbolo.symbolLayerCount() > 0:
            simbolo.symbolLayer(0).setColor(QColor(color))

        regla = QgsRuleBasedRenderer.Rule(simbolo)
        regla.setLabel("Inconsistencia: {}".format(campo))
        if campo_rev in field_names:
            regla.setFilterExpression(
                '"{c}" IS NOT NULL AND "{r}" IS NULL'.format(c=campo, r=campo_rev)
            )
        else:
            regla.setFilterExpression('"{c}" IS NOT NULL'.format(c=campo))
        root_rule.appendChild(regla)
        aplicadas += 1

    # Reglas para campos revisados -> transparente con borde negro
    for campo_rev in CAMPOS_REVISADOS:
        if campo_rev not in field_names:
            continue
        simbolo_transp = QgsSymbol.defaultSymbol(layer.geometryType())
        simbolo_transp.setOpacity(0.0)
        if simbolo_transp.symbolLayerCount() > 0:
            simbolo_transp.symbolLayer(0).setColor(QColor("black"))

        regla_transp = QgsRuleBasedRenderer.Rule(simbolo_transp)
        regla_transp.setLabel("Revisado: {}".format(campo_rev))
        regla_transp.setFilterExpression('"{r}" IS NOT NULL'.format(r=campo_rev))
        root_rule.appendChild(regla_transp)
        aplicadas += 1

    if aplicadas == 0:
        return False, (
            "La capa no tiene campos de inconsistencias (inc_* / r_inc_*). "
            "Verifica que sea la capa correcta."
        )

    # Regla: revision al 100% (porc_rev = '100') -> marco negro sin fondo.
    if "porc_rev" in field_names:
        simbolo_100 = QgsSymbol.defaultSymbol(layer.geometryType())
        _set_solo_borde(simbolo_100, color_borde=QColor(0, 0, 0))
        regla_100 = QgsRuleBasedRenderer.Rule(simbolo_100)
        regla_100.setLabel("Revisado 100%")
        regla_100.setFilterExpression("\"porc_rev\" = '100'")
        root_rule.appendChild(regla_100)

    layer.setRenderer(QgsRuleBasedRenderer(root_rule))

    # Heredar el mismo etiquetado que tiene el estilo de predios.
    etiqueta_ok = _apply_predios_labeling(layer)

    layer.triggerRepaint()
    try:
        layer.emitStyleChanged()
    except Exception:
        pass

    msg = "Estilo de inconsistencias aplicado a '{}'.".format(layer.name())
    if not etiqueta_ok:
        msg += " (No se pudo copiar el etiquetado de predios.)"
    return True, msg


def _set_solo_borde(simbolo, color_borde=None):
    """Deja un simbolo de relleno sin relleno (transparente) y solo con borde."""
    if color_borde is None:
        color_borde = QColor(90, 95, 105)
    try:
        sl = simbolo.symbolLayer(0)
        # color de relleno transparente
        sl.setColor(QColor(0, 0, 0, 0))
        # quitar el relleno explicitamente (Qt.NoBrush)
        try:
            sl.setBrushStyle(Qt.NoBrush)
        except Exception:
            pass
        # borde visible
        try:
            sl.setStrokeColor(color_borde)
        except Exception:
            pass
        try:
            sl.setStrokeWidth(0.3)
        except Exception:
            pass
    except Exception:
        pass


def _apply_predios_labeling(layer):
    """
    Copia el etiquetado (labeling) del estilo predios.qml a la capa, para que
    las inconsistencias muestren las mismas etiquetas que predios.
    Devuelve True si se aplico, False si no fue posible.
    """
    if not os.path.isfile(PREDIOS_QML):
        return False
    try:
        with open(PREDIOS_QML, "r", encoding="utf-8") as fh:
            contenido = fh.read()

        doc = QDomDocument()
        if not doc.setContent(contenido):
            return False

        root = doc.documentElement()
        labeling_node = root.firstChildElement("labeling")
        if labeling_node.isNull():
            return False

        context = QgsReadWriteContext()
        labeling = QgsRuleBasedLabeling.create(labeling_node, context)
        if labeling is None:
            return False

        layer.setLabeling(labeling)
        layer.setLabelsEnabled(True)
        return True
    except Exception:
        return False
