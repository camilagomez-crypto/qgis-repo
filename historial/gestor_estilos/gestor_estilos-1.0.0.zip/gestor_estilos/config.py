# -*- coding: utf-8 -*-
"""
Configuracion persistente del plugin "Gestor de Estilos".

Guarda la configuracion en QSettings (persistente entre sesiones de QGIS) y
define las entradas por defecto. Cada entrada asocia:
    - clave interna (id)         -> identificador estable
    - etiqueta visible (label)   -> lo que ve el usuario
    - prefijo de capa (prefix)   -> para autodetectar la capa en el proyecto
    - estilo por defecto (default_style) -> nombre de archivo .qml dentro de styles/
    - modo (mode)                -> "predeterminado" o "personalizado"
    - estilo personalizado (custom_style) -> ruta absoluta a un .qml del usuario

La configuracion se serializa como JSON dentro de QSettings, de modo que:
    - Nunca se pierden los estilos por defecto (viven dentro del plugin).
    - Las personalizaciones y nuevas entradas se recuerdan en cada sesion.
"""

import os
import json
import copy

from qgis.PyQt.QtCore import QSettings

# Directorio del plugin y carpeta de estilos empaquetados
PLUGIN_DIR = os.path.dirname(__file__)
STYLES_DIR = os.path.join(PLUGIN_DIR, "styles")

# Clave raiz en QSettings
SETTINGS_KEY = "GestorEstilos/config"

# Modos de estilo
MODE_DEFAULT = "predeterminado"
MODE_CUSTOM = "personalizado"

# Entradas por defecto (segun lo definido con el usuario).
# 'default_style' es el nombre del archivo dentro de la carpeta styles/.
DEFAULT_ENTRIES = [
    {"id": "barrios",         "label": "Barrios",         "prefix": "barrios_",         "default_style": "barrios.qml"},
    {"id": "barrios_2",       "label": "Barrios_2",       "prefix": "barrios_",         "default_style": "barrios2.qml"},
    {"id": "urbanizaciones",  "label": "Urbanizaciones",  "prefix": "urbanizaciones_",  "default_style": "urbanizaciones.qml"},
    {"id": "manzanas",        "label": "Manzanas",        "prefix": "manzanas_",        "default_style": "manzanas.qml"},
    {"id": "predios",         "label": "Predios",         "prefix": "predios_",         "default_style": "predios.qml"},
    {"id": "predios_2",       "label": "Predios_2",       "prefix": "predios_",         "default_style": "predios_2.qml"},
    {"id": "mavvial",         "label": "Mavvial",         "prefix": "mavvial_",         "default_style": "MALLA.qml"},
    {"id": "mavvial_2",       "label": "Mavvial_2",       "prefix": "mavvial_",         "default_style": "MALLA2.qml"},
]


def _make_default_config():
    """Crea la estructura de configuracion inicial a partir de DEFAULT_ENTRIES."""
    entries = []
    for base in DEFAULT_ENTRIES:
        entry = copy.deepcopy(base)
        entry["mode"] = MODE_DEFAULT
        entry["custom_style"] = ""
        entry["builtin"] = True  # entrada que viene de fabrica
        entries.append(entry)
    return {"entries": entries, "last_inconsistencias_layer": ""}


def default_style_path(style_filename):
    """Ruta absoluta de un estilo empaquetado dentro del plugin."""
    if not style_filename:
        return ""
    return os.path.join(STYLES_DIR, style_filename)


def resolve_style_path(entry):
    """
    Devuelve la ruta .qml que debe aplicarse para una entrada, segun su modo.
    - modo personalizado + ruta valida -> usa la personalizada
    - en cualquier otro caso            -> usa la predeterminada del plugin
    """
    mode = entry.get("mode", MODE_DEFAULT)
    custom = entry.get("custom_style", "")
    if mode == MODE_CUSTOM and custom and os.path.isfile(custom):
        return custom
    return default_style_path(entry.get("default_style", ""))


def load_config():
    """
    Carga la configuracion persistida. Si no existe, crea la de fabrica.
    Ademas fusiona entradas de fabrica nuevas que aun no esten guardadas
    (util cuando se actualiza el plugin y se agregan entradas por defecto).
    """
    settings = QSettings()
    raw = settings.value(SETTINGS_KEY, "")

    if not raw:
        config = _make_default_config()
        save_config(config)
        return config

    try:
        config = json.loads(raw)
    except (ValueError, TypeError):
        config = _make_default_config()
        save_config(config)
        return config

    # Sanidad basica
    if not isinstance(config, dict) or "entries" not in config:
        config = _make_default_config()
        save_config(config)
        return config

    # Fusionar entradas de fabrica que falten (por id)
    existing_ids = {e.get("id") for e in config["entries"]}
    changed = False
    for base in DEFAULT_ENTRIES:
        if base["id"] not in existing_ids:
            entry = copy.deepcopy(base)
            entry["mode"] = MODE_DEFAULT
            entry["custom_style"] = ""
            entry["builtin"] = True
            config["entries"].append(entry)
            changed = True

    # Normalizar campos faltantes en cada entrada
    for e in config["entries"]:
        e.setdefault("mode", MODE_DEFAULT)
        e.setdefault("custom_style", "")
        e.setdefault("builtin", False)
        e.setdefault("default_style", "")
        e.setdefault("prefix", "")
        e.setdefault("label", e.get("id", ""))

    config.setdefault("last_inconsistencias_layer", "")

    if changed:
        save_config(config)

    return config


def save_config(config):
    """Persiste la configuracion como JSON en QSettings."""
    settings = QSettings()
    settings.setValue(SETTINGS_KEY, json.dumps(config, ensure_ascii=False))
    settings.sync()


def reset_config():
    """Restaura la configuracion de fabrica (borra personalizaciones)."""
    config = _make_default_config()
    save_config(config)
    return config


def add_entry(config, label, prefix, default_style="", custom_style=""):
    """
    Agrega una nueva entrada de usuario a la configuracion (en memoria).
    Devuelve la entrada creada. El llamador debe persistir con save_config().
    """
    new_id = _slugify(label) or "entrada"
    existing_ids = {e.get("id") for e in config["entries"]}
    unique_id = new_id
    i = 2
    while unique_id in existing_ids:
        unique_id = "{}_{}".format(new_id, i)
        i += 1

    mode = MODE_CUSTOM if (custom_style and not default_style) else MODE_DEFAULT
    entry = {
        "id": unique_id,
        "label": label,
        "prefix": prefix,
        "default_style": default_style,
        "mode": mode,
        "custom_style": custom_style,
        "builtin": False,
    }
    config["entries"].append(entry)
    return entry


def remove_entry(config, entry_id):
    """Elimina una entrada por id (solo si no es de fabrica)."""
    config["entries"] = [
        e for e in config["entries"]
        if not (e.get("id") == entry_id and not e.get("builtin", False))
    ]


def _slugify(text):
    text = (text or "").strip().lower()
    out = []
    for ch in text:
        if ch.isalnum():
            out.append(ch)
        elif ch in (" ", "-", "_"):
            out.append("_")
    slug = "".join(out).strip("_")
    while "__" in slug:
        slug = slug.replace("__", "_")
    return slug
