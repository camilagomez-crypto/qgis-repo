# -*- coding: utf-8 -*-
"""
Tema visual (QSS) del plugin "Gestor de Estilos".

Tematica en escala de grises:
  - Fondos claros / blancos.
  - Texto negro y gris oscuro para que resalte.
  - Superficies destacadas (cabecera, encabezado de tabla, boton principal) en
    gris oscuro con texto gris muy claro (se evita el blanco puro en el texto).
"""

# Paleta en grises
PALETTE = {
    "dark":         "#4a4f57",   # gris oscuro (superficies destacadas)
    "dark_2":       "#5b616b",   # gris oscuro secundario / degradado
    "dark_press":   "#3d4149",   # gris oscuro presionado
    "mid":          "#8a8f99",   # gris medio
    "line":         "#d4d7dd",   # bordes / lineas
    "bg":           "#eef0f3",   # fondo general (gris muy claro)
    "card":         "#ffffff",   # fondo de tarjetas / campos (blanco solo fondo)
    "row_alt":      "#f4f5f7",   # fila alterna
    "text":         "#20242b",   # texto principal (casi negro)
    "text_soft":    "#5f646d",   # texto secundario (gris oscuro)
    "on_dark":      "#eef0f3",   # texto sobre superficies oscuras (gris claro)
    "on_dark_soft": "#c9cdd4",   # texto secundario sobre oscuro
    "hover":        "#e7e9ee",   # hover claro
    "pressed":      "#dcdfe5",   # pressed claro
    "danger":       "#8a5050",   # gris con matiz para peligro (discreto)
}


def stylesheet():
    p = PALETTE
    return """
    QDialog {{
        background: {bg};
        color: {text};
        font-size: 13px;
    }}

    /* ---- Cabecera ---- */
    #HeaderBanner {{
        border-radius: 14px;
        background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 {dark}, stop:1 {dark_2});
    }}
    #HeaderTitle {{
        color: {on_dark};
        font-size: 20px;
        font-weight: 700;
    }}
    #HeaderSubtitle {{
        color: {on_dark_soft};
        font-size: 12px;
    }}

    /* ---- Tarjetas / GroupBox ---- */
    QGroupBox {{
        background: {card};
        border: 1px solid {line};
        border-radius: 12px;
        margin-top: 14px;
        padding: 14px 12px 12px 12px;
        font-weight: 600;
        color: {text};
    }}
    QGroupBox::title {{
        subcontrol-origin: margin;
        subcontrol-position: top left;
        left: 14px;
        padding: 2px 10px;
        background: {dark};
        color: {on_dark};
        border-radius: 8px;
    }}

    QLabel {{
        color: {text};
    }}
    #HintLabel {{
        color: {text_soft};
        font-size: 11px;
    }}

    /* ---- Tabla ---- */
    QTableWidget {{
        background: {card};
        alternate-background-color: {row_alt};
        border: 1px solid {line};
        border-radius: 12px;
        gridline-color: transparent;
        selection-background-color: transparent;
        color: {text};
    }}
    QTableWidget::item {{
        padding: 6px 4px;
        border-bottom: 1px solid {line};
        color: {text};
    }}
    QHeaderView::section {{
        background: {dark};
        color: {on_dark};
        padding: 8px 6px;
        border: none;
        font-weight: 600;
    }}
    QHeaderView::section:first {{
        border-top-left-radius: 12px;
    }}
    QHeaderView::section:last {{
        border-top-right-radius: 12px;
    }}
    QTableCornerButton::section {{
        background: {dark};
        border: none;
    }}

    /* ---- Botones ---- */
    QPushButton {{
        background: {card};
        color: {text};
        border: 1px solid {line};
        border-radius: 9px;
        padding: 7px 14px;
        font-weight: 600;
    }}
    QPushButton:hover {{
        border: 1px solid {mid};
        background: {hover};
    }}
    QPushButton:pressed {{
        background: {pressed};
    }}

    QPushButton#Primary {{
        background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 {dark_2}, stop:1 {dark});
        color: {on_dark};
        border: none;
        padding: 9px 18px;
    }}
    QPushButton#Primary:hover {{ background: {dark}; }}
    QPushButton#Primary:pressed {{ background: {dark_press}; }}

    QPushButton#Accent {{
        background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 {dark_2}, stop:1 {dark});
        color: {on_dark};
        border: none;
        padding: 9px 18px;
    }}
    QPushButton#Accent:hover {{ background: {dark}; }}
    QPushButton#Accent:pressed {{ background: {dark_press}; }}

    QPushButton#Danger {{
        background: {card};
        color: {danger};
        border: 1px solid {danger};
    }}
    QPushButton#Danger:hover {{
        background: {danger};
        color: {on_dark};
    }}

    QPushButton#Ghost {{
        background: transparent;
        border: 1px solid {line};
        color: {text_soft};
        padding: 4px 10px;
    }}
    QPushButton#Ghost:hover {{
        border: 1px solid {danger};
        color: {danger};
    }}

    /* ---- Combos y campos ---- */
    QComboBox, QLineEdit {{
        background: {card};
        color: {text};
        border: 1px solid {line};
        border-radius: 8px;
        padding: 5px 8px;
        min-height: 20px;
    }}
    QComboBox:hover, QLineEdit:hover {{
        border: 1px solid {mid};
    }}
    QComboBox:disabled, QLineEdit:disabled {{
        color: {mid};
        background: {bg};
    }}
    QComboBox::drop-down {{
        border: none;
        width: 22px;
    }}
    QComboBox QAbstractItemView {{
        background: {card};
        color: {text};
        border: 1px solid {line};
        selection-background-color: {dark};
        selection-color: {on_dark};
        outline: none;
    }}

    /* ---- Radios / checks ---- */
    QRadioButton, QCheckBox {{
        spacing: 5px;
        color: {text};
    }}
    QCheckBox::indicator, QRadioButton::indicator {{
        width: 16px;
        height: 16px;
    }}

    /* ---- Scrollbars ---- */
    QScrollBar:vertical {{
        background: transparent;
        width: 10px;
        margin: 2px;
    }}
    QScrollBar::handle:vertical {{
        background: {mid};
        border-radius: 5px;
        min-height: 30px;
    }}
    QScrollBar::handle:vertical:hover {{
        background: {dark};
    }}
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
        height: 0;
    }}
    """.format(**p)
