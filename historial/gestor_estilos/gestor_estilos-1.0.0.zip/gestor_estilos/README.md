# Gestor de Estilos (plugin QGIS)

Plugin para aplicar estilos `.qml` a las capas del proyecto de forma automatica
segun el prefijo del nombre de la capa. Incluye estilos predeterminados, soporte
para estilos personalizados que se recuerdan entre sesiones, entradas ampliables
y un boton para aplicar el estilo de inconsistencias.

## Que hace

- **Autodeteccion por prefijo**: detecta las capas del proyecto por el inicio de
  su nombre (por ejemplo `barrios_`, `predios_`, `mavvial_`, etc.).
- **Aplicacion en grupo**: marca las entradas que quieras y aplica todos los
  estilos de una sola vez.
- **Predeterminado / Personalizado**: por cada entrada eliges si usar el estilo
  que trae el plugin (`Pred.`) o uno propio (`Pers.`). Los estilos por defecto
  viven dentro del plugin, asi que nunca se pierden.
- **Configuracion persistente**: el modo, el estilo personalizado elegido y las
  entradas nuevas se guardan en la configuracion de QGIS y se recuerdan en cada
  sesion.
- **Entradas ampliables**: puedes agregar nuevas entradas (nombre + prefijo +
  estilo `.qml`) para tus propias capas.
- **Estilo de inconsistencias**: aplica un renderer por reglas que colorea las
  familias `inc_*` no revisadas y deja transparentes los registros ya revisados
  (`r_inc_*`).

## Entradas predeterminadas

| Entrada        | Prefijo de capa    | Estilo por defecto   |
|----------------|--------------------|----------------------|
| Barrios        | `barrios_`         | barrios.qml          |
| Barrios_2      | `barrios_`         | barrios2.qml         |
| Urbanizaciones | `urbanizaciones_`  | urbanizaciones.qml   |
| Manzanas       | `manzanas_`        | manzanas.qml         |
| Predios        | `predios_`         | predios.qml          |
| Predios_2      | `predios_`         | predios_2.qml        |
| Mavvial        | `mavvial_`         | MALLA.qml            |
| Mavvial_2      | `mavvial_`         | MALLA2.qml           |

## Instalacion

1. Comprime la carpeta `gestor_estilos` en un `.zip` (la carpeta debe quedar en
   la raiz del zip).
2. En QGIS: **Complementos -> Administrar e instalar complementos ->
   Instalar a partir de ZIP** y selecciona el archivo.
3. Aparecera el icono de pincel en la barra de herramientas y la entrada
   **Gestor de Estilos** en el menu de complementos.

Alternativa (instalacion manual): copia la carpeta `gestor_estilos` en el
directorio de plugins de tu perfil de QGIS:

```
%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\gestor_estilos
```

Luego activa el plugin desde el administrador de complementos.

## Uso

1. Carga tus capas en el proyecto (con los prefijos correspondientes).
2. Abre el plugin (icono de pincel).
3. Revisa la capa detectada en cada entrada; ajusta si hay varias.
4. Elige `Pred.` o `Pers.` por entrada. Si eliges `Pers.`, selecciona tu `.qml`
   con el boton `...`.
5. Marca las entradas y pulsa **Aplicar seleccionados**.
6. Para inconsistencias: elige la capa en la seccion inferior y pulsa
   **Aplicar estilo de inconsistencias**.

Para agregar una capa nueva usa **Agregar entrada**. Para volver al estado
original usa **Restaurar de fabrica** (elimina personalizaciones y entradas
propias).

## Estructura

```
gestor_estilos/
  __init__.py        # classFactory
  metadata.txt       # metadatos del plugin
  plugin.py          # icono + menu + apertura del dialogo
  dialog.py          # interfaz principal
  config.py          # configuracion persistente (QSettings)
  styler.py          # autodeteccion y aplicacion de estilos
  icon.svg           # icono (pincel)
  styles/            # estilos .qml predeterminados
```
