# -*- coding: utf-8 -*-
"""
Dialogo principal del plugin "Gestor de Estilos".

Estructura:
  - Tabla de entradas. Cada fila:
        [Aplicar?] [Etiqueta] [Capa (combo autodetectado)] [Modo: Pred/Pers]
        [Estilo personalizado (...)] [Quitar]
  - Botones: Aplicar seleccionados, Actualizar capas, Agregar entrada,
    Restaurar de fabrica.
  - Seccion inferior: Estilo de inconsistencias (combo de capa + boton).

Toda la configuracion (modo, estilo personalizado, entradas nuevas) se
persiste con el modulo config, de modo que se recuerda entre sesiones.
"""

import os

from qgis.PyQt.QtCore import Qt, QSize
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton,
    QComboBox, QCheckBox, QTableWidget, QTableWidgetItem, QHeaderView,
    QWidget, QRadioButton, QButtonGroup, QFileDialog, QMessageBox,
    QGroupBox, QLineEdit, QInputDialog, QAbstractItemView, QFrame,
    QGraphicsDropShadowEffect, QStyle,
)
from qgis.PyQt.QtGui import QColor

from . import config as cfg
from . import styler
from . import theme
from .style_chooser import StyleChooserDialog, _export_style

PLUGIN_DIR = os.path.dirname(__file__)


# Columnas de la tabla
COL_APPLY  = 0
COL_LABEL  = 1
COL_LAYER  = 2
COL_MODE   = 3
COL_CUSTOM = 4
COL_EDIT   = 5   # botón lápiz → editor nativo de QGIS
COL_REMOVE = 6


class GestorEstilosDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.config = cfg.load_config()

        self.setWindowTitle("Gestor de Estilos")
        self.setMinimumWidth(880)
        self.setMinimumHeight(560)

        icon_path = os.path.join(PLUGIN_DIR, "icon.svg")
        if os.path.isfile(icon_path):
            self.setWindowIcon(QIcon(icon_path))

        self.setStyleSheet(theme.stylesheet())
        self._build_ui()
        self.reload_from_config()

    # ---------------------------------------------------------- cabecera
    def _build_header(self):
        banner = QFrame()
        banner.setObjectName("HeaderBanner")
        banner.setMinimumHeight(76)
        h = QHBoxLayout(banner)
        h.setContentsMargins(18, 12, 18, 12)
        h.setSpacing(14)

        # icono
        icon_lbl = QLabel()
        icon_path = os.path.join(PLUGIN_DIR, "icon.svg")
        if os.path.isfile(icon_path):
            icon_lbl.setPixmap(QIcon(icon_path).pixmap(QSize(48, 48)))
        h.addWidget(icon_lbl)

        # textos
        txt = QVBoxLayout()
        txt.setSpacing(2)
        title = QLabel("Gestor de Estilos")
        title.setObjectName("HeaderTitle")
        subtitle = QLabel(
            "Aplica estilos a tus capas por prefijo \u2022 predeterminados o personalizados"
        )
        subtitle.setObjectName("HeaderSubtitle")
        txt.addWidget(title)
        txt.addWidget(subtitle)
        h.addLayout(txt)
        h.addStretch()

        # sombra suave
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(24)
        shadow.setXOffset(0)
        shadow.setYOffset(4)
        shadow.setColor(QColor(90, 95, 105, 80))
        banner.setGraphicsEffect(shadow)

        return banner

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        # Cabecera con degradado
        layout.addWidget(self._build_header())

        info = QLabel(
            "Marca las entradas que quieras aplicar y pulsa "
            "\u00abAplicar seleccionados\u00bb. La configuraci\u00f3n se guarda "
            "autom\u00e1ticamente para las pr\u00f3ximas sesiones."
        )
        info.setObjectName("HintLabel")
        info.setWordWrap(True)
        layout.addWidget(info)

        # Tarjeta que contiene la tabla de entradas
        entries_box = QGroupBox("Entradas y estilos")
        entries_layout = QVBoxLayout(entries_box)
        entries_layout.setContentsMargins(10, 14, 10, 10)

        # Tabla de entradas
        self.table = QTableWidget(self)
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels(
            ["Aplicar", "Entrada", "Capa",
             "Estilo", "Estilo personalizado", "Editar", ""]
        )
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionMode(QAbstractItemView.NoSelection)
        self.table.verticalHeader().setVisible(False)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(COL_APPLY, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(COL_LABEL, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(COL_LAYER, QHeaderView.Stretch)
        header.setSectionResizeMode(COL_MODE, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(COL_CUSTOM, QHeaderView.Stretch)
        header.setSectionResizeMode(COL_EDIT,   QHeaderView.ResizeToContents)
        header.setSectionResizeMode(COL_REMOVE, QHeaderView.ResizeToContents)
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.verticalHeader().setDefaultSectionSize(40)
        entries_layout.addWidget(self.table)

        # Botones de accion sobre entradas
        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)
        self.btn_apply = QPushButton("  Aplicar seleccionados")
        self.btn_apply.setObjectName("Primary")
        self.btn_apply.clicked.connect(self.apply_selected)
        self.btn_select_all = QPushButton("Marcar todo")
        self.btn_select_all.clicked.connect(lambda: self._set_all_checks(True))
        self.btn_select_none = QPushButton("Desmarcar todo")
        self.btn_select_none.clicked.connect(lambda: self._set_all_checks(False))
        self.btn_refresh = QPushButton("Actualizar capas")
        self.btn_refresh.clicked.connect(self.reload_from_config)
        self.btn_add = QPushButton("Agregar entrada")
        self.btn_add.clicked.connect(self.add_entry_dialog)
        self.btn_reset = QPushButton("Restaurar")
        self.btn_reset.setObjectName("Danger")
        self.btn_reset.clicked.connect(self.reset_to_factory)

        btn_row.addWidget(self.btn_apply)
        btn_row.addWidget(self.btn_select_all)
        btn_row.addWidget(self.btn_select_none)
        btn_row.addStretch()
        btn_row.addWidget(self.btn_refresh)
        btn_row.addWidget(self.btn_add)
        btn_row.addWidget(self.btn_reset)
        entries_layout.addLayout(btn_row)

        layout.addWidget(entries_box)

        # Seccion de inconsistencias
        box = QGroupBox("Estilo de inconsistencias")
        box_layout = QGridLayout(box)
        box_layout.setContentsMargins(12, 16, 12, 12)
        box_layout.setHorizontalSpacing(10)
        box_layout.addWidget(QLabel("Capa:"), 0, 0)
        self.combo_inc = QComboBox()
        box_layout.addWidget(self.combo_inc, 0, 1)
        self.btn_inc = QPushButton("Aplicar estilo de inconsistencias")
        self.btn_inc.setObjectName("Accent")
        self.btn_inc.clicked.connect(self.apply_inconsistencias)
        box_layout.addWidget(self.btn_inc, 0, 2)
        hint = QLabel(
            "Colorea por familia (inc_*) las inconsistencias no revisadas y "
            "deja transparentes los registros ya revisados (r_inc_*)."
        )
        hint.setObjectName("HintLabel")
        hint.setWordWrap(True)
        box_layout.addWidget(hint, 1, 0, 1, 3)
        box_layout.setColumnStretch(1, 1)
        layout.addWidget(box)

        # icono en el boton principal
        icon_path = os.path.join(PLUGIN_DIR, "icon.svg")
        if os.path.isfile(icon_path):
            self.btn_apply.setIcon(QIcon(icon_path))
            self.btn_apply.setIconSize(QSize(18, 18))

        # Cerrar
        close_row = QHBoxLayout()
        close_row.addStretch()
        self.btn_close = QPushButton("Cerrar")
        self.btn_close.clicked.connect(self.close)
        close_row.addWidget(self.btn_close)
        layout.addLayout(close_row)

    # -------------------------------------------------------------- carga
    def reload_from_config(self):
        """Reconstruye la tabla y los combos a partir de la configuracion."""
        self.config = cfg.load_config()
        self._populate_table()
        self._populate_inc_combo()

    def _populate_table(self):
        entries = self.config["entries"]
        self.table.setRowCount(len(entries))
        for row, entry in enumerate(entries):
            self._build_row(row, entry)

    def _build_row(self, row, entry):
        # Aplicar (checkbox centrado)
        chk = QCheckBox()
        # Arranca siempre desmarcado — el usuario elige qué aplicar cada vez
        chk.setChecked(False)
        chk_wrap = self._center(chk)
        self.table.setCellWidget(row, COL_APPLY, chk_wrap)

        # Etiqueta
        item = QTableWidgetItem(entry.get("label", entry.get("id", "")))
        item.setToolTip(
            "Se preselecciona la capa que empieza por: {}".format(entry.get("prefix", "-"))
        )
        self.table.setItem(row, COL_LABEL, item)

        # Combo con TODAS las capas del proyecto, preseleccionando la del prefijo
        combo = QComboBox()
        self._fill_layer_combo(combo, entry.get("prefix", ""))
        self.table.setCellWidget(row, COL_LAYER, combo)

        # Modo: predeterminado / personalizado
        mode_widget = QWidget()
        mode_layout = QHBoxLayout(mode_widget)
        mode_layout.setContentsMargins(4, 0, 4, 0)
        rb_def = QRadioButton("Pred.")
        rb_cus = QRadioButton("Pers.")
        group = QButtonGroup(mode_widget)
        group.addButton(rb_def)
        group.addButton(rb_cus)
        if entry.get("mode", cfg.MODE_DEFAULT) == cfg.MODE_CUSTOM:
            rb_cus.setChecked(True)
        else:
            rb_def.setChecked(True)
        rb_def.setToolTip(
            "Estilo predeterminado del plugin: {}".format(entry.get("default_style", "-"))
        )
        rb_cus.setToolTip("Usar un estilo .qml propio")
        mode_layout.addWidget(rb_def)
        mode_layout.addWidget(rb_cus)
        self.table.setCellWidget(row, COL_MODE, mode_widget)

        # Estilo personalizado (label + boton)
        custom_widget = QWidget()
        custom_layout = QHBoxLayout(custom_widget)
        custom_layout.setContentsMargins(4, 0, 4, 0)
        custom_edit = QLineEdit(entry.get("custom_style", ""))
        custom_edit.setReadOnly(True)
        custom_edit.setPlaceholderText("(ning\u00fan estilo personalizado)")
        btn_browse = QPushButton()
        folder_icon = self.style().standardIcon(QStyle.SP_DirOpenIcon)
        btn_browse.setIcon(folder_icon)
        btn_browse.setIconSize(QSize(16, 16))
        btn_browse.setToolTip("Buscar archivo de estilo .qml")
        btn_browse.setMaximumWidth(38)
        custom_layout.addWidget(custom_edit)
        custom_layout.addWidget(btn_browse)
        self.table.setCellWidget(row, COL_CUSTOM, custom_widget)

        # Boton lapiz: abre el editor de estilos nativo de QGIS
        btn_edit = QPushButton()
        pencil_path = os.path.join(PLUGIN_DIR, "pencil.svg")
        btn_edit.setIcon(QIcon(pencil_path) if os.path.isfile(pencil_path)
                         else self.style().standardIcon(QStyle.SP_FileDialogDetailedView))
        btn_edit.setIconSize(QSize(16, 16))
        btn_edit.setToolTip(
            "Abrir editor de simbología de QGIS.\n"
            "Al guardar, el estilo se exporta a styles/ y queda vinculado."
        )
        btn_edit.setMaximumWidth(38)
        btn_edit.clicked.connect(
            lambda _=False, eid=entry.get("id"): self.open_style_editor(eid)
        )
        self.table.setCellWidget(row, COL_EDIT, self._center(btn_edit))

        # Boton quitar (solo para entradas no de fabrica)
        if not entry.get("builtin", False):
            btn_rm = QPushButton("Quitar")
            btn_rm.setObjectName("Ghost")
            btn_rm.clicked.connect(lambda _=False, eid=entry.get("id"): self.remove_entry(eid))
            self.table.setCellWidget(row, COL_REMOVE, self._center(btn_rm))
        else:
            self.table.setCellWidget(row, COL_REMOVE, self._center(QLabel("")))

        # --- Conexiones que persisten cambios ---
        entry_id   = entry.get("id")
        entry_label = entry.get("label", entry_id)

        def _get_current_layer():
            """Devuelve la capa actualmente seleccionada en el combo de esta fila."""
            lid = combo.currentData()
            if not lid:
                return None
            from qgis.core import QgsProject
            return QgsProject.instance().mapLayer(lid)

        def on_browse():
            """Botón carpeta: abre explorador directo para elegir .qml existente."""
            start_dir = os.path.dirname(custom_edit.text()) if custom_edit.text() else ""
            path, _ = QFileDialog.getOpenFileName(
                self, "Seleccionar estilo .qml", start_dir, "Estilos QGIS (*.qml)"
            )
            if path:
                custom_edit.setText(path)
                self._update_entry(entry_id, "custom_style", path)
                rb_cus.setChecked(True)
                self._update_entry(entry_id, "mode", cfg.MODE_CUSTOM)

        btn_browse.clicked.connect(on_browse)

        def on_mode_changed():
            new_mode = cfg.MODE_CUSTOM if rb_cus.isChecked() else cfg.MODE_DEFAULT
            self._update_entry(entry_id, "mode", new_mode)
            # Al pasar a "Personalizado" sin estilo cargado -> abrir StyleChooserDialog
            if new_mode == cfg.MODE_CUSTOM and not custom_edit.text().strip():
                dlg = StyleChooserDialog(
                    self.iface, entry_id, entry_label,
                    _get_current_layer(), parent=self
                )
                from qgis.PyQt.QtWidgets import QDialog
                if dlg.exec_() == QDialog.Accepted and dlg.chosen_path:
                    custom_edit.setText(dlg.chosen_path)
                    self._update_entry(entry_id, "custom_style", dlg.chosen_path)
                else:
                    # El usuario canceló: volver a Predeterminado
                    rb_def.setChecked(True)
                    self._update_entry(entry_id, "mode", cfg.MODE_DEFAULT)

        rb_def.toggled.connect(lambda _=False: on_mode_changed())
        rb_cus.toggled.connect(lambda _=False: on_mode_changed())

    def _fill_layer_combo(self, combo, prefix):
        """Llena el combo con TODAS las capas vectoriales del proyecto y
        preselecciona la primera que coincide con el prefijo (si existe)."""
        combo.clear()
        layers = styler.list_vector_layers()
        layers.sort(key=lambda l: l.name().lower())

        if not layers:
            combo.addItem("(no hay capas vectoriales)", None)
            combo.setEnabled(False)
            return

        combo.setEnabled(True)
        for lyr in layers:
            combo.addItem(lyr.name(), lyr.id())

        # Preseleccionar la capa que empieza por el prefijo
        idx = self._indice_por_prefijo(layers, prefix)
        if idx is not None:
            combo.setCurrentIndex(idx)

    def _indice_por_prefijo(self, layers, prefix):
        """Devuelve el indice de la primera capa cuyo nombre empieza por prefix."""
        if not prefix:
            return None
        pref = prefix.lower()
        for i, lyr in enumerate(layers):
            if lyr.name().lower().startswith(pref):
                return i
        return None

    def _es_entrada_secundaria(self, entry):
        """True si la entrada es una variante secundaria (id o label termina en _2 / 2)."""
        eid = (entry.get("id") or "").lower()
        label = (entry.get("label") or "").lower()
        return eid.endswith("_2") or label.endswith("_2") or label.endswith("2")

    def _populate_inc_combo(self):
        self.combo_inc.clear()
        layers = styler.list_vector_layers()
        layers.sort(key=lambda l: l.name().lower())
        if not layers:
            self.combo_inc.addItem("(no hay capas vectoriales)", None)
            self.combo_inc.setEnabled(False)
            self.btn_inc.setEnabled(False)
            return
        self.combo_inc.setEnabled(True)
        self.btn_inc.setEnabled(True)
        last = self.config.get("last_inconsistencias_layer", "")
        idx_sel = 0
        for i, lyr in enumerate(layers):
            self.combo_inc.addItem(lyr.name(), lyr.id())
            if lyr.name() == last:
                idx_sel = i
        self.combo_inc.setCurrentIndex(idx_sel)

    # ---------------------------------------------------------- acciones
    def apply_selected(self):
        entries = self.config["entries"]
        aplicados = 0
        errores = []
        for row, entry in enumerate(entries):
            chk = self._find_checkbox(row)
            if chk is None or not chk.isChecked():
                continue

            combo = self.table.cellWidget(row, COL_LAYER)
            layer_id = combo.currentData() if combo else None
            if not layer_id:
                errores.append("{}: no hay capa detectada.".format(entry.get("label")))
                continue
            layer = styler.QgsProject.instance().mapLayer(layer_id)
            if layer is None:
                errores.append("{}: capa no encontrada.".format(entry.get("label")))
                continue

            qml_path = cfg.resolve_style_path(entry)
            ok, msg = styler.apply_qml(layer, qml_path)
            if ok:
                aplicados += 1
            else:
                errores.append("{}: {}".format(entry.get("label"), msg))

        self.iface.mapCanvas().refresh()
        self._report(aplicados, errores)

    def apply_inconsistencias(self):
        layer_id = self.combo_inc.currentData()
        if not layer_id:
            QMessageBox.warning(self, "Gestor de Estilos", "Selecciona una capa.")
            return
        layer = styler.QgsProject.instance().mapLayer(layer_id)
        ok, msg = styler.apply_inconsistencias(layer)
        # recordar la ultima capa usada
        if layer is not None:
            self.config["last_inconsistencias_layer"] = layer.name()
            cfg.save_config(self.config)
        self.iface.mapCanvas().refresh()
        if ok:
            self.iface.messageBar().pushSuccess("Gestor de Estilos", msg)
        else:
            QMessageBox.warning(self, "Gestor de Estilos", msg)

    def add_entry_dialog(self):
        """Crea una nueva entrada: pide nombre y luego asigna estilo via StyleChooserDialog."""
        from qgis.PyQt.QtWidgets import QDialog

        label, ok = QInputDialog.getText(self, "Nueva entrada", "Nombre de la entrada:")
        if not ok or not label.strip():
            return
        label = label.strip()

        # Obtener la capa actualmente activa en QGIS (si hay) como referencia
        from qgis.core import QgsProject
        active_layer = self.iface.activeLayer()

        # Generar el id provisional para poder exportar el .qml con nombre correcto
        temp_id = cfg._slugify(label) or "entrada"

        # Abrir StyleChooserDialog
        dlg = StyleChooserDialog(
            self.iface, temp_id, label, active_layer, parent=self
        )
        chosen_path = ""
        if dlg.exec_() == QDialog.Accepted:
            chosen_path = dlg.chosen_path or ""

        # Agregar la entrada (con o sin estilo, se puede asignar luego)
        entry = cfg.add_entry(
            self.config,
            label=label,
            prefix="",
            default_style="",
            custom_style=chosen_path,
        )
        cfg.save_config(self.config)
        self.reload_from_config()
        self.iface.messageBar().pushInfo(
            "Gestor de Estilos", "Entrada '{}' agregada.".format(label)
        )

    def remove_entry(self, entry_id):
        resp = QMessageBox.question(
            self, "Quitar entrada",
            "\u00bfQuitar esta entrada de la configuraci\u00f3n?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if resp != QMessageBox.Yes:
            return
        cfg.remove_entry(self.config, entry_id)
        cfg.save_config(self.config)
        self.reload_from_config()

    def reset_to_factory(self):
        resp = QMessageBox.question(
            self, "Restaurar de f\u00e1brica",
            "Esto elimina las entradas personalizadas y vuelve a los estilos "
            "predeterminados. \u00bfContinuar?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if resp != QMessageBox.Yes:
            return
        self.config = cfg.reset_config()
        self.reload_from_config()

    # ------------------------------------------- editor nativo de estilos
    def open_style_editor(self, entry_id):
        """
        Botón lápiz de cada fila: abre StyleChooserDialog para que el usuario
        escoja un .qml existente o cree uno nuevo con el editor de QGIS.
        """
        from qgis.PyQt.QtWidgets import QDialog
        from qgis.core import QgsProject

        entry, row = self._find_entry_and_row(entry_id)
        if entry is None:
            QMessageBox.warning(self, "Gestor de Estilos",
                                "No se encontró la entrada.")
            return

        combo = self.table.cellWidget(row, COL_LAYER)
        layer_id = combo.currentData() if combo else None
        layer = QgsProject.instance().mapLayer(layer_id) if layer_id else None

        dlg = StyleChooserDialog(
            self.iface,
            entry_id,
            entry.get("label", entry_id),
            layer,
            parent=self,
        )

        if dlg.exec_() == QDialog.Accepted and dlg.chosen_path:
            self._update_entry(entry_id, "custom_style", dlg.chosen_path)
            self._update_entry(entry_id, "mode", cfg.MODE_CUSTOM)
            self.iface.messageBar().pushSuccess(
                "Gestor de Estilos",
                "Estilo vinculado a '{}'.".format(entry.get("label", entry_id))
            )
            self.reload_from_config()

    def _find_entry_and_row(self, entry_id):
        """Devuelve (entry_dict, row_index) para un entry_id dado, o (None, -1)."""
        for row, entry in enumerate(self.config["entries"]):
            if entry.get("id") == entry_id:
                return entry, row
        return None, -1

    # ---------------------------------------------------------- helpers
    def _update_entry(self, entry_id, key, value):
        for e in self.config["entries"]:
            if e.get("id") == entry_id:
                e[key] = value
                break
        cfg.save_config(self.config)

    def _set_all_checks(self, checked):
        for row in range(self.table.rowCount()):
            chk = self._find_checkbox(row)
            if chk is not None:
                chk.setChecked(checked)

    def _find_checkbox(self, row):
        wrap = self.table.cellWidget(row, COL_APPLY)
        if wrap is None:
            return None
        return wrap.findChild(QCheckBox)

    def _center(self, widget):
        wrap = QWidget()
        lay = QHBoxLayout(wrap)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addStretch()
        lay.addWidget(widget)
        lay.addStretch()
        return wrap

    def _report(self, aplicados, errores):
        if aplicados and not errores:
            self.iface.messageBar().pushSuccess(
                "Gestor de Estilos",
                "Se aplicaron {} estilo(s) correctamente.".format(aplicados)
            )
        elif aplicados and errores:
            QMessageBox.information(
                self, "Gestor de Estilos",
                "Aplicados: {}\n\nAdvertencias:\n- {}".format(
                    aplicados, "\n- ".join(errores)
                )
            )
        elif not aplicados and errores:
            QMessageBox.warning(
                self, "Gestor de Estilos",
                "No se aplico ningun estilo.\n\n- {}".format("\n- ".join(errores))
            )
        else:
            QMessageBox.information(
                self, "Gestor de Estilos",
                "No hay entradas marcadas para aplicar."
            )

    # refrescar cada vez que se muestra
    def showEvent(self, event):
        super().showEvent(event)
        self.reload_from_config()
