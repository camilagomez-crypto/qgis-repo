# -*- coding: utf-8 -*-
"""
popup_dialog.py
---------------
Ventana emergente (ampliable/redimensionable) que se abre al hacer clic sobre
un punto del proyecto en el mapa. Muestra:
  - Los atributos del feature (para validar que corresponde al plano)
  - La lista de archivos encontrados para ese proyecto, con su categoría
  - Un visor de imagen para los webp/jpg/png (zoom/pan)
  - Un visor de PDF embebido con navegación de páginas
  - Si el archivo es de categoría "urbanismo" (georeferenciable), un botón
    para abrir el diálogo de georreferenciación (georef_dialog.py)

Es UNA SOLA ventana reutilizada entre clics (ver identify_tool.py) - clicar
otro punto llama a `mostrar_datos(...)` de nuevo en vez de crear una ventana
nueva, para no ir acumulando ventanas abiertas que consuman memoria y
relentizen QGIS.

Cada entrada de `archivos` es un dict:
    {
      "nombre": str,                       # nombre de archivo (para clasificar y mostrar)
      "ruta_local": str | None,             # si existe una ruta real en disco (modo carpeta local)
      "cargar_bytes": callable() -> bytes,  # obtiene el contenido (descarga remota o lee el
                                             # archivo local) - se llama SOLO cuando el usuario
                                             # selecciona ese archivo (perezoso, no todos de una vez)
    }
Si `ruta_local` está presente se usa directo (más rápido); si no, se llama a
`cargar_bytes()` bajo demanda y todo se mantiene en memoria - no se escribe
ninguna copia persistente del archivo original en disco.
"""

import os
import tempfile

from qgis.PyQt.QtCore import Qt, QUrl, QTimer
from qgis.PyQt.QtGui import QDesktopServices, QPixmap
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QSplitter, QTableWidget, QTableWidgetItem,
    QListWidget, QListWidgetItem, QPushButton, QLabel, QWidget, QHeaderView,
    QApplication,
)

from .classifier import clasificar_archivo, es_georeferenciable, CATEGORIA_PDF_BROCHURE
from .image_viewer import VisorImagenConControles
from .pdf_viewer import VisorPDF, fitz_disponible, asegurar_fitz

ETIQUETAS_CATEGORIA = {
    "urbanismo": "Plano de urbanismo (georeferenciable)",
    "unidad": "Planta de unidad individual (no georeferenciable)",
    "render": "Render / fachada (no georeferenciable)",
    "brochure_pdf": "PDF de brochure (revisar página del plano)",
    "otro": "Sin clasificar (revisar manualmente)",
}


class VentanaValidacion(QDialog):
    """
    Ventana ÚNICA y reutilizable: se construye una sola vez (sin datos) y
    luego se llama a `mostrar_datos(...)` cada vez que se hace clic en un
    punto nuevo, para refrescar su contenido sin abrir una ventana aparte.

    `on_georeferenciar`: callback llamado cuando el usuario pide georreferenciar
        un plano, con firma:
        on_georeferenciar(nombre_archivo, atributos, ruta_local=None, datos_bytes=None)
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(700, 500)
        self.resize(950, 650)
        self.setWindowFlags(self.windowFlags() | Qt.WindowMaximizeButtonHint)

        self._atributos = []
        self._archivos = []
        self._on_georeferenciar = None
        self._visor_actual = None
        self._cache_bytes = {}

        splitter = QSplitter(Qt.Horizontal, self)

        # --- Panel izquierdo: atributos + lista de archivos ---
        panel_izq = QWidget()
        layout_izq = QVBoxLayout(panel_izq)

        layout_izq.addWidget(QLabel("<b>Datos del punto (para validar):</b>"))
        self.tabla = QTableWidget(0, 2)
        self.tabla.setHorizontalHeaderLabels(["Campo", "Valor"])
        self.tabla.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        layout_izq.addWidget(self.tabla, stretch=1)

        layout_izq.addWidget(QLabel("<b>Archivos encontrados para este proyecto:</b>"))
        self.lista_archivos = QListWidget()
        self.lista_archivos.currentItemChanged.connect(self._mostrar_archivo_seleccionado)
        layout_izq.addWidget(self.lista_archivos, stretch=1)

        self.label_sin_archivos = QLabel("<i>No se encontró ningún archivo asociado a este punto.</i>")
        self.label_sin_archivos.setVisible(False)
        layout_izq.addWidget(self.label_sin_archivos)

        splitter.addWidget(panel_izq)

        # --- Panel derecho: visor + acciones ---
        panel_der = QWidget()
        self.layout_der = QVBoxLayout(panel_der)
        self.contenedor_visor = QWidget()
        self.layout_contenedor_visor = QVBoxLayout(self.contenedor_visor)
        self.layout_der.addWidget(self.contenedor_visor, stretch=1)

        self.boton_georef = QPushButton("Georreferenciar este plano")
        self.boton_georef.setVisible(False)
        self.boton_georef.clicked.connect(self._pedir_georeferenciar)
        self.layout_der.addWidget(self.boton_georef)

        self.boton_abrir_externo = QPushButton("Abrir con el visor de PDF del sistema")
        self.boton_abrir_externo.setVisible(False)
        self.boton_abrir_externo.clicked.connect(self._abrir_pdf_externo)
        self.layout_der.addWidget(self.boton_abrir_externo)

        splitter.addWidget(panel_der)
        splitter.setSizes([380, 570])

        layout_principal = QVBoxLayout(self)
        layout_principal.addWidget(splitter)

    def mostrar_datos(self, titulo, atributos, archivos, on_georeferenciar=None):
        """Refresca la ventana con los datos de un punto nuevo (reemplaza
        todo lo mostrado anteriormente) y la trae al frente si ya estaba
        abierta, en vez de crear una ventana aparte."""
        self.setWindowTitle(titulo)
        self._atributos = atributos
        self._archivos = archivos
        self._on_georeferenciar = on_georeferenciar
        self._cache_bytes = {}
        self._archivo_seleccionado = None
        self._indice_seleccionado = None

        # Tabla de atributos
        self.tabla.setRowCount(len(atributos))
        for fila, (campo, valor) in enumerate(atributos):
            self.tabla.setItem(fila, 0, QTableWidgetItem(str(campo)))
            self.tabla.setItem(fila, 1, QTableWidgetItem("" if valor is None else str(valor)))
        self.tabla.resizeColumnsToContents()

        # Lista de archivos
        self.lista_archivos.blockSignals(True)
        self.lista_archivos.clear()
        for indice, archivo in enumerate(archivos):
            categoria = clasificar_archivo(archivo["nombre"])
            etiqueta = ETIQUETAS_CATEGORIA.get(categoria, categoria)
            item = QListWidgetItem(f"{archivo['nombre']}  —  {etiqueta}")
            item.setData(Qt.UserRole, indice)
            item.setData(Qt.UserRole + 1, categoria)
            self.lista_archivos.addItem(item)
        self.lista_archivos.blockSignals(False)
        self.label_sin_archivos.setVisible(not archivos)

        self._limpiar_visor()
        self.boton_georef.setVisible(False)
        self.boton_abrir_externo.setVisible(False)

        if archivos:
            self.layout_contenedor_visor.addWidget(QLabel("Cargando..."))
            # Diferimos la selección (y su descarga) para que la ventana
            # aparezca/actualice en pantalla de inmediato, en vez de quedar
            # congelada mientras se descarga el primer archivo.
            QTimer.singleShot(0, lambda: self.lista_archivos.setCurrentRow(0))

        if not self.isVisible():
            self.show()
        self.raise_()
        self.activateWindow()

    def _limpiar_visor(self):
        while self.layout_contenedor_visor.count():
            item = self.layout_contenedor_visor.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        self._visor_actual = None

    def _obtener_bytes(self, indice, archivo):
        if indice in self._cache_bytes:
            return self._cache_bytes[indice]
        datos = archivo["cargar_bytes"]()
        self._cache_bytes[indice] = datos
        return datos

    def _mostrar_texto_cargando(self):
        self._limpiar_visor()
        self.layout_contenedor_visor.addWidget(QLabel("Cargando..."))
        QApplication.processEvents()

    def _mostrar_archivo_seleccionado(self, item, _anterior=None):
        self.boton_georef.setVisible(False)
        self.boton_abrir_externo.setVisible(False)
        if item is None:
            self._limpiar_visor()
            return

        indice = item.data(Qt.UserRole)
        categoria = item.data(Qt.UserRole + 1)
        archivo = self._archivos[indice]
        self._archivo_seleccionado = archivo
        self._indice_seleccionado = indice
        self._categoria_seleccionada = categoria

        ruta_local = archivo.get("ruta_local")
        ya_en_cache = ruta_local is not None or indice in self._cache_bytes
        if not ya_en_cache:
            # Solo mostramos "Cargando..." cuando de verdad hay que esperar
            # una descarga - si ya está en caché o es local, es instantáneo.
            self._mostrar_texto_cargando()
        else:
            self._limpiar_visor()

        if categoria == CATEGORIA_PDF_BROCHURE:
            if not fitz_disponible():
                asegurar_fitz()

            if fitz_disponible():
                nombre_base = os.path.splitext(archivo["nombre"])[0]
                try:
                    if ruta_local:
                        visor_pdf = VisorPDF(ruta_pdf=ruta_local, nombre_base=nombre_base)
                    else:
                        datos = self._obtener_bytes(indice, archivo)
                        visor_pdf = VisorPDF(datos_pdf=datos, nombre_base=nombre_base)
                except Exception as e:
                    self._limpiar_visor()
                    self.layout_contenedor_visor.addWidget(QLabel(f"No se pudo abrir el PDF:\n{e}"))
                    return
                self._limpiar_visor()
                visor_pdf.pagina_para_georef.connect(self._al_usar_pagina_pdf)
                self.layout_contenedor_visor.addWidget(visor_pdf)
                self._visor_actual = visor_pdf
            else:
                self._limpiar_visor()
                self.layout_contenedor_visor.addWidget(QLabel(
                    "No se pudo instalar PyMuPDF automáticamente (revisa que tengas "
                    "conexión a internet). Puedes intentarlo tú mismo en CMD y "
                    "reiniciar QGIS:\n\n"
                    '"C:\\Program Files\\QGIS 3.44.0\\apps\\Python312\\python.exe" '
                    '-m pip install pymupdf'
                ))
                self.boton_abrir_externo.setVisible(True)
        else:
            try:
                if ruta_local:
                    visor = VisorImagenConControles(ruta_local, modo_captura_puntos=False)
                else:
                    datos = self._obtener_bytes(indice, archivo)
                    pixmap = QPixmap()
                    pixmap.loadFromData(datos)
                    visor = VisorImagenConControles(pixmap=pixmap, modo_captura_puntos=False)
            except Exception as e:
                self._limpiar_visor()
                self.layout_contenedor_visor.addWidget(QLabel(f"No se pudo abrir la imagen:\n{e}"))
                return

            self._limpiar_visor()
            if not visor.imagen_valida():
                self.layout_contenedor_visor.addWidget(QLabel("No se pudo abrir la imagen (formato no soportado)."))
            else:
                self.layout_contenedor_visor.addWidget(visor)
                self._visor_actual = visor
                if es_georeferenciable(categoria):
                    self.boton_georef.setVisible(True)

    def _abrir_pdf_externo(self):
        archivo = getattr(self, "_archivo_seleccionado", None)
        if not archivo:
            return
        ruta_local = archivo.get("ruta_local")
        if ruta_local:
            QDesktopServices.openUrl(QUrl.fromLocalFile(ruta_local))
            return
        # Modo remoto sin PyMuPDF: escribimos un archivo TEMPORAL solo para
        # poder abrirlo con el visor del sistema (única excepción a "todo en
        # memoria" - es indispensable porque un programa externo necesita
        # una ruta real; queda en la carpeta temporal del sistema, no en la
        # carpeta de datos compartida).
        try:
            indice = getattr(self, "_indice_seleccionado", None)
            datos = self._obtener_bytes(indice, archivo) if indice is not None else archivo["cargar_bytes"]()
            with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as f:
                f.write(datos)
                ruta_temp = f.name
            QDesktopServices.openUrl(QUrl.fromLocalFile(ruta_temp))
        except Exception as e:
            QLabel(f"No se pudo abrir el PDF: {e}")

    def _pedir_georeferenciar(self):
        archivo = getattr(self, "_archivo_seleccionado", None)
        if not (self._on_georeferenciar and archivo):
            return
        ruta_local = archivo.get("ruta_local")
        if ruta_local:
            self._on_georeferenciar(archivo["nombre"], self._atributos, ruta_local=ruta_local)
        else:
            indice = self.lista_archivos.currentItem().data(Qt.UserRole)
            datos = self._obtener_bytes(indice, archivo)
            self._on_georeferenciar(archivo["nombre"], self._atributos, datos_bytes=datos)

    def _al_usar_pagina_pdf(self, datos_png, nombre_sugerido):
        """Se dispara cuando el usuario exporta una página del PDF en alta
        resolución desde el visor - reutiliza el mismo flujo de
        georreferenciación por 3 puntos que usan los planos webp."""
        if self._on_georeferenciar:
            self._on_georeferenciar(nombre_sugerido, self._atributos, datos_bytes=datos_png)
