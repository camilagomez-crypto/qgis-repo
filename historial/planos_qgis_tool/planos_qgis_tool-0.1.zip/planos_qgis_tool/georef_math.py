# -*- coding: utf-8 -*-
"""
georef_math.py
--------------
Matemática pura para posicionar una imagen de plano en un mapa, usando:
  - la ubicación real del proyecto (punto del GeoJSON, en una proyección MÉTRICA)
  - un tamaño real aproximado (ancho/alto en metros, ajustable por el usuario)
  - la rotación deducida de 2 clics del usuario sobre la flecha de norte del plano

No depende de QGIS - toda la trigonometría se puede probar aislada aquí.
La integración con QGIS (reproyección de coordenadas, carga del raster) vive
en georef_dialog.py, que sí usa la API de QGIS.
"""

import math


def calcular_angulo_rotacion(x_base, y_base, x_punta, y_punta):
    """
    Dado un vector en coordenadas de PÍXEL de la imagen (x hacia la derecha,
    y hacia ABAJO, como es estándar en imágenes) que va desde la BASE hasta
    la PUNTA de la flecha de norte dibujada en el plano, calcula el ángulo
    (en radianes) que hay que rotar la imagen para que esa flecha quede
    apuntando hacia arriba (= norte real).

    Convención de salida: ángulo positivo = rotación HORARIA de la imagen.
    """
    dx = x_punta - x_base
    dy = y_punta - y_base
    if dx == 0 and dy == 0:
        return 0.0
    # ángulo actual de la flecha medido desde "arriba" (dirección (0,-1)), en sentido horario
    angulo_flecha = math.atan2(dx, -dy)
    # para llevar la flecha a "arriba" hay que rotar la imagen en sentido contrario
    return -angulo_flecha


def calcular_world_file(ancho_px, alto_px, ancho_m, alto_m, centro_x, centro_y, angulo_rad):
    """
    Calcula los 6 parámetros de un "world file" (A, D, B, E, C, F) para que,
    al cargar la imagen en un SIG, quede centrada en (centro_x, centro_y)
    -en la MISMA proyección métrica que se le pase-, con tamaño real
    ancho_m x alto_m, rotada angulo_rad radianes en sentido horario.

    Orden de escritura en el archivo .wld/.pgw/.jgw (una línea por valor,
    en este orden): A, D, B, E, C, F
    """
    if ancho_px <= 0 or alto_px <= 0:
        raise ValueError("ancho_px y alto_px deben ser mayores que 0")

    sx = ancho_m / ancho_px
    sy = alto_m / alto_px
    cos_a = math.cos(angulo_rad)
    sin_a = math.sin(angulo_rad)

    A = sx * cos_a
    D = -sx * sin_a
    B = sy * sin_a
    E = -(sy * cos_a)

    # Coordenadas del CENTRO del pixel superior izquierdo (fila 0, columna 0),
    # partiendo de que el centro geométrico de la imagen (en píxeles) es
    # (ancho_px/2, alto_px/2) y debe coincidir con (centro_x, centro_y):
    px_centro = ancho_px / 2.0
    py_centro = alto_px / 2.0
    C = centro_x - (A * px_centro + B * py_centro)
    F = centro_y - (D * px_centro + E * py_centro)

    return A, D, B, E, C, F


def escribir_world_file(ruta_world_file, parametros):
    """Escribe los 6 parámetros en el formato estándar de world file (1 valor por línea)."""
    A, D, B, E, C, F = parametros
    with open(ruta_world_file, "w", encoding="ascii") as f:
        for valor in (A, D, B, E, C, F):
            f.write(f"{valor:.10f}\n")


def _determinante_3x3(m):
    return (m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
            - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
            + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]))


def _resolver_3x3(M, b):
    """Resuelve M*x = b (matriz 3x3, vector b de 3) por regla de Cramer."""
    det = _determinante_3x3(M)
    if abs(det) < 1e-9:
        raise ValueError(
            "Los 3 puntos marcados están alineados (colineales) o son muy "
            "cercanos entre sí - no se puede calcular una transformación única. "
            "Elige 3 puntos que no estén en línea recta y bien separados."
        )
    resultado = []
    for col in range(3):
        Mi = [fila[:] for fila in M]
        for fila_idx in range(3):
            Mi[fila_idx][col] = b[fila_idx]
        resultado.append(_determinante_3x3(Mi) / det)
    return tuple(resultado)


def calcular_afin_3_puntos(puntos_img, puntos_map):
    """
    Calcula una transformación afín COMPLETA (6 parámetros: A,D,B,E,C,F) a
    partir de 3 puntos de control - permite escala independiente en X/Y y
    ligera cizalla, más precisa que la transformación de similitud (2 puntos).

    `puntos_img` y `puntos_map`: listas de 3 tuplas (x,y) cada una, en el
    mismo orden (punto 1 de la imagen <-> punto 1 del mapa, etc.)
    """
    if len(puntos_img) != 3 or len(puntos_map) != 3:
        raise ValueError("Se necesitan exactamente 3 puntos de la imagen y 3 del mapa.")

    M = [[puntos_img[i][0], puntos_img[i][1], 1.0] for i in range(3)]
    bx = [puntos_map[i][0] for i in range(3)]
    by = [puntos_map[i][1] for i in range(3)]

    A, B, C = _resolver_3x3(M, bx)
    D, E, F = _resolver_3x3(M, by)
    return A, D, B, E, C, F  # mismo orden que calcular_afin_2_puntos / calcular_world_file


def calcular_afin_2_puntos(x_img1, y_img1, x_img2, y_img2, x_map1, y_map1, x_map2, y_map2):
    """
    Calcula los 6 parámetros de la transformación afín (A, D, B, E, C, F) a
    partir de 2 puntos de control: 2 puntos identificados en la imagen
    (columna, fila = píxel) y sus 2 correspondientes en el mapa (mismo orden).

    Es una transformación de similitud (rotación + escala uniforme +
    traslación) - el mismo método que usa el Georreferenciador de QGIS con
    2 puntos de control. Se resuelve con aritmética de números complejos:
    el vector entre los 2 puntos de la imagen se convierte, mediante un único
    multiplicador complejo k, en el vector entre los 2 puntos del mapa.
    """
    z_img1 = complex(x_img1, y_img1)
    z_img2 = complex(x_img2, y_img2)
    z_map1 = complex(x_map1, y_map1)
    z_map2 = complex(x_map2, y_map2)

    diff_img = z_img2 - z_img1
    if diff_img == 0:
        raise ValueError("Los 2 puntos marcados en la imagen no pueden ser el mismo píxel.")

    k = (z_map2 - z_map1) / diff_img
    t = z_map1 - k * z_img1

    A, B = k.real, -k.imag
    D, E = k.imag, k.real
    C, F = t.real, t.imag
    return A, D, B, E, C, F  # mismo orden que calcular_world_file, reutilizable con escribir_world_file


def calcular_afin_2_puntos_dict(img1, img2, map1, map2):
    """Variante conveniente que recibe tuplas (x,y) en vez de 8 argumentos sueltos."""
    return calcular_afin_2_puntos(img1[0], img1[1], img2[0], img2[1],
                                   map1[0], map1[1], map2[0], map2[1])


def metros_a_grados_lat(distancia_m):
    """Convierte una distancia norte-sur en metros a grados de latitud (aprox. esférica)."""
    return distancia_m / 111_320.0


def metros_a_grados_lon(distancia_m, latitud_grados):
    """Convierte una distancia este-oeste en metros a grados de longitud, corrigiendo
    por la latitud (a mayor latitud, un grado de longitud representa menos metros)."""
    return distancia_m / (111_320.0 * math.cos(math.radians(latitud_grados)))


def ruta_world_file_para(ruta_imagen):
    """
    Devuelve la ruta del world file correspondiente a una imagen, usando la
    convención de 3 letras (primera+última+'w'), p. ej. .webp -> .wep... en
    la práctica usamos simplemente '<nombre_sin_ext>.wld' que QGIS también
    reconoce sin ambigüedad para cualquier formato de imagen.
    """
    base, _ext = ruta_imagen.rsplit(".", 1) if "." in ruta_imagen else (ruta_imagen, "")
    return base + ".wld"


if __name__ == "__main__":
    # --- Prueba 1: sin rotación, la flecha ya apunta "arriba" ---
    angulo = calcular_angulo_rotacion(x_base=50, y_base=80, x_punta=50, y_punta=0)
    print(f"Flecha ya apunta arriba -> ángulo esperado ~0, obtenido: {math.degrees(angulo):.2f}°")
    assert abs(angulo) < 1e-9

    # --- Prueba 2: la flecha apunta hacia la DERECHA (este) en la imagen cruda ---
    # Para llevarla a "arriba" hay que rotar la imagen 90° en sentido ANTIHORARIO (-90°)
    angulo = calcular_angulo_rotacion(x_base=0, y_base=50, x_punta=100, y_punta=50)
    print(f"Flecha apunta a la derecha -> ángulo esperado -90°, obtenido: {math.degrees(angulo):.2f}°")
    assert abs(math.degrees(angulo) - (-90)) < 1e-6

    # --- Prueba 3: la flecha apunta hacia la IZQUIERDA (oeste) ---
    angulo = calcular_angulo_rotacion(x_base=100, y_base=50, x_punta=0, y_punta=50)
    print(f"Flecha apunta a la izquierda -> ángulo esperado +90°, obtenido: {math.degrees(angulo):.2f}°")
    assert abs(math.degrees(angulo) - 90) < 1e-6

    # --- Prueba 4: world file sin rotación debe coincidir con un world file "clásico" ---
    params = calcular_world_file(ancho_px=1000, alto_px=500, ancho_m=100, alto_m=50,
                                  centro_x=1_000_000, centro_y=2_000_000, angulo_rad=0.0)
    A, D, B, E, C, F = params
    print(f"\nWorld file sin rotación: A={A:.4f} D={D:.4f} B={B:.4f} E={E:.4f} C={C:.2f} F={F:.2f}")
    assert abs(A - 0.1) < 1e-9      # 100m / 1000px
    assert abs(D) < 1e-9
    assert abs(B) < 1e-9
    assert abs(E - (-0.1)) < 1e-9   # -alto_m/alto_px = -50/500
    assert abs(C - (1_000_000 - 50)) < 1e-6   # centro_x - ancho_m/2
    assert abs(F - (2_000_000 + 25)) < 1e-6   # centro_y + alto_m/2

    # --- Prueba 5: con rotación de 90° (radianes), el eje X de la imagen debe
    #     apuntar hacia el NORTE del mapa (esto simula el caso donde la flecha
    #     de norte cruda apuntaba hacia la izquierda, y calculamos +90°) ---
    params_rot = calcular_world_file(ancho_px=1000, alto_px=500, ancho_m=100, alto_m=50,
                                      centro_x=0, centro_y=0, angulo_rad=math.radians(90))
    A2, D2, B2, E2, C2, F2 = params_rot
    print(f"World file rotado +90°: A={A2:.6f} D={D2:.6f} B={B2:.6f} E={E2:.6f}")
    # Con +90° (rotación horaria de la imagen): el eje X original de la imagen
    # ("derecha") pasa a apuntar al SUR del mapa, y el eje Y original ("abajo")
    # pasa a apuntar al ESTE del mapa. Verificamos ambos:
    assert abs(A2) < 1e-9            # ya no hay componente X pura en el eje X original
    assert abs(D2 - (-0.1)) < 1e-9   # moverse en X original mueve -Y del mapa (hacia el sur)
    assert abs(B2 - 0.1) < 1e-9      # moverse en Y original mueve +X del mapa (hacia el este)
    assert abs(E2) < 1e-9

    print("\nTodas las pruebas pasaron correctamente.")

    # --- Prueba 6: conversión metros -> grados ---
    grados_lat = metros_a_grados_lat(111_320.0)
    print(f"\n111320 m en latitud -> {grados_lat:.6f}° (esperado 1.0°)")
    assert abs(grados_lat - 1.0) < 1e-9

    grados_lon_ecuador = metros_a_grados_lon(111_320.0, 0.0)
    print(f"111320 m en longitud en el ecuador -> {grados_lon_ecuador:.6f}° (esperado 1.0°)")
    assert abs(grados_lon_ecuador - 1.0) < 1e-9

    grados_lon_60 = metros_a_grados_lon(111_320.0, 60.0)
    print(f"111320 m en longitud a 60° de latitud -> {grados_lon_60:.6f}° (esperado 2.0°)")
    assert abs(grados_lon_60 - 2.0) < 1e-6

    # A la latitud aproximada de Bogotá (~4.6°N), 60m reales deben ser una fracción pequeña de grado
    grados_lon_bogota = metros_a_grados_lon(60.0, 4.6)
    print(f"60 m en longitud en Bogotá (~4.6°N) -> {grados_lon_bogota:.8f}° "
          f"(≈ {grados_lon_bogota:.8f} grados, del orden de 0.00054°)")
    assert 0.0004 < grados_lon_bogota < 0.0007

    print("\nPrueba 6 (metros->grados) pasó correctamente.")

    # --- Prueba 7: transformación afín por 2 puntos de control ---
    # Caso simple: sin rotación, escala 1, solo traslación
    A, D, B, E, C, F = calcular_afin_2_puntos(0, 0, 10, 0, 100, 200, 110, 200)
    print(f"\n2 puntos sin rotación: A={A} B={B} D={D} E={E} C={C} F={F}")
    assert (A, B, D, E, C, F) == (1.0, 0.0, 0.0, 1.0, 100.0, 200.0)
    # pixel(0,0) -> (100,200) ; pixel(10,0) -> (110,200)
    assert abs((A*0 + B*0 + C) - 100) < 1e-9 and abs((D*0 + E*0 + F) - 200) < 1e-9
    assert abs((A*10 + B*0 + C) - 110) < 1e-9 and abs((D*10 + E*0 + F) - 200) < 1e-9

    # Caso con rotación: mover 10px a la derecha en la imagen = mover 10 unidades al norte en el mapa
    A2, D2, B2, E2, C2, F2 = calcular_afin_2_puntos(0, 0, 10, 0, 100, 200, 100, 210)
    print(f"2 puntos con rotación 90°: A={A2} B={B2} D={D2} E={E2} C={C2} F={F2}")
    x_p2 = A2 * 10 + B2 * 0 + C2
    y_p2 = D2 * 10 + E2 * 0 + F2
    assert abs(x_p2 - 100) < 1e-9 and abs(y_p2 - 210) < 1e-9

    print("\nPrueba 7 (2 puntos de control) pasó correctamente.")

    # --- Prueba 8: transformación afín por 3 puntos de control ---
    # Caso simple: sin rotación, escala 1, solo traslación
    puntos_img = [(0, 0), (10, 0), (0, 10)]
    puntos_map = [(100, 200), (110, 200), (100, 210)]
    A3, D3, B3, E3, C3, F3 = calcular_afin_3_puntos(puntos_img, puntos_map)
    print(f"\n3 puntos sin rotación: A={A3} B={B3} D={D3} E={E3} C={C3} F={F3}")
    assert (round(A3, 9), round(B3, 9), round(D3, 9), round(E3, 9), round(C3, 9), round(F3, 9)) \
           == (1.0, 0.0, 0.0, 1.0, 100.0, 200.0)

    # Caso con ESCALA DISTINTA en X e Y (algo que 2 puntos no puede capturar
    # bien, y que sí es exacto con 3 puntos): 10px en X -> 20 unidades;
    # 10px en Y -> 5 unidades
    puntos_img2 = [(0, 0), (10, 0), (0, 10)]
    puntos_map2 = [(500, 500), (520, 500), (500, 505)]
    A4, D4, B4, E4, C4, F4 = calcular_afin_3_puntos(puntos_img2, puntos_map2)
    print(f"3 puntos con escala distinta X/Y: A={A4} B={B4} D={D4} E={E4} C={C4} F={F4}")
    assert abs(A4 - 2.0) < 1e-9   # 20 unidades / 10 px en X
    assert abs(E4 - 0.5) < 1e-9   # 5 unidades / 10 px en Y
    # pixel (10,10) debe mapear a (500+20, 500+5) = (520, 505)
    x_chk = A4 * 10 + B4 * 10 + C4
    y_chk = D4 * 10 + E4 * 10 + F4
    assert abs(x_chk - 520) < 1e-6 and abs(y_chk - 505) < 1e-6

    # Caso degenerado: 3 puntos colineales debe lanzar error claro
    try:
        calcular_afin_3_puntos([(0, 0), (5, 0), (10, 0)], [(0, 0), (5, 0), (10, 0)])
        raise AssertionError("Debería haber lanzado ValueError por puntos colineales")
    except ValueError as e:
        print(f"Puntos colineales -> error esperado: {e}")

    print("\nPrueba 8 (3 puntos de control) pasó correctamente.")
