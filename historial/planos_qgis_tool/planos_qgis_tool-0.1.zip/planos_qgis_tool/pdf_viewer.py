# -*- coding: utf-8 -*-
"""
pdf_viewer.py
-------------
Visor de PDF embebido (sin depender de un lector externo). Renderiza cada
página como imagen usando PyMuPDF (fitz) y permite navegar entre páginas -
así se puede revisar directamente cuál página del brochure tiene el plano
de implantación, sin salir de la ventana de validación.

Acepta el PDF como una RUTA de archivo real (modo carpeta local) o como
BYTES en memoria (modo remoto/Drive) - en el segundo caso nunca se escribe
una copia del PDF original en disco.

Requiere: pip install pymupdf   (dentro del Python de QGIS)
Si no está instalado, fitz_disponible() devuelve False y quien lo use debe
mostrar un mensaje pidiendo instalarlo (ver popup_dialog.py).
"""

import subprocess
import sys

from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtGui import QImage, QPixmap
from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QMessageBox,
)

try:
    import fitz  # PyMuPDF
    _FITZ_DISPONIBLE = True
except Exception:
    fitz = None
    _FITZ_DISPONIBLE = False

from .image_viewer import VisorImagenConControles

ZOOM_ALTA_RESOLUCION = 4.0  # ~288 dpi para una página tamaño carta/brochure típico


def fitz_disponible():
    return _FITZ_DISPONIBLE


def asegurar_fitz():
    """
    Si PyMuPDF no está disponible, intenta instalarlo automáticamente con pip
    en el mismo intérprete de Python que está corriendo QGIS, y vuelve a
    intentar importarlo. Devuelve True si al final quedó disponible.
    """
    global fitz, _FITZ_DISPONIBLE
    if _FITZ_DISPONIBLE:
        return True
    try:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "--quiet", "--disable-pip-version-check", "pymupdf"]
        )
    except Exception:
        return False

    try:
        import importlib
        fitz = importlib.import_module("fitz")
        _FITZ_DISPONIBLE = True
        return True
    except Exception:
        return False


def _abrir_documento(ruta_pdf=None, datos_pdf=None):
    if datos_pdf is not None:
        return fitz.open(stream=datos_pdf, filetype="pdf")
    return fitz.open(ruta_pdf)


def contar_paginas(ruta_pdf=None, datos_pdf=None):
    doc = _abrir_documento(ruta_pdf, datos_pdf)
    try:
        return doc.page_count
    finally:
        doc.close()


def renderizar_pagina(ruta_pdf=None, datos_pdf=None, indice_pagina=0, zoom=2.0):
    """Devuelve un QPixmap con la página `indice_pagina` (0-based) del PDF renderizada."""
    doc = _abrir_documento(ruta_pdf, datos_pdf)
    try:
        pagina = doc[indice_pagina]
        matriz = fitz.Matrix(zoom, zoom)
        pix = pagina.get_pixmap(matrix=matriz, alpha=False)
        formato = QImage.Format_RGB888
        imagen_qt = QImage(pix.samples, pix.width, pix.height, pix.stride, formato)
        # copy() porque `pix.samples` se libera al cerrar el documento
        return QPixmap.fromImage(imagen_qt.copy())
    finally:
        doc.close()


def exportar_pagina_alta_resolucion_bytes(ruta_pdf=None, datos_pdf=None, indice_pagina=0,
                                          zoom=ZOOM_ALTA_RESOLUCION):
    """Renderiza la página en alta resolución y devuelve los bytes PNG resultantes
    (en memoria - no escribe nada en disco)."""
    doc = _abrir_documento(ruta_pdf, datos_pdf)
    try:
        pagina = doc[indice_pagina]
        matriz = fitz.Matrix(zoom, zoom)
        pix = pagina.get_pixmap(matrix=matriz, alpha=False)
        return pix.tobytes("png")
    finally:
        doc.close()


class VisorPDF(QWidget):
    """Widget con navegación de páginas (Anterior/Siguiente) + visor con zoom/pan."""

    # Emite (bytes_png, nombre_sugerido) de la página exportada en alta resolución
    pagina_para_georef = pyqtSignal(bytes, str)

    def __init__(self, ruta_pdf=None, datos_pdf=None, nombre_base="documento", parent=None):
        super().__init__(parent)
        self.ruta_pdf = ruta_pdf
        self.datos_pdf = datos_pdf
        self.nombre_base = nombre_base
        self.pagina_actual = 0
        self.total_paginas = contar_paginas(ruta_pdf, datos_pdf) if _FITZ_DISPONIBLE else 0

        layout = QVBoxLayout(self)

        nav = QHBoxLayout()
        self.boton_anterior = QPushButton("< Página anterior")
        self.boton_anterior.clicked.connect(self._anterior)
        self.label_pagina = QLabel()
        self.label_pagina.setAlignment(Qt.AlignCenter)
        self.boton_siguiente = QPushButton("Página siguiente >")
        self.boton_siguiente.clicked.connect(self._siguiente)
        nav.addWidget(self.boton_anterior)
        nav.addWidget(self.label_pagina, stretch=1)
        nav.addWidget(self.boton_siguiente)
        layout.addLayout(nav)

        self.contenedor_visor = QVBoxLayout()
        layout.addLayout(self.contenedor_visor, stretch=1)

        self.boton_usar_pagina = QPushButton(
            "Usar esta página para georreferenciar (exporta en alta resolución)"
        )
        self.boton_usar_pagina.clicked.connect(self._usar_pagina_actual)
        layout.addWidget(self.boton_usar_pagina)

        self._visor_actual = None
        self._mostrar_pagina_actual()

    def _mostrar_pagina_actual(self):
        while self.contenedor_visor.count():
            item = self.contenedor_visor.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()

        self.label_pagina.setText(f"Página {self.pagina_actual + 1} de {self.total_paginas}")
        self.boton_anterior.setEnabled(self.pagina_actual > 0)
        self.boton_siguiente.setEnabled(self.pagina_actual < self.total_paginas - 1)

        try:
            pixmap = renderizar_pagina(self.ruta_pdf, self.datos_pdf, self.pagina_actual)
        except Exception as e:
            self.contenedor_visor.addWidget(QLabel(f"No se pudo renderizar la página: {e}"))
            return

        visor = VisorImagenConControles(pixmap=pixmap, modo_captura_puntos=False)
        self.contenedor_visor.addWidget(visor)
        self._visor_actual = visor

    def _anterior(self):
        if self.pagina_actual > 0:
            self.pagina_actual -= 1
            self._mostrar_pagina_actual()

    def _siguiente(self):
        if self.pagina_actual < self.total_paginas - 1:
            self.pagina_actual += 1
            self._mostrar_pagina_actual()

    def _usar_pagina_actual(self):
        try:
            datos_png = exportar_pagina_alta_resolucion_bytes(
                self.ruta_pdf, self.datos_pdf, self.pagina_actual
            )
        except Exception as e:
            QMessageBox.critical(self, "Error exportando página", str(e))
            return
        nombre_sugerido = f"{self.nombre_base}_pagina{self.pagina_actual + 1}_alta_res.png"
        self.pagina_para_georef.emit(datos_png, nombre_sugerido)
