# -*- coding: utf-8 -*-
"""
image_viewer.py
---------------
Widget reutilizable para mostrar una imagen (webp/jpg/png) con zoom y pan,
usado tanto en la ventana de validación (solo ver) como en el diálogo de
georreferenciación (donde además hay que capturar N clics del usuario sobre
puntos de control y devolver sus coordenadas en PÍXELES de la imagen original).
"""

from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtGui import QPixmap, QPainter, QPen, QColor
from qgis.PyQt.QtWidgets import (
    QGraphicsView, QGraphicsScene, QGraphicsEllipseItem, QGraphicsLineItem,
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
)

# Colores cíclicos para distinguir cada punto de control marcado (1º rojo,
# 2º azul, 3º verde, y se repite si algún día se piden más de 3).
COLORES_PUNTOS = [QColor(255, 0, 0), QColor(0, 140, 255), QColor(0, 200, 0), QColor(255, 165, 0)]


class VisorImagen(QGraphicsView):
    """
    Visor con zoom (rueda del mouse) y paneo (arrastrar con el mouse).
    Si `modo_captura_puntos=True`, cada clic izquierdo agrega un marcador
    numerado/coloreado y emite `punto_marcado(x_pixel, y_pixel)`. Al llegar a
    `num_puntos_requeridos` clics, emite `puntos_completados(lista_de_(x,y))`
    y se puede reiniciar con `reiniciar_puntos()`.
    """

    punto_marcado = pyqtSignal(float, float)
    puntos_completados = pyqtSignal(list)

    def __init__(self, ruta_imagen=None, pixmap=None, modo_captura_puntos=False,
                 num_puntos_requeridos=3, parent=None):
        super().__init__(parent)
        self.setRenderHint(QPainter.Antialiasing)
        self.setDragMode(QGraphicsView.ScrollHandDrag)
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)

        self._scene = QGraphicsScene(self)
        self.setScene(self._scene)

        if pixmap is not None:
            self.pixmap = pixmap
        elif ruta_imagen is not None:
            self.pixmap = QPixmap(ruta_imagen)
        else:
            raise ValueError("Debes pasar ruta_imagen o pixmap")

        self._item_pixmap = self._scene.addPixmap(self.pixmap)
        self._scene.setSceneRect(self._item_pixmap.boundingRect())

        self.modo_captura_puntos = modo_captura_puntos
        self.num_puntos_requeridos = num_puntos_requeridos
        self._puntos_marcados = []  # [(x,y), ...] en coords de escena = coords de píxel de la imagen
        self._items_marcadores = []
        self._zoom_manual = False  # una vez el usuario hace zoom, dejamos de reajustar solos en cada resize

        self.fitInView(self._item_pixmap, Qt.KeepAspectRatio)

    def imagen_valida(self):
        return not self.pixmap.isNull()

    def zoom_in(self):
        self._zoom_manual = True
        self.scale(1.25, 1.25)

    def zoom_out(self):
        self._zoom_manual = True
        self.scale(0.8, 0.8)

    def ajustar_a_ventana(self):
        self._zoom_manual = False
        self.fitInView(self._item_pixmap, Qt.KeepAspectRatio)

    def wheelEvent(self, event):
        self._zoom_manual = True
        factor = 1.25 if event.angleDelta().y() > 0 else 0.8
        self.scale(factor, factor)

    def mousePressEvent(self, event):
        if self.modo_captura_puntos and event.button() == Qt.LeftButton:
            if len(self._puntos_marcados) >= self.num_puntos_requeridos:
                # ya se completaron todos los puntos - un clic más reinicia y empieza de nuevo
                self.reiniciar_puntos()

            punto_escena = self.mapToScene(event.pos())
            x, y = punto_escena.x(), punto_escena.y()
            self._agregar_marcador(x, y)
            self._puntos_marcados.append((x, y))
            self.punto_marcado.emit(x, y)

            if len(self._puntos_marcados) == self.num_puntos_requeridos:
                self.puntos_completados.emit(list(self._puntos_marcados))
            return
        super().mousePressEvent(event)

    def _agregar_marcador(self, x, y):
        radio = max(3.0, self.pixmap.width() * 0.004)
        indice = len(self._puntos_marcados)
        color = COLORES_PUNTOS[indice % len(COLORES_PUNTOS)]
        elipse = QGraphicsEllipseItem(x - radio, y - radio, radio * 2, radio * 2)
        elipse.setBrush(color)
        elipse.setPen(QPen(Qt.white, radio * 0.3))
        self._scene.addItem(elipse)
        self._items_marcadores.append(elipse)

        # línea desde el punto anterior, solo de guía visual
        if self._puntos_marcados:
            x_prev, y_prev = self._puntos_marcados[-1]
            linea = QGraphicsLineItem(x_prev, y_prev, x, y)
            linea.setPen(QPen(QColor(200, 200, 0), radio * 0.4))
            self._scene.addItem(linea)
            self._items_marcadores.append(linea)

    def reiniciar_puntos(self):
        for item in self._items_marcadores:
            self._scene.removeItem(item)
        self._items_marcadores = []
        self._puntos_marcados = []

    def resizeEvent(self, event):
        super().resizeEvent(event)
        # Solo reajustamos el encuadre automático mientras el usuario no haya
        # hecho zoom manual - si no, cada redimensionado de la ventana le
        # borraría el zoom que hizo con la rueda o los botones.
        if not self._zoom_manual:
            self.fitInView(self._item_pixmap, Qt.KeepAspectRatio)


class VisorImagenConControles(QWidget):
    """
    Envuelve VisorImagen agregando una pequeña barra con botones de
    Zoom +, Zoom -, y "Ajustar a ventana" - además del zoom con la rueda
    del mouse y el arrastre que VisorImagen ya trae, para que sea más fácil
    de descubrir y usar antes de decidir georreferenciar un plano.
    """

    def __init__(self, ruta_imagen=None, pixmap=None, modo_captura_puntos=False,
                 num_puntos_requeridos=3, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.visor = VisorImagen(
            ruta_imagen=ruta_imagen, pixmap=pixmap,
            modo_captura_puntos=modo_captura_puntos,
            num_puntos_requeridos=num_puntos_requeridos,
        )

        barra = QHBoxLayout()
        boton_menos = QPushButton("Zoom −")
        boton_menos.clicked.connect(self.visor.zoom_out)
        boton_mas = QPushButton("Zoom +")
        boton_mas.clicked.connect(self.visor.zoom_in)
        boton_ajustar = QPushButton("Ajustar a ventana")
        boton_ajustar.clicked.connect(self.visor.ajustar_a_ventana)
        barra.addWidget(boton_menos)
        barra.addWidget(boton_mas)
        barra.addWidget(boton_ajustar)
        barra.addStretch(1)

        layout.addLayout(barra)
        layout.addWidget(self.visor, stretch=1)

        # Delegamos los atributos/señales usados por quien use este widget
        # como si fuera un VisorImagen directamente.
        self.pixmap = self.visor.pixmap
        self.punto_marcado = self.visor.punto_marcado
        self.puntos_completados = self.visor.puntos_completados

    def imagen_valida(self):
        return self.visor.imagen_valida()

    def reiniciar_puntos(self):
        self.visor.reiniciar_puntos()

