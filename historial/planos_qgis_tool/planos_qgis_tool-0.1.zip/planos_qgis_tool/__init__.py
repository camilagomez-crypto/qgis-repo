# -*- coding: utf-8 -*-
def classFactory(iface):
    from .plugin_main import PlanosPlugin
    return PlanosPlugin(iface)
