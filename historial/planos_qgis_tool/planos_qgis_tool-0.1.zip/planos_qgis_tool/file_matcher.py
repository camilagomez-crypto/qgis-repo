# -*- coding: utf-8 -*-
"""
file_matcher.py
---------------
Recorre la carpeta CONSTRUTORAS\\<constructora>\\PLANOS\\... y arma un índice
de archivos por carpeta de proyecto. Luego permite emparejar cada feature del
GeoJSON (por su nombre y ciudad) contra ese índice usando coincidencia difusa
de texto (tolera tildes, mayúsculas, guiones/espacios distintos).

No depende de QGIS - se puede probar aislado.
"""

import os
import re
import unicodedata
from difflib import SequenceMatcher

EXT_IMAGEN = (".webp", ".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp")
EXT_PDF = (".pdf",)

UMBRAL_COINCIDENCIA = 0.55  # por debajo de esto, se considera "sin match confiable"

# Nombres de subcarpeta que NO representan el proyecto en sí (p.ej. Bolivar
# guarda sus PDF dentro de ".../<proyecto>/brochure/" y sus webp dentro de
# ".../<proyecto>/planos/") - hay que subir un nivel más para llegar al
# nombre real del proyecto.
SUBCARPETAS_GENERICAS = {
    "brochure", "brochures", "planos", "plano", "planta", "plantas",
    "renders", "render", "fotos", "imagenes", "images", "urbanismo",
}


def _resolver_carpeta_proyecto(ruta_carpeta, planos_dir):
    """
    Sube por el árbol de carpetas mientras el nombre de la carpeta actual sea
    una subcarpeta "genérica" (brochure/planos/fotos/...), hasta encontrar la
    carpeta que realmente representa el proyecto, o hasta llegar a planos_dir.
    """
    actual = os.path.normpath(ruta_carpeta)
    planos_dir_norm = os.path.normpath(planos_dir)
    while True:
        nombre = os.path.basename(actual)
        if nombre.lower() not in SUBCARPETAS_GENERICAS:
            return actual
        padre = os.path.dirname(actual)
        if padre == actual or os.path.normpath(padre) == planos_dir_norm:
            return actual  # no subir más (evita loop infinito / pasarse de planos_dir)
        actual = padre


def normalizar(texto):
    """minúsculas, sin tildes, sin puntuación -> solo [a-z0-9_]"""
    if texto is None:
        return ""
    texto = str(texto).lower().strip()
    texto = unicodedata.normalize("NFKD", texto)
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    texto = re.sub(r"[^a-z0-9]+", "_", texto)
    return texto.strip("_")


def construir_indice(carpeta_constructora):
    """
    Recorre <carpeta_constructora>\\PLANOS\\<ciudad>\\<proyecto>\\... y agrupa
    los archivos de imagen/pdf encontrados por carpeta de proyecto.

    Devuelve: { proyecto_normalizado: {"ciudad": str, "nombre_carpeta": str,
                                        "ruta_carpeta": str, "archivos": [rutas]} }
    Si un mismo proyecto normalizado aparece en más de una carpeta (raro, pero
    posible), se fusionan sus archivos.
    """
    indice = {}
    planos_dir = os.path.join(carpeta_constructora, "PLANOS")
    if not os.path.isdir(planos_dir):
        return indice

    for root, _dirs, files in os.walk(planos_dir):
        archivos_relevantes = [f for f in files if f.lower().endswith(EXT_IMAGEN + EXT_PDF)]
        if not archivos_relevantes:
            continue

        carpeta_proyecto = _resolver_carpeta_proyecto(root, planos_dir)
        nombre_carpeta = os.path.basename(carpeta_proyecto)
        clave = normalizar(nombre_carpeta)
        if not clave:
            continue

        rel = os.path.relpath(carpeta_proyecto, planos_dir)
        partes = rel.split(os.sep)
        ciudad = partes[0] if partes and partes[0] != "." else ""

        entry = indice.setdefault(clave, {
            "ciudad": ciudad,
            "nombre_carpeta": nombre_carpeta,
            "ruta_carpeta": carpeta_proyecto,
            "archivos": [],
        })
        entry["archivos"].extend(os.path.join(root, f) for f in archivos_relevantes)

    return indice


def construir_indice_desde_listado(listado, constructora):
    """
    Construye el mismo tipo de índice que construir_indice(), pero a partir
    del listado JSON obtenido remotamente (drive_web.listar_archivos) en vez
    de recorrer una carpeta local en disco.

    `listado`: lista completa de TODAS las constructoras (tal como la
    devuelve el Apps Script). Se filtra a la subcarpeta
    '<constructora>/PLANOS/'.

    A diferencia de construir_indice(), cada archivo queda representado
    como un dict {"id", "nombre", "ruta_relativa"} en vez de una ruta local
    real - hay que descargarlo bajo demanda con drive_web.descargar_archivo
    usando su "id".
    """
    indice = {}
    prefijo = f"{constructora}/PLANOS/"

    for archivo in listado:
        ruta_rel = archivo.get("rutaRelativa", "").replace("\\", "/")
        if not ruta_rel.startswith(prefijo):
            continue

        resto = ruta_rel[len(prefijo):]
        partes = [p for p in resto.split("/") if p]
        if len(partes) < 2:
            continue  # hace falta al menos <ciudad>/<algo>

        nombre_archivo = partes[-1]
        if not nombre_archivo.lower().endswith(EXT_IMAGEN + EXT_PDF):
            continue

        carpetas = partes[:-1]
        while len(carpetas) > 1 and carpetas[-1].lower() in SUBCARPETAS_GENERICAS:
            carpetas = carpetas[:-1]

        # Quita carpetas "envoltorio" al inicio (ej. "descargas_bolivar") para
        # que la ciudad no se confunda con ese nombre de envoltorio.
        while len(carpetas) > 1 and carpetas[0].lower().startswith("descargas"):
            carpetas = carpetas[1:]

        nombre_carpeta = carpetas[-1]
        clave = normalizar(nombre_carpeta)
        if not clave:
            continue
        ciudad = carpetas[0]

        entry = indice.setdefault(clave, {
            "ciudad": ciudad,
            "nombre_carpeta": nombre_carpeta,
            "archivos": [],
        })
        entry["archivos"].append({
            "id": archivo["id"],
            "nombre": nombre_archivo,
            "ruta_relativa": ruta_rel,
        })

    return indice


def extraer_slug_de_link(url):
    """
    Extrae el último segmento no vacío de una URL (quitando '/' finales,
    query strings '?...' y fragmentos '#...'), normalizado. Muchos sitios de
    constructoras usan ese segmento como slug del proyecto (p.ej.
    'https://www.constructorabolivar.com/proyectos/cerros-del-viento' ->
    'cerros_del_viento'), lo que suele ser una pista MÁS confiable que
    comparar el nombre comercial del proyecto contra el nombre de carpeta.
    """
    if not url:
        return ""
    url = str(url).split("?")[0].split("#")[0].rstrip("/")
    segmento = url.rsplit("/", 1)[-1]
    return normalizar(segmento)


MARGEN_AMBIGUEDAD = 0.05  # si el 2º mejor puntaje queda a menos de esto del mejor, se marca como ambiguo


def emparejar_feature(nombre_proyecto, ciudad_feature, indice, link=None):
    """
    Busca en `indice` (salida de construir_indice) la carpeta de proyecto que
    mejor coincide con el nombre/ciudad de un feature del GeoJSON.

    Si se pasa `link`, primero intenta un match EXACTO por el slug de esa URL
    contra las claves del índice (más confiable que el nombre comercial).
    Si no hay link o no coincide exacto, cae a coincidencia difusa por
    nombre + bonus si la ciudad coincide (como substring en cualquier
    dirección, no igualdad estricta - las ciudades del GeoJSON a veces son
    regiones amplias como "Cali y sus alrededores" mientras las carpetas
    usan el municipio puntual).

    Devuelve (clave, info_dict, score, alternativas) donde `alternativas` es
    una lista de otras claves candidatas casi empatadas con la elegida
    (score >= UMBRAL_COINCIDENCIA y a menos de MARGEN_AMBIGUEDAD del mejor) -
    lista vacía si no hay ambigüedad. Si no hay match aceptable, devuelve
    (None, None, 0.0, []).
    """
    # --- Intento 1: match exacto por slug del link (si se dio y existe en el índice) ---
    slug = extraer_slug_de_link(link) if link else ""
    if slug and slug in indice:
        return slug, indice[slug], 1.0, []

    # --- Intento 2: coincidencia difusa por nombre + bonus de ciudad ---
    obj_norm = normalizar(nombre_proyecto)
    ciudad_norm = normalizar(ciudad_feature)

    puntajes = []  # [(score, clave), ...]
    for clave, info in indice.items():
        score = SequenceMatcher(None, obj_norm, clave).ratio()
        ciudad_carpeta_norm = normalizar(info.get("ciudad", ""))
        if ciudad_norm and ciudad_carpeta_norm and (
            ciudad_norm in ciudad_carpeta_norm or ciudad_carpeta_norm in ciudad_norm
        ):
            score += 0.15
        puntajes.append((score, clave))

    puntajes.sort(key=lambda par: par[0], reverse=True)
    if not puntajes or puntajes[0][0] < UMBRAL_COINCIDENCIA:
        return None, None, 0.0, []

    mejor_score, mejor_clave = puntajes[0]
    alternativas = [clave for score, clave in puntajes[1:]
                    if score >= UMBRAL_COINCIDENCIA and (mejor_score - score) < MARGEN_AMBIGUEDAD]

    return mejor_clave, indice[mejor_clave], mejor_score, alternativas


if __name__ == "__main__":
    # Prueba con una estructura de carpetas simulada (sin necesitar los archivos reales)
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        proyectos_prueba = [
            # Estructura tipo Marval: archivo directo en la carpeta del proyecto
            ("soledad", "solario", "", ["Solario_Urbanismo_Piso1_Baja-vis.webp"]),
            # Estructura tipo Bolivar: archivos dentro de subcarpetas genéricas
            ("barranquilla", "bonavento", "brochure", ["Brochure Bonavento_No SMMLV.pdf"]),
            ("armenia", "cerros_del_viento", "brochure", ["PDF Cerros del viento.pdf"]),
            ("armenia", "cerros_del_viento", "planos", ["plano_01_apartamento_tipo_desde_43.webp"]),
        ]
        for ciudad, proyecto, subcarpeta, archivos in proyectos_prueba:
            carpeta = os.path.join(tmp, "PLANOS", ciudad, proyecto, subcarpeta) if subcarpeta else \
                      os.path.join(tmp, "PLANOS", ciudad, proyecto)
            os.makedirs(carpeta, exist_ok=True)
            for a in archivos:
                open(os.path.join(carpeta, a), "w").close()

        indice = construir_indice(tmp)
        print("Índice construido:", list(indice.keys()))
        # cerros_del_viento debe tener 2 archivos (el pdf de brochure Y el webp de planos), no dos entradas separadas
        assert len(indice.get("cerros_del_viento", {}).get("archivos", [])) == 2, \
            "cerros_del_viento debería agrupar el pdf y el webp bajo la misma clave"
        assert "brochure" not in indice, "no debería quedar ninguna entrada llamada 'brochure' suelta"
        assert "planos" not in indice, "no debería quedar ninguna entrada llamada 'planos' suelta"
        print("Prueba de agrupamiento por carpeta genérica: OK\n")

        casos = [
            ("Bonavento", "Barranquilla"),
            ("Cerros del Viento", "Armenia"),
            ("Solario", "Soledad"),
            ("Proyecto Que No Existe", "Bogotá"),
        ]
        for nombre, ciudad in casos:
            clave, info, score, alternativas = emparejar_feature(nombre, ciudad, indice)
            if clave:
                extra = f"  [AMBIGUO, también: {alternativas}]" if alternativas else ""
                print(f"'{nombre}' ({ciudad}) -> {clave}  score={score:.2f}  archivos={len(info['archivos'])}{extra}")
            else:
                print(f"'{nombre}' ({ciudad}) -> SIN COINCIDENCIA (score={score:.2f})")

        # --- Prueba de bonus de ciudad como región amplia (Cali y sus alrededores) ---
        clave, info, score, alt = emparejar_feature("Solario", "Cali y sus alrededores", indice)
        print(f"\n'Solario' con ciudad región amplia -> {clave} (score={score:.2f}, sin bonus porque 'soledad' "
              f"no está relacionada con 'cali_y_sus_alrededores' - esto es esperado, sin bonus de ciudad aquí)")

        # --- Prueba de ambigüedad con empate controlado (mismo largo, misma distancia de edición) ---
        indice_empate = {
            "aaaac": {"ciudad": "x", "nombre_carpeta": "x", "ruta_carpeta": "x", "archivos": ["a.webp"]},
            "aaaad": {"ciudad": "x", "nombre_carpeta": "x", "ruta_carpeta": "x", "archivos": ["b.webp"]},
        }
        clave2, info2, score2, alternativas2 = emparejar_feature("aaaab", "", indice_empate)
        print(f"\nEmpate controlado 'Proyecto Gama' -> elegido: {clave2} (score={score2:.2f}), "
              f"alternativas ambiguas: {alternativas2}")
        assert alternativas2, "Debería detectar ambigüedad en un empate exacto de puntaje"

        # --- Prueba de match exacto por slug de link ---
        clave3, info3, score3, alt3 = emparejar_feature(
            "Nombre Comercial Rarísimo Que No Se Parece", "Barranquilla", indice,
            link="https://www.constructorabolivar.com/proyectos/bonavento"
        )
        print(f"\nMatch por link (nombre comercial no coincide para nada) -> {clave3} (score={score3:.2f})")
        assert clave3 == "bonavento" and score3 == 1.0, "El match por link debería ganar con score 1.0"

    # --- Prueba de construir_indice_desde_listado (simulando la respuesta del Apps Script) ---
    listado_simulado = [
        {"id": "1", "nombre": "x.webp", "rutaRelativa": "Marval/PLANOS/soledad/solario/Solario_Urbanismo_Piso1_Baja.webp"},
        {"id": "2", "nombre": "y.pdf", "rutaRelativa": "Bolivar/PLANOS/descargas_bolivar/armenia/cerros_del_viento/brochure/PDF Cerros del viento.pdf"},
        {"id": "3", "nombre": "z.webp", "rutaRelativa": "Bolivar/PLANOS/descargas_bolivar/armenia/cerros_del_viento/planos/plano_01_apartamento_tipo_43.webp"},
        {"id": "4", "nombre": "otro.geojson", "rutaRelativa": "Bolivar/PUNTOS/bolivar_proyectos.geojson"},  # no es PLANOS, debe ignorarse
    ]
    indice_marval = construir_indice_desde_listado(listado_simulado, "Marval")
    print(f"\nÍndice remoto Marval: {list(indice_marval.keys())}")
    assert "solario" in indice_marval and len(indice_marval["solario"]["archivos"]) == 1

    indice_bolivar = construir_indice_desde_listado(listado_simulado, "Bolivar")
    print(f"Índice remoto Bolivar: {list(indice_bolivar.keys())}")
    assert "cerros_del_viento" in indice_bolivar
    assert len(indice_bolivar["cerros_del_viento"]["archivos"]) == 2, \
        "cerros_del_viento debería agrupar el pdf (brochure/) y el webp (planos/) en una sola entrada"
    assert indice_bolivar["cerros_del_viento"]["ciudad"] == "armenia"
    print("Prueba de construir_indice_desde_listado: OK")
