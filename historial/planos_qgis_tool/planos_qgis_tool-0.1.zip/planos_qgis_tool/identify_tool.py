# -*- coding: utf-8 -*-
"""
identify_tool.py
----------------
Herramienta de mapa (QgsMapTool) que, al hacer clic cerca de un punto de
proyecto, identifica el feature más cercano entre las capas cargadas
(Bolivar/Marval/...), arma sus atributos y la lista de archivos asociados,
y abre la ventana de validación (popup_dialog.VentanaValidacion).

Depende de la API de QGIS - solo se ejecuta dentro de QGIS.
"""

import os

from qgis.core import (
    QgsGeometry, QgsPointXY, QgsRectangle, QgsFeatureRequest,
    QgsCoordinateTransform, QgsProject,
)
from qgis.gui import QgsMapTool
from qgis.PyQt.QtCore import QPoint

from .popup_dialog import VentanaValidacion
from .file_matcher import emparejar_feature
from .georef_dialog import DialogoGeoreferenciar
from . import web_auth_client as drive_web

RADIO_BUSQUEDA_PX = 12


class HerramientaIdentificarPunto(QgsMapTool):
    """
    `capas_info`: lista de dicts, uno por constructora/capa cargada:
        {
          "layer": QgsVectorLayer,          # capa de puntos (EPSG:4326)
          "constructora": str,               # p.ej. "Bolivar"
          "campo_nombre": str,               # campo con el nombre del proyecto
          "campo_ciudad": str,               # campo con la ciudad (puede ser "")
          "campo_link": str,                 # campo con el link/URL (puede ser "")
          "indice_archivos": dict,           # salida de construir_indice o construir_indice_desde_listado
          "modo": "local" | "remoto",        # de dónde vienen los archivos
          "url_base": str,                   # (solo modo remoto) URL del Apps Script
        }
    """

    def __init__(self, canvas, capas_info, iface):
        super().__init__(canvas)
        self.canvas = canvas
        self.capas_info = capas_info
        self.iface = iface
        self._ventana_validacion = None  # se crea una sola vez y se reutiliza en cada clic
        self._ventanas_georef = []  # los diálogos de georreferenciar sí son uno por acción

    def canvasReleaseEvent(self, event):
        punto_mapa = self.toMapCoordinates(event.pos())
        esquina1 = self.toMapCoordinates(event.pos() - QPoint(RADIO_BUSQUEDA_PX, RADIO_BUSQUEDA_PX))
        esquina2 = self.toMapCoordinates(event.pos() + QPoint(RADIO_BUSQUEDA_PX, RADIO_BUSQUEDA_PX))
        rect_busqueda_canvas = QgsRectangle(esquina1, esquina2)
        crs_canvas = self.canvas.mapSettings().destinationCrs()

        mejor_info, mejor_feature, mejor_dist = None, None, None

        for info in self.capas_info:
            capa = info["layer"]
            if crs_canvas != capa.crs():
                transformador = QgsCoordinateTransform(crs_canvas, capa.crs(), QgsProject.instance())
                try:
                    rect_capa = transformador.transformBoundingBox(rect_busqueda_canvas)
                except Exception:
                    continue
            else:
                rect_capa = rect_busqueda_canvas

            punto_geom = QgsGeometry.fromPointXY(punto_mapa)
            if crs_canvas != capa.crs():
                transformador2 = QgsCoordinateTransform(crs_canvas, capa.crs(), QgsProject.instance())
                punto_geom.transform(transformador2)

            solicitud = QgsFeatureRequest().setFilterRect(rect_capa)
            for feature in capa.getFeatures(solicitud):
                distancia = feature.geometry().distance(punto_geom)
                if mejor_dist is None or distancia < mejor_dist:
                    mejor_dist, mejor_info, mejor_feature = distancia, info, feature

        if mejor_feature is None:
            return

        self._abrir_ventana(mejor_info, mejor_feature)

    def _construir_archivos_dict(self, info, archivos_crudos):
        """Convierte lo que trae el índice (rutas locales o dicts remotos) al
        formato unificado que espera popup_dialog.VentanaValidacion."""
        resultado = []
        modo = info.get("modo", "local")

        if modo == "remoto":
            url_base = info["url_base"]
            token = info["token"]
            for archivo in archivos_crudos:
                file_id = archivo["id"]
                resultado.append({
                    "nombre": archivo["nombre"],
                    "ruta_local": None,
                    "cargar_bytes": (lambda fid=file_id, url=url_base, tok=token, ventana=self.iface.mainWindow():
                                     drive_web.descargar_archivo(url, tok, fid, parent=ventana)[2]),
                })
        else:
            for ruta in archivos_crudos:
                resultado.append({
                    "nombre": os.path.basename(ruta),
                    "ruta_local": ruta,
                    "cargar_bytes": (lambda r=ruta: open(r, "rb").read()),
                })
        return resultado

    def _abrir_ventana(self, info, feature):
        campos = [f.name() for f in feature.fields()]
        atributos = [(campo, feature[campo]) for campo in campos]

        nombre_proyecto = feature[info["campo_nombre"]] if info["campo_nombre"] in campos else ""
        ciudad = feature[info["campo_ciudad"]] if info.get("campo_ciudad") and info["campo_ciudad"] in campos else ""
        link = feature[info["campo_link"]] if info.get("campo_link") and info["campo_link"] in campos else None

        clave, datos_indice, score, alternativas = emparejar_feature(
            nombre_proyecto, ciudad, info["indice_archivos"], link=link
        )
        archivos_crudos = datos_indice["archivos"] if datos_indice else []
        archivos = self._construir_archivos_dict(info, archivos_crudos)

        titulo = f"{info['constructora']} — {nombre_proyecto or '(sin nombre)'}"
        if alternativas:
            titulo += "  ⚠ posible ambigüedad en archivos - valida bien"
        geom = feature.geometry()
        punto = geom.asPoint() if geom else None

        def _al_georeferenciar(nombre_archivo, _atributos, ruta_local=None, datos_bytes=None):
            if punto is None:
                return
            dialogo = DialogoGeoreferenciar(
                nombre_proyecto=nombre_proyecto or clave or "proyecto",
                lon=punto.x(), lat=punto.y(),
                ruta_imagen=ruta_local, datos_imagen=datos_bytes, nombre_archivo=nombre_archivo,
                iface=self.iface,
            )
            self._ventanas_georef.append(dialogo)  # evita que se recolecte mientras está abierto
            dialogo.show()

        if self._ventana_validacion is None:
            self._ventana_validacion = VentanaValidacion(parent=self.iface.mainWindow())

        self._ventana_validacion.mostrar_datos(
            titulo=titulo, atributos=atributos, archivos=archivos,
            on_georeferenciar=_al_georeferenciar,
        )
