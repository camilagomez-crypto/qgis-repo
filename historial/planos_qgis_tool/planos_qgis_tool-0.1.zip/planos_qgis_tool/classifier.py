# -*- coding: utf-8 -*-
"""
classifier.py
-------------
Clasifica un archivo de plano (webp/imagen/pdf) según patrones en su nombre,
para saber si es candidato a georeferenciar (plano de sitio/urbanismo) o si
debe mostrarse solo como información de validación (planta de unidad, fachada,
render, etc.)

No depende de QGIS ni de ninguna librería externa - se puede probar aislado.
"""

import re

CATEGORIA_URBANISMO = "urbanismo"      # plano de sitio/implantación -> candidato a georeferenciar
CATEGORIA_UNIDAD = "unidad"            # planta de apto/casa individual -> NO georeferenciable
CATEGORIA_RENDER = "render"            # fachada, render aéreo, portería -> NO georeferenciable
CATEGORIA_PDF_BROCHURE = "brochure_pdf"  # PDF de mercadeo -> requiere revisión página por página
CATEGORIA_OTRO = "otro"                # sin clasificar -> requiere revisión manual

_PALABRAS_URBANISMO = ("urbanismo", "implantacion", "implantación", "planta_general", "loteo", "site_plan")
_PATRON_URB_CORTO = re.compile(r'(^|[_\-\.])urb(\d*)([_\-\.]|$)', re.IGNORECASE)
_PALABRAS_RENDER = ("fachada", "porteria", "portería", "aerea", "aérea", "render")
_PALABRAS_UNIDAD = ("apartamento", "apto_tipo", "apto ", "aptotipo", "casa_tipo", "torre_a", "torre_b", "torre a", "torre b")


def clasificar_archivo(nombre_archivo: str) -> str:
    """Devuelve una de las categorías CATEGORIA_* según el nombre del archivo."""
    f = nombre_archivo.lower()

    if f.endswith(".pdf"):
        return CATEGORIA_PDF_BROCHURE

    if any(p in f for p in _PALABRAS_URBANISMO) or _PATRON_URB_CORTO.search(f):
        return CATEGORIA_URBANISMO

    if any(p in f for p in _PALABRAS_RENDER):
        return CATEGORIA_RENDER

    if any(p in f for p in _PALABRAS_UNIDAD) or "apto" in f or "torre" in f:
        return CATEGORIA_UNIDAD

    return CATEGORIA_OTRO


def es_georeferenciable(categoria: str) -> bool:
    """Solo los planos de urbanismo se consideran candidatos directos a georeferenciar."""
    return categoria == CATEGORIA_URBANISMO


if __name__ == "__main__":
    # Pruebas rápidas con nombres reales vistos en el diagnóstico
    ejemplos = [
        ("Urbanismo_Piso1_Baja_Solario-barranquilla-vis.webp", CATEGORIA_URBANISMO),
        ("dimaro_urb.webp", CATEGORIA_URBANISMO),
        ("aquanova_urb_piso1.webp", CATEGORIA_URBANISMO),
        ("urb_piso3-5.webp", CATEGORIA_URBANISMO),
        ("plano_01_apartamento_tipo_desde_43.webp", CATEGORIA_UNIDAD),
        ("plano_02_apto_tipo_57.webp", CATEGORIA_UNIDAD),
        ("plano_01_casa_tipo_51.webp", CATEGORIA_UNIDAD),
        ("plano_01_torre_a_tipo_45m2_60m2.webp", CATEGORIA_UNIDAD),
        ("plano_03_fachada_de_la_porteria_del_proyecto.webp", CATEGORIA_RENDER),
        ("terrana_aerea.webp", CATEGORIA_RENDER),
        ("PDF Cerros del viento.pdf", CATEGORIA_PDF_BROCHURE),
        ("burdeos2.webp", CATEGORIA_OTRO),
    ]
    ok = 0
    for nombre, esperado in ejemplos:
        resultado = clasificar_archivo(nombre)
        estado = "OK" if resultado == esperado else "FALLO"
        if resultado == esperado:
            ok += 1
        print(f"[{estado}] {nombre!r:60s} -> {resultado} (esperado: {esperado})")
    print(f"\n{ok}/{len(ejemplos)} pruebas correctas")
