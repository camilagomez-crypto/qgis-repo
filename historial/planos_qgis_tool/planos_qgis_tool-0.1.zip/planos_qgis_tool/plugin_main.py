# -*- coding: utf-8 -*-
"""
plugin_main.py
--------------
Clase principal del plugin de QGIS. Agrega botones a la barra de
herramientas:
  1. "Cargar datos del equipo": descarga automáticamente vía el Apps Script
     (drive_web.py) el listado de proyectos/planos y carga las capas - SIN
     pedirle ninguna carpeta al usuario, y sin dejar copia persistente de
     los archivos originales en disco (los GeoJSON se cargan vía /vsimem/
     de GDAL; imágenes/PDF se descargan bajo demanda en memoria cuando se
     seleccionan, ver popup_dialog.py).
  2. "Cargar desde una carpeta (avanzado)": alternativa manual para
     pruebas/depuración, pidiendo la carpeta base directamente.
  3. "Activar validación de puntos": activa la herramienta de mapa que, al
     hacer clic sobre un punto, abre la ventana de validación/georreferenciación.
"""

import os
import uuid

from osgeo import gdal
from qgis.core import QgsVectorLayer, QgsProject
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import Qt

from .file_matcher import construir_indice_desde_listado
from .identify_tool import HerramientaIdentificarPunto
from . import web_auth_client as drive_web

# URL de la aplicación web del Apps Script (termina en /exec) - AJUSTA ESTA
# LÍNEA con la URL real una vez publicado el script (ver apps_script_codigo.gs).
URL_APPS_SCRIPT = "https://script.google.com/a/macros/servinformacion.com/s/AKfycbxLtQ5FjqoXz7xCeB8ZkYaKzjlaMQx7WKaic1GYM8fUXG1U7Tq68orbzN7uGirZoVzN/exec"

# Debe ser EXACTAMENTE la misma clave que pusiste en TOKEN_SECRETO dentro del
# Apps Script (apps_script_codigo.gs).
TOKEN_APPS_SCRIPT = "Servi2026Qgis987"

# Nombres de campo candidatos para detectar automáticamente cuál es el del
# nombre del proyecto y cuál el de la ciudad, según lo visto en los GeoJSON
# reales (Bolivar usa "nombre"/"ciudad", Marval usa "name"/"city").
CAMPOS_NOMBRE_CANDIDATOS = ["nombre", "name", "proyecto", "project", "project_name"]
CAMPOS_CIUDAD_CANDIDATOS = ["ciudad", "city", "municipio"]
CAMPOS_LINK_CANDIDATOS = ["link", "url", "enlace", "website", "web"]


def _detectar_campo(capa, candidatos):
    """Para campos que SIEMPRE deben resolver a algo (nombre, ciudad) - si no
    encuentra un candidato conocido, usa el primer campo disponible como
    mejor esfuerzo."""
    nombres_campos = [f.name() for f in capa.fields()]
    for candidato in candidatos:
        for campo in nombres_campos:
            if campo.lower() == candidato:
                return campo
    return nombres_campos[0] if nombres_campos else ""


def _detectar_campo_opcional(capa, candidatos):
    """Para campos opcionales (p.ej. link) - devuelve '' si no encuentra
    ningún candidato conocido, en vez de adivinar con el primer campo."""
    nombres_campos = [f.name() for f in capa.fields()]
    for candidato in candidatos:
        for campo in nombres_campos:
            if campo.lower() == candidato:
                return campo
    return ""


class PlanosPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.acciones = []
        self.capas_info = []
        self.herramienta_validacion = None

    def initGui(self):
        carpeta_iconos = os.path.join(os.path.dirname(__file__), "icons")
        icono_cargar = QIcon(os.path.join(carpeta_iconos, "cargar_datos.svg"))
        icono_validar = QIcon(os.path.join(carpeta_iconos, "validar_puntos.svg"))

        self.accion_cargar_remoto = QAction(icono_cargar, "Cargar datos del equipo", self.iface.mainWindow())
        self.accion_cargar_remoto.setToolTip("Cargar datos del equipo")
        self.accion_cargar_remoto.triggered.connect(self.cargar_datos_remoto)
        self.iface.addToolBarIcon(self.accion_cargar_remoto)
        self.acciones.append(self.accion_cargar_remoto)

        self.accion_validar = QAction(icono_validar, "Activar validación de puntos", self.iface.mainWindow())
        self.accion_validar.setToolTip("Activar validación de puntos")
        self.accion_validar.setCheckable(True)
        self.accion_validar.triggered.connect(self.activar_herramienta_validacion)
        self.iface.addToolBarIcon(self.accion_validar)
        self.acciones.append(self.accion_validar)

    def unload(self):
        for accion in self.acciones:
            self.iface.removeToolBarIcon(accion)
        self.acciones = []

    # --- Opción 1: automática, sin pedir carpeta (vía Apps Script / Drive) ---
    def cargar_datos_remoto(self):
        if not URL_APPS_SCRIPT or URL_APPS_SCRIPT.startswith("PON_AQUI"):
            QMessageBox.warning(
                self.iface.mainWindow(), "Falta configurar",
                "Falta poner la URL real del Apps Script en plugin_main.py "
                "(constante URL_APPS_SCRIPT)."
            )
            return

        if not drive_web.webengine_disponible():
            QMessageBox.critical(
                self.iface.mainWindow(), "Falta un componente de QGIS",
                "Esta instalación de QGIS no incluye QtWebEngine (el navegador "
                "embebido necesario para iniciar sesión con Google). No es algo "
                "que se pueda resolver desde el plugin - haría falta una "
                "instalación de QGIS que sí lo incluya, o reinstalar QGIS con "
                "ese componente activado."
            )
            return

        self.iface.mainWindow().setCursor(Qt.WaitCursor)
        try:
            try:
                listado = drive_web.listar_archivos(
                    URL_APPS_SCRIPT, TOKEN_APPS_SCRIPT, parent=self.iface.mainWindow()
                )
            except Exception as e:
                QMessageBox.critical(
                    self.iface.mainWindow(), "Error al conectar",
                    f"No se pudo obtener el listado desde el Apps Script:\n{e}\n\n"
                    f"Verifica tu conexión a internet y que la URL publicada siga activa."
                )
                return

            # Detecta cada constructora buscando su GeoJSON en "<constructora>/PUNTOS/*.geojson"
            geojsons_por_constructora = {}
            for archivo in listado:
                partes = archivo.get("rutaRelativa", "").replace("\\", "/").split("/")
                if len(partes) >= 3 and partes[1].upper() == "PUNTOS" and \
                        partes[-1].lower().endswith((".geojson", ".json")):
                    geojsons_por_constructora.setdefault(partes[0], []).append(archivo)

            if not geojsons_por_constructora:
                QMessageBox.warning(
                    self.iface.mainWindow(), "Sin datos",
                    "No se encontró ningún GeoJSON en '<constructora>/PUNTOS/' dentro "
                    "de la carpeta compartida."
                )
                return

            self.capas_info = []
            proyectos_totales = 0
            errores = []

            for constructora, geojson_archivos in geojsons_por_constructora.items():
                indice_archivos = construir_indice_desde_listado(listado, constructora)

                for archivo_geojson in geojson_archivos:
                    try:
                        _nombre, _mime, datos = drive_web.descargar_archivo(
                            URL_APPS_SCRIPT, TOKEN_APPS_SCRIPT, archivo_geojson["id"]
                        )
                    except Exception as e:
                        errores.append(f"No se pudo descargar {archivo_geojson['rutaRelativa']}: {e}")
                        continue

                    # Cargamos el GeoJSON vía /vsimem/ de GDAL - nunca se
                    # escribe una copia del archivo en disco real.
                    ruta_vsimem = f"/vsimem/{uuid.uuid4().hex}.geojson"
                    gdal.FileFromMemBuffer(ruta_vsimem, datos)

                    capa = QgsVectorLayer(
                        ruta_vsimem, f"{constructora} - proyectos", "ogr"
                    )
                    if not capa.isValid():
                        errores.append(f"No se pudo cargar la capa: {archivo_geojson['rutaRelativa']}")
                        gdal.Unlink(ruta_vsimem)
                        continue

                    QgsProject.instance().addMapLayer(capa)
                    # No liberamos el /vsimem/ aquí a propósito: la capa OGR
                    # puede necesitar seguir leyéndolo durante la sesión.

                    self.capas_info.append({
                        "layer": capa,
                        "constructora": constructora,
                        "campo_nombre": _detectar_campo(capa, CAMPOS_NOMBRE_CANDIDATOS),
                        "campo_ciudad": _detectar_campo(capa, CAMPOS_CIUDAD_CANDIDATOS),
                        "campo_link": _detectar_campo_opcional(capa, CAMPOS_LINK_CANDIDATOS),
                        "indice_archivos": indice_archivos,
                        "modo": "remoto",
                        "url_base": URL_APPS_SCRIPT,
                        "token": TOKEN_APPS_SCRIPT,
                    })
                    proyectos_totales += capa.featureCount()

            mensaje = f"Se cargaron {len(self.capas_info)} capa(s) con {proyectos_totales} proyecto(s) en total."
            if errores:
                mensaje += "\n\nErrores:\n" + "\n".join(errores)
            QMessageBox.information(self.iface.mainWindow(), "Carga completa", mensaje)
        finally:
            self.iface.mainWindow().unsetCursor()

    # --- Opción 2 (quitada por pedido del usuario): carga manual desde
    # carpeta local. Se podría restaurar aquí si algún día hace falta un
    # respaldo de depuración - ver historial del plugin.

    def activar_herramienta_validacion(self, checked):
        if not checked:
            return
        if not self.capas_info:
            QMessageBox.warning(self.iface.mainWindow(), "Faltan datos",
                                 "Primero usa 'Cargar datos del equipo'.")
            self.accion_validar.setChecked(False)
            return

        self.herramienta_validacion = HerramientaIdentificarPunto(
            self.iface.mapCanvas(), self.capas_info, self.iface
        )
        self.iface.mapCanvas().setMapTool(self.herramienta_validacion)
