# -*- coding: utf-8 -*-
"""
raster_builder.py
------------------
Convierte una imagen (webp/jpg/png) en un GeoTIFF con la georreferenciación
(geotransform + CRS) embebida DIRECTAMENTE en el archivo, en vez de depender
de un "world file" externo (.wld). Esto es más robusto: algunos drivers de
GDAL para formatos como WEBP solo soportan world files "simples" (sin
rotación), lo que causaba que el plano quedara mal posicionado cuando el
plano estaba rotado respecto al mapa.

Depende de GDAL (osgeo) - disponible dentro del Python de QGIS.
"""

import os
import uuid
from osgeo import gdal, osr

# OJO: NO llamamos gdal.UseExceptions() a propósito - esa llamada dispara
# internamente `from . import gdal_array`, que en esta instalación choca
# con el conflicto de versiones de NumPy (1.x vs 2.x) ya detectado antes.
# Sin ella, GDAL simplemente devuelve None en caso de error en vez de lanzar
# una excepción - por eso chequeamos explícitamente cada resultado.


def _aplicar_georreferenciacion(ruta_destino, geotransform, epsg_o_wkt):
    ds = gdal.Open(ruta_destino, gdal.GA_Update)
    if ds is None:
        raise RuntimeError(f"GDAL no pudo reabrir el GeoTIFF recién creado: {ruta_destino}")
    try:
        ds.SetGeoTransform(geotransform)
        srs = osr.SpatialReference()
        resultado_srs = srs.SetFromUserInput(epsg_o_wkt)
        if resultado_srs != 0:
            raise RuntimeError(f"No se pudo interpretar el CRS '{epsg_o_wkt}'.")
        ds.SetProjection(srs.ExportToWkt())
        ds.FlushCache()
    finally:
        ds = None


def generar_geotiff_georeferenciado(ruta_origen, geotransform, epsg_o_wkt):
    """
    Crea (o sobreescribe) un GeoTIFF junto a `ruta_origen` con el mismo
    contenido de píxeles, pero con `geotransform` (tupla de 6 valores en el
    ORDEN ESTÁNDAR DE GDAL: [origenX, ancho_px_x, rotacion_fila,
    origenY, rotacion_columna, alto_px_y]) y el CRS indicado, embebidos
    directamente en el archivo.

    Devuelve la ruta del GeoTIFF generado.
    """
    ruta_destino = os.path.splitext(ruta_origen)[0] + "_georef.tif"

    ds_copia = gdal.Translate(ruta_destino, ruta_origen, format="GTiff")
    if ds_copia is None:
        raise RuntimeError(
            f"GDAL no pudo convertir la imagen a GeoTIFF: {ruta_origen}\n"
            f"(gdal.Translate devolvió None - revisa que el archivo no esté "
            f"dañado y que el driver correspondiente esté disponible)."
        )
    ds_copia = None  # cierra/flush de la copia

    _aplicar_georreferenciacion(ruta_destino, geotransform, epsg_o_wkt)
    return ruta_destino


def generar_geotiff_georeferenciado_desde_bytes(datos_imagen, nombre_con_extension,
                                                 ruta_destino, geotransform, epsg_o_wkt):
    """
    Igual que generar_geotiff_georeferenciado(), pero recibe la imagen
    ORIGEN como bytes en memoria (no una ruta real) - útil cuando el plano
    viene de una fuente remota y no debe quedar una copia del archivo
    original en el disco. Usa el sistema de archivos virtual de GDAL
    (/vsimem/) para leer esos bytes sin escribirlos en disco; solo el
    GeoTIFF de SALIDA (el resultado ya georreferenciado, generado por
    nosotros) se escribe realmente en `ruta_destino`.
    """
    ruta_vsimem = f"/vsimem/{uuid.uuid4().hex}_{nombre_con_extension}"
    gdal.FileFromMemBuffer(ruta_vsimem, datos_imagen)
    try:
        ds_copia = gdal.Translate(ruta_destino, ruta_vsimem, format="GTiff")
        if ds_copia is None:
            raise RuntimeError(
                f"GDAL no pudo convertir la imagen a GeoTIFF (origen en memoria: "
                f"{nombre_con_extension}).\n(gdal.Translate devolvió None - revisa "
                f"que el formato de la imagen sea compatible)."
            )
        ds_copia = None
    finally:
        gdal.Unlink(ruta_vsimem)

    _aplicar_georreferenciacion(ruta_destino, geotransform, epsg_o_wkt)
    return ruta_destino


def parametros_a_geotransform(A, D, B, E, C, F):
    """
    Convierte del orden 'world file' (A, D, B, E, C, F) al orden estándar
    de geotransform de GDAL: (C, A, B, F, D, E).
    """
    return (C, A, B, F, D, E)
