# -*- coding: utf-8 -*-
"""
drive_web.py
------------
Cliente HTTP para la API expuesta por el Apps Script (apps_script_codigo.gs)
publicado como aplicación web. No necesita ninguna librería externa (usa
solo urllib, incluido en Python) ni cuenta de servicio ni OAuth - la
autenticación la maneja Google Workspace a nivel de organización, según cómo
se haya publicado el script.

Todo lo que se obtiene aquí queda en MEMORIA (bytes), nunca se escribe una
copia persistente de los archivos originales en disco.
"""

import base64
import json
import urllib.parse
import urllib.request

TIMEOUT_SEGUNDOS = 30


def _pedir(url_base, token, parametros):
    parametros = dict(parametros)
    parametros["token"] = token
    url = url_base.rstrip("/") + "?" + urllib.parse.urlencode(parametros)
    with urllib.request.urlopen(url, timeout=TIMEOUT_SEGUNDOS) as respuesta:
        cuerpo = respuesta.read().decode("utf-8")
    datos = json.loads(cuerpo)
    if not datos.get("ok"):
        raise RuntimeError(f"Error del servidor: {datos.get('error', 'desconocido')}")
    return datos


def listar_archivos(url_base, token):
    """
    Devuelve la lista completa (recursiva) de archivos disponibles:
    [{"id": ..., "nombre": ..., "tamano": ..., "rutaRelativa": ...}, ...]
    """
    datos = _pedir(url_base, token, {"accion": "listar"})
    return datos["archivos"]


def descargar_archivo(url_base, token, file_id):
    """Devuelve (nombre, mime_type, bytes) del archivo con ese ID."""
    datos = _pedir(url_base, token, {"accion": "descargar", "id": file_id})
    contenido = base64.b64decode(datos["base64"])
    return datos["nombre"], datos.get("mimeType", ""), contenido


if __name__ == "__main__":
    # Prueba de parsing con datos simulados (sin red real) - valida que el
    # decodificado de base64 y el manejo de errores funcionan bien.
    import unittest.mock as mock

    respuesta_listar = json.dumps({
        "ok": True,
        "archivos": [
            {"id": "abc123", "nombre": "bolivar_proyectos.geojson", "tamano": 1000,
             "rutaRelativa": "Bolivar/PUNTOS/bolivar_proyectos.geojson"},
        ],
    }).encode("utf-8")

    contenido_original = b"contenido de prueba"
    respuesta_descargar = json.dumps({
        "ok": True, "nombre": "prueba.webp", "mimeType": "image/webp",
        "base64": base64.b64encode(contenido_original).decode("ascii"),
    }).encode("utf-8")

    class FalsaRespuestaHTTP:
        def __init__(self, contenido):
            self._contenido = contenido
        def read(self):
            return self._contenido
        def __enter__(self):
            return self
        def __exit__(self, *a):
            return False

    with mock.patch("urllib.request.urlopen") as m:
        m.return_value = FalsaRespuestaHTTP(respuesta_listar)
        archivos = listar_archivos("https://script.google.com/macros/s/FAKE/exec", "token-de-prueba")
        assert archivos[0]["id"] == "abc123"
        print("listar_archivos OK:", archivos)

        m.return_value = FalsaRespuestaHTTP(respuesta_descargar)
        nombre, mime, contenido = descargar_archivo(
            "https://script.google.com/macros/s/FAKE/exec", "token-de-prueba", "abc123"
        )
        assert contenido == contenido_original
        print(f"descargar_archivo OK: nombre={nombre} mime={mime} bytes={len(contenido)}")

    print("\nTodas las pruebas pasaron correctamente.")
