# -*- coding: utf-8 -*-
"""
map_point_tool.py
------------------
Herramienta de mapa (QgsMapTool) que captura N clics del usuario sobre el
lienzo de QGIS y devuelve sus coordenadas (en el CRS del lienzo). Se usa
para marcar, sobre el mapa real, los mismos N puntos de control que el
usuario ya marcó sobre la imagen del plano.

Dibuja marcadores (cruces, coloreados igual que en el visor de imagen) sobre
el lienzo para que el usuario vea dónde hizo clic. Al completar el último
punto, restaura automáticamente la herramienta de mapa que estaba activa
antes.
"""

from qgis.gui import QgsMapTool, QgsVertexMarker
from qgis.PyQt.QtCore import pyqtSignal
from qgis.PyQt.QtGui import QColor

# Mismos colores que image_viewer.COLORES_PUNTOS, para que el usuario asocie
# visualmente qué cruz del mapa corresponde a qué punto del plano.
COLORES_PUNTOS = [QColor(255, 0, 0), QColor(0, 140, 255), QColor(0, 200, 0), QColor(255, 165, 0)]


class HerramientaCapturarPuntos(QgsMapTool):
    puntos_completados = pyqtSignal(list)  # lista de (x,y) en el CRS del lienzo

    def __init__(self, canvas, herramienta_anterior=None, num_puntos_requeridos=3):
        super().__init__(canvas)
        self.canvas = canvas
        self.herramienta_anterior = herramienta_anterior
        self.num_puntos_requeridos = num_puntos_requeridos
        self._puntos = []
        self._marcadores = []

    def canvasReleaseEvent(self, event):
        punto = self.toMapCoordinates(event.pos())
        self._agregar_marcador(punto)
        self._puntos.append((punto.x(), punto.y()))

        if len(self._puntos) == self.num_puntos_requeridos:
            self.puntos_completados.emit(list(self._puntos))
            self._restaurar_herramienta_anterior()

    def _agregar_marcador(self, punto):
        marcador = QgsVertexMarker(self.canvas)
        marcador.setCenter(punto)
        indice = len(self._marcadores)
        color = COLORES_PUNTOS[indice % len(COLORES_PUNTOS)]
        marcador.setColor(color)
        marcador.setIconType(QgsVertexMarker.ICON_CROSS)
        marcador.setIconSize(16)
        marcador.setPenWidth(3)
        self._marcadores.append(marcador)

    def _restaurar_herramienta_anterior(self):
        if self.herramienta_anterior is not None:
            self.canvas.setMapTool(self.herramienta_anterior)

    def limpiar_marcadores(self):
        for m in self._marcadores:
            self.canvas.scene().removeItem(m)
        self._marcadores = []
        self._puntos = []

    def deactivate(self):
        super().deactivate()


# Alias por compatibilidad con nombre anterior (2 puntos era el caso previo)
HerramientaCapturarDosPuntos = HerramientaCapturarPuntos
