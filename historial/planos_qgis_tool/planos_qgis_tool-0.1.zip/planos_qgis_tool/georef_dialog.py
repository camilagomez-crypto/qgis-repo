# -*- coding: utf-8 -*-
"""
georef_dialog.py
----------------
Diálogo para georreferenciar un plano de urbanismo usando 3 puntos de
control (transformación afín completa - permite escala independiente en
X/Y y ligera cizalla, más precisa que la de 2 puntos):

  1. El usuario marca 3 puntos IDENTIFICABLES sobre la imagen del plano
     (p.ej. esquinas del lote, entradas, cruces de vías dibujados) - deben
     NO estar en línea recta.
  2. El usuario marca esos MISMOS 3 puntos, en el mismo orden, sobre el
     mapa real de QGIS (apoyándose en una capa base/satelital ya cargada).
  3. Con esas 3 correspondencias se calcula una transformación afín completa
     y se genera un GeoTIFF con la georreferenciación embebida directamente
     en el archivo (ver raster_builder.py), cargándolo como capa ráster.

Este archivo SÍ depende de la API de QGIS (qgis.core / qgis.gui / qgis.PyQt)
y por tanto solo se puede ejecutar dentro de QGIS, no en este entorno de
pruebas - la matemática (georef_math.py) sí se probó de forma aislada.
"""

import json
import os
import time

from qgis.core import (
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsRasterLayer,
    QgsProject, QgsPointXY, QgsApplication,
)
from qgis.gui import QgsVertexMarker
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor, QPixmap
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QMessageBox,
)

from .georef_math import calcular_afin_3_puntos
from .raster_builder import (
    generar_geotiff_georeferenciado, generar_geotiff_georeferenciado_desde_bytes,
    parametros_a_geotransform,
)
from .image_viewer import VisorImagenConControles
from .map_point_tool import HerramientaCapturarPuntos

NUM_PUNTOS = 3

# Carpeta donde se guardan los GeoTIFF ya georreferenciados que generamos
# nosotros mismos (esto NO es una copia de los datos originales - es nuestro
# resultado derivado, por eso sí es correcto que quede guardado localmente).
CARPETA_SALIDAS_GEOREF = os.path.join(
    QgsApplication.qgisSettingsDirPath(), "planos_qgis_tool_salidas"
)

# Mantiene vivas las referencias a marcadores/herramientas (si no, Python las
# recolecta y desaparecen del mapa o dejan de funcionar).
_marcadores_persistentes = []
_herramientas_captura_activas = []


class DialogoGeoreferenciar(QDialog):
    """
    Acepta la imagen del plano de 2 formas:
      - ruta_imagen: ruta real en disco (modo carpeta local)
      - datos_imagen + nombre_archivo: bytes en memoria (modo remoto/Drive) -
        en este caso nunca se escribe una copia del original en disco; solo
        el GeoTIFF de salida (nuestro resultado) queda guardado localmente.
    """

    def __init__(self, nombre_proyecto, lon, lat, ruta_imagen=None,
                 datos_imagen=None, nombre_archivo=None, iface=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Georreferenciar — {nombre_proyecto}")
        self.setMinimumSize(750, 650)
        self.setWindowFlags(self.windowFlags() | Qt.WindowMaximizeButtonHint)

        if ruta_imagen is None and datos_imagen is None:
            raise ValueError("Debes pasar ruta_imagen o (datos_imagen + nombre_archivo)")

        self.ruta_imagen = ruta_imagen
        self.datos_imagen = datos_imagen
        self.nombre_archivo = nombre_archivo or (os.path.basename(ruta_imagen) if ruta_imagen else "plano.png")
        self.lon = lon
        self.lat = lat
        self.nombre_proyecto = nombre_proyecto
        self.iface = iface

        self.puntos_imagen = None  # lista de 3 tuplas (x,y) en píxeles
        self.puntos_mapa = None    # lista de 3 tuplas (x,y) en el CRS del lienzo

        layout = QVBoxLayout(self)

        layout.addWidget(QLabel(
            f"<b>Paso 1:</b> haz clic en {NUM_PUNTOS} puntos IDENTIFICABLES del plano, "
            "que NO estén en línea recta (p.ej. 3 esquinas del lote, o una esquina + "
            "una entrada + un cruce de vías). Orden de colores: 1º rojo, 2º azul, 3º verde."
        ))

        if datos_imagen is not None:
            pixmap = QPixmap()
            pixmap.loadFromData(datos_imagen)
            self.visor = VisorImagenConControles(pixmap=pixmap, modo_captura_puntos=True,
                                      num_puntos_requeridos=NUM_PUNTOS)
        else:
            self.visor = VisorImagenConControles(ruta_imagen, modo_captura_puntos=True,
                                      num_puntos_requeridos=NUM_PUNTOS)
        self.visor.puntos_completados.connect(self._on_puntos_imagen_listos)
        layout.addWidget(self.visor, stretch=1)

        boton_reiniciar_imagen = QPushButton("Volver a marcar los puntos en el plano")
        boton_reiniciar_imagen.clicked.connect(self._reiniciar_puntos_imagen)
        layout.addWidget(boton_reiniciar_imagen)

        self.label_estado = QLabel(
            f"Esperando que marques los {NUM_PUNTOS} puntos sobre el plano..."
        )
        layout.addWidget(self.label_estado)

        self.boton_marcar_en_mapa = QPushButton(
            f"Marcar esos mismos {NUM_PUNTOS} puntos en el mapa de QGIS"
        )
        self.boton_marcar_en_mapa.setEnabled(False)
        self.boton_marcar_en_mapa.clicked.connect(self._activar_captura_en_mapa)
        layout.addWidget(self.boton_marcar_en_mapa)

        botones = QHBoxLayout()
        self.boton_aplicar = QPushButton("Aplicar y cargar en el mapa")
        self.boton_aplicar.setEnabled(False)
        self.boton_aplicar.clicked.connect(self._aplicar)
        boton_cancelar = QPushButton("Cancelar")
        boton_cancelar.clicked.connect(self.reject)
        botones.addWidget(self.boton_aplicar)
        botones.addWidget(boton_cancelar)
        layout.addLayout(botones)

    # --- Paso 1: puntos sobre la imagen ---
    def _on_puntos_imagen_listos(self, puntos):
        self.puntos_imagen = puntos
        self.label_estado.setText(
            f"Puntos del plano marcados. Ahora presiona el botón para marcar "
            f"esos mismos {NUM_PUNTOS} puntos en el mapa de QGIS (en el mismo orden)."
        )
        self.boton_marcar_en_mapa.setEnabled(True)

    def _reiniciar_puntos_imagen(self):
        self.visor.reiniciar_puntos()
        self.puntos_imagen = None
        self.boton_marcar_en_mapa.setEnabled(False)
        self.boton_aplicar.setEnabled(False)
        self.label_estado.setText(f"Esperando que marques los {NUM_PUNTOS} puntos sobre el plano...")

    # --- Paso 2: los mismos puntos, pero en el mapa real ---
    def _activar_captura_en_mapa(self):
        if self.iface is None:
            QMessageBox.warning(self, "No disponible",
                                 "No hay acceso al lienzo de QGIS (iface no disponible).")
            return

        canvas = self.iface.mapCanvas()
        herramienta_anterior = canvas.mapTool()
        herramienta = HerramientaCapturarPuntos(canvas, herramienta_anterior,
                                                  num_puntos_requeridos=NUM_PUNTOS)
        herramienta.puntos_completados.connect(self._on_puntos_mapa_listos)
        _herramientas_captura_activas.append(herramienta)  # evita que se recolecte
        canvas.setMapTool(herramienta)

        self.label_estado.setText(
            "Ahora haz clic en el mapa de QGIS, EN EL MISMO ORDEN: rojo, azul, verde. "
            "Apóyate en una capa base/satelital si la tienes cargada."
        )
        # Minimizamos el diálogo para que puedas interactuar libremente con el mapa
        self.showMinimized()

    def _on_puntos_mapa_listos(self, puntos):
        self.puntos_mapa = puntos
        self.showNormal()
        self.raise_()
        self.activateWindow()
        self.label_estado.setText(
            "Puntos del mapa marcados. Ya puedes presionar 'Aplicar y cargar en el mapa'."
        )
        self.boton_aplicar.setEnabled(True)

    # --- Paso 3: calcular y cargar ---
    def _aplicar(self):
        if self.puntos_imagen is None or self.puntos_mapa is None:
            QMessageBox.warning(self, "Faltan puntos",
                                 f"Marca los {NUM_PUNTOS} puntos en el plano Y sus equivalentes "
                                 f"en el mapa antes de aplicar.")
            return

        try:
            parametros = calcular_afin_3_puntos(self.puntos_imagen, self.puntos_mapa)

            crs_lienzo = self.iface.mapCanvas().mapSettings().destinationCrs() if self.iface else \
                QgsCoordinateReferenceSystem("EPSG:4326")

            geotransform = parametros_a_geotransform(*parametros)

            if self.datos_imagen is not None:
                os.makedirs(CARPETA_SALIDAS_GEOREF, exist_ok=True)
                nombre_base = os.path.splitext(self.nombre_archivo)[0]
                timestamp = time.strftime("%Y%m%d_%H%M%S")
                ruta_salida = os.path.join(
                    CARPETA_SALIDAS_GEOREF, f"{nombre_base}_{timestamp}_georef.tif"
                )
                ruta_geotiff = generar_geotiff_georeferenciado_desde_bytes(
                    self.datos_imagen, self.nombre_archivo, ruta_salida,
                    geotransform, crs_lienzo.authid() or "EPSG:4326"
                )
                ruta_registro = ruta_geotiff + ".georef.json"
            else:
                ruta_geotiff = generar_geotiff_georeferenciado(
                    self.ruta_imagen, geotransform, crs_lienzo.authid() or "EPSG:4326"
                )
                ruta_registro = self.ruta_imagen + ".georef.json"

            # Guardamos un registro de lo aplicado, por si hay que revisar/rehacer después
            with open(ruta_registro, "w", encoding="utf-8") as f:
                json.dump({
                    "proyecto": self.nombre_proyecto,
                    "metodo": "3 puntos de control - afín completa (GeoTIFF embebido)",
                    "puntos_imagen": self.puntos_imagen,
                    "puntos_mapa": self.puntos_mapa,
                    "parametros_A_D_B_E_C_F": parametros,
                    "geotiff_generado": ruta_geotiff,
                    "lon_punto_original": self.lon,
                    "lat_punto_original": self.lat,
                    "fecha": time.strftime("%Y-%m-%d %H:%M:%S"),
                }, f, indent=2, ensure_ascii=False)

            capa = QgsRasterLayer(ruta_geotiff, f"Plano - {self.nombre_proyecto}")
            if not capa.isValid():
                QMessageBox.critical(self, "Error",
                                      "QGIS no pudo cargar el GeoTIFF generado. Revisa que "
                                      "GDAL esté funcionando correctamente en tu instalación.")
                return

            # Opacidad reducida para que el punto del proyecto siga siendo visible
            # DEBAJO del plano y puedas confirmar que coincide con su centro.
            try:
                capa.renderer().setOpacity(0.75)
            except Exception:
                pass

            QgsProject.instance().addMapLayer(capa)

            # Movemos la capa ráster al FONDO del árbol de capas, para que los
            # puntos de proyecto (Bolivar/Marval) y la capa base queden visibles
            # encima y puedas validar la posición en vez de que el plano los tape.
            try:
                root = QgsProject.instance().layerTreeRoot()
                nodo = root.findLayer(capa.id())
                if nodo is not None:
                    clon = nodo.clone()
                    padre = nodo.parent()
                    padre.insertChildNode(padre.childCount(), clon)
                    padre.removeChildNode(nodo)
            except Exception:
                pass

            if self.iface is not None:
                extent_ampliado = capa.extent()
                extent_ampliado.scale(2.0)
                self.iface.mapCanvas().setExtent(extent_ampliado)

                # Marcador cruz permanente en el punto real del proyecto.
                # OJO: self.lon/self.lat vienen del GeoJSON en EPSG:4326 (grados),
                # pero QgsVertexMarker dibuja en las coordenadas del LIENZO - si el
                # proyecto no está en EPSG:4326 hay que transformar primero, o el
                # marcador aparece en un lugar completamente distinto.
                crs_4326 = QgsCoordinateReferenceSystem("EPSG:4326")
                if crs_lienzo != crs_4326:
                    transformador_validacion = QgsCoordinateTransform(
                        crs_4326, crs_lienzo, QgsProject.instance()
                    )
                    punto_validacion = transformador_validacion.transform(
                        QgsPointXY(self.lon, self.lat)
                    )
                else:
                    punto_validacion = QgsPointXY(self.lon, self.lat)

                marcador = QgsVertexMarker(self.iface.mapCanvas())
                marcador.setCenter(punto_validacion)
                marcador.setColor(QColor(0, 255, 0))
                marcador.setIconType(QgsVertexMarker.ICON_CROSS)
                marcador.setIconSize(18)
                marcador.setPenWidth(3)
                _marcadores_persistentes.append(marcador)

                self.iface.mapCanvas().refresh()

            QMessageBox.information(self, "Listo",
                                     "Plano cargado y posicionado en el mapa según los "
                                     f"{NUM_PUNTOS} puntos de control.\n\n"
                                     "Busca la CRUZ VERDE (marca el punto del GeoJSON del "
                                     "proyecto) y compara su posición contra el plano para "
                                     "validar.\n\n"
                                     "Ajusta manualmente desde las propiedades de la capa si "
                                     "hace falta afinarlo.")
            self.accept()

        except Exception as e:
            QMessageBox.critical(self, "Error al georreferenciar", str(e))
