# -*- coding: utf-8 -*-
"""
web_auth_client.py
-------------------
Alternativa a drive_web.py para cuando el Apps Script está desplegado con
acceso restringido al dominio de la empresa ("Cualquier usuario de
servinformacion.com"). Ese modo exige que la petición venga de un NAVEGADOR
con sesión de Google iniciada - una petición HTTP simple (urllib) no sirve,
Google la redirige a una pantalla de login.

Este módulo abre un navegador embebido (QtWebEngine) con un perfil
PERSISTENTE (la sesión se recuerda entre reinicios de QGIS, no hay que
volver a iniciar sesión cada vez), y lo usa para cargar cada URL del Apps
Script y leer su respuesta.

Requiere que la instalación de QGIS incluya QtWebEngine - no todas lo
traen. Si no está disponible, `webengine_disponible()` devuelve False y
hay que usar otro método (ver plugin_main.py).
"""

import json
import os

# IMPORTANTE: esto debe ir ANTES de importar QtWebEngineWidgets - fuerza a
# que el proceso interno de Chromium NO intente usar aceleración de video
# (GPU). En algunos equipos Windows, QtWebEngine se queda atascado varios
# minutos (o indefinidamente) intentando inicializar la GPU; deshabilitarla
# es la solución estándar recomendada para ese problema.
os.environ.setdefault(
    "QTWEBENGINE_CHROMIUM_FLAGS",
    "--disable-gpu --disable-software-rasterizer --disable-gpu-compositing"
)

from qgis.core import QgsApplication
from qgis.PyQt.QtCore import Qt, QUrl, QEventLoop, QTimer

try:
    from qgis.PyQt.QtWebEngineWidgets import QWebEngineView, QWebEngineProfile, QWebEnginePage
    _WEBENGINE_DISPONIBLE = True
except Exception:
    _WEBENGINE_DISPONIBLE = False

from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton, QHBoxLayout

CARPETA_PERFIL_WEB = os.path.join(
    QgsApplication.qgisSettingsDirPath(), "planos_qgis_tool_perfil_web"
)

TIMEOUT_CARGA_MS = 5 * 60 * 1000  # 5 minutos - el listado completo de miles de archivos puede tardar


def webengine_disponible():
    return _WEBENGINE_DISPONIBLE


class NavegadorAutenticado(QDialog):
    """
    Ventana con navegador embebido y perfil persistente. `pedir_texto(url)`
    carga esa URL y devuelve el texto plano de la página (bloqueante, con
    un mini-bucle de eventos local - no congela el resto de QGIS más que
    el tiempo de carga).

    La PRIMERA vez, si Google pide login, la ventana se muestra visible
    para que el usuario inicie sesión con su cuenta @servinformacion.com;
    las siguientes veces la sesión ya queda recordada (perfil persistente)
    y normalmente no hace falta mostrar nada.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Acceso a datos del equipo — inicia sesión si te lo pide")
        self.resize(1000, 750)
        self.setMinimumSize(700, 500)
        self.setWindowFlags(Qt.Window)

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(
            "Si aparece una pantalla de inicio de sesión de Google, entra con tu "
            "correo @servinformacion.com. Cuando la página deje de pedir login "
            "(vas a ver texto plano, no un formulario), presiona 'Continuar'.\n\n"
            "Si la ventana queda en blanco: es normal, sigue cargando en segundo "
            "plano - la primera vez puede tardar varios minutos (hay muchos "
            "archivos). No cierres esta ventana, espera."
        ))

        self.label_estado = QLabel("Cargando...")
        layout.addWidget(self.label_estado)

        os.makedirs(CARPETA_PERFIL_WEB, exist_ok=True)
        self.profile = QWebEngineProfile("planos_qgis_tool_perfil", self)
        self.profile.setPersistentStoragePath(CARPETA_PERFIL_WEB)
        self.profile.setPersistentCookiesPolicy(QWebEngineProfile.ForcePersistentCookies)
        # Google bloquea logins desde navegadores "embebidos" detectados por
        # user-agent - probamos identificarnos como un Chrome de escritorio
        # normal para evitar ese bloqueo.
        self.profile.setHttpUserAgent(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        )

        self.vista = QWebEngineView(self)
        pagina = QWebEnginePage(self.profile, self.vista)
        self.vista.setPage(pagina)
        layout.addWidget(self.vista, stretch=1)

        botones = QHBoxLayout()
        self.boton_continuar = QPushButton("Continuar (ya inicié sesión / ya veo el texto)")
        self.boton_continuar.clicked.connect(self._continuar)
        botones.addWidget(self.boton_continuar)
        self.boton_recargar = QPushButton("Recargar página (si quedó atascada)")
        self.boton_recargar.clicked.connect(lambda: self.vista.reload())
        botones.addWidget(self.boton_recargar)
        layout.addLayout(botones)

        self._loop = None
        self._resultado = None

    def _continuar(self):
        if self._loop is not None:
            self._loop.quit()

    def pedir_texto(self, url):
        """Carga `url` en el navegador embebido y devuelve el texto plano
        renderizado. Si el texto ya parece JSON válido, se resuelve solo
        (sin mostrar la ventana); si no, muestra la ventana para que el
        usuario inicie sesión y presione 'Continuar'."""
        self.label_estado.setText("Cargando...")
        self.vista.load(QUrl(url))

        self._loop = QEventLoop()
        cargo = {"listo": False}

        def _al_cargar(ok):
            cargo["listo"] = True
            self.label_estado.setText(
                f"Carga {'completa' if ok else 'con ERROR'} — "
                f"URL actual: {self.vista.url().toString()}"
            )
            self._loop.quit()

        self.vista.loadFinished.connect(_al_cargar)
        QTimer.singleShot(TIMEOUT_CARGA_MS, self._loop.quit)
        self._loop.exec_()
        try:
            self.vista.loadFinished.disconnect(_al_cargar)
        except Exception:
            pass

        if not cargo["listo"]:
            self.label_estado.setText(
                f"Se agotó el tiempo de espera ({TIMEOUT_CARGA_MS // 1000}s) sin "
                f"terminar de cargar. URL actual: {self.vista.url().toString()}"
            )

        texto = self._extraer_texto_pagina()
        if _parece_json(texto):
            return texto

        # No parece JSON (probablemente pantalla de login) - mostramos la
        # ventana y esperamos a que el usuario confirme.
        self.showMaximized()
        self.raise_()
        self.activateWindow()
        self._loop = QEventLoop()
        self._loop.exec_()  # se libera cuando el usuario presiona "Continuar"
        self.hide()

        return self._extraer_texto_pagina()

    def _extraer_texto_pagina(self):
        resultado = {}
        loop_interno = QEventLoop()

        def _callback(texto):
            resultado["texto"] = texto
            loop_interno.quit()

        self.vista.page().toPlainText(_callback)
        QTimer.singleShot(10000, loop_interno.quit)
        loop_interno.exec_()
        return resultado.get("texto", "")


def _parece_json(texto):
    texto = (texto or "").strip()
    if not texto:
        return False
    try:
        json.loads(texto)
        return True
    except Exception:
        return False


# --- Funciones de alto nivel, mismo formato que drive_web.py ---

_navegador_compartido = None
_cache_listados = {}   # url_base -> lista de archivos (evita re-listar todo de nuevo)
_cache_descargas = {}  # file_id -> (nombre, mime, bytes) (evita re-descargar el mismo archivo)


def _obtener_navegador(parent=None):
    global _navegador_compartido
    if _navegador_compartido is None:
        _navegador_compartido = NavegadorAutenticado(parent)
    return _navegador_compartido


def _pedir(url_base, token, parametros, parent=None):
    import urllib.parse
    parametros = dict(parametros)
    parametros["token"] = token
    url = url_base.rstrip("/") + "?" + urllib.parse.urlencode(parametros)

    navegador = _obtener_navegador(parent)
    texto = navegador.pedir_texto(url)
    if not _parece_json(texto):
        raise RuntimeError(
            "No se obtuvo una respuesta válida del Apps Script (revisa que hayas "
            "iniciado sesión con tu cuenta @servinformacion.com en la ventana que "
            "se abrió, y vuelve a intentar)."
        )
    datos = json.loads(texto)
    if not datos.get("ok"):
        raise RuntimeError(f"Error del servidor: {datos.get('error', 'desconocido')}")
    return datos


def listar_archivos(url_base, token, parent=None, forzar_actualizar=False):
    if not forzar_actualizar and url_base in _cache_listados:
        return _cache_listados[url_base]
    datos = _pedir(url_base, token, {"accion": "listar"}, parent=parent)
    _cache_listados[url_base] = datos["archivos"]
    return datos["archivos"]


def descargar_archivo(url_base, token, file_id, parent=None):
    if file_id in _cache_descargas:
        return _cache_descargas[file_id]
    datos = _pedir(url_base, token, {"accion": "descargar", "id": file_id}, parent=parent)
    import base64
    contenido = base64.b64decode(datos["base64"])
    if datos.get("comprimido"):
        import gzip
        contenido = gzip.decompress(contenido)
    resultado = (datos["nombre"], datos.get("mimeType", ""), contenido)
    _cache_descargas[file_id] = resultado
    return resultado
