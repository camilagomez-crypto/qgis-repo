# --- START OF FILE: __init__.py ---

def classFactory(iface):
    """Carga la clase principal del plugin."""
    from .productivity_tracker import QGISProductivityTracker
    return QGISProductivityTracker(iface)