# --- START OF FILE: core/config.py ---
import os
import configparser
from qgis.core import Qgis, QgsMessageLog

class Config:
    def __init__(self, plugin_dir):
        self.plugin_dir = plugin_dir
        self.config_file = os.path.join(self.plugin_dir, 'config.ini')
        self.config = configparser.ConfigParser()
        self.ruta_db_central = ""
        self.patrones_capas_productivas = []
        if not os.path.exists(self.config_file):
            self.log_message("El archivo 'config.ini' no se encuentra.", Qgis.Critical)
        else:
            self.read_config()

    def read_config(self):
        try:
            self.config.read(self.config_file)
            self.ruta_db_central = self.config.get('database', 'ruta_db_central')
            patterns_str = self.config.get('layers', 'patrones_capas_productivas', fallback='*')
            self.patrones_capas_productivas = [p.strip() for p in patterns_str.split(',') if p.strip()]
        except Exception as e:
            self.log_message(f"Error al leer config.ini: {e}", Qgis.Critical)

    def log_message(self, message, level=Qgis.Info):
        QgsMessageLog.logMessage(message, 'Productivity Tracker', level)