import os
import fnmatch
from datetime import datetime
from qgis.core import Qgis, QgsProject, QgsVectorLayer, QgsApplication
from qgis.PyQt.QtCore import QObject, QTimer

from .config import Config
from .database_manager import DatabaseManager
from .kpi_calculator import KPICalculator
from . import constants

# ---------------------------------------------------------------------------
# Patrones de capas temporales / geoprocesamiento que NUNCA se registran
# ---------------------------------------------------------------------------
TEMP_LAYER_PATTERNS = [
    "capa unida", "joined layer",
    "resultado_*", "result_*",
    "memory_*", "tmp_*", "temp_*",
    "output_*", "salida_*",
    "buffer_*", "clip_*", "intersect_*",
    "dissolve_*", "union_*", "merge_*",
]


def _is_temp_layer(layer_name: str) -> bool:
    name_lower = layer_name.lower()
    for pattern in TEMP_LAYER_PATTERNS:
        if fnmatch.fnmatch(name_lower, pattern.lower()):
            return True
    return False


class LayerSignalConnector(QObject):
    def __init__(self, layer, engine):
        super().__init__()
        self.layer, self.engine = layer, engine
        self.connect_signals()

    def connect_signals(self):
        self.layer.featureAdded.connect(self.on_feature_added)
        self.layer.geometryChanged.connect(self.on_geometry_changed)
        self.layer.attributeValueChanged.connect(self.on_attribute_changed)
        self.layer.featuresDeleted.connect(self.on_feature_deleted)

    def disconnect_signals(self):
        try:
            self.layer.featureAdded.disconnect(self.on_feature_added)
            self.layer.geometryChanged.disconnect(self.on_geometry_changed)
            self.layer.attributeValueChanged.disconnect(self.on_attribute_changed)
            self.layer.featuresDeleted.disconnect(self.on_feature_deleted)
        except:
            pass

    def on_feature_added(self, fid):
        self.engine._log_edit_event(self.layer, fid, constants.EVENT_FEATURE_CREATED, constants.AUDIT_ACTION_CREATED)

    def on_geometry_changed(self, fid, geom):
        self.engine._log_edit_event(self.layer, fid, constants.EVENT_FEATURE_MODIFIED_GEOM, constants.AUDIT_ACTION_MODIFIED_GEOM)

    def on_attribute_changed(self, fid, f_idx, old):
        try:
            feat = self.layer.getFeature(fid)
            new = feat.attribute(f_idx)
            if str(new) != str(old):
                f_name = self.layer.fields().field(f_idx).name()
                self.engine._log_edit_event(self.layer, fid, constants.EVENT_FEATURE_MODIFIED_ATTR,
                                            constants.AUDIT_ACTION_MODIFIED_ATTR, f_name, new)
        except:
            pass

    def on_feature_deleted(self, fids):
        for fid in fids:
            self.engine._log_edit_event(self.layer, fid, constants.EVENT_FEATURE_DELETED, constants.AUDIT_ACTION_DELETED)


class TrackerEngine(QObject):
    def __init__(self, iface, plugin_dir):
        super().__init__()
        self.iface, self.plugin_dir = iface, plugin_dir
        self.config = Config(self.plugin_dir)
        self.db_manager = DatabaseManager(self.plugin_dir, self.config.ruta_db_central)
        self.calculator = KPICalculator(self.db_manager)

        self.is_processing_active = False
        self.layer_connectors = {}
        self.last_auto_report_day = ""
        self._shutdown_done = False  # evita que shutdown() corra más de una vez

        self._consolidate_on_startup()

        self.auto_save_timer = QTimer(self)
        self.auto_save_timer.timeout.connect(self.check_time_for_report)
        self.auto_save_timer.start(30000)

        self.connect_global_signals()
        self.monitor_all_existing_layers()

    # ------------------------------------------------------------------
    # FILTRO: ¿debe monitorearse esta capa?
    # ------------------------------------------------------------------
    def _should_track_layer(self, layer) -> bool:
        if not isinstance(layer, QgsVectorLayer):
            return False
        # Rechazar capas en memoria pura (resultado de geoprocesamiento)
        if layer.dataProvider() and layer.dataProvider().name() == "memory":
            return False
        name = layer.name()
        if _is_temp_layer(name):
            return False
        # Filtrar por patrones productivos del config.ini
        patterns = self.config.patrones_capas_productivas
        if patterns:
            if not any(fnmatch.fnmatch(name.lower(), p.lower()) for p in patterns):
                return False
        return True

    # ------------------------------------------------------------------
    # CONSOLIDACIÓN AL ARRANCAR
    # ------------------------------------------------------------------
    def _consolidate_on_startup(self):
        docs_path = os.path.join(os.path.expanduser("~"), "Documents", "QGIS_Productivity_Reports")
        for date_str in self.db_manager.get_available_dates():
            today_str = datetime.now().strftime('%Y-%m-%d')
            if date_str == today_str:
                continue
            report_prefix = f"Reporte_{date_str}_"
            existing = []
            if os.path.exists(docs_path):
                existing = [f for f in os.listdir(docs_path) if f.startswith(report_prefix)]
            if not existing:
                self.db_manager.log_message(f"Consolidando datos sin reporte de {date_str}...", Qgis.Info)
                self.save_automatic_report("Recuperado", date_str=date_str)
        self.db_manager.cleanup_old_logs()

    # ------------------------------------------------------------------
    # RELOJ
    # ------------------------------------------------------------------
    def check_time_for_report(self):
        now = datetime.now()
        current_time = now.strftime("%H:%M")
        current_day = now.strftime("%Y-%m-%d")
        if current_time == "23:59" and self.last_auto_report_day != current_day:
            self.save_automatic_report("Medianoche", date_str=current_day)
            self.last_auto_report_day = current_day

    # ------------------------------------------------------------------
    # GENERADOR DE REPORTE — un solo archivo por (fecha + motivo)
    # ------------------------------------------------------------------
    def save_automatic_report(self, motivo="Auto", date_str=None):
        if date_str is None:
            date_str = datetime.now().strftime('%Y-%m-%d')

        docs_path = os.path.join(os.path.expanduser("~"), "Documents", "QGIS_Productivity_Reports")
        os.makedirs(docs_path, exist_ok=True)

        # Nombre fijo por fecha+motivo → nunca se duplica
        filename = f"Reporte_{date_str}_{motivo}.html"
        path = os.path.join(docs_path, filename)

        t = self.calculator.get_time_metrics_for_date(date_str)
        s = self.calculator.get_session_stats_for_date(date_str)

        layer_summary = self.db_manager.query_date_readonly(
            date_str,
            "SELECT layer_name, COUNT(*) FROM audit_log "
            "WHERE strftime('%Y-%m-%d', timestamp, 'localtime') = ? "
            "GROUP BY layer_name ORDER BY COUNT(*) DESC",
            (date_str,)
        )
        layer_rows = "".join(
            f"<tr><td>{r[0]}</td><td>{r[1]}</td></tr>"
            for r in (layer_summary or [])
        )

        full_audit = self.calculator.get_full_daily_audit(date_str)
        audit_rows = ""
        for r in (full_audit or []):
            try:
                h = datetime.fromisoformat(r[0].replace('Z', '+00:00')).astimezone(None).strftime("%H:%M:%S")
            except Exception:
                h = r[0]
            audit_rows += (
                f"<tr><td>{h}</td><td>{r[1]}</td><td>{r[2]}</td>"
                f"<td>{r[3]}</td><td>{r[4] if r[4] else '-'}</td>"
                f"<td>{r[5] if r[5] else '-'}</td></tr>"
            )

        def fmt(sec):
            return f"{int(sec//3600):02}:{int((sec%3600)//60):02}:{int(sec%60):02}"

        eficiencia = (s['created'] + s['modified']) / (t['active'] / 60) if t['active'] > 0 else 0

        html = f"""<!DOCTYPE html>
<html lang="es"><head><meta charset="UTF-8"><style>
  body{{font-family:'Segoe UI',sans-serif;margin:40px;background:#f5f5f5;}}
  .header{{background:linear-gradient(135deg,#2c3e50,#3498db);color:white;padding:24px;
           text-align:center;border-radius:10px;margin-bottom:24px;}}
  .header h1{{margin:0 0 6px;font-size:22px;}}
  .header p{{margin:0;opacity:.85;font-size:13px;}}
  .cards{{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px;margin-bottom:24px;}}
  .card{{background:white;border-radius:8px;padding:16px;box-shadow:0 2px 6px rgba(0,0,0,.08);border-left:4px solid #3498db;}}
  .card .lbl{{font-size:10px;text-transform:uppercase;color:#888;margin-bottom:4px;}}
  .card .val{{font-size:22px;font-weight:700;color:#2c3e50;}}
  .card.g{{border-color:#2ecc71;}} .card.g .val{{color:#27ae60;}}
  .card.o{{border-color:#f39c12;}} .card.o .val{{color:#e67e22;}}
  .card.r{{border-color:#e74c3c;}} .card.r .val{{color:#c0392b;}}
  .section{{background:white;border-radius:8px;padding:20px;
            box-shadow:0 2px 6px rgba(0,0,0,.08);margin-bottom:20px;}}
  .section h2{{margin:0 0 14px;font-size:15px;color:#2c3e50;
               border-bottom:2px solid #ecf0f1;padding-bottom:8px;}}
  table{{width:100%;border-collapse:collapse;font-size:13px;}}
  th{{background:#2c3e50;color:white;padding:9px 12px;text-align:left;}}
  td{{padding:7px 12px;border-bottom:1px solid #ecf0f1;}}
  tr:last-child td{{border-bottom:none;}}
</style></head>
<body>
  <div class="header">
    <h1>📊 Informe de Productividad — {date_str}</h1>
    <p>Motivo: {motivo} &nbsp;|&nbsp; Generado: {datetime.now().strftime('%d/%m/%Y %H:%M')}</p>
  </div>
  <div class="cards">
    <div class="card">  <div class="lbl">Tiempo Total QGIS</div><div class="val">{fmt(t['total'])}</div></div>
    <div class="card g"><div class="lbl">Tiempo Activo</div>    <div class="val">{fmt(t['active'])}</div></div>
    <div class="card o"><div class="lbl">Creados</div>          <div class="val">{s['created']}</div></div>
    <div class="card o"><div class="lbl">Modificados</div>      <div class="val">{s['modified']}</div></div>
    <div class="card">  <div class="lbl">Total Procesados</div> <div class="val">{s['created']+s['modified']}</div></div>
    <div class="card r"><div class="lbl">Eficiencia obj/min</div><div class="val">{eficiencia:.2f}</div></div>
  </div>
  <div class="section">
    <h2>📁 Resumen por Capa</h2>
    <table><tr><th>Capa</th><th>Acciones</th></tr>
    {layer_rows or '<tr><td colspan="2" style="color:#999;text-align:center">Sin datos de capas</td></tr>'}
    </table>
  </div>
  <div class="section">
    <h2>🔍 Auditoría Completa</h2>
    <table>
      <tr><th>Hora</th><th>Capa</th><th>ID</th><th>Acción</th><th>Campo</th><th>Valor Nuevo</th></tr>
      {audit_rows or '<tr><td colspan="6" style="color:#999;text-align:center">Sin registros</td></tr>'}
    </table>
  </div>
</body></html>"""

        try:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(html)
            self.iface.messageBar().pushMessage(
                "Productivity Tracker", f"Reporte guardado: {filename}", level=Qgis.Success)
        except Exception as e:
            self.iface.messageBar().pushMessage(
                "Productivity Tracker", f"Error al guardar reporte: {e}", level=Qgis.Critical)

    # ------------------------------------------------------------------
    # SEÑALES
    # ------------------------------------------------------------------
    def connect_global_signals(self):
        QgsProject.instance().layersAdded.connect(self.on_layers_added)
        QgsProject.instance().layerWillBeRemoved.connect(self.on_layer_will_be_removed)
        try:
            proc_reg = QgsApplication.processingRegistry()
            proc_reg.algorithmExecuting.connect(lambda: setattr(self, 'is_processing_active', True))
            proc_reg.algorithmFinished.connect(lambda: setattr(self, 'is_processing_active', False))
        except:
            pass

    def on_layers_added(self, layers):
        for layer in layers:
            self.setup_layer_monitoring(layer)

    def on_layer_will_be_removed(self, lid):
        if lid in self.layer_connectors:
            self.layer_connectors.pop(lid).disconnect_signals()

    def monitor_all_existing_layers(self):
        for layer in QgsProject.instance().mapLayers().values():
            self.setup_layer_monitoring(layer)

    def setup_layer_monitoring(self, layer):
        if not self._should_track_layer(layer):
            return
        layer.editingStarted.connect(lambda: self.connect_feature_level_signals(layer))
        layer.editingStopped.connect(lambda: self.disconnect_feature_level_signals(layer))
        if layer.isEditable():
            self.connect_feature_level_signals(layer)

    def connect_feature_level_signals(self, layer):
        if layer.id() not in self.layer_connectors:
            self.layer_connectors[layer.id()] = LayerSignalConnector(layer, self)

    def disconnect_feature_level_signals(self, layer):
        if layer.id() in self.layer_connectors:
            self.layer_connectors.pop(layer.id()).disconnect_signals()

    def _log_edit_event(self, layer, fid, event_type, audit_action, field_name=None, new_value=None):
        if _is_temp_layer(layer.name()):
            return
        is_manual = not self.is_processing_active
        self.db_manager.log_event(
            constants.TABLE_AUDIT,
            layer_name=layer.name(), feature_id=fid,
            action_type=audit_action, field_name=field_name, new_value=new_value)
        self.db_manager.log_event(
            constants.TABLE_ACTIVITY,
            event_type=event_type, layer_name=layer.name(),
            feature_id=fid, is_manual=is_manual)

    # ------------------------------------------------------------------
    # CIERRE SEGURO — ejecuta solo UNA vez aunque QGIS llame varias
    # ------------------------------------------------------------------
    def shutdown(self):
        if self._shutdown_done:
            return
        self._shutdown_done = True

        self.auto_save_timer.stop()
        self.db_manager.flush_to_disk()
        self.save_automatic_report("Cierre_Sesion")

        for connector in self.layer_connectors.values():
            connector.disconnect_signals()

        if self.db_manager:
            self.db_manager.close_connection()
