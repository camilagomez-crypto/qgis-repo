# --- START OF FILE core/database_manager.py ---

import os
import sqlite3
from datetime import datetime, timezone
from qgis.core import Qgis, QgsMessageLog
from . import constants

class DatabaseManager:
    USERNAME = os.environ.get("USERNAME", "unknown")
    HOSTNAME = os.environ.get("COMPUTERNAME", "unknown")

    def __init__(self, plugin_dir, central_db_path):
        try:
            home_path = os.path.expanduser("~")
            self.data_dir = os.path.join(home_path, "QGIS_Productivity_Tracker_Data")
            os.makedirs(self.data_dir, exist_ok=True)
        except Exception as e:
            self.log_message(f"No se pudo crear el directorio de datos en la carpeta de usuario: {e}", Qgis.Critical)
            self._local_conn = None
            self._local_db_path = None
            return

        self.central_db_path = central_db_path
        self._local_db_path = None
        self._local_conn = None
        self.rotate_log_if_needed()

    @property
    def local_db_path(self):
        self.rotate_log_if_needed()
        return self._local_db_path

    def rotate_log_if_needed(self):
        """
        Verifica si la fecha ha cambiado O si la conexión está muerta,
        y (re)conecta si es necesario.
        """
        today_str = datetime.now().strftime('%Y-%m-%d')
        new_path = os.path.join(self.data_dir, f'log_{today_str}.sqlite')

        if new_path != self._local_db_path or self._local_conn is None:
            self.log_message(f"Intentando conectar a: {new_path}", Qgis.Info)
            if self._local_conn:
                self._local_conn.close()

            self._local_db_path = new_path
            try:
                self._local_conn = sqlite3.connect(self._local_db_path, check_same_thread=False)
                # Modo WAL: más robusto ante cierres inesperados y recargas del plugin
                self._local_conn.execute("PRAGMA journal_mode=WAL;")
                # Sincronización NORMAL: equilibrio entre velocidad y durabilidad
                self._local_conn.execute("PRAGMA synchronous=NORMAL;")
                self._local_conn.commit()
                self._setup_local_db()
                self.log_message(f"Conexión exitosa a: {os.path.basename(new_path)}", Qgis.Success)
            except sqlite3.Error as e:
                self.log_message(f"FALLO CRÍTICO al conectar con DB local '{self._local_db_path}'. Error: {e}", Qgis.Critical)
                self._local_conn = None

    def log_message(self, message, level=Qgis.Info):
        QgsMessageLog.logMessage(message, 'Productivity Tracker', level)

    def _execute_local(self, query, params=()):
        """Ejecuta una consulta de escritura en la base de datos local de forma segura."""
        if self._local_conn is None:
            self.rotate_log_if_needed()
            if self._local_conn is None:
                self.log_message("Fallo persistente de conexión a DB local. Evento no registrado.", Qgis.Critical)
                return False

        try:
            cursor = self._local_conn.cursor()
            cursor.execute(query, params)
            self._local_conn.commit()
            return True
        except sqlite3.Error as e:
            self.log_message(f"Error durante ejecución en DB local: {e}", Qgis.Critical)
            if self._local_conn: self._local_conn.rollback()
            return False

    def query_local_readonly(self, query, params=(), fetch='all'):
        """
        Ejecuta una consulta de solo lectura (SELECT) sobre la DB del día de hoy.
        """
        if self._local_conn is None:
            self.log_message("Intento de lectura sin conexión a DB local.", Qgis.Warning)
            return [] if fetch == 'all' else None

        try:
            cursor = self._local_conn.cursor()
            cursor.execute(query, params)
            if fetch == 'one':
                return cursor.fetchone()
            else:
                return cursor.fetchall()
        except sqlite3.Error as e:
            self.log_message(f"Error durante consulta de solo lectura: {e}", Qgis.Warning)
            return [] if fetch == 'all' else None

    # ---------------------------------------------------------------
    # NUEVO: Consulta sobre una DB histórica de una fecha específica
    # ---------------------------------------------------------------
    def query_date_readonly(self, date_str, query, params=(), fetch='all'):
        """
        Abre (en modo solo lectura) el archivo log_<date_str>.sqlite y ejecuta
        una consulta SELECT.  Si la fecha es la de hoy, reutiliza la conexión
        activa para no interferir con las escrituras.

        Args:
            date_str (str): Fecha en formato 'YYYY-MM-DD'.
            query    (str): Sentencia SQL SELECT con ? como placeholders.
            params   (tuple): Parámetros de la consulta.
            fetch    (str): 'all' → fetchall(), 'one' → fetchone().

        Returns:
            list | tuple | None según `fetch`.
        """
        today_str = datetime.now().strftime('%Y-%m-%d')

        if date_str == today_str:
            # Reutilizar la conexión activa del día de hoy
            return self.query_local_readonly(query, params, fetch)

        db_path = os.path.join(self.data_dir, f'log_{date_str}.sqlite')
        if not os.path.exists(db_path):
            self.log_message(f"No existe DB para la fecha {date_str}: {db_path}", Qgis.Warning)
            return [] if fetch == 'all' else None

        try:
            # Abrir en modo read-only para no bloquear ni corromper el archivo
            uri = f"file:{db_path}?mode=ro"
            with sqlite3.connect(uri, uri=True, check_same_thread=False) as conn:
                cursor = conn.cursor()
                cursor.execute(query, params)
                return cursor.fetchone() if fetch == 'one' else cursor.fetchall()
        except sqlite3.Error as e:
            self.log_message(f"Error leyendo DB histórica '{db_path}': {e}", Qgis.Warning)
            return [] if fetch == 'all' else None

    # ---------------------------------------------------------------
    # NUEVO: Devuelve lista de fechas con DB disponible (más antigua a más reciente)
    # ---------------------------------------------------------------
    def get_available_dates(self):
        """
        Escanea data_dir y retorna una lista ordenada de cadenas 'YYYY-MM-DD'
        para las que existe un archivo log_<fecha>.sqlite.
        """
        dates = []
        if not self.data_dir or not os.path.isdir(self.data_dir):
            return dates
        for fname in os.listdir(self.data_dir):
            if fname.startswith('log_') and fname.endswith('.sqlite'):
                date_part = fname[4:-7]  # extrae 'YYYY-MM-DD'
                try:
                    datetime.strptime(date_part, '%Y-%m-%d')
                    dates.append(date_part)
                except ValueError:
                    pass
        return sorted(dates)

    def _setup_local_db(self):
        if not self._local_conn: return
        schema = f"""
        CREATE TABLE IF NOT EXISTS {constants.TABLE_ACTIVITY} (id INTEGER PRIMARY KEY, timestamp TEXT, event_type TEXT, layer_name TEXT, feature_id TEXT, details TEXT, is_manual INTEGER);
        CREATE TABLE IF NOT EXISTS {constants.TABLE_AUDIT} (id INTEGER PRIMARY KEY, timestamp TEXT, layer_name TEXT, feature_id TEXT, action_type TEXT, field_name TEXT, new_value TEXT);
        """
        self._local_conn.executescript(schema)
        self._local_conn.commit()

    def log_event(self, table_name, **kwargs):
        ts = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
        if table_name == constants.TABLE_ACTIVITY:
            query = f"INSERT INTO {table_name} (timestamp, event_type, layer_name, feature_id, details, is_manual) VALUES (?, ?, ?, ?, ?, ?);"
            params = (ts, kwargs.get('event_type'), kwargs.get('layer_name'), str(kwargs.get('feature_id')), kwargs.get('details'), kwargs.get('is_manual'))
        elif table_name == constants.TABLE_AUDIT:
            query = f"INSERT INTO {table_name} (timestamp, layer_name, feature_id, action_type, field_name, new_value) VALUES (?, ?, ?, ?, ?, ?);"
            params = (ts, kwargs.get('layer_name'), str(kwargs.get('feature_id')), kwargs.get('action_type'), kwargs.get('field_name'), str(kwargs.get('new_value')))
        else:
            return
        self._execute_local(query, params)

    def flush_to_disk(self):
        """
        Fuerza que todos los datos pendientes del WAL se escriban al archivo principal
        (.sqlite) antes de cerrar o recargar el plugin. Así nada queda en el buffer.
        """
        if self._local_conn:
            try:
                self._local_conn.execute("PRAGMA wal_checkpoint(TRUNCATE);")
                self._local_conn.commit()
                self.log_message("Checkpoint WAL completado. Datos persistidos en disco.", Qgis.Info)
            except sqlite3.Error as e:
                self.log_message(f"Error durante checkpoint WAL: {e}", Qgis.Warning)

    def close_connection(self):
        """Cierra la conexión de forma segura, forzando primero el flush al disco."""
        self.flush_to_disk()
        if self._local_conn:
            self._local_conn.close()
            self._local_conn = None

    def _execute_central(self, query, params=(), is_many=False):
        if not self.central_db_path or not os.path.exists(os.path.dirname(self.central_db_path)):
            return False
        try:
            with sqlite3.connect(self.central_db_path, timeout=10) as conn:
                cursor = conn.cursor()
                if is_many:
                    cursor.executemany(query, params)
                else:
                    cursor.execute(query, params)
                conn.commit()
                return True
        except sqlite3.Error as e:
            self.log_message(f"Error en DB central: {e}", Qgis.Warning)
            return False

    def _prepare_central_db(self):
        if not self.central_db_path or not os.path.exists(os.path.dirname(self.central_db_path)):
            self.log_message("Directorio de red no accesible.", Qgis.Warning)
            return False
        schema = f"""
        CREATE TABLE IF NOT EXISTS {constants.TABLE_ACTIVITY} (id INTEGER PRIMARY KEY, timestamp TEXT, event_type TEXT, layer_name TEXT, feature_id TEXT, details TEXT, is_manual INTEGER, username TEXT, hostname TEXT);
        CREATE TABLE IF NOT EXISTS {constants.TABLE_AUDIT} (id INTEGER PRIMARY KEY, timestamp TEXT, layer_name TEXT, feature_id TEXT, action_type TEXT, field_name TEXT, new_value TEXT, username TEXT, hostname TEXT);
        """
        try:
            with sqlite3.connect(self.central_db_path, timeout=10) as conn:
                conn.executescript(schema)
            return True
        except sqlite3.Error as e:
            self.log_message(f"No se pudo preparar la DB central: {e}", Qgis.Warning)
            return False

    def sync_to_central(self, db_path_to_sync):
        if not self._prepare_central_db():
            return False
        success_activity = self._sync_table(constants.TABLE_ACTIVITY, db_path_to_sync)
        success_audit = self._sync_table(constants.TABLE_AUDIT, db_path_to_sync)
        return success_activity and success_audit

    def _sync_table(self, table_name, db_path_to_sync):
        query = f"SELECT MAX(timestamp) FROM {table_name} WHERE username = ? AND hostname = ?"
        try:
            with sqlite3.connect(f"file:{self.central_db_path}?mode=ro", uri=True) as conn:
                last_sync_time = conn.execute(query, (self.USERNAME, self.HOSTNAME)).fetchone()[0] or '1970-01-01T00:00:00'
        except sqlite3.Error:
            return False
        with sqlite3.connect(f"file:{db_path_to_sync}?mode=ro", uri=True) as conn:
            records = conn.execute(f"SELECT * FROM {table_name} WHERE timestamp > ?", (last_sync_time,)).fetchall()
        if not records:
            return True
        records_to_insert = [rec[1:] + (self.USERNAME, self.HOSTNAME) for rec in records]
        if table_name == constants.TABLE_ACTIVITY:
            query_insert = f"INSERT INTO {table_name} (timestamp, event_type, layer_name, feature_id, details, is_manual, username, hostname) VALUES (?,?,?,?,?,?,?,?)"
        else:
            query_insert = f"INSERT INTO {table_name} (timestamp, layer_name, feature_id, action_type, field_name, new_value, username, hostname) VALUES (?,?,?,?,?,?,?,?)"
        if self._execute_central(query_insert, records_to_insert, is_many=True):
            self.log_message(f"{len(records_to_insert)} registros de '{table_name}' sincronizados.", Qgis.Success)
            return True
        else:
            self.log_message(f"Fallo al sincronizar {table_name}.", Qgis.Warning)
            return False

    def cleanup_old_logs(self):
        self.log_message("Buscando logs antiguos para limpiar...", Qgis.Info)
        if not self._local_db_path: return
        current_log_filename = os.path.basename(self._local_db_path)
        for filename in os.listdir(self.data_dir):
            if filename.startswith('log_') and filename.endswith('.sqlite') and filename != current_log_filename:
                full_path = os.path.join(self.data_dir, filename)
                if self.sync_to_central(full_path):
                    try:
                        os.remove(full_path)
                        self.log_message(f"Log antiguo '{filename}' sincronizado y eliminado.", Qgis.Success)
                    except OSError as e:
                        self.log_message(f"No se pudo eliminar log '{filename}': {e}", Qgis.Warning)

# --- END OF FILE core/database_manager.py ---
