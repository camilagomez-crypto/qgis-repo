from datetime import datetime


class KPICalculator:
    def __init__(self, db_manager):
        self.db_manager = db_manager

    def _query_local(self, query, params=(), fetch='all'):
        return self.db_manager.query_local_readonly(query, params, fetch)

    def _query_date(self, date_str, query, params=(), fetch='all'):
        return self.db_manager.query_date_readonly(date_str, query, params, fetch)

    # ------------------------------------------------------------------
    # CAPAS DE AUDITORÍA (todas las fechas disponibles)
    # ------------------------------------------------------------------
    def get_audit_layers(self):
        all_layers = set()
        for date_str in self.db_manager.get_available_dates():
            res = self._query_date(
                date_str,
                "SELECT DISTINCT layer_name FROM audit_log ORDER BY layer_name ASC"
            )
            if res:
                for row in res:
                    all_layers.add(row[0])
        return sorted(all_layers)

    # ------------------------------------------------------------------
    # BÚSQUEDA FLEXIBLE — usa la DB de la fecha elegida
    # ------------------------------------------------------------------
    def search_audit_flexible(self, layer_name, feature_id, date_str, start_time, end_time):
        query = """
            SELECT timestamp, layer_name, feature_id, action_type, field_name, new_value
            FROM audit_log
            WHERE strftime('%Y-%m-%d', timestamp, 'localtime') = ?
            AND strftime('%H:%M:%S', timestamp, 'localtime') BETWEEN ? AND ?
        """
        params = [date_str, start_time, end_time]
        if feature_id and feature_id.strip():
            query += " AND layer_name = ? AND feature_id = ?"
            params.extend([layer_name, feature_id.strip()])
        query += " ORDER BY timestamp ASC"
        return self._query_date(date_str, query, tuple(params))

    # ------------------------------------------------------------------
    # AUDITORÍA COMPLETA DE UNA FECHA
    # ------------------------------------------------------------------
    def get_full_daily_audit(self, date_str=None):
        if date_str is None:
            date_str = datetime.now().strftime('%Y-%m-%d')
        query = """
            SELECT timestamp, layer_name, feature_id, action_type, field_name, new_value
            FROM audit_log
            WHERE strftime('%Y-%m-%d', timestamp, 'localtime') = ?
            ORDER BY timestamp ASC
        """
        return self._query_date(date_str, query, (date_str,))

    # ------------------------------------------------------------------
    # MÉTRICAS DE TIEMPO — hoy (para el dashboard en vivo)
    # ------------------------------------------------------------------
    def get_time_metrics(self):
        return self.get_time_metrics_for_date(datetime.now().strftime('%Y-%m-%d'))

    # ------------------------------------------------------------------
    # MÉTRICAS DE TIEMPO — para cualquier fecha (para reportes)
    # ------------------------------------------------------------------
    def get_time_metrics_for_date(self, date_str):
        rows = self._query_date(
            date_str,
            "SELECT timestamp FROM activity_log ORDER BY timestamp ASC"
        )
        if not rows:
            return {'total': 0, 'session': 0, 'active': 0}
        try:
            def parse(ts):
                return datetime.fromisoformat(ts.replace('Z', '+00:00'))
            t_start = parse(rows[0][0])
            t_end   = parse(rows[-1][0])
            active_sec = 0
            for i in range(1, len(rows)):
                d = (parse(rows[i][0]) - parse(rows[i-1][0])).total_seconds()
                if d < 300:
                    active_sec += d
            return {
                'total': (t_end - t_start).total_seconds(),
                'session': active_sec * 1.1,
                'active': active_sec
            }
        except:
            return {'total': 0, 'session': 0, 'active': 0}

    # ------------------------------------------------------------------
    # ESTADÍSTICAS DE SESIÓN — hoy (para el dashboard en vivo)
    # ------------------------------------------------------------------
    def get_session_stats(self):
        return self.get_session_stats_for_date(datetime.now().strftime('%Y-%m-%d'))

    # ------------------------------------------------------------------
    # ESTADÍSTICAS DE SESIÓN — para cualquier fecha (para reportes)
    # ------------------------------------------------------------------
    def get_session_stats_for_date(self, date_str):
        stats = {'created': 0, 'modified': 0, 'last_activity_utc': None}
        res = self._query_date(date_str, """
            SELECT
                IFNULL(SUM(CASE WHEN action_type = 'CREATED' THEN 1 ELSE 0 END), 0),
                IFNULL(SUM(CASE WHEN action_type LIKE 'MODIFIED%' THEN 1 ELSE 0 END), 0)
            FROM audit_log
            WHERE strftime('%Y-%m-%d', timestamp, 'localtime') = ?
        """, (date_str,), fetch='one')
        last = self._query_date(date_str,
            "SELECT MAX(timestamp) FROM audit_log "
            "WHERE strftime('%Y-%m-%d', timestamp, 'localtime') = ?",
            (date_str,), fetch='one')
        if res:
            stats['created'], stats['modified'] = res[0], res[1]
        if last:
            stats['last_activity_utc'] = last[0]
        return stats

    # ------------------------------------------------------------------
    # KPI
    # ------------------------------------------------------------------
    def get_kpi_metrics(self, t):
        s = self.get_session_stats()
        edits = s['created'] + s['modified']
        active_min = t['active'] / 60
        return {
            'edit_rate': edits / active_min if active_min > 0 else 0,
            'gis_focus': min(100, t['active'] / t['total'] * 100) if t['total'] > 0 else 0
        }

    def calculate_work_profile(self):
        s = self.get_session_stats()
        total = s['created'] + s['modified']
        if total == 0:
            return "Analista de Información"
        return "Digitalizador" if s['created'] > s['modified'] else "Editor Experto"

    def get_hourly_productivity(self):
        h = {f"{i:02d}": 0 for i in range(24)}
        res = self._query_local(
            "SELECT strftime('%H', timestamp, 'localtime') as hr, COUNT(*) FROM audit_log GROUP BY hr"
        )
        if res:
            for hr, cnt in res:
                h[hr] = cnt
        return h

    def get_productivity_assessment(self, t, k):
        s = self.get_session_stats()
        if t['active'] < 120:
            return ("NEUTRO", "Sesión Iniciada", "Registrando datos...")
        return ("EXCELENTE", "Rendimiento Óptimo",
                f"Llevas {s['created'] + s['modified']} cambios registrados.")
