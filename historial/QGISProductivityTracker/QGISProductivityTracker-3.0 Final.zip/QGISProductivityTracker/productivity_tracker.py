import os
from datetime import datetime
from qgis.PyQt.QtCore import Qt, QTimer, QTime, QDate
from qgis.PyQt.QtWidgets import (QAction, QDialog, QVBoxLayout, QLabel, QPushButton,
                                QWidget, QFrame, QGridLayout, QHBoxLayout, QFileDialog,
                                QTabWidget, QLineEdit, QComboBox, QTimeEdit, QDateEdit,
                                QTableWidget, QTableWidgetItem, QHeaderView)
from qgis.PyQt.QtGui import QIcon, QFont
from qgis.core import Qgis, QgsMessageLog, QgsProject

try:
    from qgis.PyQt.QtWebEngineWidgets import QWebEngineView
    WEB_ENGINE_AVAILABLE = True
except ImportError:
    WEB_ENGINE_AVAILABLE = False

def format_seconds(seconds):
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{int(h):02}:{int(m):02}:{int(s):02}"


class MetricCard(QFrame):
    def __init__(self, title, value, color="#3498db"):
        super().__init__()
        self.setFrameShape(QFrame.StyledPanel)
        self.setStyleSheet("background-color: #2b2b2b; border: 1px solid #555; border-radius: 8px; padding: 10px;")
        layout = QVBoxLayout(self)
        layout.setSpacing(2)
        self.lbl_title = QLabel(title.upper())
        self.lbl_title.setFont(QFont("Segoe UI", 8, QFont.Bold))
        self.lbl_title.setStyleSheet(f"color: {color}; background: none; border: none;")
        self.lbl_value = QLabel(value)
        self.lbl_value.setFont(QFont("Segoe UI", 16, QFont.Bold))
        self.lbl_value.setStyleSheet("color: #ffffff; background: none; border: none;")
        layout.addWidget(self.lbl_title)
        layout.addWidget(self.lbl_value)

    def update_text(self, val):
        self.lbl_value.setText(str(val))


class ProductivityTrackerDialog(QDialog):
    def __init__(self, iface, engine, calculator, parent=None):
        super().__init__(parent)
        self.iface, self.engine, self.calculator = iface, engine, calculator
        self.setWindowTitle("Sistema de Auditoría y Productividad Profesional")
        self.setMinimumSize(950, 750)
        self.setStyleSheet("background-color: #1e1e1e; color: white;")

        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("""
            QTabBar::tab { background: #2c3e50; padding: 12px 20px; color: white; border-top-left-radius: 4px; border-top-right-radius: 4px; }
            QTabBar::tab:selected { background: #3498db; font-weight: bold; }
            QTabWidget::pane { border: 1px solid #444; background: #1e1e1e; }
        """)

        self.tab_dash = QWidget()
        self._setup_dash_tab()
        self.tabs.addTab(self.tab_dash, "Dashboard General")

        self.tab_audit = QWidget()
        self._setup_audit_tab()
        self.tabs.addTab(self.tab_audit, "Búsqueda por ID / Rango Horario")

        layout = QVBoxLayout(self)
        layout.addWidget(self.tabs)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_ui)
        self.timer.start(5000)
        self.refresh_ui()

    # ------------------------------------------------------------------
    # PESTAÑA DASHBOARD
    # ------------------------------------------------------------------
    def _setup_dash_tab(self):
        lyt = QVBoxLayout(self.tab_dash)

        header = QFrame()
        header.setStyleSheet("background-color: #2c3e50; border-radius: 8px; border: none;")
        h_lyt = QVBoxLayout(header)
        self.lbl_m = QLabel("ANALIZANDO RENDIMIENTO...")
        self.lbl_m.setFont(QFont("Segoe UI", 14, QFont.Bold))
        self.lbl_m.setStyleSheet("color: #3498db; border: none;")
        self.lbl_s = QLabel("Cargando métricas...")
        self.lbl_s.setFont(QFont("Segoe UI", 10))
        self.lbl_s.setStyleSheet("color: #bdc3c7; border: none;")
        h_lyt.addWidget(self.lbl_m)
        h_lyt.addWidget(self.lbl_s)
        lyt.addWidget(header)

        grid = QGridLayout()
        grid.setSpacing(10)
        self.c1 = MetricCard("Tiempo en QGIS", "00:00:00")
        self.c2 = MetricCard("Tiempo Activo", "00:00:00", "#2ecc71")
        self.c3 = MetricCard("Producción Total", "0", "#f39c12")
        self.c4 = MetricCard("Eficiencia (obj/m)", "0.00", "#e74c3c")
        self.c5 = MetricCard("Enfoque GIS", "0.0 %", "#9b59b6")
        self.c6 = MetricCard("Perfil de Trabajo", "...", "#1abc9c")
        grid.addWidget(self.c1, 0, 0); grid.addWidget(self.c2, 0, 1); grid.addWidget(self.c3, 0, 2)
        grid.addWidget(self.c4, 1, 0); grid.addWidget(self.c5, 1, 1); grid.addWidget(self.c6, 1, 2)
        lyt.addLayout(grid)

        if WEB_ENGINE_AVAILABLE:
            self.web = QWebEngineView()
            self.web.setFixedHeight(250)
            lyt.addWidget(self.web)

        btn = QPushButton(" GENERAR REPORTE PROFESIONAL AHORA")
        btn.setFont(QFont("Segoe UI", 10, QFont.Bold))
        btn.setStyleSheet("background: #27ae60; color: white; padding: 12px; border-radius: 5px;")
        btn.clicked.connect(self.generate_html_report_manual)
        lyt.addWidget(btn)

    # ------------------------------------------------------------------
    # PESTAÑA AUDITORÍA
    # ------------------------------------------------------------------
    def _setup_audit_tab(self):
        lyt = QVBoxLayout(self.tab_audit)
        f_box = QFrame()
        f_box.setStyleSheet("background: #2b2b2b; padding: 15px; border-radius: 8px;")
        flyt = QGridLayout(f_box)

        self.cmb_layers = QComboBox()
        self.cmb_layers.setStyleSheet("background: #1e1e1e; color: white; padding: 6px;")

        self.txt_id = QLineEdit()
        self.txt_id.setPlaceholderText("ID del Objeto (Opcional)")
        self.txt_id.setStyleSheet("background: #1e1e1e; color: white; padding: 6px;")

        self.date_sel = QDateEdit(QDate.currentDate())
        self.date_sel.setCalendarPopup(True)
        self.date_sel.setStyleSheet("background: #1e1e1e; color: white; padding: 4px;")
        # ← CAMBIO: al cambiar la fecha recargamos las capas disponibles para esa DB
        self.date_sel.dateChanged.connect(self.on_date_changed)

        self.t_start = QTimeEdit(QTime(9, 0))
        self.t_start.setStyleSheet("background: #1e1e1e; color: white; padding: 4px;")
        self.t_end = QTimeEdit(QTime(14, 0))
        self.t_end.setStyleSheet("background: #1e1e1e; color: white; padding: 4px;")

        flyt.addWidget(QLabel("Capa Histórica:"), 0, 0)
        flyt.addWidget(self.cmb_layers, 0, 1)
        flyt.addWidget(QLabel("ID del Objeto:"), 0, 2)
        flyt.addWidget(self.txt_id, 0, 3)
        flyt.addWidget(QLabel("Fecha:"), 1, 0)
        flyt.addWidget(self.date_sel, 1, 1)
        flyt.addWidget(QLabel("Desde Hora:"), 1, 2)
        flyt.addWidget(self.t_start, 1, 3)
        flyt.addWidget(QLabel("Hasta Hora:"), 1, 4)
        flyt.addWidget(self.t_end, 1, 5)

        btn = QPushButton("EJECUTAR BÚSQUEDA DE CAMBIOS")
        btn.setFont(QFont("Segoe UI", 10, QFont.Bold))
        btn.setStyleSheet("background: #3498db; color: white; padding: 10px; border-radius: 5px;")
        btn.clicked.connect(self.run_search)
        flyt.addWidget(btn, 2, 0, 1, 6)
        lyt.addWidget(f_box)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Hora", "Capa", "Acción (ID)", "Campo", "Valor Nuevo"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setStyleSheet("color: white; background: #2b2b2b; gridline-color: #444;")
        lyt.addWidget(self.table)

        # Carga inicial de capas (todas las fechas disponibles)
        self.refresh_audit_layers()

    # ------------------------------------------------------------------
    # NUEVO: recarga el combo de capas filtrando por la fecha elegida
    # ------------------------------------------------------------------
    def on_date_changed(self, qdate):
        date_str = qdate.toString("yyyy-MM-dd")
        self.cmb_layers.clear()
        query = "SELECT DISTINCT layer_name FROM audit_log ORDER BY layer_name ASC"
        rows = self.calculator.db_manager.query_date_readonly(date_str, query)
        if rows:
            self.cmb_layers.addItems([r[0] for r in rows])
        else:
            self.cmb_layers.addItem("(sin datos para esta fecha)")

    def refresh_audit_layers(self):
        """Carga capas de TODAS las fechas disponibles (para la carga inicial)."""
        self.cmb_layers.clear()
        ls = self.calculator.get_audit_layers()
        if ls:
            self.cmb_layers.addItems(ls)

    # ------------------------------------------------------------------
    # BUG 2 CORREGIDO: run_search pasa la fecha al calculador
    # ------------------------------------------------------------------
    def run_search(self):
        layer = self.cmb_layers.currentText()
        fid = self.txt_id.text()
        date = self.date_sel.date().toString("yyyy-MM-dd")
        ts = self.t_start.time().toString("HH:mm:ss")
        te = self.t_end.time().toString("HH:mm:ss")

        # El calculador ya usa query_date_readonly internamente
        res = self.calculator.search_audit_flexible(layer, fid, date, ts, te)

        self.table.setRowCount(0)
        if not res:
            return

        for r in res:
            idx = self.table.rowCount()
            self.table.insertRow(idx)
            try:
                h = datetime.fromisoformat(r[0].replace('Z', '+00:00')).astimezone(None).strftime("%H:%M:%S")
            except Exception:
                h = r[0]
            self.table.setItem(idx, 0, QTableWidgetItem(h))
            self.table.setItem(idx, 1, QTableWidgetItem(str(r[1])))
            self.table.setItem(idx, 2, QTableWidgetItem(f"{r[3]} ({r[2]})"))
            self.table.setItem(idx, 3, QTableWidgetItem(str(r[4] if r[4] else "-")))
            self.table.setItem(idx, 4, QTableWidgetItem(str(r[5] if r[5] else "-")))

    def refresh_ui(self):
        t = self.calculator.get_time_metrics()
        k = self.calculator.get_kpi_metrics(t)
        s = self.calculator.get_session_stats()

        self.c1.update_text(format_seconds(t['total']))
        self.c2.update_text(format_seconds(t['active']))
        self.c3.update_text(str(s['created'] + s['modified']))
        self.c4.update_text(f"{k['edit_rate']:.2f}")
        self.c5.update_text(f"{k['gis_focus']:.1f} %")
        self.c6.update_text(self.calculator.calculate_work_profile())

        _, title, desc = self.calculator.get_productivity_assessment(t, k)
        self.lbl_m.setText(title.upper())
        self.lbl_s.setText(desc)

        if WEB_ENGINE_AVAILABLE:
            self.update_chart()

    def update_chart(self):
        d = self.calculator.get_hourly_productivity()
        labels = list(d.keys())
        values = list(d.values())
        html = (
            f"<html><head><script src='https://cdn.jsdelivr.net/npm/chart.js'></script></head>"
            f"<body style='background:#1e1e1e; margin:0;'>"
            f"<canvas id='ch' style='width:100%; height:230px;'></canvas>"
            f"<script>new Chart('ch',{{type:'bar',data:{{labels:{labels},"
            f"datasets:[{{data:{values},backgroundColor:'#3498db',borderRadius:5}}]}},"
            f"options:{{responsive:true,maintainAspectRatio:false,"
            f"plugins:{{legend:{{display:false}}}},"
            f"scales:{{y:{{grid:{{color:'#333'}},ticks:{{color:'#666'}}}},"
            f"x:{{grid:{{color:'#333'}},ticks:{{color:'#666'}}}}}}}}}});"
            f"</script></body></html>"
        )
        if hasattr(self, 'web'):
            self.web.setHtml(html)

    # ------------------------------------------------------------------
    # BUG 1 CORREGIDO: reporte manual usa la fecha de hoy explícitamente
    # ------------------------------------------------------------------
    def generate_html_report_manual(self):
        today_str = datetime.now().strftime('%Y-%m-%d')
        self.engine.save_automatic_report("Manual", date_str=today_str)
        docs_path = os.path.join(os.path.expanduser("~"), "Documents", "QGIS_Productivity_Reports")
        if os.path.exists(docs_path):
            try:
                os.startfile(docs_path)   # Windows
            except AttributeError:
                pass                      # Linux/Mac: no hacer nada


# ------------------------------------------------------------------
# Clase principal del plugin
# ------------------------------------------------------------------
class QGISProductivityTracker:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.toolbar = None
        self.engine = None
        self.calculator = None
        self.dialog = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, 'icons', 'icon.svg')
        self.action = QAction(QIcon(icon_path), "Dashboard de Productividad", self.iface.mainWindow())
        self.action.triggered.connect(self.run)

        self.toolbar = self.iface.addToolBar("ProductivityTrackerToolbar")
        self.toolbar.setObjectName("ProductivityTrackerToolbar")
        self.toolbar.addAction(self.action)

        self.iface.addPluginToMenu("&Productivity Tracker", self.action)
        self.start_engine()

    def start_engine(self):
        from .core.tracker_engine import TrackerEngine
        from .core.kpi_calculator import KPICalculator
        if not self.engine:
            self.engine = TrackerEngine(self.iface, self.plugin_dir)
            self.calculator = KPICalculator(self.engine.db_manager)

    def unload(self):
        if self.toolbar:
            self.iface.mainWindow().removeToolBar(self.toolbar)
            del self.toolbar
        if self.action:
            self.iface.removePluginMenu("&Productivity Tracker", self.action)
        if self.engine:
            self.engine.shutdown()

    def run(self):
        if not self.engine:
            self.start_engine()
        if not self.dialog:
            self.dialog = ProductivityTrackerDialog(
                self.iface, self.engine, self.calculator, self.iface.mainWindow()
            )
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
