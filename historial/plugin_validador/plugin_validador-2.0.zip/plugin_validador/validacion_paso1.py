# -*- coding: utf-8 -*-
"""
Módulo PASO 1: Validación de Capas SITI vs TELEF
"""

from qgis.core import (
    QgsProject, QgsVectorLayer, QgsFeature, QgsGeometry, 
    QgsField, QgsWkbTypes, QgsSpatialIndex
)
from qgis.PyQt.QtCore import QVariant, QCoreApplication
import difflib


def ejecutar_validacion_paso1(barrios_siti, urb_siti, barrios_telef, urb_telef, 
                               umbral, log_func, progress_bar):
    """
    Ejecuta la validación completa del PASO 1
    
    Returns:
        str: Resumen de resultados
    """
    
    # 1. Crear mallas fusionadas
    log_func("\n2. Creando mallas de comparación...")
    malla_siti = merge_capas_manual(barrios_siti, urb_siti, "MALLA_SITI", log_func)
    malla_telef = merge_capas_manual(barrios_telef, urb_telef, "MALLA_TELEF", log_func)
    
    if not malla_siti or not malla_telef:
        raise Exception("Error al crear las mallas fusionadas")
    
    progress_bar.setValue(20)
    
    # 2. Validar capas existentes
    log_func("\n3. TAREA A: Validando información existente...")
    
    capa_revisar_barrios, capa_actualizar_barrios = validar_existentes(
        barrios_siti, barrios_telef, "nombre", "nombre", "BARRIOS_SITI", log_func
    )
    
    progress_bar.setValue(40)
    
    capa_revisar_urb, capa_actualizar_urb = validar_existentes(
        urb_siti, urb_telef, "nombre", "nombre", "URBANIZACIONES_SITI", log_func
    )
    
    progress_bar.setValue(60)
    
    # 3. Identificar nuevos
    log_func("\n4. TAREA B: Identificando información nueva...")
    log_func(f"   Umbral de similitud configurado: {umbral}%")
    
    capa_nuevos_barrios = identificar_nuevos_logica_final(
        barrios_telef, malla_siti, "nombre", "BARRIOS", umbral, log_func
    )
    
    progress_bar.setValue(75)
    
    capa_nuevos_urb = identificar_nuevos_logica_final(
        urb_telef, malla_siti, "nombre", "URBANIZACIONES", umbral, log_func
    )
    
    progress_bar.setValue(90)
    
    # 4. Agregar capas al proyecto
    log_func("\n5. Agregando capas al proyecto...")
    
    capas_generadas = []
    
    if capa_revisar_barrios and capa_revisar_barrios.featureCount() > 0:
        QgsProject.instance().addMapLayer(capa_revisar_barrios)
        capas_generadas.append(f"REVISAR_BARRIOS_SITI ({capa_revisar_barrios.featureCount()})")
    
    if capa_actualizar_barrios and capa_actualizar_barrios.featureCount() > 0:
        QgsProject.instance().addMapLayer(capa_actualizar_barrios)
        capas_generadas.append(f"ACTUALIZAR_BARRIOS_SITI ({capa_actualizar_barrios.featureCount()})")
    
    if capa_revisar_urb and capa_revisar_urb.featureCount() > 0:
        QgsProject.instance().addMapLayer(capa_revisar_urb)
        capas_generadas.append(f"REVISAR_URBANIZACIONES_SITI ({capa_revisar_urb.featureCount()})")
    
    if capa_actualizar_urb and capa_actualizar_urb.featureCount() > 0:
        QgsProject.instance().addMapLayer(capa_actualizar_urb)
        capas_generadas.append(f"ACTUALIZAR_URBANIZACIONES_SITI ({capa_actualizar_urb.featureCount()})")
    
    if capa_nuevos_barrios and capa_nuevos_barrios.featureCount() > 0:
        QgsProject.instance().addMapLayer(capa_nuevos_barrios)
        capas_generadas.append(f"AGREGAR_BARRIOS ({capa_nuevos_barrios.featureCount()})")
    
    if capa_nuevos_urb and capa_nuevos_urb.featureCount() > 0:
        QgsProject.instance().addMapLayer(capa_nuevos_urb)
        capas_generadas.append(f"AGREGAR_URBANIZACIONES ({capa_nuevos_urb.featureCount()})")
    
    # 5. Generar resumen
    resumen = f"""RESUMEN DE RESULTADOS:

📊 BARRIOS:
   - Para revisar: {capa_revisar_barrios.featureCount() if capa_revisar_barrios else 0}
   - Para actualizar: {capa_actualizar_barrios.featureCount() if capa_actualizar_barrios else 0}
   - Para agregar: {capa_nuevos_barrios.featureCount() if capa_nuevos_barrios else 0}

📊 URBANIZACIONES:
   - Para revisar: {capa_revisar_urb.featureCount() if capa_revisar_urb else 0}
   - Para actualizar: {capa_actualizar_urb.featureCount() if capa_actualizar_urb else 0}
   - Para agregar: {capa_nuevos_urb.featureCount() if capa_nuevos_urb else 0}

📁 CAPAS GENERADAS:
""" + "\n".join([f"   ✓ {c}" for c in capas_generadas])
    
    return resumen


def normalizar_texto(texto):
    """Normaliza texto para comparación"""
    if not texto:
        return set()
    texto = str(texto).upper().strip()
    palabras = texto.split()
    return set(palabras)


def calcular_similitud(nombre_siti, nombre_telef):
    """Calcula la similitud entre dos nombres"""
    if not nombre_siti or not nombre_telef:
        return 0.0
    
    ratio = difflib.SequenceMatcher(None, 
                                    str(nombre_siti).upper(), 
                                    str(nombre_telef).upper()).ratio()
    return round(ratio * 100, 2)


def obtener_discrepancia(nombre_siti, nombre_telef):
    """Identifica palabras que difieren entre los nombres"""
    palabras_vacias = {'EL', 'LA', 'LOS', 'LAS', 'DE', 'DEL', 'Y'}
    palabras_peso = {'URB', 'URBANIZACION', 'ETA', 'ETAPA', 'CONJUNTO', 'BARRIO', 'BRR'}
    
    set_siti = normalizar_texto(nombre_siti)
    set_telef = normalizar_texto(nombre_telef)
    
    diferencia = set_siti ^ set_telef
    diferencia_real = diferencia - palabras_vacias
    
    if not diferencia_real:
        return "", "VACIA"
    
    tiene_peso = bool(diferencia_real & palabras_peso)
    return " ".join(sorted(diferencia_real)), "PESO" if tiene_peso else "MENOR"


def clasificar_estado(pct_similitud, tipo_discrepancia):
    """Clasifica el estado según porcentaje y tipo de discrepancia"""
    if pct_similitud == 100:
        return "OK"
    elif tipo_discrepancia == "VACIA":
        return "ACTUALIZAR"
    else:
        return "REVISAR"


def crear_capa_resultado(nombre, crs, tipo_geometria="Polygon"):
    """Crea una capa de memoria con campos estándar"""
    uri = f"{tipo_geometria}?crs={crs.authid()}"
    capa = QgsVectorLayer(uri, nombre, "memory")
    
    if not capa.isValid():
        return None
    
    provider = capa.dataProvider()
    
    campos = [
        QgsField("ID_ORIGEN", QVariant.String),
        QgsField("NOMBRE_SITI", QVariant.String, len=254),
        QgsField("NOM_TELEF", QVariant.String, len=254),
        QgsField("ESTADO", QVariant.String),
        QgsField("DISCREPANCIA", QVariant.String, len=254),
        QgsField("PCT_SIMIL", QVariant.Double)
    ]
    
    provider.addAttributes(campos)
    capa.updateFields()
    
    return capa


def merge_capas_manual(capa1, capa2, nombre, log_func):
    """Une dos capas manualmente copiando features"""
    crs = capa1.crs()
    
    tipo_geom1 = QgsWkbTypes.displayString(capa1.wkbType())
    if "Multi" in tipo_geom1:
        tipo_geom = "MultiPolygon"
    else:
        tipo_geom = "Polygon"
    
    uri = f"{tipo_geom}?crs={crs.authid()}"
    capa_merge = QgsVectorLayer(uri, nombre, "memory")
    
    if not capa_merge.isValid():
        return None
    
    provider = capa_merge.dataProvider()
    campos_capa1 = capa1.fields()
    provider.addAttributes(campos_capa1.toList())
    capa_merge.updateFields()
    
    features_merge = []
    
    log_func(f"   Copiando {capa1.featureCount()} features de {capa1.name()}...")
    for feat in capa1.getFeatures():
        nueva_feat = QgsFeature(capa_merge.fields())
        nueva_feat.setGeometry(feat.geometry())
        
        for field in capa_merge.fields():
            if field.name() in feat.fields().names():
                nueva_feat[field.name()] = feat[field.name()]
        
        features_merge.append(nueva_feat)
    
    log_func(f"   Copiando {capa2.featureCount()} features de {capa2.name()}...")
    for feat in capa2.getFeatures():
        nueva_feat = QgsFeature(capa_merge.fields())
        nueva_feat.setGeometry(feat.geometry())
        
        for field in capa_merge.fields():
            if field.name() in feat.fields().names():
                nueva_feat[field.name()] = feat[field.name()]
        
        features_merge.append(nueva_feat)
    
    provider.addFeatures(features_merge)
    capa_merge.updateExtents()
    
    log_func(f"   ✓ Merge completado: {capa_merge.featureCount()} features totales")
    
    return capa_merge


def validar_existentes(capa_siti, capa_telef, nombre_campo_siti, nombre_campo_telef, tipo_capa, log_func):
    """Valida las capas SITI contra TELEF"""
    log_func(f"\n   Validando {tipo_capa}...")
    
    capa_revisar = crear_capa_resultado(
        f"REVISAR_{tipo_capa}", 
        capa_siti.crs(),
        "MultiPolygon" if "Multi" in QgsWkbTypes.displayString(capa_siti.wkbType()) else "Polygon"
    )
    
    capa_actualizar = crear_capa_resultado(
        f"ACTUALIZAR_{tipo_capa}", 
        capa_siti.crs(),
        "MultiPolygon" if "Multi" in QgsWkbTypes.displayString(capa_siti.wkbType()) else "Polygon"
    )
    
    if not capa_revisar or not capa_actualizar:
        return None, None
    
    index_telef = QgsSpatialIndex(capa_telef.getFeatures())
    
    features_revisar = []
    features_actualizar = []
    
    total = capa_siti.featureCount()
    contador = 0
    
    for feat_siti in capa_siti.getFeatures():
        contador += 1
        if contador % 50 == 0:
            log_func(f"      Procesando {contador}/{total}...")
            QCoreApplication.processEvents()
        
        geom_siti = feat_siti.geometry()
        
        if geom_siti.isEmpty() or geom_siti.isNull():
            continue
        
        centroide = geom_siti.centroid()
        ids_candidatos = index_telef.intersects(centroide.boundingBox())
        
        feat_telef_encontrado = None
        for fid in ids_candidatos:
            feat_telef = capa_telef.getFeature(fid)
            if feat_telef.geometry().contains(centroide):
                feat_telef_encontrado = feat_telef
                break
        
        if feat_telef_encontrado:
            nombre_siti = str(feat_siti[nombre_campo_siti]) if nombre_campo_siti in feat_siti.fields().names() else ""
            nombre_telef = str(feat_telef_encontrado[nombre_campo_telef]) if nombre_campo_telef in feat_telef_encontrado.fields().names() else ""
            
            pct_simil = calcular_similitud(nombre_siti, nombre_telef)
            discrepancia, tipo_disc = obtener_discrepancia(nombre_siti, nombre_telef)
            estado = clasificar_estado(pct_simil, tipo_disc)
            
            nueva_feat = QgsFeature(capa_revisar.fields())
            nueva_feat.setGeometry(geom_siti)
            
            id_origen = str(feat_siti.id())
            
            nueva_feat.setAttributes([
                id_origen,
                nombre_siti,
                nombre_telef,
                estado,
                discrepancia,
                pct_simil
            ])
            
            if estado == "REVISAR":
                features_revisar.append(nueva_feat)
            elif estado == "ACTUALIZAR":
                features_actualizar.append(nueva_feat)
    
    if features_revisar:
        capa_revisar.dataProvider().addFeatures(features_revisar)
        capa_revisar.updateExtents()
    
    if features_actualizar:
        capa_actualizar.dataProvider().addFeatures(features_actualizar)
        capa_actualizar.updateExtents()
    
    log_func(f"   ✓ {tipo_capa}: {len(features_revisar)} para revisar, {len(features_actualizar)} para actualizar")
    
    return capa_revisar, capa_actualizar


def identificar_nuevos_logica_final(capa_telef, malla_siti, nombre_campo_telef, tipo_capa, umbral, log_func):
    """
    Un polígono de TELEF es NUEVO si:
    1. Su centroide NO cae en ningún polígono de SITI, Y
    2. Su nombre NO existe en TODA la base SITI (en ninguna ubicación)
    O si:
    3. Su centroide SÍ cae en SITI pero el nombre es muy diferente (<umbral%)
    """
    log_func(f"\n   Identificando información nueva para {tipo_capa}...")
    
    # Crear índice espacial de SITI
    index_siti = QgsSpatialIndex(malla_siti.getFeatures())
    
    # Recolectar TODOS los nombres que existen en SITI
    log_func(f"      Recolectando todos los nombres de SITI...")
    nombres_siti_global = set()
    
    for feat in malla_siti.getFeatures():
        if 'nombre' in feat.fields().names():
            nombre = str(feat['nombre']).upper().strip()
            if nombre:
                nombres_siti_global.add(nombre)
    
    log_func(f"      {len(nombres_siti_global)} nombres únicos en toda la base SITI")
    
    # Crear capa de nuevos
    capa_nuevos = crear_capa_resultado(
        f"AGREGAR_{tipo_capa}", 
        capa_telef.crs(),
        "MultiPolygon" if "Multi" in QgsWkbTypes.displayString(capa_telef.wkbType()) else "Polygon"
    )
    
    if not capa_nuevos:
        return None
    
    features_nuevos = []
    
    total = capa_telef.featureCount()
    contador = 0
    nuevos_por_hueco_y_nombre = 0
    nuevos_por_nombre_diferente = 0
    descartados_nombre_existe = 0
    
    for feat_telef in capa_telef.getFeatures():
        contador += 1
        if contador % 20 == 0:
            QCoreApplication.processEvents()
        
        geom_telef = feat_telef.geometry()
        
        if geom_telef.isEmpty() or geom_telef.isNull():
            continue
        
        # Obtener nombre de TELEF
        nombre_telef = str(feat_telef[nombre_campo_telef]) if nombre_campo_telef in feat_telef.fields().names() else ""
        nombre_telef_norm = nombre_telef.upper().strip()
        
        if not nombre_telef_norm:
            continue
        
        # Obtener centroide
        centroide = geom_telef.centroid()
        
        # Buscar si el centroide cae en algún polígono de SITI
        ids_candidatos = index_siti.intersects(centroide.boundingBox())
        
        feat_siti_encontrado = None
        for fid in ids_candidatos:
            feat_siti = malla_siti.getFeature(fid)
            if feat_siti.geometry().contains(centroide):
                feat_siti_encontrado = feat_siti
                break
        
        # CASO 1: Centroide NO cae en SITI (hueco geográfico)
        if not feat_siti_encontrado:
            # Verificar si el nombre existe en ALGUNA parte de SITI
            if nombre_telef_norm not in nombres_siti_global:
                # ES NUEVO: hueco + nombre nuevo
                nuevos_por_hueco_y_nombre += 1
                
                if nuevos_por_hueco_y_nombre <= 3:
                    log_func(f"      ✓ NUEVO (hueco + nombre nuevo): '{nombre_telef}'")
                
                nueva_feat = QgsFeature(capa_nuevos.fields())
                nueva_feat.setGeometry(geom_telef)
                
                nueva_feat.setAttributes([
                    str(feat_telef.id()),
                    "",
                    nombre_telef,
                    "NUEVO",
                    "HUECO_NOMBRE_NUEVO",
                    0.0
                ])
                
                features_nuevos.append(nueva_feat)
            else:
                # NO es nuevo: el nombre ya existe en otra parte de SITI
                descartados_nombre_existe += 1
                if descartados_nombre_existe <= 3:
                    log_func(f"      ✗ Descartado (nombre existe): '{nombre_telef}'")
        
        # CASO 2: Centroide SÍ cae en SITI
        else:
            # Obtener el nombre del polígono de SITI que lo contiene
            nombre_siti = ""
            if 'nombre' in feat_siti_encontrado.fields().names():
                nombre_siti = str(feat_siti_encontrado['nombre']).strip()
            
            # Calcular similitud con el polígono que lo contiene
            similitud = calcular_similitud(nombre_siti, nombre_telef)
            
            # Si la similitud es muy baja, son entidades diferentes
            if similitud < umbral:
                nuevos_por_nombre_diferente += 1
                
                if nuevos_por_nombre_diferente <= 5:
                    log_func(f"      ✓ NUEVO (nombre muy diferente {similitud:.1f}%): '{nombre_telef}' vs '{nombre_siti}'")
                
                nueva_feat = QgsFeature(capa_nuevos.fields())
                nueva_feat.setGeometry(geom_telef)
                
                nueva_feat.setAttributes([
                    str(feat_telef.id()),
                    nombre_siti,
                    nombre_telef,
                    "NUEVO",
                    "NOMBRE_MUY_DIFERENTE",
                    similitud
                ])
                
                features_nuevos.append(nueva_feat)
    
    log_func(f"\n      ESTADÍSTICAS DE DETECCIÓN:")
    log_func(f"      - Total procesados: {contador}")
    log_func(f"      - Nuevos (hueco + nombre no existe): {nuevos_por_hueco_y_nombre}")
    log_func(f"      - Nuevos (nombre muy diferente <{umbral}%): {nuevos_por_nombre_diferente}")
    log_func(f"      - Descartados (nombre ya existe en SITI): {descartados_nombre_existe}")
    log_func(f"      - TOTAL NUEVOS: {len(features_nuevos)}")
    
    if features_nuevos:
        capa_nuevos.dataProvider().addFeatures(features_nuevos)
        capa_nuevos.updateExtents()
    
    return capa_nuevos

# ─────────────────────────────────────────────────────────────────────────────
# WRAPPER: función esperada por validacion_capas_pasto.py
# ─────────────────────────────────────────────────────────────────────────────

def ejecutar_paso1_completo(barrios_siti, urb_siti, barrios_telef, urb_telef,
                             campo, parent_dialog, iface):
    """
    Wrapper que adapta la firma esperada por el diálogo principal.
    Crea una barra de progreso ficticia compatible y llama a la función core.
    """
    from qgis.PyQt.QtWidgets import QProgressBar
    from qgis.PyQt.QtWidgets import QApplication

    # Crear una barra de progreso mínima (no visible) para compatibilidad
    class ProgressBarFictiicio:
        def setValue(self, v): pass

    progress_bar = ProgressBarFictiicio()

    def log_func(msg):
        parent_dialog.log_mensaje(msg, paso=1)

    # Umbral por defecto 75%
    umbral = 75.0

    try:
        resumen = ejecutar_validacion_paso1(
            barrios_siti, urb_siti, barrios_telef, urb_telef,
            umbral, log_func, progress_bar
        )
        log_func("\n" + "=" * 50)
        log_func(resumen)
        log_func("=" * 50)

        from qgis.PyQt.QtWidgets import QMessageBox
        QMessageBox.information(
            parent_dialog,
            "✅ PASO 1 Completado",
            resumen
        )

    except Exception as e:
        import traceback
        log_func(f"❌ ERROR: {traceback.format_exc()}")
        raise
