# -*- coding: utf-8 -*-

from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
import os


class PluginValidador:
    
    def __init__(self, iface):
        self.iface = iface
        self.dialog = None
        self.action = None
    
    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        
        self.action = QAction(
            QIcon(icon_path) if os.path.exists(icon_path) else QIcon(),
            "Validación de Capas Administrativas",
            self.iface.mainWindow()
        )
        
        self.action.triggered.connect(self.run)
        
        self.iface.addPluginToMenu("Validación Capas Pasto", self.action)
        self.iface.addToolBarIcon(self.action)
    
    def unload(self):
        self.iface.removePluginMenu("Validación Capas Pasto", self.action)
        self.iface.removeToolBarIcon(self.action)
    
    def run(self):
        from .validacion_capas_pasto import ValidacionCapasPastoDialog
        
        if self.dialog is None:
            self.dialog = ValidacionCapasPastoDialog(self.iface)
        
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()