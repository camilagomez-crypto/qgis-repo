# -*- coding: utf-8 -*-
"""
Módulo de Transferencia TELEF → SITI
Proceso optimizado con validaciones estrictas
"""

from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.core import QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY, QgsSpatialIndex, NULL
import time


def ejecutar_transferencia_completa(capa_telef, capa_siti, capa_malla, capa_barrios, capa_urb,
                                    campos_telef, campos_siti, campos_malla, campos_barrios, 
                                    campos_urb, metadatos, parent_dialog, iface):
    """
    Función principal de transferencia TELEF → SITI
    Optimizada para velocidad y sin bloqueo de QGIS
    """
    
    tiempo_inicio = time.time()
    parent_dialog.log_mensaje("=" * 60, paso=4)
    parent_dialog.log_mensaje("🔄 INICIANDO PROCESO DE TRANSFERENCIA", paso=4)
    parent_dialog.log_mensaje("=" * 60, paso=4)
    
    try:
        # PASO 1: Convertir TELEF a puntos
        parent_dialog.log_mensaje("📍 PASO 1: Convirtiendo predios TELEF a puntos...", paso=4)
        puntos_telef = convertir_a_puntos(capa_telef, campos_telef, parent_dialog)
        parent_dialog.log_mensaje(f"   ✅ {len(puntos_telef)} puntos generados", paso=4)
        
        # PASO 2: Pre-cargar combinaciones existentes en SITI (para validar duplicados)
        parent_dialog.log_mensaje("📊 PASO 2: Cargando combinaciones existentes en SITI...", paso=4)
        combinaciones_existentes = cargar_combinaciones_siti(capa_siti, campos_siti, parent_dialog)
        parent_dialog.log_mensaje(f"   ✅ {len(combinaciones_existentes)} combinaciones en memoria", paso=4)
        
        # PASO 3: Crear índices espaciales
        parent_dialog.log_mensaje("🗺️ PASO 3: Creando índices espaciales...", paso=4)
        indices = crear_indices_espaciales(capa_siti, capa_malla, capa_barrios, capa_urb, parent_dialog)
        parent_dialog.log_mensaje("   ✅ Índices espaciales creados", paso=4)
        
        # PASO 4: Validar predios SITI receptores
        parent_dialog.log_mensaje("🔍 PASO 4: Identificando predios SITI receptores...", paso=4)
        predios_receptores = identificar_receptores(capa_siti, campos_siti, indices['index_siti'], parent_dialog)
        parent_dialog.log_mensaje(f"   ✅ {len(predios_receptores)} predios SITI pueden recibir información", paso=4)
        
        # PASO 5: Procesar transferencias
        parent_dialog.log_mensaje("🚀 PASO 5: Procesando transferencias...", paso=4)
        resultado = procesar_transferencias(
            puntos_telef, predios_receptores, combinaciones_existentes,
            capa_siti, capa_malla, capa_barrios, capa_urb,
            campos_siti, campos_malla, campos_barrios, campos_urb,
            metadatos, indices, parent_dialog
        )
        
        # PASO 6: Aplicar cambios
        parent_dialog.log_mensaje("💾 PASO 6: Guardando cambios en SITI...", paso=4)
        aplicar_cambios_masivos(capa_siti, resultado['cambios'], campos_siti, metadatos, parent_dialog)
        
        # RESUMEN FINAL
        tiempo_total = time.time() - tiempo_inicio
        parent_dialog.log_mensaje("=" * 60, paso=4)
        parent_dialog.log_mensaje("✅ TRANSFERENCIA COMPLETADA", paso=4)
        parent_dialog.log_mensaje("=" * 60, paso=4)
        parent_dialog.log_mensaje(f"📊 RESUMEN:", paso=4)
        parent_dialog.log_mensaje(f"   • Predios procesados: {resultado['procesados']}", paso=4)
        parent_dialog.log_mensaje(f"   • Transferencias CARDINAL: {resultado['cardinal']}", paso=4)
        parent_dialog.log_mensaje(f"   • Transferencias MZA CASA: {resultado['mza_casa']}", paso=4)
        parent_dialog.log_mensaje(f"   • Descartados (duplicados): {resultado['duplicados']}", paso=4)
        parent_dialog.log_mensaje(f"   • Descartados (sin validación): {resultado['sin_validacion']}", paso=4)
        parent_dialog.log_mensaje(f"   ⏱️ Tiempo total: {tiempo_total:.2f} segundos", paso=4)
        parent_dialog.log_mensaje("=" * 60, paso=4)
        
        QMessageBox.information(
            parent_dialog,
            "✅ Transferencia Completada",
            f"Proceso finalizado exitosamente:\n\n"
            f"• Transferencias CARDINAL: {resultado['cardinal']}\n"
            f"• Transferencias MZA CASA: {resultado['mza_casa']}\n"
            f"• Descartados por duplicados: {resultado['duplicados']}\n\n"
            f"Tiempo: {tiempo_total:.2f} segundos"
        )
        
    except Exception as e:
        parent_dialog.log_mensaje(f"❌ ERROR CRÍTICO: {str(e)}", paso=4)
        import traceback
        parent_dialog.log_mensaje(f"   {traceback.format_exc()}", paso=4)
        raise


def convertir_a_puntos(capa_telef, campos, parent_dialog):
    """Convertir predios TELEF a puntos (centroides)"""
    puntos = []
    
    for feat in capa_telef.getFeatures():
        geom = feat.geometry()
        if geom.isEmpty() or geom.isNull():
            continue
        
        via_princ = feat[campos['via_princ']]
        via_sec = feat[campos['via_sec']]
        placa = feat[campos['placa']]
        
        # Validar que tenga datos
        if not via_princ or via_princ == NULL:
            continue
        
        centroide = geom.centroid().asPoint()
        
        puntos.append({
            'fid': feat.id(),
            'punto': centroide,
            'via_princ': str(via_princ).strip().upper(),
            'via_sec': str(via_sec).strip().upper() if via_sec and via_sec != NULL else "",
            'placa': str(placa).strip() if placa and placa != NULL else ""
        })
    
    return puntos


def cargar_combinaciones_siti(capa_siti, campos, parent_dialog):
    """Pre-cargar todas las combinaciones existentes para validación rápida"""
    combinaciones = set()
    
    total = capa_siti.featureCount()
    contador = 0
    
    for feat in capa_siti.getFeatures():
        contador += 1
        
        if contador % 1000 == 0:
            parent_dialog.log_mensaje(f"      {contador}/{total}...", paso=4)
            QCoreApplication.processEvents()
        
        via_princ = feat[campos['via_princ']]
        via_sec = feat[campos['via_sec']]
        placa = feat[campos['placa']]
        
        if via_princ and via_princ != NULL:
            via_princ_str = str(via_princ).strip().upper()
            via_sec_str = str(via_sec).strip().upper() if via_sec and via_sec != NULL else ""
            placa_str = str(placa).strip() if placa and placa != NULL else ""
            
            # Agregar combinación
            combinaciones.add((via_princ_str, via_sec_str, placa_str))
    
    return combinaciones


def crear_indices_espaciales(capa_siti, capa_malla, capa_barrios, capa_urb, parent_dialog):
    """Crear índices espaciales para búsquedas rápidas"""
    indices = {
        'index_siti': QgsSpatialIndex(capa_siti.getFeatures()),
        'index_malla': QgsSpatialIndex(capa_malla.getFeatures()),
        'index_barrios': QgsSpatialIndex(capa_barrios.getFeatures()),
        'index_urb': QgsSpatialIndex(capa_urb.getFeatures()),
        'geom_siti': {},
        'geom_malla': {},
        'geom_barrios': {},
        'geom_urb': {}
    }
    
    for feat in capa_siti.getFeatures():
        indices['geom_siti'][feat.id()] = feat.geometry()
    
    for feat in capa_malla.getFeatures():
        indices['geom_malla'][feat.id()] = feat.geometry()
    
    for feat in capa_barrios.getFeatures():
        indices['geom_barrios'][feat.id()] = feat.geometry()
    
    for feat in capa_urb.getFeatures():
        indices['geom_urb'][feat.id()] = feat.geometry()
    
    return indices


def identificar_receptores(capa_siti, campos, index_siti, parent_dialog):
    """Identificar predios SITI que pueden recibir información"""
    receptores = {}
    
    total = capa_siti.featureCount()
    contador = 0
    
    for feat in capa_siti.getFeatures():
        contador += 1
        
        if contador % 1000 == 0:
            parent_dialog.log_mensaje(f"      {contador}/{total}...", paso=4)
            QCoreApplication.processEvents()
        
        via_princ = feat[campos['via_princ']]
        via_sec = feat[campos['via_sec']]
        placa = feat[campos['placa']]
        
        via_princ_str = str(via_princ).strip().upper() if via_princ and via_princ != NULL else ""
        
        # VALIDACIÓN 3.1: principal == 'SN' o 'LTE'
        if via_princ_str in ('SN', 'LTE'):
            receptores[feat.id()] = feat
            continue
        
        # VALIDACIÓN 3.2: tiene principal Y generadora PERO placa == 'SP'
        via_sec_str = str(via_sec).strip().upper() if via_sec and via_sec != NULL else ""
        placa_str = str(placa).strip().upper() if placa and placa != NULL else ""
        
        if via_princ_str and via_sec_str and placa_str == 'SP':
            receptores[feat.id()] = feat
    
    return receptores


def procesar_transferencias(puntos_telef, predios_receptores, combinaciones_existentes,
                            capa_siti, capa_malla, capa_barrios, capa_urb,
                            campos_siti, campos_malla, campos_barrios, campos_urb,
                            metadatos, indices, parent_dialog):
    """Procesar transferencias con validaciones"""
    
    # Prefijos CARDINAL
    PREFIJOS_CARDINAL = ('CL', 'KR', 'DG', 'TV', 'AC', 'AV', 'CR', 'VIA')
    
    # Prefijos MZA CASA
    PREFIJOS_MZA = ('BRR', 'URB', 'CDE', 'CJR', 'URD', 'CONJ', 'SECT')
    
    cambios = []
    resultado = {
        'procesados': 0,
        'cardinal': 0,
        'mza_casa': 0,
        'duplicados': 0,
        'sin_validacion': 0,
        'cambios': []
    }
    
    total = len(puntos_telef)
    
    parent_dialog.log_mensaje(f"   📊 Procesando {total} puntos TELEF...", paso=4)
    
    for idx, punto_data in enumerate(puntos_telef):
        if idx % 100 == 0:
            parent_dialog.log_mensaje(f"      {idx}/{total}...", paso=4)
            QCoreApplication.processEvents()
        
        resultado['procesados'] += 1
        
        # Buscar predio SITI que intersecta
        punto_geom = QgsGeometry.fromPointXY(punto_data['punto'])
        bbox = punto_geom.boundingBox()
        
        ids_cercanos = indices['index_siti'].intersects(bbox)
        
        fid_receptor = None
        for fid in ids_cercanos:
            if fid in predios_receptores:
                if indices['geom_siti'][fid].contains(punto_data['punto']):
                    fid_receptor = fid
                    break
        
        if not fid_receptor:
            resultado['sin_validacion'] += 1
            continue
        
        # Determinar tipo de transferencia
        via_princ_telef = punto_data['via_princ']
        
        # Detectar tipo por prefijo
        prefijo = via_princ_telef.split()[0] if ' ' in via_princ_telef else via_princ_telef[:3]
        
        if prefijo in PREFIJOS_CARDINAL:
            # TRANSFERENCIA CARDINAL
            exito = procesar_cardinal(
                punto_data, fid_receptor, combinaciones_existentes,
                capa_malla, campos_malla, indices, resultado, parent_dialog
            )
            if exito:
                resultado['cardinal'] += 1
                cambios.append({
                    'fid': fid_receptor,
                    'via_princ': punto_data['via_princ'],
                    'via_sec': punto_data['via_sec'],
                    'placa': punto_data['placa']
                })
        
        elif prefijo in PREFIJOS_MZA:
            # TRANSFERENCIA MZA CASA
            exito = procesar_mza_casa(
                punto_data, fid_receptor, combinaciones_existentes,
                capa_barrios, capa_urb, campos_barrios, campos_urb,
                indices, resultado, parent_dialog
            )
            if exito:
                resultado['mza_casa'] += 1
                cambios.append({
                    'fid': fid_receptor,
                    'via_princ': punto_data['via_princ'],
                    'via_sec': punto_data['via_sec'],
                    'placa': punto_data['placa']
                })
    
    resultado['cambios'] = cambios
    return resultado


def procesar_cardinal(punto_data, fid_receptor, combinaciones_existentes,
                     capa_malla, campos_malla, indices, resultado, parent_dialog):
    """Procesar transferencia CARDINAL"""
    
    via_princ = punto_data['via_princ']
    via_sec = punto_data['via_sec']
    placa = punto_data['placa']
    
    # Validar con malla (opcional, podría omitirse para velocidad)
    # Por ahora asumimos que via_princ == principal, via_sec == generadora
    
    # Validar duplicados con placas separadas por /
    if '/' in placa:
        placas_split = placa.split('/')
        
        # Solo transferir la PRIMERA placa que NO esté duplicada
        for p in placas_split:
            p_clean = p.strip()
            if (via_princ, via_sec, p_clean) not in combinaciones_existentes:
                # Usar solo esta placa
                punto_data['placa'] = p_clean
                combinaciones_existentes.add((via_princ, via_sec, p_clean))
                return True
        
        # Todas las placas ya existen
        resultado['duplicados'] += 1
        return False
    else:
        # Placa simple
        if (via_princ, via_sec, placa) not in combinaciones_existentes:
            combinaciones_existentes.add((via_princ, via_sec, placa))
            return True
        else:
            resultado['duplicados'] += 1
            return False


def procesar_mza_casa(punto_data, fid_receptor, combinaciones_existentes,
                     capa_barrios, capa_urb, campos_barrios, campos_urb,
                     indices, resultado, parent_dialog):
    """Procesar transferencia MZA CASA"""
    
    via_princ = punto_data['via_princ']
    via_sec = punto_data['via_sec']
    placa = punto_data['placa']
    
    # Buscar barrio/urbanización por intersección
    punto_geom = QgsGeometry.fromPointXY(punto_data['punto'])
    
    # Buscar en barrios
    ids_barrios = indices['index_barrios'].intersects(punto_geom.boundingBox())
    for fid_b in ids_barrios:
        if indices['geom_barrios'][fid_b].contains(punto_data['punto']):
            feat_barrio = capa_barrios.getFeature(fid_b)
            nombre_barrio = str(feat_barrio[campos_barrios['nombre']]).strip().upper()
            
            # Actualizar via_princ con nombre del barrio
            punto_data['via_princ'] = nombre_barrio
            break
    
    # Buscar en urbanizaciones
    ids_urb = indices['index_urb'].intersects(punto_geom.boundingBox())
    for fid_u in ids_urb:
        if indices['geom_urb'][fid_u].contains(punto_data['punto']):
            feat_urb = capa_urb.getFeature(fid_u)
            nombre_urb = str(feat_urb[campos_urb['nombre']]).strip().upper()
            
            # Actualizar via_princ con nombre de urbanización
            punto_data['via_princ'] = nombre_urb
            break
    
    # Validar duplicados con placas /
    if '/' in placa:
        placas_split = placa.split('/')
        
        for p in placas_split:
            p_clean = p.strip()
            if (punto_data['via_princ'], via_sec, p_clean) not in combinaciones_existentes:
                punto_data['placa'] = p_clean
                combinaciones_existentes.add((punto_data['via_princ'], via_sec, p_clean))
                return True
        
        resultado['duplicados'] += 1
        return False
    else:
        if (punto_data['via_princ'], via_sec, placa) not in combinaciones_existentes:
            combinaciones_existentes.add((punto_data['via_princ'], via_sec, placa))
            return True
        else:
            resultado['duplicados'] += 1
            return False


def aplicar_cambios_masivos(capa_siti, cambios, campos, metadatos, parent_dialog):
    """Aplicar cambios de forma masiva"""
    
    if not cambios:
        parent_dialog.log_mensaje("   ⚠️ No hay cambios para aplicar", paso=4)
        return
    
    idx_via_princ = capa_siti.fields().indexOf(campos['via_princ'])
    idx_via_sec = capa_siti.fields().indexOf(campos['via_sec'])
    idx_placa = capa_siti.fields().indexOf(campos['placa'])
    idx_fecha = capa_siti.fields().indexOf(campos['fecha'])
    idx_marca = capa_siti.fields().indexOf(campos['marca'])
    idx_version = capa_siti.fields().indexOf(campos['version'])
    
    if not capa_siti.isEditable():
        capa_siti.startEditing()
    
    total = len(cambios)
    parent_dialog.log_mensaje(f"   📝 Aplicando {total} cambios...", paso=4)
    
    for idx, cambio in enumerate(cambios):
        if idx % 100 == 0:
            parent_dialog.log_mensaje(f"      {idx}/{total}...", paso=4)
            QCoreApplication.processEvents()
        
        fid = cambio['fid']
        
        capa_siti.changeAttributeValue(fid, idx_via_princ, cambio['via_princ'])
        capa_siti.changeAttributeValue(fid, idx_via_sec, cambio['via_sec'])
        capa_siti.changeAttributeValue(fid, idx_placa, cambio['placa'])
        capa_siti.changeAttributeValue(fid, idx_fecha, metadatos['fecha'])
        capa_siti.changeAttributeValue(fid, idx_marca, metadatos['marca'])
        capa_siti.changeAttributeValue(fid, idx_version, metadatos['version'])
    
    if capa_siti.commitChanges():
        parent_dialog.log_mensaje(f"   ✅ {total} predios actualizados exitosamente", paso=4)
    else:
        errores = capa_siti.commitErrors()
        parent_dialog.log_mensaje(f"   ❌ Error al guardar: {errores}", paso=4)
        capa_siti.rollBack()