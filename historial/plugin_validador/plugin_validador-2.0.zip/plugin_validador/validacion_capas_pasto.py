# -*- coding: utf-8 -*-
"""
Validación de Capas Administrativas - Pasto
Interfaz principal con pestañas COMPARATIVAS y PROCESOS
"""

from qgis.PyQt.QtCore import Qt, QCoreApplication
from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QTabWidget, 
                                 QWidget, QLabel, QPushButton, QComboBox, 
                                 QTextEdit, QGroupBox, QFormLayout, QCheckBox,
                                 QMessageBox, QLineEdit, QScrollArea)
from qgis.core import (QgsProject, QgsVectorLayer, QgsWkbTypes, QgsFeature, QgsField, 
                       QgsSpatialIndex, QgsGeometry, NULL, QgsPointXY)
from qgis.PyQt.QtCore import QVariant
import math


class ValidacionCapasPastoDialog(QDialog):
    """Ventana principal del plugin de validación"""
    
    def __init__(self, iface):
        super(ValidacionCapasPastoDialog, self).__init__()
        self.iface = iface
        
        self.setWindowTitle("Validación de Capas Administrativas - Pasto")
        self.setMinimumSize(900, 700)
        
        # Layout principal
        layout = QVBoxLayout()
        
        # Título
        titulo = QLabel("🗺️ Validación de Capas Administrativas")
        titulo.setStyleSheet("font-size: 18pt; font-weight: bold; color: #2c3e50; padding: 10px;")
        titulo.setAlignment(Qt.AlignCenter)
        layout.addWidget(titulo)
        
        subtitulo = QLabel("Ciudad de Pasto - Sistema de Información Geográfica")
        subtitulo.setStyleSheet("font-size: 10pt; color: #7f8c8d; font-style: italic;")
        subtitulo.setAlignment(Qt.AlignCenter)
        layout.addWidget(subtitulo)
        
        # Pestañas principales
        self.tabs_principales = QTabWidget()
        self.tabs_principales.setStyleSheet("""
            QTabWidget::pane {
                border: 1px solid #bdc3c7;
                background: white;
            }
            QTabBar::tab {
                background: #ecf0f1;
                padding: 10px 20px;
                margin-right: 2px;
                font-weight: bold;
            }
            QTabBar::tab:selected {
                background: #3498db;
                color: white;
            }
        """)
        
        # PESTAÑA 1: COMPARATIVAS
        self.crear_pestana_comparativas()
        
        # PESTAÑA 2: PROCESOS
        self.crear_pestana_procesos()
        
        layout.addWidget(self.tabs_principales)
        
        # Botones de control
        botones_layout = QHBoxLayout()
        
        self.btn_actualizar = QPushButton("🔄 Actualizar Capas")
        self.btn_actualizar.setStyleSheet("padding: 8px; font-size: 10pt; background-color: #3498db; color: white;")
        self.btn_actualizar.clicked.connect(self.actualizar_capas)
        botones_layout.addWidget(self.btn_actualizar)
        
        botones_layout.addStretch()
        
        self.btn_cerrar = QPushButton("❌ Cerrar")
        self.btn_cerrar.setStyleSheet("padding: 8px; font-size: 10pt; background-color: #95a5a6; color: white;")
        self.btn_cerrar.clicked.connect(self.close)
        botones_layout.addWidget(self.btn_cerrar)
        
        layout.addLayout(botones_layout)
        
        self.setLayout(layout)
        
        # Cargar capas disponibles
        self.actualizar_capas()
    
    def crear_pestana_comparativas(self):
        """Crear pestaña de COMPARATIVAS con sub-pestañas"""
        tab_comparativas = QWidget()
        layout = QVBoxLayout()
        
        self.tabs_comparativas = QTabWidget()
        
        self.crear_paso0()
        self.crear_paso1()
        self.crear_paso2()
        
        layout.addWidget(self.tabs_comparativas)
        tab_comparativas.setLayout(layout)
        
        self.tabs_principales.addTab(tab_comparativas, "📊 COMPARATIVAS")
    
    def crear_paso0(self):
        """PASO 0: Validador de Malla"""
        widget_paso0 = QWidget()
        main_layout = QVBoxLayout()
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        
        scroll_widget = QWidget()
        layout = QVBoxLayout(scroll_widget)
        
        desc = QLabel("🔍 PASO 0: Validador de Malla Vial")
        desc.setStyleSheet("font-size: 12pt; font-weight: bold; color: #e67e22; padding: 5px;")
        layout.addWidget(desc)
        
        objetivo = QLabel("Objetivo: Identificar elementos faltantes en SITI comparando con TELEF y validar posibles adiciones por paralelismo")
        objetivo.setStyleSheet("font-style: italic; color: #7f8c8d; padding: 5px;")
        objetivo.setWordWrap(True)
        layout.addWidget(objetivo)
        
        lbl_etapa1 = QLabel("📋 ETAPA 1: Comparación de Datos Faltantes")
        lbl_etapa1.setStyleSheet("font-size: 11pt; font-weight: bold; color: #2c3e50; padding: 8px; background-color: #ecf0f1; border-radius: 3px;")
        layout.addWidget(lbl_etapa1)
        
        nota_etapa1 = QLabel("💡 Genera capa 'Elementos_Faltantes' con vectores presentes en TELEF pero ausentes en SITI")
        nota_etapa1.setStyleSheet("font-size: 9pt; color: #7f8c8d; padding: 5px; font-style: italic;")
        nota_etapa1.setWordWrap(True)
        layout.addWidget(nota_etapa1)
        
        form_etapa1 = QFormLayout()
        
        self.combo_malla_telef_p0 = QComboBox()
        form_etapa1.addRow("Malla TELEF:", self.combo_malla_telef_p0)
        
        self.combo_malla_siti_p0 = QComboBox()
        form_etapa1.addRow("Malla SITI:", self.combo_malla_siti_p0)
        
        self.combo_campo_concat_p0 = QComboBox()
        form_etapa1.addRow("Campo Comparación:", self.combo_campo_concat_p0)
        
        layout.addLayout(form_etapa1)
        
        self.btn_ejecutar_etapa1 = QPushButton("▶️ EJECUTAR ETAPA 1")
        self.btn_ejecutar_etapa1.setStyleSheet("padding: 8px; font-size: 10pt; font-weight: bold; background-color: #e67e22; color: white; border-radius: 3px;")
        self.btn_ejecutar_etapa1.clicked.connect(self.ejecutar_paso0_etapa1)
        layout.addWidget(self.btn_ejecutar_etapa1)
        
        layout.addSpacing(10)
        
        lbl_etapa2 = QLabel("🔍 ETAPA 2: Validación de Paralelas con Generadoras")
        lbl_etapa2.setStyleSheet("font-size: 11pt; font-weight: bold; color: #2c3e50; padding: 8px; background-color: #ecf0f1; border-radius: 3px;")
        layout.addWidget(lbl_etapa2)
        
        nota_etapa2 = QLabel("💡 Genera nube de puntos donde se puede agregar información validando paralelismo y coincidencia de principal")
        nota_etapa2.setStyleSheet("font-size: 9pt; color: #7f8c8d; padding: 5px; font-style: italic;")
        nota_etapa2.setWordWrap(True)
        layout.addWidget(nota_etapa2)
        
        form_etapa2 = QFormLayout()
        
        self.txt_distancia_p0 = QLineEdit("0.00015")
        self.txt_distancia_p0.setPlaceholderText("Aprox 15 metros en EPSG:4326")
        form_etapa2.addRow("Distancia búsqueda:", self.txt_distancia_p0)
        
        self.txt_tolerancia_p0 = QLineEdit("15.0")
        self.txt_tolerancia_p0.setPlaceholderText("Grados de tolerancia")
        form_etapa2.addRow("Tolerancia ángulo:", self.txt_tolerancia_p0)
        
        layout.addLayout(form_etapa2)
        
        self.btn_ejecutar_etapa2 = QPushButton("▶️ EJECUTAR ETAPA 2")
        self.btn_ejecutar_etapa2.setStyleSheet("padding: 8px; font-size: 10pt; font-weight: bold; background-color: #16a085; color: white; border-radius: 3px;")
        self.btn_ejecutar_etapa2.clicked.connect(self.ejecutar_paso0_etapa2)
        layout.addWidget(self.btn_ejecutar_etapa2)
        
        lbl_log = QLabel("📋 Log:")
        layout.addWidget(lbl_log)
        
        self.log_paso0 = QTextEdit()
        self.log_paso0.setReadOnly(True)
        self.log_paso0.setMaximumHeight(150)
        layout.addWidget(self.log_paso0)
        
        scroll.setWidget(scroll_widget)
        main_layout.addWidget(scroll)
        widget_paso0.setLayout(main_layout)
        
        self.combo_malla_telef_p0.currentIndexChanged.connect(self.actualizar_campos_malla_telef)
        
        self.tabs_comparativas.addTab(widget_paso0, "PASO 0: Validador Malla")
    
    def crear_paso1(self):
        """PASO 1: Validación SITI vs TELEF"""
        widget_paso1 = QWidget()
        layout = QVBoxLayout()
        
        desc = QLabel("🔍 PASO 1: Validación SITI vs TELEF")
        desc.setStyleSheet("font-size: 12pt; font-weight: bold; color: #2980b9; padding: 5px;")
        layout.addWidget(desc)
        
        objetivo = QLabel("Objetivo: Comparar capas SITI (actuales) contra TELEF (referencia)")
        objetivo.setStyleSheet("font-style: italic; color: #7f8c8d; padding: 5px;")
        layout.addWidget(objetivo)
        
        group_siti = QGroupBox("🗺️ Capas SITI (Base Actual)")
        form_siti = QFormLayout()
        
        self.combo_barrios_siti_p1 = QComboBox()
        form_siti.addRow("Barrios SITI:", self.combo_barrios_siti_p1)
        
        self.combo_urb_siti_p1 = QComboBox()
        form_siti.addRow("Urbanizaciones SITI:", self.combo_urb_siti_p1)
        
        self.combo_campo_comparar = QComboBox()
        self.combo_campo_comparar.addItem("nombre")
        form_siti.addRow("Campo a comparar:", self.combo_campo_comparar)
        
        group_siti.setLayout(form_siti)
        layout.addWidget(group_siti)
        
        group_telef = QGroupBox("📡 Capas TELEF (Base Referencia)")
        form_telef = QFormLayout()
        
        self.combo_barrios_telef_p1 = QComboBox()
        form_telef.addRow("Barrios TELEF:", self.combo_barrios_telef_p1)
        
        self.combo_urb_telef_p1 = QComboBox()
        form_telef.addRow("Urbanizaciones TELEF:", self.combo_urb_telef_p1)
        
        group_telef.setLayout(form_telef)
        layout.addWidget(group_telef)
        
        self.btn_ejecutar_p1 = QPushButton("▶️ EJECUTAR PASO 1")
        self.btn_ejecutar_p1.setStyleSheet("padding: 10px; font-size: 11pt; font-weight: bold; background-color: #27ae60; color: white;")
        self.btn_ejecutar_p1.clicked.connect(self.ejecutar_paso1)
        layout.addWidget(self.btn_ejecutar_p1)
        
        self.log_paso1 = QTextEdit()
        self.log_paso1.setReadOnly(True)
        self.log_paso1.setMaximumHeight(150)
        layout.addWidget(QLabel("📋 Log:"))
        layout.addWidget(self.log_paso1)
        
        layout.addStretch()
        widget_paso1.setLayout(layout)
        
        self.tabs_comparativas.addTab(widget_paso1, "PASO 1: SITI vs TELEF")
    
    def crear_paso2(self):
        """PASO 2: Inconsistencias en Predios"""
        widget_paso2 = QWidget()
        layout = QVBoxLayout()
        
        desc = QLabel("🔍 PASO 2: Detección de Inconsistencias en Predios")
        desc.setStyleSheet("font-size: 12pt; font-weight: bold; color: #2980b9; padding: 5px;")
        layout.addWidget(desc)
        
        objetivo = QLabel("Objetivo: Comparar via_princ de predios con barrios/urbanizaciones")
        objetivo.setStyleSheet("font-style: italic; color: #7f8c8d; padding: 5px;")
        layout.addWidget(objetivo)
        
        nota = QLabel("ℹ️ Este proceso filtra predios con tipo_direccion: INDEFINIDA, MZ CASA - COMPLETA, MZ CASA - INCOMPLETA")
        nota.setStyleSheet("background-color: #fff3cd; color: #856404; padding: 8px; border-radius: 3px; font-size: 9pt;")
        nota.setWordWrap(True)
        layout.addWidget(nota)
        
        group_config = QGroupBox("⚙️ Capas de Entrada")
        form_config = QFormLayout()
        
        self.combo_predios_p2 = QComboBox()
        form_config.addRow("Capa de Predios:", self.combo_predios_p2)
        
        self.combo_urb_siti_p2 = QComboBox()
        form_config.addRow("Capa de Urbanizaciones:", self.combo_urb_siti_p2)
        
        self.combo_barrios_siti_p2 = QComboBox()
        form_config.addRow("Capa de Barrios:", self.combo_barrios_siti_p2)
        
        group_config.setLayout(form_config)
        layout.addWidget(group_config)
        
        self.btn_ejecutar_p2 = QPushButton("▶️ EJECUTAR PASO 2")
        self.btn_ejecutar_p2.setStyleSheet("padding: 10px; font-size: 11pt; font-weight: bold; background-color: #e74c3c; color: white;")
        self.btn_ejecutar_p2.clicked.connect(self.ejecutar_paso2)
        layout.addWidget(self.btn_ejecutar_p2)
        
        self.log_paso2 = QTextEdit()
        self.log_paso2.setReadOnly(True)
        self.log_paso2.setMaximumHeight(150)
        layout.addWidget(QLabel("📋 Log de ejecución:"))
        layout.addWidget(self.log_paso2)
        
        layout.addStretch()
        widget_paso2.setLayout(layout)
        
        self.tabs_comparativas.addTab(widget_paso2, "PASO 2: Inconsistencias Predios")
    
    def crear_pestana_procesos(self):
        """Crear pestaña de PROCESOS"""
        tab_procesos = QWidget()
        layout = QVBoxLayout()
        
        self.tabs_procesos = QTabWidget()
        self.crear_proceso_mza_casa()
        self.crear_proceso_transferencia()  # NUEVA PESTAÑA
        
        layout.addWidget(self.tabs_procesos)
        tab_procesos.setLayout(layout)
        
        self.tabs_principales.addTab(tab_procesos, "⚙️ PROCESOS")
    
    def crear_proceso_mza_casa(self):
        """Proceso MZA CASA: Edición masiva por grupos"""
        widget_proceso = QWidget()
        main_layout = QVBoxLayout()
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        
        scroll_widget = QWidget()
        layout = QVBoxLayout(scroll_widget)
        
        desc = QLabel("🏠 Proceso MZA CASA - Edición por Grupos")
        desc.setStyleSheet("font-size: 12pt; font-weight: bold; color: #8e44ad; padding: 5px;")
        layout.addWidget(desc)
        
        objetivo = QLabel("Objetivo: Editar de forma masiva predios agrupados por 'via_princ' comparando con barrios y urbanizaciones.")
        objetivo.setStyleSheet("font-style: italic; color: #7f8c8d; padding: 5px;")
        objetivo.setWordWrap(True)
        layout.addWidget(objetivo)
        
        lbl_siti = QLabel("🗺️ Capas SITI (Para Modificar)")
        lbl_siti.setStyleSheet("font-size: 11pt; font-weight: bold; color: #2c3e50; padding: 8px; background-color: #ecf0f1; border-radius: 3px;")
        layout.addWidget(lbl_siti)
        
        form_siti = QFormLayout()
        
        self.combo_barrios_siti_p3 = QComboBox()
        form_siti.addRow("Barrios SITI:", self.combo_barrios_siti_p3)
        
        self.combo_campo_barrios_siti_p3 = QComboBox()
        form_siti.addRow("    Campo:", self.combo_campo_barrios_siti_p3)
        
        self.combo_urb_siti_p3 = QComboBox()
        form_siti.addRow("Urbanizaciones SITI:", self.combo_urb_siti_p3)
        
        self.combo_campo_urb_siti_p3 = QComboBox()
        form_siti.addRow("    Campo:", self.combo_campo_urb_siti_p3)
        
        self.combo_predios_siti_p3 = QComboBox()
        form_siti.addRow("Predios SITI:", self.combo_predios_siti_p3)
        
        self.combo_campo_predios_p3 = QComboBox()
        form_siti.addRow("    Campo comparar:", self.combo_campo_predios_p3)
        
        self.combo_fecha_p3 = QComboBox()
        form_siti.addRow("    Campo Fecha:", self.combo_fecha_p3)
        
        self.combo_version_p3 = QComboBox()
        form_siti.addRow("    Campo Versión:", self.combo_version_p3)
        
        self.combo_marca_p3 = QComboBox()
        form_siti.addRow("    Campo Marca:", self.combo_marca_p3)
        
        layout.addLayout(form_siti)
        layout.addSpacing(10)
        
        lbl_telef = QLabel("📡 Capas TELEF (Solo Consulta)")
        lbl_telef.setStyleSheet("font-size: 11pt; font-weight: bold; color: #2c3e50; padding: 8px; background-color: #ecf0f1; border-radius: 3px;")
        layout.addWidget(lbl_telef)
        
        form_telef = QFormLayout()
        
        self.combo_barrios_telef_p3 = QComboBox()
        form_telef.addRow("Barrios TELEF:", self.combo_barrios_telef_p3)
        
        self.combo_campo_barrios_telef_p3 = QComboBox()
        form_telef.addRow("    Campo:", self.combo_campo_barrios_telef_p3)
        
        self.combo_urb_telef_p3 = QComboBox()
        form_telef.addRow("Urbanizaciones TELEF:", self.combo_urb_telef_p3)
        
        self.combo_campo_urb_telef_p3 = QComboBox()
        form_telef.addRow("    Campo:", self.combo_campo_urb_telef_p3)
        
        layout.addLayout(form_telef)
        layout.addSpacing(10)
        
        lbl_poligonizada = QLabel("🆕 Creación de Urbanizaciones desde Polígonos")
        lbl_poligonizada.setStyleSheet("font-size: 11pt; font-weight: bold; color: #16a085; padding: 8px; background-color: #d5f4e6; border-radius: 3px;")
        layout.addWidget(lbl_poligonizada)
        
        nota_poligonizada = QLabel("💡 Permite crear urbanizaciones automáticamente cuando el campo está vacío. Une polígonos de esta capa donde se encuentren los predios del grupo.")
        nota_poligonizada.setStyleSheet("font-size: 9pt; color: #16a085; padding: 5px; font-style: italic;")
        nota_poligonizada.setWordWrap(True)
        layout.addWidget(nota_poligonizada)
        
        form_poligonizada = QFormLayout()
        
        self.combo_poligonizada_p3 = QComboBox()
        form_poligonizada.addRow("Capa Poligonizada:", self.combo_poligonizada_p3)
        
        layout.addLayout(form_poligonizada)
        layout.addSpacing(10)
        
        lbl_opcional = QLabel("➕ Capas Opcionales (Consulta)")
        lbl_opcional.setStyleSheet("font-size: 11pt; font-weight: bold; color: #2c3e50; padding: 8px; background-color: #ecf0f1; border-radius: 3px;")
        layout.addWidget(lbl_opcional)
        
        form_opcional = QFormLayout()
        
        opcional1_layout = QHBoxLayout()
        self.check_opcional1_p3 = QCheckBox("Usar Opcional 1")
        opcional1_layout.addWidget(self.check_opcional1_p3)
        self.combo_opcional1_p3 = QComboBox()
        self.combo_opcional1_p3.setEnabled(False)
        opcional1_layout.addWidget(self.combo_opcional1_p3)
        form_opcional.addRow(opcional1_layout)
        
        self.combo_campo_opcional1_p3 = QComboBox()
        self.combo_campo_opcional1_p3.setEnabled(False)
        form_opcional.addRow("    Campo:", self.combo_campo_opcional1_p3)
        
        opcional2_layout = QHBoxLayout()
        self.check_opcional2_p3 = QCheckBox("Usar Opcional 2")
        opcional2_layout.addWidget(self.check_opcional2_p3)
        self.combo_opcional2_p3 = QComboBox()
        self.combo_opcional2_p3.setEnabled(False)
        opcional2_layout.addWidget(self.combo_opcional2_p3)
        form_opcional.addRow(opcional2_layout)
        
        self.combo_campo_opcional2_p3 = QComboBox()
        self.combo_campo_opcional2_p3.setEnabled(False)
        form_opcional.addRow("    Campo:", self.combo_campo_opcional2_p3)
        
        layout.addLayout(form_opcional)
        layout.addSpacing(15)
        
        self.btn_iniciar_edicion = QPushButton("▶️ INICIAR EDICIÓN POR GRUPOS")
        self.btn_iniciar_edicion.setStyleSheet("padding: 12px; font-size: 12pt; font-weight: bold; background-color: #8e44ad; color: white; border-radius: 5px;")
        self.btn_iniciar_edicion.clicked.connect(self.iniciar_edicion_grupos)
        layout.addWidget(self.btn_iniciar_edicion)
        
        lbl_log = QLabel("📋 Log:")
        layout.addWidget(lbl_log)
        
        self.log_proceso = QTextEdit()
        self.log_proceso.setReadOnly(True)
        self.log_proceso.setMaximumHeight(150)
        layout.addWidget(self.log_proceso)
        
        scroll.setWidget(scroll_widget)
        main_layout.addWidget(scroll)
        widget_proceso.setLayout(main_layout)
        
        self.tabs_procesos.addTab(widget_proceso, "Proceso MZA CASA")
        
        self.combo_barrios_siti_p3.currentIndexChanged.connect(lambda: self.actualizar_campos_capa(self.combo_barrios_siti_p3, self.combo_campo_barrios_siti_p3))
        self.combo_urb_siti_p3.currentIndexChanged.connect(lambda: self.actualizar_campos_capa(self.combo_urb_siti_p3, self.combo_campo_urb_siti_p3))
        self.combo_predios_siti_p3.currentIndexChanged.connect(self.actualizar_campos_predios)
        self.combo_barrios_telef_p3.currentIndexChanged.connect(lambda: self.actualizar_campos_capa(self.combo_barrios_telef_p3, self.combo_campo_barrios_telef_p3))
        self.combo_urb_telef_p3.currentIndexChanged.connect(lambda: self.actualizar_campos_capa(self.combo_urb_telef_p3, self.combo_campo_urb_telef_p3))
        
        self.check_opcional1_p3.stateChanged.connect(self.toggle_opcional1)
        self.combo_opcional1_p3.currentIndexChanged.connect(lambda: self.actualizar_campos_capa(self.combo_opcional1_p3, self.combo_campo_opcional1_p3))
        
        self.check_opcional2_p3.stateChanged.connect(self.toggle_opcional2)
        self.combo_opcional2_p3.currentIndexChanged.connect(lambda: self.actualizar_campos_capa(self.combo_opcional2_p3, self.combo_campo_opcional2_p3))
    
    def crear_proceso_transferencia(self):
        """Proceso de Transferencia TELEF → SITI"""
        widget_proceso = QWidget()
        main_layout = QVBoxLayout()
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        
        scroll_widget = QWidget()
        layout = QVBoxLayout(scroll_widget)
        
        desc = QLabel("🔄 Transferencia de Información TELEF → SITI")
        desc.setStyleSheet("font-size: 12pt; font-weight: bold; color: #c0392b; padding: 5px;")
        layout.addWidget(desc)
        
        objetivo = QLabel("⚠️ PROCESO CRÍTICO: Transfiere información de predios TELEF a SITI con validaciones estrictas")
        objetivo.setStyleSheet("font-style: italic; color: #e74c3c; padding: 5px; font-weight: bold;")
        objetivo.setWordWrap(True)
        layout.addWidget(objetivo)
        
        # PREDIOS TELEF
        lbl_telef = QLabel("📡 Predios TELEF (Solo Consulta)")
        lbl_telef.setStyleSheet("font-size: 11pt; font-weight: bold; color: #2c3e50; padding: 8px; background-color: #ecf0f1; border-radius: 3px;")
        layout.addWidget(lbl_telef)
        
        form_telef = QFormLayout()
        
        self.combo_predios_telef_trans = QComboBox()
        form_telef.addRow("Capa Predios TELEF:", self.combo_predios_telef_trans)
        
        self.combo_via_princ_telef_trans = QComboBox()
        form_telef.addRow("    Via Principal:", self.combo_via_princ_telef_trans)
        
        self.combo_via_sec_telef_trans = QComboBox()
        form_telef.addRow("    Via Secundaria:", self.combo_via_sec_telef_trans)
        
        self.combo_placa_telef_trans = QComboBox()
        form_telef.addRow("    Placa:", self.combo_placa_telef_trans)
        
        layout.addLayout(form_telef)
        layout.addSpacing(10)
        
        # PREDIOS SITI
        lbl_siti = QLabel("🗺️ Predios SITI (Para Modificar)")
        lbl_siti.setStyleSheet("font-size: 11pt; font-weight: bold; color: #2c3e50; padding: 8px; background-color: #ecf0f1; border-radius: 3px;")
        layout.addWidget(lbl_siti)
        
        form_siti = QFormLayout()
        
        self.combo_predios_siti_trans = QComboBox()
        form_siti.addRow("Capa Predios SITI:", self.combo_predios_siti_trans)
        
        self.combo_via_princ_siti_trans = QComboBox()
        form_siti.addRow("    Via Principal:", self.combo_via_princ_siti_trans)
        
        self.combo_via_sec_siti_trans = QComboBox()
        form_siti.addRow("    Via Secundaria:", self.combo_via_sec_siti_trans)
        
        self.combo_placa_siti_trans = QComboBox()
        form_siti.addRow("    Placa:", self.combo_placa_siti_trans)
        
        self.combo_fecha_siti_trans = QComboBox()
        form_siti.addRow("    Fecha:", self.combo_fecha_siti_trans)
        
        self.combo_marca_siti_trans = QComboBox()
        form_siti.addRow("    Marca:", self.combo_marca_siti_trans)
        
        self.combo_version_siti_trans = QComboBox()
        form_siti.addRow("    Versión:", self.combo_version_siti_trans)
        
        layout.addLayout(form_siti)
        layout.addSpacing(10)
        
        # MALLA SITI
        lbl_malla = QLabel("🛣️ Malla Vial SITI")
        lbl_malla.setStyleSheet("font-size: 11pt; font-weight: bold; color: #2c3e50; padding: 8px; background-color: #ecf0f1; border-radius: 3px;")
        layout.addWidget(lbl_malla)
        
        form_malla = QFormLayout()
        
        self.combo_malla_siti_trans = QComboBox()
        form_malla.addRow("Capa Malla:", self.combo_malla_siti_trans)
        
        self.combo_principal_malla_trans = QComboBox()
        form_malla.addRow("    Campo Principal:", self.combo_principal_malla_trans)
        
        self.combo_generadora_malla_trans = QComboBox()
        form_malla.addRow("    Campo Generadora:", self.combo_generadora_malla_trans)
        
        layout.addLayout(form_malla)
        layout.addSpacing(10)
        
        # BARRIOS Y URBANIZACIONES
        lbl_barrios = QLabel("🏘️ Barrios y Urbanizaciones SITI")
        lbl_barrios.setStyleSheet("font-size: 11pt; font-weight: bold; color: #2c3e50; padding: 8px; background-color: #ecf0f1; border-radius: 3px;")
        layout.addWidget(lbl_barrios)
        
        form_barrios = QFormLayout()
        
        self.combo_barrios_trans = QComboBox()
        form_barrios.addRow("Capa Barrios:", self.combo_barrios_trans)
        
        self.combo_campo_barrios_trans = QComboBox()
        form_barrios.addRow("    Campo Nombre:", self.combo_campo_barrios_trans)
        
        self.combo_urb_trans = QComboBox()
        form_barrios.addRow("Capa Urbanizaciones:", self.combo_urb_trans)
        
        self.combo_campo_urb_trans = QComboBox()
        form_barrios.addRow("    Campo Nombre:", self.combo_campo_urb_trans)
        
        layout.addLayout(form_barrios)
        layout.addSpacing(10)
        
        # METADATOS
        lbl_metadatos = QLabel("📝 Metadatos de Actualización")
        lbl_metadatos.setStyleSheet("font-size: 11pt; font-weight: bold; color: #2c3e50; padding: 8px; background-color: #d5f4e6; border-radius: 3px;")
        layout.addWidget(lbl_metadatos)
        
        form_metadatos = QFormLayout()
        
        self.txt_fecha_trans = QLineEdit()
        self.txt_fecha_trans.setPlaceholderText("Ej: 2026-05-23")
        form_metadatos.addRow("Fecha:", self.txt_fecha_trans)
        
        self.txt_marca_trans = QLineEdit()
        self.txt_marca_trans.setPlaceholderText("Ej: 3")
        form_metadatos.addRow("Marca:", self.txt_marca_trans)
        
        self.txt_version_trans = QLineEdit()
        self.txt_version_trans.setPlaceholderText("Ej: V1-26")
        form_metadatos.addRow("Versión:", self.txt_version_trans)
        
        layout.addLayout(form_metadatos)
        layout.addSpacing(15)
        
        # Botón EJECUTAR
        self.btn_ejecutar_transferencia = QPushButton("▶️ EJECUTAR TRANSFERENCIA")
        self.btn_ejecutar_transferencia.setStyleSheet("padding: 12px; font-size: 12pt; font-weight: bold; background-color: #c0392b; color: white; border-radius: 5px;")
        self.btn_ejecutar_transferencia.clicked.connect(self.ejecutar_transferencia)
        layout.addWidget(self.btn_ejecutar_transferencia)
        
        # Log
        lbl_log = QLabel("📋 Log:")
        layout.addWidget(lbl_log)
        
        self.log_transferencia = QTextEdit()
        self.log_transferencia.setReadOnly(True)
        self.log_transferencia.setMaximumHeight(200)
        layout.addWidget(self.log_transferencia)
        
        scroll.setWidget(scroll_widget)
        main_layout.addWidget(scroll)
        widget_proceso.setLayout(main_layout)
        
        self.tabs_procesos.addTab(widget_proceso, "Transferencia TELEF→SITI")
        
        # CONECTAR EVENTOS
        self.combo_predios_telef_trans.currentIndexChanged.connect(self.actualizar_campos_predios_telef_trans)
        self.combo_predios_siti_trans.currentIndexChanged.connect(self.actualizar_campos_predios_siti_trans)
        self.combo_malla_siti_trans.currentIndexChanged.connect(self.actualizar_campos_malla_trans)
        self.combo_barrios_trans.currentIndexChanged.connect(lambda: self.actualizar_campos_capa(self.combo_barrios_trans, self.combo_campo_barrios_trans))
        self.combo_urb_trans.currentIndexChanged.connect(lambda: self.actualizar_campos_capa(self.combo_urb_trans, self.combo_campo_urb_trans))
    
    def buscar_capa_por_nombre(self, nombre_parcial):
        """Buscar capa que contenga el texto en su nombre"""
        capas = QgsProject.instance().mapLayers().values()
        nombre_lower = nombre_parcial.lower()
        
        for capa in capas:
            if isinstance(capa, QgsVectorLayer):
                if nombre_lower in capa.name().lower():
                    return capa
        return None
    
    def autoseleccionar_capas_paso0(self):
        """AUTO-SELECCIÓN para PASO 0"""
        for i in range(self.combo_malla_telef_p0.count()):
            capa = self.combo_malla_telef_p0.itemData(i)
            if capa and "mavvial" in capa.name().lower() and "telef" in capa.name().lower():
                self.combo_malla_telef_p0.setCurrentIndex(i)
                break
        
        for i in range(self.combo_malla_siti_p0.count()):
            capa = self.combo_malla_siti_p0.itemData(i)
            if capa and "mavvial" in capa.name().lower() and "siti" in capa.name().lower():
                self.combo_malla_siti_p0.setCurrentIndex(i)
                break
    
    def autoseleccionar_capas_paso2(self):
        """AUTO-SELECCIÓN para PASO 2"""
        capa_predios = self.buscar_capa_por_nombre("predios")
        if capa_predios and "siti" in capa_predios.name().lower():
            idx = self.combo_predios_p2.findData(capa_predios)
            if idx >= 0:
                self.combo_predios_p2.setCurrentIndex(idx)
                self.log_mensaje("✅ Auto-seleccionado: " + capa_predios.name(), paso=2)
        
        capa_urb = self.buscar_capa_por_nombre("urbanizaciones")
        if capa_urb and "siti" in capa_urb.name().lower():
            idx = self.combo_urb_siti_p2.findData(capa_urb)
            if idx >= 0:
                self.combo_urb_siti_p2.setCurrentIndex(idx)
                self.log_mensaje("✅ Auto-seleccionado: " + capa_urb.name(), paso=2)
        
        capa_barrios = self.buscar_capa_por_nombre("barrios")
        if capa_barrios and "siti" in capa_barrios.name().lower():
            idx = self.combo_barrios_siti_p2.findData(capa_barrios)
            if idx >= 0:
                self.combo_barrios_siti_p2.setCurrentIndex(idx)
                self.log_mensaje("✅ Auto-seleccionado: " + capa_barrios.name(), paso=2)
    
    def autoseleccionar_capas_proceso3(self):
        """AUTO-SELECCIÓN para Proceso MZA CASA"""
        for i in range(self.combo_barrios_siti_p3.count()):
            capa = self.combo_barrios_siti_p3.itemData(i)
            if capa and "barrios" in capa.name().lower() and "siti" in capa.name().lower():
                self.combo_barrios_siti_p3.setCurrentIndex(i)
                break
        
        for i in range(self.combo_urb_siti_p3.count()):
            capa = self.combo_urb_siti_p3.itemData(i)
            if capa and "urbanizaciones" in capa.name().lower() and "siti" in capa.name().lower():
                self.combo_urb_siti_p3.setCurrentIndex(i)
                break
        
        for i in range(self.combo_predios_siti_p3.count()):
            capa = self.combo_predios_siti_p3.itemData(i)
            if capa and "predios" in capa.name().lower() and "siti" in capa.name().lower():
                self.combo_predios_siti_p3.setCurrentIndex(i)
                break
        
        for i in range(self.combo_barrios_telef_p3.count()):
            capa = self.combo_barrios_telef_p3.itemData(i)
            if capa and "barrios" in capa.name().lower() and "telef" in capa.name().lower():
                self.combo_barrios_telef_p3.setCurrentIndex(i)
                break
        
        for i in range(self.combo_urb_telef_p3.count()):
            capa = self.combo_urb_telef_p3.itemData(i)
            if capa and "urbanizaciones" in capa.name().lower() and "telef" in capa.name().lower():
                self.combo_urb_telef_p3.setCurrentIndex(i)
                break
        
        for i in range(self.combo_poligonizada_p3.count()):
            capa = self.combo_poligonizada_p3.itemData(i)
            if capa and "poligonizada" in capa.name().lower():
                self.combo_poligonizada_p3.setCurrentIndex(i)
                break
    
    def autoseleccionar_capas_transferencia(self):
        """AUTO-SELECCIÓN para Transferencia"""
        for i in range(self.combo_predios_telef_trans.count()):
            capa = self.combo_predios_telef_trans.itemData(i)
            if capa and "predios" in capa.name().lower() and "telef" in capa.name().lower():
                self.combo_predios_telef_trans.setCurrentIndex(i)
                break
        
        for i in range(self.combo_predios_siti_trans.count()):
            capa = self.combo_predios_siti_trans.itemData(i)
            if capa and "predios" in capa.name().lower() and "siti" in capa.name().lower():
                self.combo_predios_siti_trans.setCurrentIndex(i)
                break
        
        for i in range(self.combo_malla_siti_trans.count()):
            capa = self.combo_malla_siti_trans.itemData(i)
            if capa and "mavvial" in capa.name().lower() and "siti" in capa.name().lower():
                self.combo_malla_siti_trans.setCurrentIndex(i)
                break
        
        for i in range(self.combo_barrios_trans.count()):
            capa = self.combo_barrios_trans.itemData(i)
            if capa and "barrios" in capa.name().lower() and "siti" in capa.name().lower():
                self.combo_barrios_trans.setCurrentIndex(i)
                break
        
        for i in range(self.combo_urb_trans.count()):
            capa = self.combo_urb_trans.itemData(i)
            if capa and "urbanizaciones" in capa.name().lower() and "siti" in capa.name().lower():
                self.combo_urb_trans.setCurrentIndex(i)
                break
    
    def actualizar_capas(self):
        """Actualizar todos los combos con las capas disponibles"""
        capas = QgsProject.instance().mapLayers().values()
        capas_vectoriales = [capa for capa in capas if isinstance(capa, QgsVectorLayer)]
        
        combos = [
            self.combo_malla_telef_p0, self.combo_malla_siti_p0,
            self.combo_barrios_siti_p1, self.combo_urb_siti_p1,
            self.combo_barrios_telef_p1, self.combo_urb_telef_p1,
            self.combo_predios_p2, self.combo_barrios_siti_p2, self.combo_urb_siti_p2,
            self.combo_barrios_siti_p3, self.combo_urb_siti_p3, self.combo_predios_siti_p3,
            self.combo_barrios_telef_p3, self.combo_urb_telef_p3,
            self.combo_poligonizada_p3,
            self.combo_opcional1_p3, self.combo_opcional2_p3,
            self.combo_predios_telef_trans, self.combo_predios_siti_trans,
            self.combo_malla_siti_trans, self.combo_barrios_trans, self.combo_urb_trans
        ]
        
        for combo in combos:
            combo.clear()
            combo.addItem("-- Seleccionar capa --", None)
            for capa in capas_vectoriales:
                combo.addItem(capa.name(), capa)
        
        self.autoseleccionar_capas_paso0()
        self.autoseleccionar_capas_paso2()
        self.autoseleccionar_capas_proceso3()
        self.autoseleccionar_capas_transferencia()
    
    def actualizar_campos_malla_telef(self):
        """Actualizar combo de campos cuando se selecciona malla TELEF"""
        self.combo_campo_concat_p0.clear()
        capa = self.combo_malla_telef_p0.currentData()
        
        if capa:
            campos = [field.name() for field in capa.fields()]
            self.combo_campo_concat_p0.addItems(campos)
            
            if 'concat' in campos:
                idx = self.combo_campo_concat_p0.findText('concat')
                if idx >= 0:
                    self.combo_campo_concat_p0.setCurrentIndex(idx)
    
    def actualizar_campos_capa(self, combo_capa, combo_campo):
        """Actualizar combo de campos"""
        combo_campo.clear()
        capa = combo_capa.currentData()
        
        if capa:
            campos = [field.name() for field in capa.fields()]
            combo_campo.addItems(campos)
    
    def actualizar_campos_predios(self):
        """Actualizar combos de campos de predios"""
        capa = self.combo_predios_siti_p3.currentData()
        
        if capa:
            campos = [field.name() for field in capa.fields()]
            
            self.combo_campo_predios_p3.clear()
            self.combo_campo_predios_p3.addItems(campos)
            
            self.combo_fecha_p3.clear()
            self.combo_fecha_p3.addItems(campos)
            
            self.combo_version_p3.clear()
            self.combo_version_p3.addItems(campos)
            
            self.combo_marca_p3.clear()
            self.combo_marca_p3.addItems(campos)
    
    def actualizar_campos_predios_telef_trans(self):
        """Actualizar campos de predios TELEF"""
        capa = self.combo_predios_telef_trans.currentData()
        
        if capa:
            campos = [field.name() for field in capa.fields()]
            
            self.combo_via_princ_telef_trans.clear()
            self.combo_via_princ_telef_trans.addItems(campos)
            
            self.combo_via_sec_telef_trans.clear()
            self.combo_via_sec_telef_trans.addItems(campos)
            
            self.combo_placa_telef_trans.clear()
            self.combo_placa_telef_trans.addItems(campos)
    
    def actualizar_campos_predios_siti_trans(self):
        """Actualizar campos de predios SITI"""
        capa = self.combo_predios_siti_trans.currentData()
        
        if capa:
            campos = [field.name() for field in capa.fields()]
            
            self.combo_via_princ_siti_trans.clear()
            self.combo_via_princ_siti_trans.addItems(campos)
            
            self.combo_via_sec_siti_trans.clear()
            self.combo_via_sec_siti_trans.addItems(campos)
            
            self.combo_placa_siti_trans.clear()
            self.combo_placa_siti_trans.addItems(campos)
            
            self.combo_fecha_siti_trans.clear()
            self.combo_fecha_siti_trans.addItems(campos)
            
            self.combo_marca_siti_trans.clear()
            self.combo_marca_siti_trans.addItems(campos)
            
            self.combo_version_siti_trans.clear()
            self.combo_version_siti_trans.addItems(campos)
    
    def actualizar_campos_malla_trans(self):
        """Actualizar campos de malla"""
        capa = self.combo_malla_siti_trans.currentData()
        
        if capa:
            campos = [field.name() for field in capa.fields()]
            
            self.combo_principal_malla_trans.clear()
            self.combo_principal_malla_trans.addItems(campos)
            
            self.combo_generadora_malla_trans.clear()
            self.combo_generadora_malla_trans.addItems(campos)
    
    def toggle_opcional1(self, state):
        """Habilitar/deshabilitar opcional 1"""
        enabled = (state == Qt.Checked)
        self.combo_opcional1_p3.setEnabled(enabled)
        self.combo_campo_opcional1_p3.setEnabled(enabled)
        
        if enabled and self.combo_opcional1_p3.currentData():
            self.actualizar_campos_capa(self.combo_opcional1_p3, self.combo_campo_opcional1_p3)
    
    def toggle_opcional2(self, state):
        """Habilitar/deshabilitar opcional 2"""
        enabled = (state == Qt.Checked)
        self.combo_opcional2_p3.setEnabled(enabled)
        self.combo_campo_opcional2_p3.setEnabled(enabled)
        
        if enabled and self.combo_opcional2_p3.currentData():
            self.actualizar_campos_capa(self.combo_opcional2_p3, self.combo_campo_opcional2_p3)
    
    def log_mensaje(self, mensaje, paso=1):
        """Agregar mensaje al log"""
        if paso == 0:
            self.log_paso0.append(mensaje)
        elif paso == 1:
            self.log_paso1.append(mensaje)
        elif paso == 2:
            self.log_paso2.append(mensaje)
        elif paso == 3:
            self.log_proceso.append(mensaje)
        elif paso == 4:
            self.log_transferencia.append(mensaje)
    
    def ejecutar_paso0_etapa1(self):
        """ETAPA 1: Comparación de datos faltantes"""
        try:
            self.log_mensaje("🚀 Iniciando ETAPA 1: Comparación de datos faltantes...", paso=0)
            
            capa_telef = self.combo_malla_telef_p0.currentData()
            capa_siti = self.combo_malla_siti_p0.currentData()
            campo_comp = self.combo_campo_concat_p0.currentText()
            
            if not all([capa_telef, capa_siti, campo_comp]):
                QMessageBox.warning(self, "Error", "Faltan parámetros por configurar")
                return
            
            if campo_comp not in [f.name() for f in capa_telef.fields()]:
                QMessageBox.warning(self, "Error", f"Campo '{campo_comp}' no existe en Malla TELEF")
                return
            
            if campo_comp not in [f.name() for f in capa_siti.fields()]:
                QMessageBox.warning(self, "Error", f"Campo '{campo_comp}' no existe en Malla SITI")
                return
            
            self.log_mensaje(f"   📊 Comparando campo: {campo_comp}", paso=0)
            
            valores_siti = {feat[campo_comp] for feat in capa_siti.getFeatures()}
            self.log_mensaje(f"   📍 {len(valores_siti)} valores únicos en SITI", paso=0)
            
            crs = capa_telef.crs().authid()
            geom_type = QgsWkbTypes.displayString(capa_telef.wkbType())
            
            capa_faltantes = QgsVectorLayer(f"{geom_type}?crs={crs}", "Elementos_Faltantes", "memory")
            pr_faltantes = capa_faltantes.dataProvider()
            
            pr_faltantes.addAttributes(capa_telef.fields())
            capa_faltantes.updateFields()
            
            faltantes = []
            for feat in capa_telef.getFeatures():
                if feat[campo_comp] not in valores_siti:
                    faltantes.append(QgsFeature(feat))
            
            pr_faltantes.addFeatures(faltantes)
            QgsProject.instance().addMapLayer(capa_faltantes)
            
            self.log_mensaje(f"   ✅ {len(faltantes)} elementos faltantes encontrados", paso=0)
            self.log_mensaje(f"   📁 Capa 'Elementos_Faltantes' creada", paso=0)
            
            QMessageBox.information(self, "Éxito", f"ETAPA 1 completada:\n{len(faltantes)} elementos faltantes encontrados")
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error en ETAPA 1:\n{str(e)}")
            import traceback
            self.log_mensaje(f"❌ ERROR: {traceback.format_exc()}", paso=0)
    
    def ejecutar_paso0_etapa2(self):
        """ETAPA 2: Validación de paralelas"""
        try:
            self.log_mensaje("🚀 Iniciando ETAPA 2: Validación de paralelas...", paso=0)
            
            capas_ef = QgsProject.instance().mapLayersByName("Elementos_Faltantes")
            capa_siti = self.combo_malla_siti_p0.currentData()
            
            if not capas_ef:
                QMessageBox.warning(self, "Error", "No se encontró capa 'Elementos_Faltantes'.\nEjecuta primero ETAPA 1")
                return
            
            if not capa_siti:
                QMessageBox.warning(self, "Error", "Selecciona la Malla SITI")
                return
            
            lyr_ef = capas_ef[0]
            
            try:
                distancia = float(self.txt_distancia_p0.text())
                tolerancia = float(self.txt_tolerancia_p0.text())
            except:
                QMessageBox.warning(self, "Error", "Distancia y tolerancia deben ser números")
                return
            
            self.log_mensaje(f"   📏 Distancia: {distancia}, Tolerancia: {tolerancia}°", paso=0)
            
            def obtener_angulo_linea(geom):
                if geom.isNull():
                    return 0
                
                if geom.isMultipart():
                    lineas = geom.asMultiPolyline()
                    if not lineas or len(lineas[0]) < 2: 
                        return 0
                    p1 = lineas[0][0]
                    p2 = lineas[0][-1]
                else:
                    linea = geom.asPolyline()
                    if len(linea) < 2: 
                        return 0
                    p1 = linea[0]
                    p2 = linea[-1]
                
                angulo = math.degrees(math.atan2(p2.y() - p1.y(), p2.x() - p1.x()))
                return angulo % 180
            
            def son_paralelas(ang1, ang2, tol):
                diff = abs(ang1 - ang2)
                return diff <= tol or diff >= (180 - tol)
            
            output_lyr = QgsVectorLayer("Point?crs=" + lyr_ef.crs().authid(), "Validacion_Final_Paralelas_Generadoras", "memory")
            pr = output_lyr.dataProvider()
            pr.addAttributes([
                QgsField("EF_ID", QVariant.Int),
                QgsField("EF_Prin", QVariant.String),
                QgsField("EF_Gen", QVariant.String),
                QgsField("MV_ID", QVariant.Int),
                QgsField("MV_Prin", QVariant.String),
                QgsField("MV_Gen", QVariant.String),
                QgsField("Ang_Diff", QVariant.Double),
                QgsField("Estado", QVariant.String)
            ])
            output_lyr.updateFields()
            
            self.log_mensaje("   🔍 Creando índice espacial...", paso=0)
            index_siti = QgsSpatialIndex(capa_siti.getFeatures())
            features_resultado = []
            
            total = lyr_ef.featureCount()
            contador = 0
            
            self.log_mensaje(f"   📊 Procesando {total} elementos...", paso=0)
            
            for feat_ef in lyr_ef.getFeatures():
                contador += 1
                
                if contador % 100 == 0:
                    self.log_mensaje(f"      {contador}/{total}...", paso=0)
                    QCoreApplication.processEvents()
                
                geom_ef = feat_ef.geometry()
                if geom_ef.isNull(): 
                    continue
                
                id_ef = feat_ef['id'] if 'id' in feat_ef.fields().names() else feat_ef.id()
                p_ef = str(feat_ef['principal']).strip().upper() if feat_ef['principal'] != NULL else ""
                g_ef = str(feat_ef['generadora']).strip().upper() if feat_ef['generadora'] != NULL else "VACIO"
                
                ang_ef = obtener_angulo_linea(geom_ef)
                centroide = geom_ef.centroid()
                buffer_area = centroide.buffer(distancia, 5)
                
                ids_cercanos = index_siti.intersects(buffer_area.boundingBox())
                
                for id_siti_idx in ids_cercanos:
                    feat_siti = capa_siti.getFeature(id_siti_idx)
                    geom_siti = feat_siti.geometry()
                    
                    if buffer_area.intersects(geom_siti):
                        id_siti_val = feat_siti['id'] if 'id' in feat_siti.fields().names() else feat_siti.id()
                        p_siti_raw = feat_siti['principal']
                        g_siti_raw = feat_siti['generadora']
                        
                        p_siti = str(p_siti_raw).strip().upper() if p_siti_raw != NULL else ""
                        
                        prin_vacia = (p_siti_raw == NULL or p_siti == "" or p_siti == "NULL")
                        prin_ok = (p_ef == p_siti) or (p_siti == "SN") or prin_vacia
                        
                        gen_siti_vacia = (g_siti_raw == NULL or str(g_siti_raw).strip() == "" or str(g_siti_raw).upper() == "NULL")
                        
                        if prin_ok and gen_siti_vacia:
                            ang_siti = obtener_angulo_linea(geom_siti)
                            if son_paralelas(ang_ef, ang_siti, tolerancia):
                                diff_ang = abs(ang_ef - ang_siti)
                                diff_final = diff_ang if diff_ang <= 90 else abs(180 - diff_ang)
                                
                                est = "PARALELA_OK"
                                if prin_vacia: 
                                    est += " (PRIN VACIA)"
                                elif p_siti == "SN": 
                                    est += " (PRIN SN)"
                                
                                f_out = QgsFeature()
                                f_out.setGeometry(centroide)
                                f_out.setAttributes([
                                    id_ef, p_ef, g_ef,
                                    id_siti_val,
                                    p_siti if not prin_vacia else "VACIO/NULL",
                                    "VACIO/NULL",
                                    round(diff_final, 2),
                                    est
                                ])
                                features_resultado.append(f_out)
                                break
            
            pr.addFeatures(features_resultado)
            QgsProject.instance().addMapLayer(output_lyr)
            
            self.log_mensaje(f"   ✅ {len(features_resultado)} puntos generados", paso=0)
            self.log_mensaje(f"   📁 Capa 'Validacion_Final_Paralelas_Generadoras' creada", paso=0)
            
            QMessageBox.information(self, "Éxito", f"ETAPA 2 completada:\n{len(features_resultado)} puntos de validación generados")
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error en ETAPA 2:\n{str(e)}")
            import traceback
            self.log_mensaje(f"❌ ERROR: {traceback.format_exc()}", paso=0)
    
    def ejecutar_paso1(self):
        """Ejecutar PASO 1"""
        try:
            self.log_mensaje("🚀 Iniciando PASO 1...", paso=1)
            
            barrios_siti = self.combo_barrios_siti_p1.currentData()
            urb_siti = self.combo_urb_siti_p1.currentData()
            barrios_telef = self.combo_barrios_telef_p1.currentData()
            urb_telef = self.combo_urb_telef_p1.currentData()
            
            if not all([barrios_siti, urb_siti, barrios_telef, urb_telef]):
                QMessageBox.warning(self, "Error", "Faltan capas por seleccionar")
                return
            
            from .validacion_paso1 import ejecutar_paso1_completo
            ejecutar_paso1_completo(barrios_siti, urb_siti, barrios_telef, urb_telef, 
                                   "nombre", self, self.iface)
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error en PASO 1:\n{str(e)}")
            self.log_mensaje(f"❌ ERROR: {str(e)}", paso=1)
    
    def ejecutar_paso2(self):
        """Ejecutar PASO 2"""
        try:
            self.log_mensaje("🚀 Iniciando PASO 2...", paso=2)
            
            predios = self.combo_predios_p2.currentData()
            barrios_siti = self.combo_barrios_siti_p2.currentData()
            urb_siti = self.combo_urb_siti_p2.currentData()
            
            if not all([predios, barrios_siti, urb_siti]):
                QMessageBox.warning(self, "Error", "Faltan capas por seleccionar")
                return
            
            from .validacion_paso2 import ejecutar_paso2_completo
            ejecutar_paso2_completo(predios, barrios_siti, urb_siti, self, self.iface)
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error en PASO 2:\n{str(e)}")
            self.log_mensaje(f"❌ ERROR: {str(e)}", paso=2)
    
    def iniciar_edicion_grupos(self):
        """Iniciar proceso de edición por grupos"""
        try:
            self.log_mensaje("🚀 Iniciando proceso MZA CASA...", paso=3)
            
            config = {
                'barrios_siti': self.combo_barrios_siti_p3.currentData(),
                'campo_barrios_siti': self.combo_campo_barrios_siti_p3.currentText(),
                'urb_siti': self.combo_urb_siti_p3.currentData(),
                'campo_urb_siti': self.combo_campo_urb_siti_p3.currentText(),
                'predios_siti': self.combo_predios_siti_p3.currentData(),
                'campo_predios': self.combo_campo_predios_p3.currentText(),
                'campo_fecha': self.combo_fecha_p3.currentText(),
                'campo_version': self.combo_version_p3.currentText(),
                'campo_marca': self.combo_marca_p3.currentText(),
                'barrios_telef': self.combo_barrios_telef_p3.currentData(),
                'campo_barrios_telef': self.combo_campo_barrios_telef_p3.currentText(),
                'urb_telef': self.combo_urb_telef_p3.currentData(),
                'campo_urb_telef': self.combo_campo_urb_telef_p3.currentText(),
                'poligonizada': self.combo_poligonizada_p3.currentData()
            }
            
            if self.check_opcional1_p3.isChecked() and self.combo_opcional1_p3.currentData():
                config['opcional1'] = self.combo_opcional1_p3.currentData()
                config['campo_opcional1'] = self.combo_campo_opcional1_p3.currentText()
            
            if self.check_opcional2_p3.isChecked() and self.combo_opcional2_p3.currentData():
                config['opcional2'] = self.combo_opcional2_p3.currentData()
                config['campo_opcional2'] = self.combo_campo_opcional2_p3.currentText()
            
            if not all([config['barrios_siti'], config['urb_siti'], config['predios_siti'], 
                        config['barrios_telef'], config['urb_telef']]):
                QMessageBox.warning(self, "Error", "Faltan capas obligatorias")
                return
            
            if not config['poligonizada']:
                respuesta = QMessageBox.question(
                    self, 
                    "Advertencia", 
                    "No se seleccionó capa 'Poligonizada'. No se podrán crear urbanizaciones.\n\n¿Continuar?",
                    QMessageBox.Yes | QMessageBox.No
                )
                if respuesta == QMessageBox.No:
                    return
            
            try:
                from .proceso_mza_casa import VentanaEdicionGrupos
                self.ventana_edicion = VentanaEdicionGrupos(config, self.iface, self)
            except ImportError as ie:
                self.log_mensaje(f"❌ Error al importar: {str(ie)}", paso=3)
                QMessageBox.critical(self, "Error de Importación", f"No se puede importar VentanaEdicionGrupos:\n{str(ie)}")
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error:\n{str(e)}")
            import traceback
            self.log_mensaje(f"❌ ERROR: {traceback.format_exc()}", paso=3)
    
    def ejecutar_transferencia(self):
        """PROCESO DE TRANSFERENCIA TELEF → SITI"""
        try:
            self.log_mensaje("🚀 Iniciando Transferencia TELEF → SITI...", paso=4)
            self.log_mensaje("⚠️ VALIDANDO CONFIGURACIÓN...", paso=4)
            
            # Validar capas
            capa_telef = self.combo_predios_telef_trans.currentData()
            capa_siti = self.combo_predios_siti_trans.currentData()
            capa_malla = self.combo_malla_siti_trans.currentData()
            capa_barrios = self.combo_barrios_trans.currentData()
            capa_urb = self.combo_urb_trans.currentData()
            
            if not all([capa_telef, capa_siti, capa_malla, capa_barrios, capa_urb]):
                QMessageBox.warning(self, "Error", "Faltan capas por seleccionar")
                return
            
            # Validar metadatos
            fecha = self.txt_fecha_trans.text().strip()
            marca = self.txt_marca_trans.text().strip()
            version = self.txt_version_trans.text().strip()
            
            if not all([fecha, marca, version]):
                QMessageBox.warning(self, "Error", "Debes ingresar Fecha, Marca y Versión")
                return
            
            # Confirmación
            respuesta = QMessageBox.question(
                self,
                "⚠️ CONFIRMAR TRANSFERENCIA",
                f"Vas a transferir información de TELEF a SITI.\n\n"
                f"Metadatos:\n"
                f"  • Fecha: {fecha}\n"
                f"  • Marca: {marca}\n"
                f"  • Versión: {version}\n\n"
                f"Este proceso puede tomar varios minutos.\n\n"
                f"¿Continuar?",
                QMessageBox.Yes | QMessageBox.No
            )
            
            if respuesta == QMessageBox.No:
                self.log_mensaje("❌ Transferencia cancelada por el usuario", paso=4)
                return
            
            self.log_mensaje("✅ Configuración validada", paso=4)
            
            # EJECUTAR TRANSFERENCIA
            from .transferencia_telef_siti import ejecutar_transferencia_completa
            ejecutar_transferencia_completa(
                capa_telef=capa_telef,
                capa_siti=capa_siti,
                capa_malla=capa_malla,
                capa_barrios=capa_barrios,
                capa_urb=capa_urb,
                campos_telef={
                    'via_princ': self.combo_via_princ_telef_trans.currentText(),
                    'via_sec': self.combo_via_sec_telef_trans.currentText(),
                    'placa': self.combo_placa_telef_trans.currentText()
                },
                campos_siti={
                    'via_princ': self.combo_via_princ_siti_trans.currentText(),
                    'via_sec': self.combo_via_sec_siti_trans.currentText(),
                    'placa': self.combo_placa_siti_trans.currentText(),
                    'fecha': self.combo_fecha_siti_trans.currentText(),
                    'marca': self.combo_marca_siti_trans.currentText(),
                    'version': self.combo_version_siti_trans.currentText()
                },
                campos_malla={
                    'principal': self.combo_principal_malla_trans.currentText(),
                    'generadora': self.combo_generadora_malla_trans.currentText()
                },
                campos_barrios={
                    'nombre': self.combo_campo_barrios_trans.currentText()
                },
                campos_urb={
                    'nombre': self.combo_campo_urb_trans.currentText()
                },
                metadatos={
                    'fecha': fecha,
                    'marca': marca,
                    'version': version
                },
                parent_dialog=self,
                iface=self.iface
            )
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error en Transferencia:\n{str(e)}")
            import traceback
            self.log_mensaje(f"❌ ERROR: {traceback.format_exc()}", paso=4)
            
            
            
