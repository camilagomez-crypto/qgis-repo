# -*- coding: utf-8 -*-
"""
Módulo PASO 2: Inconsistencias en Predios
"""

import processing
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsFeature, QgsField
)
from qgis.PyQt.QtCore import QVariant, QCoreApplication
from difflib import SequenceMatcher


def similar(a, b):
    """Calcula similitud entre dos textos"""
    if a is None or b is None or str(a).strip() == "" or str(b).strip() == "": 
        return 0.0
    val_a = str(a).upper().strip()
    val_b = str(b).upper().strip()
    return SequenceMatcher(None, val_a, val_b).ratio() * 100


def ejecutar_inconsistencias_predios(predios, urbanizaciones, barrios, log_func, progress_bar):
    """
    Detecta inconsistencias en predios
    
    Returns:
        str: Resumen de resultados
    """
    
    try:
        log_func("\n1. Filtrando predios...")
        
        # Verificar que existe el campo tipo_direccion
        if 'tipo_direccion' not in [f.name() for f in predios.fields()]:
            raise Exception("La capa de predios no contiene el campo 'tipo_direccion'")
        
        filter_expr = "\"tipo_direccion\" IN ('INDEFINIDA','MZ CASA - COMPLETA','MZ CASA - INCOMPLETA')"
        
        predios_filtrados = processing.run("native:extractbyexpression", {
            'INPUT': predios,
            'EXPRESSION': filter_expr,
            'OUTPUT': 'TEMPORARY_OUTPUT'
        })['OUTPUT']
        
        log_func(f"   ✓ Predios filtrados: {predios_filtrados.featureCount()}")
        progress_bar.setValue(15)
        
        log_func("\n2. Generando puntos sobre superficie...")
        puntos_superficie = processing.run("native:pointonsurface", {
            'INPUT': predios_filtrados,
            'ALL_PARTS': False,
            'OUTPUT': 'TEMPORARY_OUTPUT'
        })['OUTPUT']
        
        log_func(f"   ✓ Puntos generados: {puntos_superficie.featureCount()}")
        progress_bar.setValue(30)
        
        log_func("\n3. Realizando cruces espaciales...")
        log_func("   Join con Barrios...")
        
        join_barrios = processing.run("native:joinattributesbylocation", {
            'INPUT': puntos_superficie,
            'JOIN': barrios,
            'PREDICATE': [0],
            'JOIN_FIELDS': ['nombre', 'observaciones'],
            'METHOD': 0,
            'DISCARD_NON_MATCHING': False,
            'PREFIX': 'brr_',
            'OUTPUT': 'TEMPORARY_OUTPUT'
        })['OUTPUT']
        
        log_func(f"   ✓ Join con barrios completado")
        progress_bar.setValue(50)
        
        log_func("   Join con Urbanizaciones...")
        
        res_intermedio = processing.run("native:joinattributesbylocation", {
            'INPUT': join_barrios,
            'JOIN': urbanizaciones,
            'PREDICATE': [0],
            'JOIN_FIELDS': ['nombre', 'observaciones'],
            'METHOD': 0,
            'DISCARD_NON_MATCHING': False,
            'PREFIX': 'urb_',
            'OUTPUT': 'TEMPORARY_OUTPUT'
        })['OUTPUT']
        
        log_func(f"   ✓ Join con urbanizaciones completado")
        progress_bar.setValue(70)
        
        log_func("\n4. Analizando similitudes y detectando inconsistencias...")
        
        # Crear capa final
        final_layer = QgsVectorLayer("Point?crs=" + res_intermedio.crs().authid(), 
                                     "PREDIOS_INCONSISTENTES", "memory")
        final_data = final_layer.dataProvider()
        
        # Copiar campos originales y añadir nuevos
        final_data.addAttributes(res_intermedio.fields())
        final_data.addAttributes([
            QgsField("nombre_brr", QVariant.String),
            QgsField("observaciones_brr", QVariant.String),
            QgsField("nombre_urb", QVariant.String),
            QgsField("observaciones_urb", QVariant.String),
            QgsField("val_brr", QVariant.String),
            QgsField("val_urb", QVariant.String),
            QgsField("pct_similitud", QVariant.Double),
            QgsField("capa_mejor_match", QVariant.String)
        ])
        final_layer.updateFields()
        
        new_features = []
        total = res_intermedio.featureCount()
        contador = 0
        
        for feat in res_intermedio.getFeatures():
            contador += 1
            if contador % 100 == 0:
                log_func(f"   Procesando {contador}/{total}...")
                QCoreApplication.processEvents()
            
            via_p = str(feat['via_princ']) if feat['via_princ'] else ""
            n_brr = str(feat['brr_nombre']) if feat['brr_nombre'] else ""
            n_urb = str(feat['urb_nombre']) if feat['urb_nombre'] else ""
            
            # Validaciones de existencia (SI/NO)
            v_brr = "SI" if via_p and via_p.upper() in n_brr.upper() else "NO"
            v_urb = "SI" if via_p and via_p.upper() in n_urb.upper() else "NO"
            
            # Similitud
            sim_brr = similar(via_p, n_brr)
            sim_urb = similar(via_p, n_urb)
            
            max_sim = max(sim_brr, sim_urb)
            mejor_capa = "BARRIOS" if sim_brr >= sim_urb else "URBANIZACIONES"
            
            # FILTRO CRÍTICO: Solo exportar lo que NO está al 100%
            if max_sim < 100.0:
                f_new = QgsFeature(final_layer.fields())
                f_new.setGeometry(feat.geometry())
                
                # Pasar atributos de la capa procesada
                for i in range(res_intermedio.fields().count()):
                    f_new.setAttribute(i, feat.attributes()[i])
                
                # Asignar nuevos campos calculados
                f_new.setAttribute("nombre_brr", n_brr)
                f_new.setAttribute("observaciones_brr", feat['brr_observaciones'])
                f_new.setAttribute("nombre_urb", n_urb)
                f_new.setAttribute("observaciones_urb", feat['urb_observaciones'])
                f_new.setAttribute("val_brr", v_brr)
                f_new.setAttribute("val_urb", v_urb)
                f_new.setAttribute("pct_similitud", round(max_sim, 2))
                f_new.setAttribute("capa_mejor_match", mejor_capa)
                
                new_features.append(f_new)
        
        # Añadir registros a la capa de memoria
        final_data.addFeatures(new_features)
        QgsProject.instance().addMapLayer(final_layer)
        
        progress_bar.setValue(95)
        
        log_func(f"\n✓ Análisis completado")
        log_func(f"   Total de predios analizados: {total}")
        log_func(f"   Inconsistencias encontradas: {len(new_features)}")
        
        resumen = f"""Predios analizados: {total}
Inconsistencias encontradas: {len(new_features)}
Capa generada: PREDIOS_INCONSISTENTES"""
        
        return resumen
        
    except Exception as e:
        raise Exception(f"Error en PASO 2: {str(e)}")

# ─────────────────────────────────────────────────────────────────────────────
# WRAPPER: función esperada por validacion_capas_pasto.py
# ─────────────────────────────────────────────────────────────────────────────

def ejecutar_paso2_completo(predios, barrios_siti, urb_siti, parent_dialog, iface):
    """
    Wrapper que adapta la firma esperada por el diálogo principal.
    Llama a ejecutar_inconsistencias_predios con los parámetros correctos.
    """
    class ProgressBarFictiicio:
        def setValue(self, v): pass

    progress_bar = ProgressBarFictiicio()

    def log_func(msg):
        parent_dialog.log_mensaje(msg, paso=2)

    try:
        resumen = ejecutar_inconsistencias_predios(
            predios=predios,
            urbanizaciones=urb_siti,
            barrios=barrios_siti,
            log_func=log_func,
            progress_bar=progress_bar
        )
        log_func("\n" + "=" * 50)
        log_func(resumen)
        log_func("=" * 50)

        from qgis.PyQt.QtWidgets import QMessageBox
        QMessageBox.information(
            parent_dialog,
            "✅ PASO 2 Completado",
            resumen
        )

    except Exception as e:
        import traceback
        log_func(f"❌ ERROR: {traceback.format_exc()}")
        raise
