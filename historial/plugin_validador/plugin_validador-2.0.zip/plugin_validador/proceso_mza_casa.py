# -*- coding: utf-8 -*-
"""
Módulo Proceso MZA CASA: Panel de Edición por Grupos
VERSIÓN FINAL - NO BLOQUEA QGIS + CREACIÓN DE URBANIZACIONES CON ID
"""

from qgis.PyQt.QtCore import Qt, QCoreApplication
from difflib import SequenceMatcher
from qgis.PyQt.QtWidgets import (QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                                 QLineEdit, QPushButton, QMessageBox, QGroupBox,
                                 QFormLayout, QScrollArea)
from qgis.core import (QgsProject, QgsFeatureRequest, QgsSpatialIndex, QgsGeometry, 
                       QgsPointXY, QgsRectangle, QgsFeature, QgsVectorLayer, QgsWkbTypes)
from qgis.PyQt.QtGui import QFont


class VentanaEdicionGrupos(QDockWidget):
    """Panel flotante para editar predios - NUNCA BLOQUEA QGIS"""
    
    def __init__(self, config, iface, parent_dialog):
        # DockWidget = Panel flotante que NO bloquea
        super(VentanaEdicionGrupos, self).__init__("Edición por Grupos - Proceso MZA CASA", iface.mainWindow())
        
        self.config = config
        self.iface = iface
        self.parent_dialog = parent_dialog
        
        # Permitir flotar, mover, cerrar
        self.setAllowedAreas(Qt.AllDockWidgetAreas)
        self.setFloating(True)
        
        # Tamaño inicial
        self.resize(700, 600)
        
        self.parent_dialog.log_mensaje("⏳ Cargando grupos...", paso=3)
        QCoreApplication.processEvents()
        
        try:
            self.crear_indices_espaciales()
            self.grupos = self.obtener_grupos_rapido()
            self.indice_actual = 0
            self.total_grupos = len(self.grupos)
            
            if self.total_grupos == 0:
                QMessageBox.warning(self, "Advertencia", "No se encontraron grupos con inconsistencias (>=10 predios tipo MZ CASA)")
                self.close()
                self.parent_dialog.show()
                return
            
            self.parent_dialog.log_mensaje(f"✅ {self.total_grupos} grupos encontrados", paso=3)
            self.parent_dialog.hide()
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error:\n{str(e)}")
            self.close()
            self.parent_dialog.show()
            return
        
        self.crear_interfaz()
        self.cargar_grupo_actual()
        
        # Agregar al QGIS - esto lo muestra automáticamente
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self)
    
    def closeEvent(self, event):
        """Al cerrar, limpiar selección y mostrar ventana principal"""
        try:
            capa_predios = self.config['predios_siti']
            capa_predios.removeSelection()
        except:
            pass
        
        self.parent_dialog.show()
        event.accept()
    
    def crear_indices_espaciales(self):
        """Crear índices espaciales UNA SOLA VEZ"""
        self.parent_dialog.log_mensaje("   Creando índices...", paso=3)
        
        capa_barrios = self.config['barrios_siti']
        capa_urb = self.config['urb_siti']
        
        self.index_barrios = QgsSpatialIndex(capa_barrios.getFeatures())
        self.index_urb = QgsSpatialIndex(capa_urb.getFeatures())
        
        self.geom_barrios = {}
        self.geom_urb = {}
        
        for feat in capa_barrios.getFeatures():
            self.geom_barrios[feat.id()] = feat.geometry()
        
        for feat in capa_urb.getFeatures():
            self.geom_urb[feat.id()] = feat.geometry()
        
        # Índice espacial para capa poligonizada (si existe)
        if self.config.get('poligonizada'):
            capa_poligonizada = self.config['poligonizada']
            self.index_poligonizada = QgsSpatialIndex(capa_poligonizada.getFeatures())
            self.geom_poligonizada = {}
            
            for feat in capa_poligonizada.getFeatures():
                self.geom_poligonizada[feat.id()] = feat.geometry()
    
    def obtener_poligono_rapido(self, punto):
        """Buscar polígono que contiene el punto.
        ORDEN: urbanizaciones primero (más específicas), luego barrios.
        Si un predio tiene URB, su via_princ debe compararse contra el nombre de la URB,
        no contra el barrio que la contiene. Esto evita falsos positivos donde
        'URB ALTOS DE CHAPINERO' == 'URB ALTOS DE CHAPINERO' (urb) pero
        'URB ALTOS DE CHAPINERO' != 'BRR CARLOS PIZARRO' (barrio) generaba
        una inconsistencia incorrecta.
        """
        bbox = QgsRectangle(punto.x()-0.0001, punto.y()-0.0001,
                            punto.x()+0.0001, punto.y()+0.0001)
        
        # 1. Buscar en urbanizaciones PRIMERO (son más específicas/pequeñas)
        ids_urb = self.index_urb.intersects(bbox)
        for fid in ids_urb:
            if self.geom_urb[fid].contains(punto):
                return ('urb', fid)
        
        # 2. Solo si no hay URB, buscar en barrios
        ids_barrios = self.index_barrios.intersects(bbox)
        for fid in ids_barrios:
            if self.geom_barrios[fid].contains(punto):
                return ('barrio', fid)
        
        return (None, None)
    
    def obtener_grupos_rapido(self):
        """Agrupación con filtro tipo_direccion MZ CASA"""
        capa_predios = self.config['predios_siti']
        campo_via = self.config['campo_predios']
        
        # Verificar que existe el campo tipo_direccion
        idx_tipo_dir = capa_predios.fields().indexOf('tipo_direccion')
        
        if idx_tipo_dir == -1:
            raise Exception("⚠️ Campo 'tipo_direccion' no encontrado en la capa de predios")
        
        # Diccionario: {(via_princ, tipo_pol, fid_pol): [lista de fids]}
        grupos = {}
        
        total = capa_predios.featureCount()
        contador = 0
        filtrados = 0
        
        self.parent_dialog.log_mensaje(f"   Filtrando predios MZ CASA...", paso=3)
        
        for feat in capa_predios.getFeatures():
            contador += 1
            
            if contador % 500 == 0:
                self.parent_dialog.log_mensaje(f"   {contador}/{total}... ({filtrados} MZ CASA)", paso=3)
                QCoreApplication.processEvents()
            
            # FILTRO 1: tipo_direccion
            tipo_dir = feat['tipo_direccion']
            
            if tipo_dir not in ('MZ CASA - COMPLETA', 'MZ CASA - INCOMPLETA'):
                continue
            
            filtrados += 1
            
            # FILTRO 2: via_princ no vacío
            via_princ = feat[campo_via]
            if not via_princ or str(via_princ).strip() == "":
                continue
            
            via_princ = str(via_princ).strip()
            
            # Obtener centroide
            geom = feat.geometry()
            if geom.isEmpty() or geom.isNull():
                continue
            
            punto = geom.centroid().asPoint()
            
            # Buscar polígono
            tipo_pol, fid_pol = self.obtener_poligono_rapido(punto)
            
            if tipo_pol is None:
                continue
            
            # Clave única
            clave = (via_princ, tipo_pol, fid_pol)
            
            if clave not in grupos:
                grupos[clave] = []
            
            grupos[clave].append(feat.id())
        
        self.parent_dialog.log_mensaje(f"   ✅ {filtrados} predios MZ CASA encontrados", paso=3)
        
        # Filtrar: >= min_predios (configurable, default 5)
        min_predios = self.config.get('min_predios', 5)
        self.parent_dialog.log_mensaje(f"   Filtrando grupos >= {min_predios} predios...", paso=3)
        grupos_filtrados = {k: v for k, v in grupos.items() if len(v) >= min_predios}
        self.parent_dialog.log_mensaje(f"   {len(grupos_filtrados)} grupos encontrados", paso=3)
        
        # Detectar inconsistencias — COMPARACIÓN EXACTA (no "in")
        # FIX: antes usaba "via_upper not in nombre_upper" lo que causaba que
        # "BRR CAICEDO" pasara como correcto dentro de "BRR CAICEDO ALTO".
        # FIX 2: ahora las URB tienen prioridad sobre barrios en obtener_poligono_rapido,
        # por lo que "URB ALTOS DE CHAPINERO" se compara contra la URB, no el barrio.
        self.parent_dialog.log_mensaje("   Detectando inconsistencias (comparación exacta)...", paso=3)
        
        grupos_inconsistentes = []
        capa_barrios = self.config['barrios_siti']
        capa_urb = self.config['urb_siti']
        campo_barrios = self.config['campo_barrios_siti']
        campo_urb = self.config['campo_urb_siti']
        
        desc_ok = 0
        
        for (via_princ, tipo_pol, fid_pol), fids in grupos_filtrados.items():
            if tipo_pol == 'barrio':
                feat_pol = capa_barrios.getFeature(fid_pol)
                nombre_pol = str(feat_pol[campo_barrios]) if feat_pol[campo_barrios] else ""
            else:
                feat_pol = capa_urb.getFeature(fid_pol)
                nombre_pol = str(feat_pol[campo_urb]) if feat_pol[campo_urb] else ""
            
            via_norm    = via_princ.upper().strip()
            nombre_norm = nombre_pol.upper().strip()
            
            # INCONSISTENCIA solo si NO son exactamente iguales
            if via_norm != nombre_norm:
                grupos_inconsistentes.append({
                    'via_princ':  via_princ,
                    'tipo_pol':   tipo_pol,
                    'fid_pol':    fid_pol,
                    'nombre_pol': nombre_pol,
                    'fids':       fids,
                    'cantidad':   len(fids),
                    'similitud':  round(
                        SequenceMatcher(None, via_norm, nombre_norm).ratio() * 100, 1
                    )
                })
            else:
                desc_ok += 1
        
        self.parent_dialog.log_mensaje(
            f"   ✅ {len(grupos_inconsistentes)} inconsistencias | {desc_ok} grupos correctos", paso=3
        )
        
        # Ordenar: mayor cantidad de predios primero
        grupos_inconsistentes.sort(key=lambda g: g['cantidad'], reverse=True)
        
        return grupos_inconsistentes
    
    def seleccionar_y_zoom(self, fids):
        """Seleccionar predios y hacer zoom"""
        try:
            capa = self.config['predios_siti']
            capa.removeSelection()
            capa.selectByIds(fids)
            
            bbox = QgsRectangle()
            bbox.setMinimal()
            
            for fid in fids:
                feat = capa.getFeature(fid)
                geom = feat.geometry()
                if not geom.isEmpty():
                    if bbox.isEmpty():
                        bbox = geom.boundingBox()
                    else:
                        bbox.combineExtentWith(geom.boundingBox())
            
            if not bbox.isEmpty():
                bbox.scale(1.3)
                self.iface.mapCanvas().setExtent(bbox)
                self.iface.mapCanvas().refresh()
        except:
            pass
    
    def crear_interfaz(self):
        """Crear interfaz"""
        widget_principal = QWidget()
        main_layout = QVBoxLayout()
        
        # Nota importante
        nota = QLabel("✅ Puedes usar el mapa libremente - Este panel no bloquea QGIS")
        nota.setStyleSheet("background-color: #d5f4e6; color: #16a085; padding: 8px; font-weight: bold; border-radius: 3px;")
        nota.setWordWrap(True)
        main_layout.addWidget(nota)
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll_widget = QWidget()
        layout = QVBoxLayout(scroll_widget)
        
        # Header
        self.lbl_contador = QLabel()
        self.lbl_contador.setStyleSheet("font-size: 13pt; font-weight: bold; color: #e74c3c;")
        layout.addWidget(self.lbl_contador)
        
        # Info grupo
        info_group = QGroupBox("⚠️ Grupo MZ CASA con Inconsistencia")
        info_layout = QVBoxLayout()
        
        self.lbl_info = QLabel()
        self.lbl_info.setStyleSheet("font-size: 10pt; color: #e74c3c; font-weight: bold;")
        self.lbl_info.setWordWrap(True)
        info_layout.addWidget(self.lbl_info)
        
        self.lbl_poligono = QLabel()
        self.lbl_poligono.setStyleSheet("font-size: 9pt; color: #8e44ad;")
        self.lbl_poligono.setWordWrap(True)
        info_layout.addWidget(self.lbl_poligono)
        
        self.lbl_sel = QLabel("🔵 Predios SELECCIONADOS en amarillo")
        self.lbl_sel.setStyleSheet("font-size: 9pt; color: #2980b9; font-style: italic; padding: 3px; background-color: #e8f4f8;")
        info_layout.addWidget(self.lbl_sel)
        
        info_group.setLayout(info_layout)
        layout.addWidget(info_group)
        
        # TELEF
        telef_group = QGroupBox("👁️ TELEF (Consulta)")
        telef_layout = QFormLayout()
        
        self.txt_barrios_telef = QLineEdit()
        self.txt_barrios_telef.setReadOnly(True)
        self.txt_barrios_telef.setStyleSheet("background-color: #ffffff; color: #000000; padding: 4px;")
        telef_layout.addRow("Barrios:", self.txt_barrios_telef)
        
        self.txt_urb_telef = QLineEdit()
        self.txt_urb_telef.setReadOnly(True)
        self.txt_urb_telef.setStyleSheet("background-color: #ffffff; color: #000000; padding: 4px;")
        telef_layout.addRow("Urbanizaciones:", self.txt_urb_telef)
        
        telef_group.setLayout(telef_layout)
        layout.addWidget(telef_group)
        
        # CAPAS OPCIONALES (Consulta)
        self.opcional_group = QGroupBox("📋 Capas Opcionales (Consulta)")
        self.opcional_group.setStyleSheet(
            "QGroupBox { font-weight: bold; color: #6c3483; "
            "border: 1px solid #a569bd; border-radius: 4px; margin-top: 6px; padding-top: 6px; }"
        )
        self.opcional_layout = QFormLayout()
        self.txt_opcional1 = QLineEdit()
        self.txt_opcional1.setReadOnly(True)
        self.txt_opcional1.setStyleSheet(
            "background-color: #f5eef8; color: #4a235a; padding: 4px; font-style: italic;"
        )
        self.txt_opcional2 = QLineEdit()
        self.txt_opcional2.setReadOnly(True)
        self.txt_opcional2.setStyleSheet(
            "background-color: #f5eef8; color: #4a235a; padding: 4px; font-style: italic;"
        )
        tiene_op1 = bool(self.config.get('opcional1'))
        tiene_op2 = bool(self.config.get('opcional2'))
        if tiene_op1:
            nombre_op1 = self.config['opcional1'].name()
            campo_op1  = self.config.get('campo_opcional1', 'valor')
            self.opcional_layout.addRow(f"{nombre_op1}\n({campo_op1}):", self.txt_opcional1)
        if tiene_op2:
            nombre_op2 = self.config['opcional2'].name()
            campo_op2  = self.config.get('campo_opcional2', 'valor')
            self.opcional_layout.addRow(f"{nombre_op2}\n({campo_op2}):", self.txt_opcional2)
        self.opcional_group.setLayout(self.opcional_layout)
        if tiene_op1 or tiene_op2:
            layout.addWidget(self.opcional_group)
        
        # SITI
        siti_group = QGroupBox("✏️ SITI (Editable)")
        siti_layout = QFormLayout()
        
        self.txt_barrios_siti = QLineEdit()
        self.txt_barrios_siti.setStyleSheet("background-color: #ffffcc; color: #000000; font-weight: bold; padding: 4px; border: 2px solid #f39c12;")
        siti_layout.addRow("Barrios:", self.txt_barrios_siti)
        
        self.txt_urb_siti = QLineEdit()
        self.txt_urb_siti.setStyleSheet("background-color: #ffffcc; color: #000000; font-weight: bold; padding: 4px; border: 2px solid #f39c12;")
        siti_layout.addRow("Urbanizaciones:", self.txt_urb_siti)
        
        self.txt_via = QLineEdit()
        self.txt_via.setStyleSheet("background-color: #ffffcc; color: #000000; font-weight: bold; padding: 4px; border: 2px solid #f39c12;")
        siti_layout.addRow("Via Princ:", self.txt_via)
        
        self.txt_fecha = QLineEdit()
        self.txt_fecha.setStyleSheet("background-color: #ffffcc; color: #000000; padding: 4px; border: 2px solid #f39c12;")
        self.txt_fecha.setPlaceholderText("Ej: 2026-05-21")
        siti_layout.addRow("Fecha:", self.txt_fecha)
        
        self.txt_version = QLineEdit()
        self.txt_version.setStyleSheet("background-color: #ffffcc; color: #000000; padding: 4px; border: 2px solid #f39c12;")
        self.txt_version.setPlaceholderText("Ej: V1-26")
        siti_layout.addRow("Versión:", self.txt_version)
        
        self.txt_marca = QLineEdit()
        self.txt_marca.setStyleSheet("background-color: #ffffcc; color: #000000; padding: 4px; border: 2px solid #f39c12;")
        self.txt_marca.setPlaceholderText("Ej: 3")
        siti_layout.addRow("Marca:", self.txt_marca)
        
        siti_group.setLayout(siti_layout)
        layout.addWidget(siti_group)
        
        scroll.setWidget(scroll_widget)
        main_layout.addWidget(scroll)
        
        # Botones
        btn_layout = QHBoxLayout()
        
        self.btn_aceptar = QPushButton("✅ ACEPTAR Y SIGUIENTE")
        self.btn_aceptar.setStyleSheet("padding: 8px; font-size: 10pt; font-weight: bold; background-color: #27ae60; color: white; border-radius: 3px;")
        self.btn_aceptar.clicked.connect(self.aceptar)
        btn_layout.addWidget(self.btn_aceptar)
        
        self.btn_siguiente = QPushButton("⏭️ OMITIR")
        self.btn_siguiente.setStyleSheet("padding: 8px; font-size: 10pt; font-weight: bold; background-color: #3498db; color: white; border-radius: 3px;")
        self.btn_siguiente.clicked.connect(self.siguiente)
        btn_layout.addWidget(self.btn_siguiente)
        
        self.btn_cancelar = QPushButton("❌ CERRAR")
        self.btn_cancelar.setStyleSheet("padding: 8px; font-size: 10pt; background-color: #95a5a6; color: white; border-radius: 3px;")
        self.btn_cancelar.clicked.connect(self.close)
        btn_layout.addWidget(self.btn_cancelar)
        
        main_layout.addLayout(btn_layout)
        
        widget_principal.setLayout(main_layout)
        self.setWidget(widget_principal)
    
    def cargar_grupo_actual(self):
        """Cargar grupo actual"""
        if self.indice_actual >= self.total_grupos:
            self.config['predios_siti'].removeSelection()
            QMessageBox.information(self, "Completado", f"✅ {self.total_grupos} grupos procesados")
            self.close()
            return
        
        grupo = self.grupos[self.indice_actual]
        via = grupo['via_princ']
        cant = grupo['cantidad']
        fids = grupo['fids']
        tipo = grupo['tipo_pol']
        nombre_pol = grupo['nombre_pol']
        
        self.seleccionar_y_zoom(fids)
        
        self.lbl_contador.setText(f"Grupo {self.indice_actual + 1} de {self.total_grupos}")
        similitud = grupo.get('similitud', 0.0)
        self.lbl_info.setText(f"Via: '{via}' | {cant} predios  (similitud: {similitud}%)")
        tipo_texto = "Barrio" if tipo == 'barrio' else "Urbanización"
        self.lbl_poligono.setText(f"📐 {tipo_texto} SITI: '{nombre_pol}' — via ≠ nombre ({similitud}%)")
        
        capa = self.config['predios_siti']
        feat = capa.getFeature(fids[0])
        
        valor_via = feat[self.config['campo_predios']]
        valor_fecha = feat[self.config['campo_fecha']]
        valor_version = feat[self.config['campo_version']]
        valor_marca = feat[self.config['campo_marca']]
        
        self.txt_via.setText(str(valor_via) if valor_via is not None else "")
        self.txt_fecha.setText(str(valor_fecha) if valor_fecha is not None else "")
        self.txt_version.setText(str(valor_version) if valor_version is not None else "")
        self.txt_marca.setText(str(valor_marca) if valor_marca is not None else "")
        
        punto = feat.geometry().centroid().asPoint()
        
        barrio_t = self.obtener_valor_punto(self.config['barrios_telef'], self.config['campo_barrios_telef'], punto)
        self.txt_barrios_telef.setText(barrio_t)
        
        urb_t = self.obtener_valor_punto(self.config['urb_telef'], self.config['campo_urb_telef'], punto)
        self.txt_urb_telef.setText(urb_t)
        
        barrio_s = self.obtener_valor_punto(self.config['barrios_siti'], self.config['campo_barrios_siti'], punto)
        self.txt_barrios_siti.setText(barrio_s)
        
        urb_s = self.obtener_valor_punto(self.config['urb_siti'], self.config['campo_urb_siti'], punto)
        self.txt_urb_siti.setText(urb_s)
        
        # Capas Opcionales
        if self.config.get('opcional1'):
            try:
                val_op1 = self.obtener_valor_punto(
                    self.config['opcional1'], self.config.get('campo_opcional1', ''), punto)
                self.txt_opcional1.setText(val_op1)
            except Exception:
                self.txt_opcional1.setText('(error)')
        if self.config.get('opcional2'):
            try:
                val_op2 = self.obtener_valor_punto(
                    self.config['opcional2'], self.config.get('campo_opcional2', ''), punto)
                self.txt_opcional2.setText(val_op2)
            except Exception:
                self.txt_opcional2.setText('(error)')
        
        self.valores_orig = {
            'barrios_siti': barrio_s,
            'urb_siti': urb_s,
            'via': self.txt_via.text(),
            'fecha': self.txt_fecha.text(),
            'version': self.txt_version.text(),
            'marca': self.txt_marca.text()
        }
    
    def obtener_valor_punto(self, capa, campo, punto):
        """Obtener valor de campo en punto"""
        for f in capa.getFeatures():
            if f.geometry().contains(punto):
                val = f[campo]
                return str(val) if val is not None else ""
        return ""
    
    def crear_urbanizacion_desde_poligonos(self, fids_predios, nombre_urb):
        """
        Crear urbanización desde polígonos de la capa poligonizada
        """
        try:
            if not self.config.get('poligonizada'):
                return False
            
            capa_poligonizada = self.config['poligonizada']
            capa_urb_siti = self.config['urb_siti']
            campo_urb = self.config['campo_urb_siti']
            
            self.parent_dialog.log_mensaje(f"   🆕 Creando urbanización '{nombre_urb}' desde polígonos...", paso=3)
            
            # Obtener centroides de todos los predios
            capa_predios = self.config['predios_siti']
            puntos_predios = []
            
            for fid in fids_predios:
                feat = capa_predios.getFeature(fid)
                geom = feat.geometry()
                if not geom.isEmpty():
                    puntos_predios.append(geom.centroid().asPoint())
            
            # Buscar polígonos de poligonizada que contienen los predios
            fids_poligonos_encontrados = set()
            
            for punto in puntos_predios:
                bbox = QgsRectangle(punto.x()-0.0001, punto.y()-0.0001, 
                                   punto.x()+0.0001, punto.y()+0.0001)
                ids_candidatos = self.index_poligonizada.intersects(bbox)
                
                for fid_pol in ids_candidatos:
                    if self.geom_poligonizada[fid_pol].contains(punto):
                        fids_poligonos_encontrados.add(fid_pol)
            
            if not fids_poligonos_encontrados:
                self.parent_dialog.log_mensaje(f"      ⚠️ No se encontraron polígonos en capa poligonizada", paso=3)
                return False
            
            self.parent_dialog.log_mensaje(f"      📍 {len(fids_poligonos_encontrados)} polígonos encontrados", paso=3)
            
            # UNIR TODOS LOS POLÍGONOS EN UNO SOLO (dissolve)
            geometrias = []
            for fid_pol in fids_poligonos_encontrados:
                geometrias.append(self.geom_poligonizada[fid_pol])
            
            # Combinar geometrías
            geom_unida = QgsGeometry.unaryUnion(geometrias)
            
            # CRÍTICO: Verificar que NO sea multipolígono
            if geom_unida.isMultipart():
                self.parent_dialog.log_mensaje(f"      ⚠️ Resultado es multipolígono, tomando parte más grande...", paso=3)
                
                partes = geom_unida.asMultiPolygon()
                if not partes:
                    partes = geom_unida.asGeometryCollection()
                
                geom_mas_grande = None
                area_maxima = 0
                
                for parte in partes:
                    geom_parte = QgsGeometry.fromPolygonXY(parte)
                    area = geom_parte.area()
                    if area > area_maxima:
                        area_maxima = area
                        geom_mas_grande = geom_parte
                
                if geom_mas_grande:
                    geom_unida = geom_mas_grande
                else:
                    self.parent_dialog.log_mensaje(f"      ❌ No se pudo crear polígono único", paso=3)
                    return False
            
            # VERIFICAR: No debe contener totalmente otro polígono existente
            for feat_existente in capa_urb_siti.getFeatures():
                geom_existente = feat_existente.geometry()
                
                if geom_unida.contains(geom_existente):
                    self.parent_dialog.log_mensaje(f"      ⚠️ El polígono contendría totalmente a '{feat_existente[campo_urb]}'. No se creará.", paso=3)
                    return False
                
                if geom_existente.contains(geom_unida):
                    self.parent_dialog.log_mensaje(f"      ⚠️ El polígono estaría totalmente dentro de '{feat_existente[campo_urb]}'. No se creará.", paso=3)
                    return False
            
            # OBTENER EL PRÓXIMO ID DISPONIBLE
            max_id = 0
            idx_id = capa_urb_siti.fields().indexOf('id')
            
            if idx_id != -1:
                for feat in capa_urb_siti.getFeatures():
                    valor_id = feat['id']
                    if valor_id is not None:
                        try:
                            id_num = int(valor_id)
                            if id_num > max_id:
                                max_id = id_num
                        except:
                            pass
                
                nuevo_id = max_id + 1
                self.parent_dialog.log_mensaje(f"      📝 Asignando ID: {nuevo_id}", paso=3)
            else:
                nuevo_id = None
                self.parent_dialog.log_mensaje(f"      ⚠️ Campo 'id' no encontrado, se creará sin ID", paso=3)
            
            # CREAR EL NUEVO FEATURE
            if not capa_urb_siti.isEditable():
                capa_urb_siti.startEditing()
            
            nuevo_feat = QgsFeature(capa_urb_siti.fields())
            nuevo_feat.setGeometry(geom_unida)
            
            # Establecer el ID (si existe el campo)
            if idx_id != -1 and nuevo_id is not None:
                nuevo_feat.setAttribute(idx_id, nuevo_id)
            
            # Establecer el nombre
            idx_nombre = capa_urb_siti.fields().indexOf(campo_urb)
            if idx_nombre != -1:
                nuevo_feat.setAttribute(idx_nombre, nombre_urb)
            
            # COPIAR OTROS CAMPOS DEL PRIMER POLÍGONO FUENTE
            if fids_poligonos_encontrados:
                feat_fuente = capa_poligonizada.getFeature(list(fids_poligonos_encontrados)[0])
                
                for field in capa_urb_siti.fields():
                    nombre_campo = field.name()
                    
                    # Saltar campos especiales
                    if nombre_campo.lower() in ['id', 'fid', campo_urb.lower(), 'geom', 'geometry']:
                        continue
                    
                    # Si existe en la fuente, copiar
                    idx_fuente = capa_poligonizada.fields().indexOf(nombre_campo)
                    if idx_fuente != -1:
                        valor = feat_fuente[nombre_campo]
                        idx_destino = capa_urb_siti.fields().indexOf(nombre_campo)
                        if idx_destino != -1:
                            nuevo_feat.setAttribute(idx_destino, valor)
            
            # Agregar a la capa
            resultado = capa_urb_siti.addFeature(nuevo_feat)
            
            if not resultado:
                self.parent_dialog.log_mensaje(f"      ❌ addFeature() retornó False", paso=3)
                capa_urb_siti.rollBack()
                return False
            
            if capa_urb_siti.commitChanges():
                self.parent_dialog.log_mensaje(f"      ✅ Urbanización '{nombre_urb}' creada exitosamente (ID: {nuevo_id})", paso=3)
                
                # Actualizar índices
                self.index_urb = QgsSpatialIndex(capa_urb_siti.getFeatures())
                self.geom_urb = {}
                for feat in capa_urb_siti.getFeatures():
                    self.geom_urb[feat.id()] = feat.geometry()
                
                return True
            else:
                errores = capa_urb_siti.commitErrors()
                self.parent_dialog.log_mensaje(f"      ❌ Error al crear: {errores}", paso=3)
                capa_urb_siti.rollBack()
                return False
            
        except Exception as e:
            self.parent_dialog.log_mensaje(f"   ❌ ERROR creando urbanización: {str(e)}", paso=3)
            import traceback
            self.parent_dialog.log_mensaje(f"   {traceback.format_exc()}", paso=3)
            
            try:
                if capa_urb_siti.isEditable():
                    capa_urb_siti.rollBack()
            except:
                pass
            
            return False
    
    def aceptar(self):
        """Guardar cambios y avanzar"""
        try:
            cambios = {}
            
            # Detectar cambios
            if self.txt_barrios_siti.text() != self.valores_orig['barrios_siti']:
                cambios['barrios_siti'] = self.txt_barrios_siti.text()
            
            if self.txt_urb_siti.text() != self.valores_orig['urb_siti']:
                cambios['urb_siti'] = self.txt_urb_siti.text()
            
            if self.txt_via.text() != self.valores_orig['via']:
                cambios['via'] = self.txt_via.text()
            
            if self.txt_fecha.text().strip() != self.valores_orig['fecha']:
                cambios['fecha'] = self.txt_fecha.text().strip()
            
            if self.txt_version.text().strip() != self.valores_orig['version']:
                cambios['version'] = self.txt_version.text().strip()
            
            if self.txt_marca.text().strip() != self.valores_orig['marca']:
                cambios['marca'] = self.txt_marca.text().strip()
            
            # CRÍTICO: Si el campo urbanización está vacío Y se ingresó un valor, crear urbanización
            if 'urb_siti' in cambios and self.valores_orig['urb_siti'].strip() == "" and cambios['urb_siti'].strip() != "":
                grupo = self.grupos[self.indice_actual]
                fids = grupo['fids']
                nombre_nueva_urb = cambios['urb_siti']
                
                # Intentar crear la urbanización
                if self.crear_urbanizacion_desde_poligonos(fids, nombre_nueva_urb):
                    self.parent_dialog.log_mensaje(f"   🎉 Urbanización creada con éxito", paso=3)
                else:
                    self.parent_dialog.log_mensaje(f"   ⚠️ No se pudo crear urbanización, se continuará sin crearla", paso=3)
            
            if cambios:
                self.aplicar_cambios(cambios)
                self.parent_dialog.log_mensaje(f"✅ Grupo {self.indice_actual + 1}: Guardado", paso=3)
            
            self.indice_actual += 1
            self.cargar_grupo_actual()
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error al guardar:\n{str(e)}")
            import traceback
            self.parent_dialog.log_mensaje(f"❌ ERROR: {traceback.format_exc()}", paso=3)
    
    def aplicar_cambios(self, cambios):
        """Aplicar cambios a las capas"""
        try:
            grupo = self.grupos[self.indice_actual]
            fids = grupo['fids']
            fid_pol = grupo['fid_pol']
            tipo_pol = grupo['tipo_pol']
            
            # CAMBIOS EN PREDIOS
            if any(k in cambios for k in ['via', 'fecha', 'version', 'marca']):
                capa = self.config['predios_siti']
                
                idx_via = capa.fields().indexOf(self.config['campo_predios'])
                idx_fecha = capa.fields().indexOf(self.config['campo_fecha'])
                idx_version = capa.fields().indexOf(self.config['campo_version'])
                idx_marca = capa.fields().indexOf(self.config['campo_marca'])
                
                if not capa.isEditable():
                    capa.startEditing()
                
                for fid in fids:
                    if 'via' in cambios and idx_via != -1:
                        capa.changeAttributeValue(fid, idx_via, cambios['via'])
                    if 'fecha' in cambios and idx_fecha != -1:
                        capa.changeAttributeValue(fid, idx_fecha, cambios['fecha'] if cambios['fecha'] else None)
                    if 'version' in cambios and idx_version != -1:
                        capa.changeAttributeValue(fid, idx_version, cambios['version'] if cambios['version'] else None)
                    if 'marca' in cambios and idx_marca != -1:
                        capa.changeAttributeValue(fid, idx_marca, cambios['marca'] if cambios['marca'] else None)
                
                capa.commitChanges()
            
            # CAMBIOS EN BARRIOS SITI
            if 'barrios_siti' in cambios and tipo_pol == 'barrio':
                capa = self.config['barrios_siti']
                idx = capa.fields().indexOf(self.config['campo_barrios_siti'])
                
                if idx != -1:
                    if not capa.isEditable():
                        capa.startEditing()
                    capa.changeAttributeValue(fid_pol, idx, cambios['barrios_siti'])
                    capa.commitChanges()
            
            # CAMBIOS EN URBANIZACIONES SITI
            if 'urb_siti' in cambios and tipo_pol == 'urb':
                capa = self.config['urb_siti']
                idx = capa.fields().indexOf(self.config['campo_urb_siti'])
                
                if idx != -1:
                    if not capa.isEditable():
                        capa.startEditing()
                    capa.changeAttributeValue(fid_pol, idx, cambios['urb_siti'])
                    capa.commitChanges()
            
            self.iface.mapCanvas().refresh()
            
        except Exception as e:
            self.parent_dialog.log_mensaje(f"❌ ERROR: {str(e)}", paso=3)
    
    def siguiente(self):
        """Siguiente grupo sin guardar"""
        self.parent_dialog.log_mensaje(f"⏭️ Grupo {self.indice_actual + 1}: Omitido", paso=3)
        self.indice_actual += 1
        self.cargar_grupo_actual()