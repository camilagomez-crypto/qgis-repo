# -*- coding: utf-8 -*-

def classFactory(iface):
    from .plugin_validador import PluginValidador
    return PluginValidador(iface)