import webbrowser
from urllib.parse import unquote, urlparse, parse_qs, quote
from qgis.PyQt.QtCore import Qt, QUrl, QTimer, QSize
from qgis.PyQt.QtGui import QIcon, QColor, QFont
from qgis.PyQt.QtWidgets import (QAction, QComboBox, QDialog, QVBoxLayout, QHBoxLayout,
                                     QPushButton, QLabel, QListWidget, QListWidgetItem, 
                                     QFrame, QLineEdit, QProgressBar, QApplication)
from qgis.PyQt.QtWebEngineWidgets import QWebEngineView

# =========================================================
# BASE DE DATOS TOTAL DE COLOMBIA (1.122 MUNICIPIOS)
# =========================================================
DATA_COLOMBIA = {
    "AMAZONAS": ["LETICIA", "EL ENCANTO", "LA CHORRERA", "LA PEDRERA", "LA VICTORIA", "MIRITIPARANA", "PUERTO ALEGRIA", "PUERTO ARICA", "PUERTO NARIÑO", "PUERTO SANTANDER", "TARAPACA"],
    "ANTIOQUIA": ["MEDELLIN", "ABEJORRAL", "ABRIAQUI", "ALEJANDRIA", "AMAGA", "AMALFI", "ANDES", "ANGELOPOLIS", "ANGOSTURA", "ANORI", "ANZA", "APARTADO", "ARBOLETES", "ARGELIA", "ARMENIA", "BARBOSA", "BELLO", "BELMIRA", "BETANIA", "BETULIA", "BRICEÑO", "BURITICA", "CACERES", "CAICEDO", "CALDAS", "CAMPAMENTO", "CAÑASGORDAS", "CARACOLI", "CARAMANTA", "CAREPA", "CARMEN DE VIBORAL", "CAROLINA", "CAUCASIA", "CHIGORODO", "CISNEROS", "CIUDAD BOLIVAR", "CONCEPCION", "CONCORDIA", "COPACABANA", "DABEIBA", "DONMATIAS", "EBEJICO", "EL BAGRE", "EL CARMEN DE VIBORAL", "EL SANTUARIO", "ENTRERRIOS", "ENVIGADO", "FREDONIA", "FRONTINO", "GIRALDO", "GIRARDOTA", "GOMEZ PLATA", "GRANADA", "GUADALUPE", "GUARNE", "GUATAPE", "HELICONIA", "HISPANIA", "ITAGUI", "ITUANGO", "JARDIN", "JERICO", "LA CEJA", "LA ESTRELLA", "LA PINTADA", "LA UNION", "LIBORINA", "MACEO", "MARINILLA", "MONTEBELLO", "MURINDO", "MUTATA", "NARIÑO", "NECHI", "NECOCLI", "OLAYA", "PEÑOL", "PEQUE", "PUEBLORRICO", "PUERTO BERRIO", "PUERTO NARE", "PUERTO TRIUNFO", "REMEDIOS", "RETIRO", "RIONEGRO", "SABANALARGA", "SABANETA", "SALGAR", "SAN ANDRES DE CUERQUIA", "SAN CARLOS", "SAN FRANCISCO", "SAN JERONIMO", "SAN JOSE DE LA MONTAÑA", "SAN JUAN DE URABA", "SAN LUIS", "SAN PEDRO DE LOS MILAGROS", "SAN PEDRO DE URABA", "SAN RAFAEL", "SAN ROQUE", "SAN VICENTE FERRER", "SANTA BARBARA", "SANTA FE DE ANTIOQUIA", "SANTA ROSA DE OSOS", "SANTO DOMINGO", "SEGOVIA", "SONSON", "SOPETRAN", "TAMESIS", "TARAZA", "TARSO", "TITIRIBI", "TOLEDO", "TURBO", "URAMITA", "URRAO", "VALDIVIA", "VALPARAISO", "VEGACHI", "VENECIA", "VIGIA DEL FUERTE", "YALI", "YARUMAL", "YOLOMBO", "YONDO", "ZARAGOZA"],
    "ARAUCA": ["ARAUCA", "ARAUQUITA", "CRAVO NORTE", "FORTUL", "PUERTO RONDON", "SARAVENA", "TAME"],
    "ATLANTICO": ["BARRANQUILLA", "BARANOA", "CAMPO DE LA CRUZ", "CANDELARIA", "GALAPA", "JUAN DE ACOSTA", "LURUACO", "MALAMBO", "MANATI", "PALMAR DE VARELA", "PIOJO", "POLONUEVO", "PONEDERA", "PUERTO COLOMBIA", "REPELON", "SABANAGRANDE", "SABANALARGA", "SANTA LUCIA", "SANTO TOMAS", "SOLEDAD", "SUAN", "TUBARA", "USIACURI"],
    "BOGOTA D.C.": ["BOGOTA D.C."],
    "BOLIVAR": ["CARTAGENA", "ACHI", "ALTOS DEL ROSARIO", "ARENAL", "ARJONA", "ARROYOHONDO", "BARRANCO DE LOBA", "CALAMAR", "CANTAGALLO", "CICUCO", "CLEMENCIA", "CORDOBA", "EL CARMEN DE BOLIVAR", "EL GUAMO", "EL PEÑON", "HATILLO DE LOBA", "MAGANGUE", "MAHATES", "MARGARITA", "MARIA LA BAJA", "MONTECRISTO", "MORALES", "NOROSI", "PINILLOS", "REGIDOR", "RIO VIEJO", "SAN CRISTOBAL", "SAN ESTANISLAO", "SAN FERNANDO", "SAN JACINTO", "SAN JACINTO DEL CAUCA", "SAN JUAN NEPOMUCENO", "SAN MARTIN DE LOBA", "SAN PABLO", "SANTA CATALINA", "SANTA ROSA", "SANTA ROSA DEL SUR", "SIMITI", "SOPLAVIENTO", "TALAIGUA NUEVO", "TIQUISIO", "TURBACO", "TURBANA", "VILLANUEVA", "ZAMBRANO"],
    "BOYACA": ["TUNJA", "ALMEIDA", "AQUITANIA", "ARCABUCO", "BELEN", "BERBEO", "BETEITIVA", "BOAVITA", "BOYACA", "BRICEÑO", "BUENAVISTA", "BUSBANZA", "CALDAS", "CAMPOHERMOSO", "CERINZA", "CHINAVITA", "CHIQUINQUIRA", "CHIQUIZA", "CHISCAS", "CHITA", "CHITARAQUE", "CHIVATA", "CHIVOR", "CIENEGA", "COMBITA", "COPER", "CORRALES", "COVARACHIA", "CUBARA", "CUCAITA", "CUITIVA", "DUITAMA", "EL COCUY", "EL ESPINO", "FIRAVITOBA", "FLORESTA", "GACHANTIVA", "GAMEZA", "GARAGOA", "GUACAMAYAS", "GUATEQUE", "GUAYATA", "GUICAN", "IZA", "JENESANO", "JERICO", "LABRANZAGRANDE", "LA CAPILLA", "LA UVITA", "LA VICTORIA", "MACANAL", "MARIPI", "MIRAFLORES", "MONGUA", "MONGUI", "MONIQUIRA", "MOTAVITA", "MUZO", "NOBSA", "NUEVO COLON", "OICATA", "OTANCHE", "PACHAVITA", "PAEZ", "PAIPA", "PAJARITO", "PANQUEBA", "PAUNA", "PAYA", "PAZ DE RIO", "PESCA", "PISBA", "PUERTO BOYACA", "QUIPAMA", "RAMIRIQUI", "RAQUIRA", "RONDON", "SABOYA", "SACHICA", "SAMACA", "SAN EDUARDO", "SAN JOSE DE PARE", "SAN LUIS DE GACENO", "SAN MATEO", "SAN MIGUEL DE SEMA", "SAN PABLO DE BORBUR", "SANTA MARIA", "SANTA ROSA DE VITERBO", "SANTA SOFIA", "SANTANA", "SATIVANORTE", "SATIVASUR", "SIACHOQUE", "SOATA", "SOCOTA", "SOCHA", "SOGAMOSO", "SOMONDOCO", "SORA", "SORACA", "SOTAQUIRA", "SUSACON", "SUTAMARCHAN", "SUTATENZA", "TASCO", "TENZA", "TIBANA", "TIBASOSA", "TINJACA", "TIPACOQUE", "TOCA", "TOGUI", "TOPAGA", "TOTA", "TUNUNGUA", "TURMEQUE", "TUTA", "TUTAZA", "UMBITA", "VENTAQUEMADA", "VILLA DE LEYVA", "VIRACACHA", "ZETAQUIRA"],
    "CALDAS": ["MANIZALES", "AGUADAS", "ANSERMA", "ARANZAZU", "BELALCAZAR", "CHINCHINA", "FILADELFIA", "LA DORADA", "LA MERCED", "MANZANARES", "MARMATO", "MARQUETALIA", "MARULANDA", "NEIRA", "NORCASIA", "PACORA", "PALESTINA", "PENSILVANIA", "RIOSUCIO", "RISARALDA", "SALAMINA", "SAMANA", "SAN JOSE", "SUPIA", "VICTORIA", "VILLAMARIA", "VITERBO"],
    "CAQUETA": ["FLORENCIA", "ALBANIA", "BELEN DE LOS ANDAQUIES", "CARTAGENA DEL CHAIRA", "CURILLO", "EL DONCELLO", "EL PAUJIL", "LA MONTAÑITA", "MILAN", "MORELIA", "PUERTO RICO", "SAN JOSE DEL FRAGUA", "SAN VICENTE DEL CAGUAN", "SOLANO", "SOLITA", "VALPARAISO"],
    "CASANARE": ["YOPAL", "AGUAZUL", "CHAMEZA", "HATO COROZAL", "LA SALINA", "MANI", "MONTERREY", "NUNCHIA", "OROCUE", "PAZ DE ARIPORO", "PORE", "RECETOR", "SABANALARGA", "SACAMA", "SAN LUIS DE PALENQUE", "TAMARA", "TAURAMENA", "TRINIDAD", "VILLANUEVA"],
    "CAUCA": ["POPAYAN", "ALMAGUER", "ARGELIA", "BALBOA", "BOLIVAR", "BUENOS AIRES", "CAJIBIO", "CALDONO", "CALOTO", "CORINTO", "EL TAMBO", "FLORENCIA", "GUACHENE", "GUAPI", "INZA", "JAMBALO", "LA SIERRA", "LA VEGA", "LOPEZ DE MICAY", "MERCADERES", "MIRANDA", "MORALES", "PADILLA", "PAEZ", "PATIA", "PIAMONTE", "PIENDAMO - TUNIA", "PUERTO TEJADA", "PURACE", "ROSAS", "SAN SEBASTIAN", "SANTA ROSA", "SANTANDER DE QUILICHAO", "SILVIA", "SOTARA", "SUAREZ", "SUCRE", "TIMBIO", "TIMBIQUI", "TORIBIO", "TOTORO", "VILLA RICA"],
    "CESAR": ["VALLEDUPAR", "AGUACHICA", "AGUSTIN CODAZZI", "ASTREA", "BECERRIL", "BOSCONIA", "CHIMICHAGUA", "CHIRIGUANA", "CURUMANI", "EL COPEY", "EL PASO", "GAMARRA", "GONZALEZ", "LA GLORIA", "LA JAGUA DE IBIRICO", "LA PAZ", "MANAURE BALCON DEL CESAR", "PAILITAS", "PELAYA", "PUEBLO BELLO", "RIO DE ORO", "SAN ALBERTO", "SAN DIEGO", "SAN MARTIN", "TAMALAMEQUE"],
    "CHOCO": ["QUIBDO", "ACANDI", "ALTO BAUDO", "ATRATO", "BAGADO", "BAHIA SOLANO", "BAJO BAUDO", "BOJAYA", "CANTON DE SAN PABLO", "CARMEN DEL DARIEN", "CERTEGUI", "CONDOTO", "EL CARMEN DE ATRATO", "EL LITORAL DEL SAN JUAN", "ISTMINA", "JURADO", "LLORO", "MEDIO ATRATO", "MEDIO BAUDO", "MEDIO SAN JUAN", "NOVITA", "NUQUI", "RIO IRO", "RIO QUITO", "RIOSUCIO", "SAN JOSE DEL PALMAR", "SIPI", "TADO", "UNGUIA", "UNION PANAMERICANA"],
    "CORDOBA": ["MONTERIA", "AYAPEL", "BUENAVISTA", "CANALETE", "CERETE", "CHIMA", "CHINU", "CIENAGA DE ORO", "COTORRA", "LA APARTADA", "LORICA", "LOS CORDOBAS", "MOMIL", "MOÑITOS", "PLANETA RICA", "PUEBLO NUEVO", "PUERTO ESCONDIDO", "PUERTO LIBERTADOR", "PURISIMA", "SAHAGUN", "SAN ANDRES DE SOTAVENTO", "SAN ANTERO", "SAN BERNARDO DEL VIENTO", "SAN CARLOS", "SAN JOSE DE URE", "SAN PELAYO", "TIERRALTA", "TUCHIN", "VALENCIA"],
    "CUNDINAMARCA": ["BOGOTA", "AGUA DE DIOS", "ALBAN", "ANAPOIMA", "ANOLAIMA", "APULO", "ARBELAEZ", "BELTRAN", "BITUIMA", "BOJACA", "CABRERA", "CACHIPAY", "CAJICA", "CAPARRAPI", "CAQUEZA", "CARMEN DE CARUPA", "CHAGUANI", "CHIA", "CHIPAQUE", "CHOACHI", "CHOCONTA", "COGUA", "COTA", "CUCUNUBA", "EL COLEGIO", "EL PEÑON", "EL ROSAL", "FACATATIVA", "FOMEQUE", "FOSCA", "FUNZA", "FUQUENE", "FUSAGASUGA", "GACHALA", "GACHANCIPA", "GACHETA", "GAMA", "GIRARDOT", "GRANADA", "GUACHETA", "GUADUAS", "GUASCA", "GUATAQUI", "GUATAVITA", "GUAYABAL DE SIQUIMA", "GUAYABETAL", "GUTIERREZ", "JERUSALEN", "JUNIN", "LA CALERA", "LA MESA", "LA PALMA", "LA PEÑA", "LA VEGA", "LENGUAZAQUE", "MACHETA", "MADRID", "MANTA", "MEDINA", "MOSQUERA", "NARIÑO", "NEMOCON", "NILO", "NIMAIMA", "NOCAIMA", "PACHO", "PAIME", "PANDI", "PARATEBUENO", "PASCA", "PUERTO SALGAR", "PULI", "QUEBRADANEGRA", "QUETAME", "QUIPILE", "RICAURTE", "SAN ANTONIO DEL TEQUENDAMA", "SAN BERNARDO", "SAN CAYETANO", "SAN FRANCISCO", "SAN JUAN DE RIOSECO", "SASAIMA", "SESQUILE", "SIBATE", "SOACHA", "SOPO", "SUBACHOQUE", "SUESCA", "SUPATA", "SUSA", "SUTATAUSA", "TABIO", "TAUSA", "TENA", "TENJO", "TIBACUY", "TIBIRITA", "TOCAIMA", "TOCANCIPA", "TOPAIPI", "UBALA", "UBAQUE", "UBATE", "UNE", "UTICA", "VENECIA", "VERGARA", "VIANI", "VILLAGOMEZ", "VILLAPINZON", "VILLETA", "VIOTA", "YACOPI", "ZIPACON", "ZIPAQUIRA"],
    "HUILA": ["NEIVA", "ACEVEDO", "AGRADO", "AIPE", "ALGECIRAS", "ALTAMIRA", "BARAYA", "CAMPOALEGRE", "COLOMBIA", "ELIAS", "GARZON", "GIGANTE", "GUADALUPE", "HOBO", "IQUIRA", "ISNOS", "LA ARGENTINA", "LA PLATA", "NATAGA", "OPORAPA", "PAICOL", "PALERMO", "PALESTINA", "PITAL", "PITALITO", "RIVERA", "SALADOBLANCO", "SAN AGUSTIN", "SANTA MARIA", "SUAZA", "TARQUI", "TESALIA", "TELLO", "TERUEL", "TIMANA", "VILLAVIEJA", "YAGUARA"],
    "LA GUAJIRA": ["RIOHACHA", "ALBANIA", "BARRANCAS", "DIBULLA", "DISTRACCION", "EL MOLINO", "FONSECA", "HATONUEVO", "LA JAGUA DEL PILAR", "MAICAO", "MANAURE", "SAN JUAN DEL CESAR", "URIBIA", "URUMITA", "VILLANUEVA"],
    "MAGDALENA": ["SANTA MARTA", "ALGARROBO", "ARACATACA", "ARIGUANI", "CERRO SAN ANTONIO", "CHIBOLO", "CIENAGA", "CONCORDIA", "EL BANCO", "EL PIÑON", "EL RETEN", "FUNDACION", "GUAMAL", "NUEVA GRANADA", "PEDRAZA", "PIJIÑO DEL CARMEN", "PIVIJAY", "PLATO", "PUEBLOVIEJO", "REMOLINO", "SABANAS DE SAN ANGEL", "SALAMINA", "SAN SEBASTIAN DE BUENAVISTA", "SAN ZENON", "SANTA ANA", "SANTA BARBARA DE PINTO", "SITIONUEVO", "TENERIFE", "ZAPAYAN", "ZONA BANANERA"],
    "META": ["VILLAVICENCIO", "ACACIAS", "BARRANCA DE UPIA", "CABUYARO", "CASTILLA LA NUEVA", "CUBARRAL", "CUMARAL", "EL CALVARIO", "EL CASTILLO", "EL DORADO", "FUENTE DE ORO", "GRANADA", "GUAMAL", "LA MACARENA", "LEJANIAS", "MAPIRIPAN", "MESETAS", "PUERTO CONCORDIA", "PUERTO GAITAN", "PUERTO LOPEZ", "PUERTO LLERAS", "PUERTO RICO", "RESTREPO", "SAN CARLOS DE GUAROA", "SAN JUAN DE ARAMA", "SAN JUANITO", "SAN MARTIN", "URIBE", "VISTAHERMOSA"],
    "NARIÑO": ["PASTO", "ALBAN", "ALDANA", "ANCUYA", "ARBOLEDA", "BARBACOAS", "BELEN", "BUESACO", "COLON", "CONSACA", "CONTADERO", "CORDOBA", "CUASPUD", "CUMBAL", "CUMBITARA", "CHACHAGUI", "EL CHARCO", "EL PEÑOL", "EL ROSARIO", "EL TABLON DE GOMEZ", "EL TAMBO", "FUNES", "GUACHUCAL", "GUAITARILLA", "GUALMATAN", "ILES", "IMUES", "IPIALES", "LA CRUZ", "LA FLORIDA", "LA LLANADA", "LA TOLA", "LA UNION", "LEIVA", "LINARES", "LOS ANDES", "MAGUI", "MALLAMA", "MOSQUERA", "OLAYA HERRERA", "OSPINA", "FRANCISCO PIZARRO", "POLICARPA", "POTOSI", "PROVIDENCIA", "PUERRES", "PUPIALES", "RICAURTE", "ROBERTO PAYAN", "SAMANIEGO", "SANDONA", "SAN BERNARDO", "SAN LORENZO", "SAN PABLO", "SAN PEDRO DE CARTAGO", "SANTA BARBARA", "SANTACRUZ", "SAPUYES", "TAMINANGO", "TANGUA", "TUMACO", "TUQUERRES", "YACUANQUER"],
    "NORTE DE SANTANDER": ["CUCUTA", "ABREGO", "ARBOLEDAS", "BOCHALEMA", "BUCARASICA", "CACOTA", "CACHIRA", "CHINACOTA", "CHITAGA", "CONVENCION", "CUCUTILLA", "DURANIA", "EL CARMEN", "EL TARRA", "EL ZULIA", "GRAMALOTE", "HACARI", "HERRAN", "LA ESPERANZA", "LA PLAYA", "LABATECA", "LOURDES", "MUTISCUA", "OCAÑA", "PAMPLONA", "PAMPLONITA", "PUERTO SANTANDER", "RAGONVALIA", "SALAZAR", "SAN CALIXTO", "SAN CAYETANO", "SANTIAGO", "SARDINATA", "SILOS", "TEORAMA", "TIBU", "TOLEDO", "VILLA CARO", "VILLA DEL ROSARIO"],
    "QUINDIO": ["ARMENIA", "BUENAVISTA", "CALARCA", "CIRCASIA", "CORDOBA", "FILANDIA", "GENOVA", "LA TEBAIDA", "MONTENEGRO", "PIJAO", "QUIMBAYA", "SALENTO"],
    "RISARALDA": ["PEREIRA", "APIA", "BALBOA", "BELEN DE UMBRIA", "DOSQUEBRADAS", "GUATICA", "LA CELIA", "LA VIRGINIA", "MARSELLA", "MISTRATO", "PUEBLO RICO", "QUINCHIA", "SANTA ROSA DE CABAL", "SANTUARIO"],
    "SANTANDER": ["BUCARAMANGA", "AGUADA", "ALBANIA", "ARATOCA", "BARBOSA", "BARICHARA", "BARRANCABERMEJA", "BETULIA", "BOLIVAR", "CABRERA", "CARCASI", "CEPITA", "CERRITO", "CHARALA", "CHARTA", "CHIMA", "CHIPATA", "CIMITARRA", "CONCEPCION", "CONFINES", "CONTRATACION", "COROMORO", "CURITI", "EL CARMEN DE CHUCURI", "EL GUACAMAYO", "EL PEÑON", "EL PLAYON", "ENCINO", "ENCISO", "FLORIAN", "FLORIDABLANCA", "GALAN", "GAMBITA", "GIRON", "GUACA", "GUADALUPE", "GUAPOTA", "GUAVATA", "GUEPSA", "HATO", "JESUS MARIA", "JORDAN", "LA BELLEZA", "LA PAZ", "LANDAZURI", "LEBRIJA", "LOS SANTOS", "MACARAVITA", "MALAGA", "MATANZA", "MOGOTES", "MOLAGAVITA", "OCAMONTE", "OIBA", "ONZAGA", "PALMAR", "PALMAS DEL SOCORRO", "PARAMO", "PIEDECUESTA", "PINCHOTE", "PUENTE NACIONAL", "PUERTO PARRA", "PUERTO WILCHES", "RIONEGRO", "SABANA DE TORRES", "SAN ANDRES", "SAN BENITO", "SAN GIL", "SAN JOAQUIN", "SAN JOSE DE MIRANDA", "SAN MIGUEL", "SAN VICENTE DE CHUCURI", "SANTA BARBARA", "SANTA HELENA DEL OPON", "SIMACOTA", "SOCORRO", "SUAITA", "SUCRE", "SURATA", "TONA", "VALDE SAN JUAN", "VENADILLO", "VILLAHERMOSA", "VILLARRICA"],
    "SUCRE": ["SINCELEJO", "BUENAVISTA", "CAIMITO", "COLOSO", "COROZAL", "COVEÑAS", "CHALAN", "EL ROBLE", "GALERAS", "GUARANDA", "LA UNION", "LOS PALMITOS", "MAJAGUAL", "MORROA", "OVEJAS", "PALMITO", "SAMPUES", "SAN BENITO ABAD", "SAN JUAN DE BETULIA", "SAN MARCOS", "SAN ONOFRE", "SAN PEDRO", "SINCE", "TOLU", "TOLU VIEJO"],
    "TOLIMA": ["IBAGUE", "ALPUJARRA", "ALVARADO", "AMBALEMA", "ANZOATEGUI", "ARMERO", "ATACO", "CAJAMARCA", "CARMEN DE APICALA", "CASABIANCA", "CHAPARRAL", "COELLO", "COYAIMA", "CUNDAY", "DOLORES", "ESPINAL", "FALAN", "FLANDES", "FRESNO", "GUAMO", "HERVEO", "HONDA", "ICONONZO", "LERIDA", "LIBANO", "MARIQUITA", "MELGAR", "MURILLO", "NATAGAIMA", "ORTEGA", "PALOCABILDO", "PLANADAS", "PRADO", "PURIFICACION", "RIOBLANCO", "RONCESVALLES", "ROVIRA", "SALDAÑA", "SAN ANTONIO", "SAN LUIS", "SANTA ISABEL", "SUAREZ", "VALLE DE SAN JUAN", "VENADILLO", "VILLAHERMOSA", "VILLARRICA"],
    "VALLE DEL CAUCA": ["CALI", "ALCALA", "ANDALUCIA", "ANSERMANUEVO", "ARGELIA", "BOLIVAR", "BUENAVENTURA", "BUGALAGRANDE", "CAICEDONIA", "CALIMA", "CANDELARIA", "CARTAGO", "DAGUA", "EL AGUILA", "EL CAIRO", "EL CERRITO", "EL DOVIO", "FLORIDA", "GINEBRA", "GUACARI", "GUADALAJARA DE BUGA", "JAMUNDI", "LA CUMBRE", "LA UNION", "LA VICTORIA", "OBANDO", "PALMIRA", "PRADERA", "RESTREPO", "RIOFRIO", "ROLDANILLO", "SAN PEDRO", "SEVILLA", "TORO", "TRUJILLO", "TULUA", "ULLOA", "VERSALLES", "VIJES", "YOTOCO", "YUMBO", "ZARZAL"],
    "GUAINIA": ["INIRIDA", "BARRANCO MINAS", "MAPIRIPANA", "SAN FELIPE", "PUERTO COLOMBIA", "LA GUADALUPE", "CACAHUAL", "PANA PANA", "MORICHAL"],
    "GUAVIARE": ["SAN JOSE DEL GUAVIARE", "CALAMAR", "EL RETORNO", "MIRAFLORES"],
    "PUTUMAYO": ["MOCOA", "COLON", "ORITO", "PUERTO ASIS", "PUERTO CAICEDO", "PUERTO GUZMAN", "PUERTO LEGUIZAMO", "SIBUNDOY", "SAN FRANCISCO", "SAN MIGUEL", "SANTIAGO", "VALLE DEL GUAMUEZ", "VILLAGARZON"],
    "SAN ANDRES": ["SAN ANDRES", "PROVIDENCIA"],
    "VAUPES": ["MITU", "CARURU", "PACOA", "TARAIRA", "PAPUNAUA", "YAVARATE"],
    "VICHADA": ["PUERTO CARREÑO", "LA PRIMAVERA", "SANTA ROSALIA", "CUMARIBO"]
}

class BuscadorVisoresPlugin:
    def __init__(self, iface):
        self.iface = iface

    def initGui(self):
        icon_path = ':/images/themes/default/mActionSearch.svg'
        self.action = QAction(QIcon(icon_path), "Rastreador Colombia Pro", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action: self.iface.removeToolBarIcon(self.action)

    def run(self):
        self.dlg = QDialog(self.iface.mainWindow())
        self.dlg.setWindowTitle("RASTREADOR GEO-COLOMBIA v6.0 (GEOINT)")
        self.dlg.setMinimumSize(1100, 800)
        
        # --- DARK THEME PROFESIONAL ---
        self.dlg.setStyleSheet("""
            QDialog { background-color: #121416; color: #e1e1e1; }
            QLabel { color: #8e949e; font-size: 8pt; font-weight: bold; text-transform: uppercase; }
            QComboBox { 
                background-color: #24272b; color: #ffffff; border: 1px solid #363a3f; 
                padding: 6px; border-radius: 4px; font-size: 10pt;
            }
            QLineEdit { 
                background-color: #1c1e21; color: #ffffff; border: 1px solid #363a3f; 
                padding: 10px; border-radius: 6px; font-size: 10pt;
            }
            QPushButton#btn_buscar {
                background-color: #0063b1; color: white; font-weight: bold; border-radius: 6px; padding: 12px; border: none;
            }
            QPushButton#btn_buscar:hover { background-color: #0078d4; }
            QPushButton#btn_extraer {
                background-color: #333333; color: #777; font-weight: bold; border-radius: 6px; padding: 12px; border: 1px solid #444;
            }
            QPushButton#btn_extraer:enabled {
                background-color: #107c10; color: white; border: none;
            }
            QProgressBar {
                border: 1px solid #333; border-radius: 5px; text-align: center; background-color: #0c0d0e; color: white;
            }
            QProgressBar::chunk { background-color: #0063b1; }
            QListWidget { background-color: #0c0d0e; border: 1px solid #24272b; border-radius: 10px; padding: 5px; }
            QListWidget::item { background-color: #1c1e21; margin-bottom: 8px; border-radius: 8px; border: 1px solid #2d3136; }
            QListWidget::item:hover { border: 1px solid #3a3f45; }
        """)
        
        main_layout = QVBoxLayout(self.dlg)
        main_layout.setContentsMargins(25, 25, 25, 25)
        main_layout.setSpacing(15)
        
        # --- FILA 1: SELECTORES ---
        geo_layout = QHBoxLayout()
        col_depto = QVBoxLayout(); col_depto.addWidget(QLabel("Departamento"))
        self.combo_depto = QComboBox(); self.combo_depto.addItems(sorted(DATA_COLOMBIA.keys()))
        self.combo_depto.currentTextChanged.connect(self.actualizar_municipios)
        col_depto.addWidget(self.combo_depto); geo_layout.addLayout(col_depto, 1)
        
        col_muni = QVBoxLayout(); col_muni.addWidget(QLabel("Municipio"))
        self.combo_muni = QComboBox(); self.combo_muni.setEditable(True)
        col_muni.addWidget(self.combo_muni); geo_layout.addLayout(col_muni, 1)
        
        col_mode = QVBoxLayout(); col_mode.addWidget(QLabel("Modo de Rastreo"))
        self.combo_mode = QComboBox()
        self.combo_mode.addItems(["CATASTRO / PREDIAL", "INFRAESTRUCTURA / REDES", "POT / ORDENAMIENTO"])
        col_mode.addWidget(self.combo_mode); geo_layout.addLayout(col_mode, 1)
        main_layout.addLayout(geo_layout)

        # --- BOTONES ---
        btns = QHBoxLayout()
        self.btn_1 = QPushButton("🔍 1. INICIAR BÚSQUEDA"); self.btn_1.setObjectName("btn_buscar")
        self.btn_1.clicked.connect(self.paso_1_buscar)
        
        self.btn_2 = QPushButton("⚡ 2. EXTRAER ENLACES"); self.btn_2.setObjectName("btn_extraer")
        self.btn_2.setEnabled(False) 
        self.btn_2.clicked.connect(self.paso_2_extraer)
        
        btns.addWidget(self.btn_1); btns.addWidget(self.btn_2)
        main_layout.addLayout(btns)

        # --- BARRA DE PROGRESO ---
        self.pbar = QProgressBar(); self.pbar.hide()
        main_layout.addWidget(self.pbar)

        # --- BARRA DE FILTRADO ---
        self.filtro_txt = QLineEdit(); self.filtro_txt.setPlaceholderText("🔍 Filtrar resultados obtenidos..."); self.filtro_txt.textChanged.connect(self.filtrar_resultados)
        main_layout.addWidget(self.filtro_txt)

        # --- LISTA DE RESULTADOS ---
        self.lista = QListWidget(); self.lista.itemDoubleClicked.connect(self.abrir_externo)
        main_layout.addWidget(self.lista)

        # Navegador invisible
        self.browser = QWebEngineView(); self.browser.setFixedHeight(1)
        self.browser.loadFinished.connect(self.notificar_carga_finalizada)
        main_layout.addWidget(self.browser)
        self.browser.page().profile().setHttpUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36")

        self.actualizar_municipios(self.combo_depto.currentText())
        self.dlg.show()

    def actualizar_municipios(self, depto):
        self.combo_muni.clear(); self.combo_muni.addItems(sorted(DATA_COLOMBIA.get(depto, [])))

    def paso_1_buscar(self):
        muni = self.combo_muni.currentText().upper(); depto = self.combo_depto.currentText().upper(); mode = self.combo_mode.currentText()
        self.lista.clear(); self.btn_2.setEnabled(False); self.pbar.show(); self.pbar.setRange(0, 0)
        
        modes_map = {
            "CATASTRO / PREDIAL": "(catastro OR predial OR manzanas OR barrios OR igac OR UAECD)",
            "INFRAESTRUCTURA / REDES": "(acueducto OR alcantarillado OR energia OR luz OR gas OR alumbrado OR redes)",
            "POT / ORDENAMIENTO": "(POT OR ordenamiento OR normativa OR urbanismo OR nomenclatura OR 'malla vial')"
        }
        query = f'"{muni}, {depto}" {modes_map[mode]} (geovisor OR arcgis OR geoportal OR rest) site:gov.co OR site:arcgis.com'
        self.browser.load(QUrl(f"https://www.google.com/search?q={quote(query)}"))
        self.lista.addItem("⏳ CONECTANDO CON LA NUBE... ESPERE A QUE EL BOTÓN SE ACTIVE.")

    def notificar_carga_finalizada(self, ok):
        self.pbar.hide()
        if ok:
            self.btn_2.setEnabled(True)
            self.btn_2.setText("⚡ 2. EXTRAER ENLACES (¡LISTO!)")
            self.lista.clear()
            item = QListWidgetItem("🔔 ¡BÚSQUEDA TERMINADA! YA PUEDE PRESIONAR EL BOTÓN 'EXTRAER'.")
            item.setForeground(QColor("#f1c40f"))
            font = QFont(); font.setBold(True); item.setFont(font)
            self.lista.addItem(item)

    def paso_2_extraer(self):
        script = "Array.from(document.querySelectorAll('a')).map(a => ({t: a.innerText, u: a.href}))"
        self.browser.page().runJavaScript(script, self.procesar_datos)
        self.btn_2.setText("⚡ 2. EXTRAER ENLACES")

    def filtrar_resultados(self, texto):
        for i in range(self.lista.count()):
            item = self.lista.item(i); widget = self.lista.itemWidget(item)
            if widget: 
                match = texto.lower() in widget.text().lower() or texto.lower() in str(item.data(Qt.UserRole)).lower()
                item.setHidden(not match)

    def procesar_datos(self, data):
        if not data: return
        self.lista.clear(); vistos = set(); filtro_tecnico = ['catastro', 'gov.co', 'arcgis', 'visor', 'mapa', 'nomenclatura', 'vial', 'acueducto', 'igac', 'predial', 'pot']
        
        for item in data:
            url = item['u']
            if "google.com/url?" in url:
                try: url = parse_qs(urlparse(url).query).get('q', [url])[0]
                except: continue
            
            if any(f in url.lower() or f in item['t'].lower() for f in filtro_tecnico):
                if url not in vistos and "google.com" not in url.lower() and len(item['t']) > 8:
                    tipo = "🌐 PORTAL"; color = "#5dade2"
                    if "/rest/services" in url.lower(): tipo = "⚙️ ARCGIS REST"; color = "#9b59b6"
                    elif "catastro" in url.lower() or "igac" in url.lower(): tipo = "🏛️ CATASTRO"; color = "#f39c12"
                    
                    html = f"<div style='padding:10px;'><b style='color:{color}; font-size:9pt;'>{tipo}</b><br><b style='color:white; font-size:11pt;'>{item['t'][:75]}</b><br><i style='color:#27ae60; font-size:8pt;'>{url[:110]}...</i></div>"
                    
                    li = QListWidgetItem(); self.lista.addItem(li)
                    container = QFrame()
                    lbl = QLabel(html); lbl.setWordWrap(True)
                    btn_copy = QPushButton("📋 COPIAR")
                    btn_copy.setFixedWidth(80); btn_copy.setStyleSheet("font-size:7pt; background:#333; color:white;")
                    btn_copy.clicked.connect(lambda checked, u=url: QApplication.clipboard().setText(u))
                    
                    card_layout = QVBoxLayout(container); card_layout.addWidget(lbl); card_layout.addWidget(btn_copy, 0, Qt.AlignRight)
                    li.setSizeHint(QSize(0, 110)); self.lista.setItemWidget(li, container); li.setData(Qt.UserRole, url); vistos.add(url)

    def abrir_externo(self, item):
        url = item.data(Qt.UserRole); webbrowser.open(url) if url else None