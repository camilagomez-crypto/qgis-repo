def classFactory(iface):
    from .main import BuscadorVisoresPlugin
    return BuscadorVisoresPlugin(iface)