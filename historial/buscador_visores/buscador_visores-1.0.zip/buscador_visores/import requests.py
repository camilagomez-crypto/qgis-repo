import requests
import json
import time
import random
import os

# --- TUS CREDENCIALES REALES (Extraídas de tu mensaje) ---
MI_COOKIE = "_web_visitorid=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ3ZWJTZXNzaW9uIjoiYjFWb1pVNXBXVWQ0YmxKd2QzY3hOM3BaUlVOWGJ6VmlPR0UyYVN0NFlYRmtNelJQUVNzdmQxbDNiR0ZCVVc5M1NEWkJUM0JaWWxOVWFsaDNXakJPTlZwTmRVdEdla3RHWVZGclJFdHZkbUl3ZWt3eVNscDBiRkpYYUZCb2IxUXlkR2RMZVVoT1dUQnhWM005TFMxdGRubDZMM1lyWm10c1ZYRkhiVlJVYTFSVEwzTkJQVDA9LS04ODIzM2NlNWRhMThjYzBkODZkMzlmYTU0NGUzMzE1OTc0MDAxZTNkIiwidXVpZCI6ImE2YmY3ODI2LWE2NzctNDM1NC1hODIyLTY2OTIzYmRmMmU0ZCIsImlhdCI6MTczOTg5NzgyM30.W352goc9xaGalFNvHcn2heTrW0BjJtsyDPijlCWWSnI; _ga_T2C59N2WYS=GS2.2.s1761922387$o180$g1$t1761926787$j57$l0$h0; _ga=GA1.1.525086241.1739897822; _ga_NNCFE4W9M4=GS2.1.s1770902985$o222$g0$t1770902989$j56$l0$h0; _ga_2848KND9CX=GS2.1.s1770902985$o6$g0$t1770902989$j56$l0$h0; _ga_1Z3SDDD5BS=GS2.1.s1772566314$o33$g1$t1772566640$j60$l0$h0; _web_session=TnIwSk5oK2lUUkhCL0hTTkdQWlpDUFFjODBXMWZYZW84a3BHc2pVTkJkTlRsdjFxZnEyQXZodmxmbExWQStMSlBXLzh6NE10ZzIybDJVTlBnNm1rb0hXZFdSWTZFUUZrblVmWjRRTHphSWdGN241elQ5WUszTUh0NTZ3a3ptVjItLS9iWnJRZ29IekhYcnZ3aGNxSFdBVWc9PQ%3D%3D--8f43ccf506c3f6b0b40b6e86cfffb41c3c15c04b; _csrf_token=9YGzc6OpwYzOP8knTPUDVnPVuSddZJ3ISN4N7tISqaI"
MI_CSRF = "9YGzc6OpwYzOP8knTPUDVnPVuSddZJ3ISN4N7tISqaI"
MI_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0"

# --- CONFIGURACIÓN DE ZONA (Bogotá Norte - Basado en tu URL) ---
# Formato: [Longitud Min, Latitud Min, Longitud Max, Latitud Max]
BBOX_GRANDE = [-74.1500, 4.6500, -74.0400, 4.7500] 

STEP = 0.015  # Tamaño de cada cuadro
OVERLAP = 0.30 # Traslape del 30%
EFFECTIVE_STEP = STEP * (1 - OVERLAP)

OUTPUT_DIR = "descargas_waze_masivas"
if not os.path.exists(OUTPUT_DIR): os.makedirs(OUTPUT_DIR)

HEADERS = {
    "user-agent": MI_USER_AGENT,
    "cookie": MI_COOKIE,
    "x-csrf-token": MI_CSRF,
    "referer": "https://www.waze.com/es-419/editor",
    "accept": "*/*",
    "accept-language": "es-419,es;q=0.9"
}

def ejecutar_robot():
    lon_min, lat_min, lon_max, lat_max = BBOX_GRANDE
    curr_lat = lat_min
    
    print(f"🤖 Robot iniciado. Guardando en carpeta: {OUTPUT_DIR}")

    while curr_lat < lat_max:
        curr_lon = lon_min
        while curr_lon < lon_max:
            # Definir la ventana de captura
            l1, t1 = round(curr_lon, 6), round(curr_lat, 6)
            l2, t2 = round(l1 + STEP, 6), round(t1 + STEP, 6)
            
            url = f"https://www.waze.com/row-Descartes/app/Features?bbox={l1}%2C{t1}%2C{l2}%2C{t2}&language=es-419&v=2&sandbox=true"
            
            try:
                # Realizar la petición
                res = requests.get(url, headers=HEADERS, timeout=20)
                
                if res.status_code == 200:
                    data = res.json()
                    # Contar objetos para saber si hay datos
                    objs = data.get('users', {}).get('objects', [])
                    
                    filename = f"bbox_{l1}_{t1}.json".replace("-", "m").replace(".", "_")
                    with open(os.path.join(OUTPUT_DIR, filename), 'w', encoding='utf-8') as f:
                        json.dump(data, f)
                    
                    kb = len(res.content) // 1024
                    print(f"✅ CAPTURADO: {l1}, {t1} | Tamaño: {kb} KB | Sitios: {len(objs)}")
                
                elif res.status_code == 403:
                    print("❌ ERROR 403: La sesión expiró. Debes sacar una nueva Cookie y CSRF de Waze.")
                    return
                else:
                    print(f"⚠️ Error {res.status_code} en zona {l1}, {t1}")

            except Exception as e:
                print(f"❌ Error crítico: {e}")

            # PAUSA ANTI-BOT (Importante para que no te bloqueen)
            espera = random.uniform(4, 7)
            time.sleep(espera)
            
            curr_lon += EFFECTIVE_STEP
        curr_lat += EFFECTIVE_STEP

    print("\n✨ BARRIDO COMPLETADO. Todos los JSON están en la carpeta.")

if __name__ == "__main__":
    ejecutar_robot()